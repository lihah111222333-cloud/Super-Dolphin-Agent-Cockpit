# AgentHost 技术栈说明

整理日期：2026-06-23

## 1. 定位

`agent-host` 是桌面应用里的本地 API 服务，是轻量 Go 单体进程，不是微服务平台，也不按高并发服务设计。

它对上服务 Electron，对内承载 Host API、AgentRuntime、CodexRuntimeAdapter、远程 API 代理、本地缓存和后台任务。

## 2. 确认技术栈

| 层 | 选型 | 说明 |
| --- | --- | --- |
| 服务形态 | Go 单体进程 | 由桌面应用启动和管理，不拆微服务。 |
| HTTP API | Gin | 提供本地 REST API 和中间件。 |
| 事件流 | SSE | 基于 Gin handler 输出事件流，不引入消息系统。 |
| ORM | GORM | 禁止在业务代码中散落手写 SQL。 |
| SQLite driver | `github.com/glebarez/sqlite` | 纯 Go、多平台友好，避免 CGO 依赖。 |
| 本地存储 | SQLite | 存任务、事件、缓存、同步状态和本地配置。 |
| 日志 | 标准库 `log/slog` | 不引入额外日志框架。 |
| 配置 | `config.yaml` | 保存端口、路径、远程 base URL、日志级别、DB 路径、worker 开关。 |
| YAML 解析 | `gopkg.in/yaml.v3` | 只做简单配置解析，不引入 Viper。 |
| 后台任务 | goroutine + `context.Context` + SQLite 状态表 | 用于 token refresh、缓存刷新、同步队列重试、日志上传。 |

## 3. 明确不使用

- 不使用 Redis。
- 不使用 Kafka。
- 不使用 PostgreSQL。
- 不引入独立队列系统。
- 不拆微服务。
- 不按高并发服务做复杂治理。
- 不使用 CGO SQLite driver 作为默认实现。
- 不在业务代码里到处写 raw SQL。

## 4. 依赖边界

```text
httpapi / hostapi
  -> agentruntime
  -> codexruntime
  -> codexapp-go
```

```text
httpapi / hostapi
  -> remote
  -> AgentCloud / remote APIs
```

```text
worker
  -> store / remote / agentruntime
```

禁止依赖：

- Host API 不直接调用 `codexapp-go`。
- AgentRuntime 不依赖 `codexapp-go`。
- 只有 CodexRuntimeAdapter 可以依赖 `codexapp-go`。
- Store 不反向依赖 HTTP 层。
- Remote client 不反向依赖 HTTP 层。

## 5. SQLite 约定

默认启用：

```text
foreign_keys = ON
journal_mode = WAL
busy_timeout = 5000
```

SQLite 用于本地状态和轻量缓存，不作为分布式协调系统。表、字段、索引、外键和 GORM model 边界见 `database-design.md`。

本地空库创建使用 `../../../scripts/sqlite/create-database.sql`。从仓库根目录执行：

```bash
mkdir -p ./agent-host/.local
sqlite3 ./agent-host/.local/agent-host.db < ./agent-host/scripts/sqlite/create-database.sql
```

## 6. 后续升级触发条件

| 当前保持轻量 | 只有出现以下情况才升级 |
| --- | --- |
| GORM | 查询复杂到难以维护，再评估 `gorm/gen` 或类型安全查询生成。 |
| 进程内 worker | 需要跨进程可靠调度或多实例协调，再讨论队列系统。 |
| SQLite | 单机本地存储无法满足桌面端需求，再讨论其他数据库。 |
| slog | 结构化日志能力不足或性能瓶颈明确，再讨论第三方日志库。 |
