# AgentHost 技术架构说明书

整理日期：2026-06-23

| 项目 | 内容 |
| --- | --- |
| 文档名称 | AgentHost 技术架构说明书 |
| 所属项目 | `agent-host` |
| 文档类型 | 技术架构总说明 |
| 当前状态 | 架构入口稿 |
| 详细域文档 | `agent-runtime-technical-architecture.md`、`agent-runtime-adapter-technical-architecture.md` |

## 1. 总体架构定位

`agent-host` 是唯一的本地项目主体。Host API、AgentRuntime、AgentRuntimeAdapter 是同一项目内的需求域，不是并列项目。

```text
Electron
  -> Host API
  -> AgentRuntime
  -> CodexRuntimeAdapter
  -> codexapp-go
  -> Codex app-server
```

远程业务数据链路：

```text
Electron
  -> Host API
  -> Remote API Client
  -> AgentCloud / remote APIs
```

## 2. 内部需求域

| 需求域 | 技术职责 | 依赖约束 |
| --- | --- | --- |
| Host API | HTTP REST/SSE、鉴权、投影、远程代理、SQLite 本地状态。 | 只能通过 AgentRuntime 触达 runtime。 |
| AgentRuntime | thread、turn、event、pending request、capability、error 的统一模型。 | 不依赖具体后端 SDK。 |
| AgentRuntimeAdapter | 把具体后端 SDK/protocol 映射到 AgentRuntime。 | CodexRuntimeAdapter 才能依赖 `codexapp-go`。 |

## 3. 技术栈

AgentHost 使用轻量 Go 单体技术栈：Gin、SSE、GORM、`github.com/glebarez/sqlite`、SQLite、`log/slog`、`config.yaml`、进程内 worker。

详细说明见 `technology-stack.md`。

数据库表、字段、索引、约束和 GORM model 边界见 `database-design.md`。

## 4. 禁止依赖

- Host API 不直接调用 `codexapp-go`。
- Host API 不引用 Codex app-server protocol 类型。
- AgentRuntime 不依赖 `codexapp-go` 或具体 runtime SDK。
- CodexRuntimeAdapter 不定义 REST/SSE API。
- `codexapp-go` 不吸收 AgentHost 产品语义。
- 不引入 Redis、Kafka、PostgreSQL、独立队列系统或微服务拆分。

## 5. 详细架构入口

- 技术栈说明：`technology-stack.md`
- 数据库设计：`database-design.md`
- AgentRuntime 详细架构：`agent-runtime-technical-architecture.md`
- AgentRuntimeAdapter 详细架构：`agent-runtime-adapter-technical-architecture.md`
- AgentHost 产品边界：`../product/agent-host-product-spec.md`
