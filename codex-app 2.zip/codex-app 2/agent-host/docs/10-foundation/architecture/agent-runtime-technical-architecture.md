# AgentRuntime 技术架构说明书

| 项目 | 内容 |
| --- | --- |
| 文档名称 | AgentRuntime 技术架构说明书 |
| 所属产品 | AgentHost |
| 文档类型 | 技术架构说明书 |
| 文档版本 | v0.1 |
| 日期 | 2026-06-22 |
| 当前状态 | 技术架构定义稿 |
| 目标模块 | AgentRuntime |
| 产品形态 | AgentHost 内部 runtime 抽象能力 |
| 主要使用方 | AgentHost HTTP API、事件投影、状态聚合、审批处理模块 |
| 首版实现 | CodexRuntime Adapter |
| 首版底层 SDK | `codexapp-go` |
| 参考文档 | `../product/agent-runtime-product-spec.md`、`../../../../codexapp-go/docs/10-foundation/architecture/technical-architecture.md`、`../../../../codexapp-go/docs/10-foundation/product/codexapp-go-product-spec.md` |

## 1. 架构总述

`AgentRuntime` 是 AgentHost 内部的 runtime 能力抽象层。它定义 AgentHost 如何创建 thread、启动 turn、取消 turn、订阅事件、处理 pending request、查询 runtime 健康状态和能力。

`AgentRuntime` 不是独立进程，不暴露 HTTP API，不直接面向 Electron，不封装具体 agent 后端协议。具体后端由 runtime adapter 实现。首版只实现 `CodexRuntime Adapter`，并通过 `codexapp-go` 接入 Codex app-server。

总体关系：

```mermaid
flowchart TB
  Electron["Electron 桌面客户端"]
  AgentHost["AgentHost"]
  HostAPI["HTTP REST / SSE"]
  Projection["状态投影 / 事件投影"]
  Runtime["AgentRuntime"]
  CodexAdapter["CodexRuntime Adapter"]
  CodexSDK["codexapp-go"]
  CodexServer["Codex app-server"]
  OtherAdapter["OtherAgentRuntime Adapter"]
  OtherSDK["OtherAgent SDK"]

  Electron --> HostAPI
  HostAPI --> Runtime
  Runtime --> Projection
  Projection --> HostAPI
  Runtime --> CodexAdapter
  CodexAdapter --> CodexSDK
  CodexSDK --> CodexServer
  Runtime -. "未来" .-> OtherAdapter
  OtherAdapter -.-> OtherSDK
```

首版实现应保持简单：

```text
AgentHost
  AgentRuntime
    CodexRuntime Adapter
      codexapp-go
        Codex app-server
```

## 2. 架构目标

### 2.1 核心目标

- 给 AgentHost 提供稳定 runtime port。
- 隔离 AgentHost HTTP/SSE 模型与 Codex app-server JSON-RPC。
- 支持首版 Codex app-server runtime。
- 支持未来用薄 SDK + adapter 接入非 Codex agent 后端。
- 统一 thread、turn、event、pending request、capability、error 模型。
- 保留 raw 信息用于诊断和协议兼容。
- 让 `codexapp-go` 保持底层协议 SDK，不吸收 AgentHost 产品语义。

### 2.2 非目标

- 不做独立 runtime 服务。
- 不做动态插件加载。
- 不做 runtime marketplace。
- 不做远程 worker 调度。
- 不做跨 runtime thread 迁移。
- 不在首版支持多个 runtime 同时运行。
- 不复制 Codex app-server 完整协议。
- 不让 Electron 直接调用 AgentRuntime。
- 不让 AgentRuntime 负责 HTTP 路由、SSE 序列化或 UI 状态展示。

## 3. 架构原则

| 原则 | 说明 |
| --- | --- |
| 小接口 | AgentRuntime 只放 AgentHost 真正需要的能力。 |
| Adapter 翻译 | 具体后端差异由 adapter 消化，不污染 AgentHost 上层。 |
| SDK 保薄 | 底层 SDK 只封装后端协议和基础通信。 |
| Capability 优先 | 可选能力通过 capability 表达，不为每个差异增加核心方法。 |
| Raw 保留 | 统一模型外保留 raw，便于诊断和兼容。 |
| 不阻塞 reader | 事件消费慢不能阻塞底层 runtime 读取。 |
| 首版硬编码 | 首版只硬编码 CodexRuntime，第二个 runtime 出现后再抽 registry。 |

## 4. 系统边界

### 4.1 上下游边界

| 边界 | 输入 | 输出 | AgentRuntime 责任 |
| --- | --- | --- | --- |
| AgentHost HTTP API -> AgentRuntime | 创建 thread、启动 turn、取消 turn、响应 request | ref、error | 校验内部请求语义，调用 adapter。 |
| AgentRuntime -> Adapter | runtime command、subscribe request、response | runtime result、event stream、pending request | 定义接口和统一模型。 |
| Adapter -> SDK | 后端 SDK 方法调用 | 后端原生 response、event、error | 不由 AgentRuntime 负责。 |
| Adapter -> AgentRuntime | 后端事件翻译结果 | `RuntimeEvent`、`PendingRequest`、`RuntimeError` | 接收统一模型并交给 AgentHost 投影。 |
| AgentRuntime -> AgentHost Projection | 统一事件、状态、错误 | HTTP/SSE 投影输入 | 不序列化 SSE，不决定 UI 文案。 |

### 4.2 职责边界

| 能力 | AgentRuntime | Runtime Adapter | 底层 SDK | AgentHost 上层 |
| --- | --- | --- | --- | --- |
| thread/turn 抽象 | 负责定义 | 负责实现映射 | 不负责 | 使用 |
| 后端协议通信 | 不负责 | 不重复实现 | 负责 | 不负责 |
| 事件统一模型 | 负责定义 | 负责翻译 | 提供原始事件 | 投影为 SSE |
| pending request 模型 | 负责定义 | 负责翻译和回复 | 提供底层 request/response 机制 | 保存、审批、展示 |
| capability | 负责定义 | 负责声明 | 可提供原始能力 | 控制 API 和 UI |
| 错误归一 | 负责定义 | 负责转换 | 提供底层错误 | 展示、日志、重试策略 |
| HTTP REST | 不负责 | 不负责 | 不负责 | 负责 |
| SSE | 不负责 | 不负责 | 不负责 | 负责 |
| 持久化 | 不负责 | 不负责 | 不负责 | 负责 |

## 5. 总体技术架构

```mermaid
flowchart LR
  subgraph AgentHost["AgentHost"]
    API["HTTP API"]
    SSE["SSE Event Stream"]
    Projection["Projection Store"]
    PendingStore["Pending Request Store"]
    Runtime["AgentRuntime"]
    EventMux["Runtime Event Mux"]
    ErrorMapper["Runtime Error Mapper"]
    CodexAdapter["CodexRuntime Adapter"]
  end

  subgraph CodexSDK["codexapp-go"]
    SDKFacade["Thin Facades"]
    SDKClient["Client Core"]
    SDKEvents["Event Bus"]
    SDKPending["Server Requests"]
    SDKTransport["Transport"]
  end

  AppServer["Codex app-server"]

  API --> Runtime
  Runtime --> CodexAdapter
  CodexAdapter --> SDKFacade
  SDKFacade --> SDKClient
  SDKClient --> SDKTransport
  SDKTransport --> AppServer
  AppServer --> SDKTransport
  SDKTransport --> SDKEvents
  SDKTransport --> SDKPending
  SDKEvents --> CodexAdapter
  SDKPending --> CodexAdapter
  CodexAdapter --> EventMux
  EventMux --> Projection
  EventMux --> SSE
  CodexAdapter --> PendingStore
  PendingStore --> API
  Runtime --> ErrorMapper
```

### 5.1 运行时调用方向

- 写路径：`HTTP API -> AgentRuntime -> Adapter -> SDK -> Backend`。
- 读路径：`Backend -> SDK -> Adapter -> RuntimeEvent -> Projection/SSE`。
- pending request 路径：`Backend -> SDK -> Adapter -> PendingStore -> HTTP/SSE -> User -> HTTP -> AgentRuntime -> Adapter -> SDK -> Backend`。

## 6. 模块划分

建议首版只保留以下模块。文件名可按 Go 项目习惯微调。

```text
agent-host/
  internal/
    agentruntime/
      runtime.go
      model.go
      errors.go
      events.go
      pending.go
    codexruntime/
      adapter.go
      mapper.go
      events.go
      pending.go
```

### 6.1 `internal/agentruntime`

定义稳定抽象和统一模型。

| 文件 | 职责 |
| --- | --- |
| `runtime.go` | `AgentRuntime` 接口和核心 request/response 类型。 |
| `model.go` | `RuntimeInfo`、`ThreadRef`、`TurnRef`、capability 等模型。 |
| `events.go` | `RuntimeEvent`、event type、event payload。 |
| `pending.go` | `PendingRequest`、`RuntimeResponse`。 |
| `errors.go` | `RuntimeError`、错误 code、错误分类。 |

### 6.2 `internal/codexruntime`

实现 Codex app-server adapter。

| 文件 | 职责 |
| --- | --- |
| `adapter.go` | 实现 `AgentRuntime`，组合 `codexapp-go` client。 |
| `mapper.go` | Codex params/result 与 AgentRuntime model 的转换。 |
| `events.go` | Codex notification -> `RuntimeEvent`。 |
| `pending.go` | Codex server request -> `PendingRequest`，response -> Codex reply。 |

首版不需要 `registry.go`。

```go
// ponytail: hardcode CodexRuntime first; add a registry when a second runtime ships.
runtime := codexruntime.New(client)
```

## 7. 核心接口设计

### 7.1 AgentRuntime 接口

```go
type AgentRuntime interface {
    Info(ctx context.Context) (RuntimeInfo, error)
    StartThread(ctx context.Context, req StartThreadRequest) (ThreadRef, error)
    StartTurn(ctx context.Context, req StartTurnRequest) (TurnRef, error)
    CancelTurn(ctx context.Context, req CancelTurnRequest) error
    Events(ctx context.Context, req EventSubscribeRequest) (<-chan RuntimeEvent, error)
    Respond(ctx context.Context, req RuntimeResponse) error
}
```

接口保持一个，不按能力拆小接口。能力差异由 `RuntimeInfo.Capabilities` 表达。

### 7.2 RuntimeInfo

```go
type RuntimeInfo struct {
    RuntimeID    string
    Kind         RuntimeKind
    DisplayName  string
    Version      string
    Health       RuntimeHealth
    Capabilities []RuntimeCapability
    Raw          any
}
```

### 7.3 ThreadRef

```go
type ThreadRef struct {
    ThreadID  string
    RuntimeID string
    Status    ThreadStatus
    Raw       any
}
```

### 7.4 TurnRef

```go
type TurnRef struct {
    TurnID    string
    ThreadID  string
    RuntimeID string
    Status    TurnStatus
    Raw       any
}
```

### 7.5 EventSubscribeRequest

```go
type EventSubscribeRequest struct {
    ThreadID string
    TurnID   string
    SinceID  string
}
```

`SinceID` 是可选游标。首版 CodexRuntime 如果底层不支持回放，可以返回 `capability_unsupported` 或只从当前时刻订阅。

### 7.6 RuntimeResponse

```go
type RuntimeResponse struct {
    RequestID string
    Decision  ResponseDecision
    Payload   any
}
```

`Payload` 由 pending request type 决定，adapter 负责校验并翻译到底层 SDK。

## 8. 核心数据模型

### 8.1 RuntimeKind

| 值 | 说明 |
| --- | --- |
| `codex` | Codex app-server runtime。 |
| `other_agent` | 未来其他 agent runtime。 |

### 8.2 RuntimeHealth

| 状态 | 说明 |
| --- | --- |
| `uninitialized` | 尚未初始化。 |
| `connecting` | 正在连接或握手。 |
| `ready` | 可正常使用。 |
| `degraded` | 部分能力不可用。 |
| `unavailable` | 不可用。 |

### 8.3 ThreadStatus

| 状态 | 说明 |
| --- | --- |
| `active` | 有可交互会话。 |
| `idle` | 当前无运行 turn。 |
| `archived` | 已归档。 |
| `unavailable` | 底层状态不可确认。 |

### 8.4 TurnStatus

| 状态 | 说明 |
| --- | --- |
| `queued` | 已提交，尚未运行。 |
| `running` | 正在运行。 |
| `waiting` | 等待审批或输入。 |
| `completed` | 成功结束。 |
| `failed` | 失败结束。 |
| `cancelled` | 已取消。 |

### 8.5 RuntimeCapability

基础 capability：

```text
thread.start
thread.resume
turn.start
turn.cancel
event.stream
event.replay
approval.command
approval.file_change
approval.permission
input.user
tool.call
model.select
workspace.fs
```

Capability 判断规则：

- API 调用前可用 capability 做快速拒绝。
- Adapter 仍必须在执行时校验。
- 不支持能力返回 `capability_unsupported`。
- 不因为某 runtime 不支持某能力而扩展核心接口。

## 9. 事件架构

### 9.1 RuntimeEvent

```go
type RuntimeEvent struct {
    EventID   string
    RuntimeID string
    ThreadID  string
    TurnID    string
    Type      RuntimeEventType
    Time      time.Time
    Sequence  int64
    Payload   any
    Raw       any
}
```

字段规则：

| 字段 | 规则 |
| --- | --- |
| `EventID` | 必须稳定。底层无 id 时由 adapter 生成。 |
| `RuntimeID` | 必填。 |
| `ThreadID` | thread 相关事件必填。 |
| `TurnID` | turn 相关事件必填。 |
| `Type` | 使用统一事件类型。 |
| `Sequence` | 同一 stream 内递增；无法保证时填 0。 |
| `Payload` | AgentRuntime typed payload。 |
| `Raw` | 底层事件摘要，仅诊断使用。 |

### 9.2 事件类型

| 类型 | payload |
| --- | --- |
| `thread.created` | `ThreadPayload` |
| `thread.updated` | `ThreadPayload` |
| `turn.started` | `TurnPayload` |
| `turn.delta` | `DeltaPayload` |
| `turn.message` | `MessagePayload` |
| `turn.tool_call.started` | `ToolCallPayload` |
| `turn.tool_call.updated` | `ToolCallPayload` |
| `turn.tool_call.finished` | `ToolCallPayload` |
| `turn.command.started` | `CommandPayload` |
| `turn.command.output` | `CommandOutputPayload` |
| `turn.command.finished` | `CommandPayload` |
| `turn.file_change` | `FileChangePayload` |
| `turn.waiting_for_input` | `PendingRequestPayload` |
| `turn.completed` | `TurnPayload` |
| `turn.failed` | `ErrorPayload` |
| `turn.cancelled` | `TurnPayload` |
| `runtime.health_changed` | `RuntimeInfo` |

### 9.3 事件流规则

- Adapter 不得在底层 SDK reader goroutine 中执行慢逻辑。
- Adapter 应把底层事件快速转换后写入有限缓冲。
- 缓冲满时按事件类型处理：delta 可合并，状态事件不可丢。
- AgentHost Projection 负责 SSE 游标、断线重连和 UI 状态聚合。
- AgentRuntime 不负责 SSE event name 和 JSON 格式。

### 9.4 Event Mux

Event Mux 是 AgentHost 内部组件，用于把 runtime event 分发到 Projection、PendingStore 和 SSE。

```mermaid
flowchart LR
  Adapter["Runtime Adapter"]
  Mux["Runtime Event Mux"]
  Projection["Projection Store"]
  Pending["Pending Store"]
  SSE["SSE Stream"]
  Log["Diagnostic Log"]

  Adapter --> Mux
  Mux --> Projection
  Mux --> Pending
  Mux --> SSE
  Mux --> Log
```

首版可以是一个 goroutine + channel，不需要通用 pub/sub 框架。

## 10. PendingRequest 架构

### 10.1 PendingRequest

```go
type PendingRequest struct {
    RequestID      string
    RuntimeID      string
    ThreadID       string
    TurnID         string
    Type           PendingRequestType
    Title          string
    Summary        string
    Payload        any
    Raw            any
    IdempotencyKey string
    CreatedAt      time.Time
    ExpiresAt      *time.Time
}
```

### 10.2 类型

| 类型 | 说明 |
| --- | --- |
| `approval.command` | 命令执行审批。 |
| `approval.file_change` | 文件变更审批。 |
| `approval.permission` | 权限审批。 |
| `input.user` | 用户输入。 |
| `tool.dynamic_call` | 动态工具调用。 |
| `auth.refresh` | token 刷新。 |

### 10.3 状态机

```mermaid
stateDiagram-v2
  [*] --> Pending
  Pending --> Approved
  Pending --> Denied
  Pending --> Answered
  Pending --> Cancelled
  Pending --> Expired
  Pending --> Failed
```

### 10.4 响应规则

- `RequestID` 必须存在于 PendingStore。
- 每个 request 只能完成一次。
- 重复响应同一个 `IdempotencyKey` 可以返回已完成结果。
- 不同响应重复提交必须返回 conflict。
- Adapter 负责把 `RuntimeResponse` 翻译到底层 SDK response。
- AgentHost 负责 pending 状态持久化和恢复。

## 11. 错误架构

### 11.1 RuntimeError

```go
type RuntimeError struct {
    Code        RuntimeErrorCode
    Message     string
    UserMessage string
    Retryable   bool
    RuntimeID   string
    ThreadID    string
    TurnID      string
    Cause       error
    Raw         any
}
```

### 11.2 错误 code

| code | HTTP 映射 | 说明 |
| --- | --- | --- |
| `runtime_unavailable` | 503 | runtime 不可用。 |
| `capability_unsupported` | 400 | runtime 不支持该能力。 |
| `invalid_request` | 400 | AgentHost 内部请求无效。 |
| `permission_denied` | 403 | 权限或审批拒绝。 |
| `turn_failed` | 500 | turn 执行失败。 |
| `transport_error` | 502 | 底层连接错误。 |
| `protocol_error` | 502 | 底层协议错误。 |
| `internal_error` | 500 | adapter 或 AgentHost 内部错误。 |

HTTP 映射由 AgentHost API 层执行，AgentRuntime 只返回错误 code。

### 11.3 错误转换

CodexRuntime Adapter 转换规则：

| 来源 | 转换 |
| --- | --- |
| `codexapp-go` transport error | `transport_error` |
| JSON-RPC method error | `protocol_error` 或具体业务错误 |
| Codex approval denied | `permission_denied` |
| Codex turn failed event | `turn_failed` |
| context canceled | 调用方取消，不包装为 runtime failure |
| context deadline exceeded | `runtime_unavailable` 或 `transport_error`，按阶段判断 |

## 12. 生命周期架构

### 12.1 Runtime 生命周期

```mermaid
stateDiagram-v2
  [*] --> Uninitialized
  Uninitialized --> Connecting
  Connecting --> Ready
  Connecting --> Unavailable
  Ready --> Degraded
  Ready --> Unavailable
  Degraded --> Ready
  Degraded --> Unavailable
  Unavailable --> Connecting
```

转换来源：

| 转换 | 触发 |
| --- | --- |
| `uninitialized -> connecting` | AgentHost 启动 runtime 初始化。 |
| `connecting -> ready` | Adapter 初始化成功。 |
| `connecting -> unavailable` | 连接或握手失败。 |
| `ready -> degraded` | 部分 capability 失败。 |
| `ready -> unavailable` | transport 断开。 |
| `unavailable -> connecting` | AgentHost 重试连接。 |

### 12.2 Thread 生命周期

Thread 生命周期由底层 runtime 和 AgentHost 投影共同决定。AgentRuntime 只输出事件和 ref。

```mermaid
stateDiagram-v2
  [*] --> Active
  Active --> Idle
  Idle --> Active
  Idle --> Archived
  Active --> Unavailable
  Idle --> Unavailable
```

### 12.3 Turn 生命周期

```mermaid
stateDiagram-v2
  [*] --> Queued
  Queued --> Running
  Running --> Waiting
  Waiting --> Running
  Running --> Completed
  Running --> Failed
  Running --> Cancelled
  Waiting --> Cancelled
```

Adapter 必须把底层 run/job/turn 状态映射到这组状态。

## 13. 并发与背压

### 13.1 Goroutine 边界

建议首版边界：

```text
codexapp-go reader goroutine
  -> codexapp-go event channel
    -> CodexRuntime Adapter mapper goroutine
      -> AgentRuntime event channel
        -> AgentHost Event Mux
```

### 13.2 背压策略

| 数据类型 | 策略 |
| --- | --- |
| 状态事件 | 不丢弃，必要时阻塞 adapter 输出。 |
| pending request | 不丢弃，写入 PendingStore。 |
| delta 事件 | 可合并。 |
| command output | 可按 chunk 合并。 |
| diagnostic raw dump | 可采样或关闭。 |

### 13.3 关闭规则

- `ctx.Done()` 后停止新的 runtime 调用。
- event channel 关闭必须可被消费者识别。
- Adapter shutdown 必须先停止订阅，再关闭输出 channel。
- PendingRequest 不因 Electron 断线自动取消。
- AgentHost 进程退出时由上层决定是否取消运行中 turn。

## 14. CodexRuntime Adapter 架构

### 14.1 依赖方向

```text
codexruntime -> agentruntime
codexruntime -> codexapp-go
agentruntime -> no codexapp-go dependency
```

`agentruntime` 包不得 import `codexapp-go`。

### 14.2 Adapter 结构

```go
type Adapter struct {
    runtimeID string
    client    *codexapp.Client
    events    chan agentruntime.RuntimeEvent
}
```

首版字段够用即可。不要提前加 registry、plugin metadata、dynamic loader。

### 14.3 方法映射

| AgentRuntime 方法 | CodexRuntime Adapter 实现 |
| --- | --- |
| `Info` | 读取 initialize 结果、版本、静态 capabilities。 |
| `StartThread` | 调用 `codexapp-go` thread facade。 |
| `StartTurn` | 调用 `codexapp-go` turn facade。 |
| `CancelTurn` | 调用 `codexapp-go` cancel/interrupt 能力。 |
| `Events` | 返回 adapter 统一事件 channel。 |
| `Respond` | 查找 pending request 并调用 `codexapp-go` response 机制。 |

### 14.4 事件映射

| Codex 事件类别 | RuntimeEvent |
| --- | --- |
| thread notification | `thread.created` / `thread.updated` |
| turn started | `turn.started` |
| assistant/user item | `turn.message` |
| delta / reasoning | `turn.delta` |
| command execution | `turn.command.*` |
| file change | `turn.file_change` |
| tool / MCP call | `turn.tool_call.*` |
| server request | `turn.waiting_for_input` + `PendingRequest` |
| turn completed | `turn.completed` |
| error | `turn.failed` 或 runtime error |

### 14.5 不允许

- 不手写 JSON-RPC transport。
- 不复制 `codexapp-go` generated types。
- 不让 HTTP handler import Codex protocol 类型。
- 不自动 approve request。
- 不把 Codex 专属字段放入 AgentRuntime 核心字段。

## 15. OtherAgent 接入架构

未来接入 OtherAgent 时，新增：

```text
internal/otheragentruntime/
  adapter.go
  mapper.go
  events.go
  pending.go
```

接入规则：

- OtherAgent SDK 只封装对方后端基础 API。
- OtherAgentRuntime Adapter 实现 `AgentRuntime`。
- session/run/job 等概念映射为 thread/turn。
- 后端事件映射为 `RuntimeEvent`。
- 后端交互请求映射为 `PendingRequest`。
- 不修改 Electron API。
- 不修改 `codexapp-go`。
- 不把 OtherAgent 专属字段塞进 AgentRuntime 核心模型。

新增第二个 runtime 后，再考虑：

```go
type RuntimeFactory func(Config) (AgentRuntime, error)
```

首版不需要。

## 16. 配置架构

首版配置由 AgentHost 管理，AgentRuntime 只接收已校验配置。

| 配置 | 所属层 | 说明 |
| --- | --- | --- |
| runtime kind | AgentHost | 首版固定 `codex`。 |
| app-server command/path | AgentHost | 启动链路配置，不属于 AgentRuntime。 |
| workspace path | AgentHost | 必须校验。 |
| model | AgentHost/API | 传给 Runtime，adapter 校验 capability。 |
| permission profile | AgentHost | 转换为 runtime 参数。 |
| event buffer size | AgentHost/Adapter | 首版常量即可。 |

## 17. 安全架构

### 17.1 Trust boundary

| 输入来源 | 校验位置 |
| --- | --- |
| Electron HTTP request | AgentHost API |
| workspace path | AgentHost API |
| runtime event | Adapter mapper |
| pending response | AgentHost API + Adapter |
| raw payload | 仅诊断，默认不展示 |

### 17.2 必须校验

- `WorkspacePath` 必须是允许访问的本地路径。
- `ThreadID`、`TurnID`、`RequestID` 必须存在并属于当前 runtime。
- `RuntimeResponse.Decision` 必须匹配 pending request type。
- `Payload` 必须按 request type 校验。
- 日志和 raw dump 必须脱敏。

## 18. 可观测性架构

### 18.1 指标

| 指标 | 说明 |
| --- | --- |
| `runtime_health` | 当前 runtime 健康状态。 |
| `runtime_events_total` | runtime event 数量。 |
| `runtime_errors_total` | runtime error 数量。 |
| `pending_requests_total` | pending request 创建数。 |
| `pending_requests_open` | 当前未完成 pending request 数。 |
| `turns_started_total` | turn 启动数。 |
| `turns_failed_total` | turn 失败数。 |

### 18.2 日志

日志字段：

| 字段 | 说明 |
| --- | --- |
| `runtime_id` | runtime id。 |
| `runtime_kind` | runtime kind。 |
| `thread_id` | 可选 thread id。 |
| `turn_id` | 可选 turn id。 |
| `event_id` | 可选 event id。 |
| `request_id` | 可选 pending request id。 |
| `error_code` | 可选错误码。 |

AgentRuntime 不决定日志落盘位置。AgentHost 负责日志存储、脱敏和展示。

## 19. 测试架构

### 19.1 最小测试范围

| 测试 | 目的 |
| --- | --- |
| Adapter mapper 单测 | Codex event -> RuntimeEvent 映射不漂移。 |
| Pending response 单测 | request 只能响应一次。 |
| Capability 单测 | 不支持能力返回正确错误。 |
| Error mapper 单测 | 底层错误归一化正确。 |
| Codex contract check | 真实 app-server thread/turn/event 行为可用。 |

### 19.2 首版最小自检

首版至少留一个无框架自检或小测试：

```text
StartThread -> StartTurn -> receive turn.started -> receive terminal event
```

如果真实 Codex app-server 在 CI 不稳定，contract check 可以作为手动或 nightly。

## 20. 实施分期

### 20.1 M1: CodexRuntime 最小闭环

- 定义 `agentruntime` 包。
- 实现 `CodexRuntime Adapter`。
- 支持 `Info`、`StartThread`、`StartTurn`、`Events`。
- 映射基础 turn lifecycle 事件。

### 20.2 M2: PendingRequest

- 支持 command approval。
- 支持 file change approval。
- 支持 user input。
- 实现 `Respond`。
- AgentHost 保存 pending 状态。

### 20.3 M3: 错误与诊断

- 完成 RuntimeError。
- 完成 health/capability。
- 增加基础 counters 和日志字段。

### 20.4 M4: 第二 runtime 前的准备

- 梳理 Codex 专属字段泄漏。
- 保证 HTTP/SSE 不依赖 Codex protocol。
- 暂不实现 runtime registry，等第二 runtime 开始接入再加。

## 21. 验收标准

### 21.1 架构验收

- `agentruntime` 包不 import `codexapp-go`。
- `codexruntime` 包通过 `codexapp-go` 接入 Codex app-server。
- AgentHost HTTP handler 不引用 Codex protocol 类型。
- AgentHost SSE payload 不直接使用 Codex notification 类型。
- PendingRequest 由 AgentHost 保存，adapter 负责底层回复。
- Capability 能控制不支持能力的错误返回。

### 21.2 行为验收

- 可以查询 runtime info。
- 可以创建 thread。
- 可以启动 turn。
- 可以接收 runtime event。
- 可以取消 turn。
- 可以创建并响应 pending request。
- runtime 断开时返回 `runtime_unavailable` 或 `transport_error`。
- CodexRuntime Adapter 不自动批准任何 request。

### 21.3 扩展验收

- 接入 OtherAgent 时新增 SDK + adapter 即可。
- 不需要修改 `codexapp-go`。
- 不需要让 Electron 理解 OtherAgent 协议。
- 不需要把 OtherAgent 专属字段加入 AgentRuntime 核心模型。

## 22. 风险与对策

| 风险 | 影响 | 对策 |
| --- | --- | --- |
| AgentRuntime 抽象过大 | 首版实现慢，维护成本高 | 只保留 thread、turn、event、pending、capability、error。 |
| Codex 字段泄漏 | 未来接入其他 runtime 困难 | HTTP/SSE 和 Projection 只使用统一模型。 |
| Adapter 重复 SDK 能力 | JSON-RPC 逻辑重复 | CodexRuntime Adapter 必须依赖 `codexapp-go`。 |
| 事件阻塞 | 输出卡顿或 deadlock | reader、mapper、mux 分层，有限缓冲。 |
| pending request 丢失 | 审批无法恢复 | AgentHost 持久化 pending。 |
| 第二 runtime 过早抽象 | 出现无用 registry 和复杂配置 | 第二 runtime 真接入时再抽。 |

## 23. 最终架构结论

`AgentRuntime` 是 AgentHost 内部的 runtime port，负责定义统一 thread、turn、event、pending request、capability 和 error 模型。

`CodexRuntime Adapter` 是首个 adapter，实现 `AgentRuntime`，并通过 `codexapp-go` 调用 Codex app-server。

`codexapp-go` 是底层协议 SDK，只处理 Codex app-server JSON-RPC，不承载 AgentHost runtime 抽象。

首版架构应硬编码 CodexRuntime，不做 registry、插件系统或动态加载。等第二个真实 runtime 开始接入时，再增加最小 factory/registry。
