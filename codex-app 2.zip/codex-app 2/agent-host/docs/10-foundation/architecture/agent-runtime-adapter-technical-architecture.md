# AgentRuntimeAdapter 技术架构说明书

| 项目 | 内容 |
| --- | --- |
| 文档名称 | AgentRuntimeAdapter 技术架构说明书 |
| 所属产品 | AgentHost |
| 文档类型 | 技术架构说明书 |
| 文档版本 | v0.1 |
| 日期 | 2026-06-22 |
| 当前状态 | 技术架构定义稿 |
| 目标模块 | AgentRuntimeAdapter |
| 产品形态 | AgentHost 内部 runtime 适配实现单元 |
| 首版实现 | CodexRuntimeAdapter |
| 首版底层 SDK | `codexapp-go` |
| 主要使用方 | AgentRuntime、AgentHost runtime 接入模块 |
| 上游依赖 | 具体 agent 后端 SDK 或协议客户端 |
| 下游消费者 | AgentRuntime 统一模型、AgentHost 事件投影、PendingRequest 模块 |
| 参考文档 | `../product/agent-runtime-adapter-product-spec.md`、`../product/agent-runtime-product-spec.md`、`agent-runtime-technical-architecture.md`、`../../../../codexapp-go/docs/10-foundation/architecture/technical-architecture.md` |

## 1. 架构总述

`AgentRuntimeAdapter` 是 AgentHost 内部连接具体 agent 后端与 `AgentRuntime` 统一模型的适配实现单元。它不定义产品 API，不暴露 HTTP/SSE，不负责持久化，不实现底层协议通信。

每个具体后端应有一个独立 adapter。首版只实现 `CodexRuntimeAdapter`，它依赖 `codexapp-go` 调用 Codex app-server，并把 Codex thread、turn、notification、server request、error 映射为 AgentRuntime 的统一模型。

首版实现关系：

```mermaid
flowchart TB
  AgentHost["AgentHost"]
  Runtime["AgentRuntime interface"]
  Adapter["CodexRuntimeAdapter"]
  SDK["codexapp-go"]
  Backend["Codex app-server"]

  AgentHost --> Runtime
  Runtime --> Adapter
  Adapter --> SDK
  SDK --> Backend
  Backend --> SDK
  SDK --> Adapter
  Adapter --> Runtime
  Runtime --> AgentHost
```

未来接入其他后端时，只增加对应 SDK 和 adapter：

```text
OtherAgentRuntimeAdapter
  -> OtherAgent SDK
    -> OtherAgent backend
```

首版不需要单独定义 `AgentRuntimeAdapter` 接口。具体 adapter 直接实现 `AgentRuntime`。

## 2. 架构目标

### 2.1 核心目标

- 定义 adapter 在 AgentHost 内的技术边界。
- 支持 CodexRuntimeAdapter 通过 `codexapp-go` 接入 Codex app-server。
- 保证 `agentruntime` 包不依赖任何具体后端 SDK。
- 保证 AgentHost 上层不直接引用 Codex protocol 类型。
- 将后端 SDK result 映射为 `ThreadRef`、`TurnRef`、`RuntimeInfo`。
- 将后端 event/notification 映射为 `RuntimeEvent`。
- 将后端交互请求映射为 `PendingRequest`。
- 将 `RuntimeResponse` 映射回后端 request response。
- 将后端错误映射为 `RuntimeError`。
- 支持 future adapter 以同样结构接入其他后端。

### 2.2 非目标

- 不提供 HTTP API。
- 不提供 SSE 序列化。
- 不做 UI 状态投影。
- 不做本地数据库持久化。
- 不做 runtime registry。
- 不做动态 adapter 加载。
- 不做插件系统。
- 不重新实现底层 SDK 的 transport、request id、协议类型。
- 不自研 agent loop。
- 不在首版支持多个 adapter 同时运行。

## 3. 架构原则

| 原则 | 说明 |
| --- | --- |
| 直接实现 AgentRuntime | 首版不增加 `AgentRuntimeAdapter` 接口，避免一层空抽象。 |
| 一个后端一个包 | `codexruntime`、未来 `otheragentruntime` 各自独立。 |
| SDK 做协议 | 底层 SDK 负责协议、连接、类型、请求响应。 |
| Adapter 做映射 | Adapter 只负责模型、事件、请求、错误、capability 映射。 |
| 上层只看统一模型 | AgentHost HTTP/SSE/Projection 不引用后端 SDK 类型。 |
| Raw 只诊断 | Raw 可保留，但不作为上层业务判断依据。 |
| Capability 表达差异 | 不因后端差异扩大核心接口。 |

## 4. 系统边界

### 4.1 上下游边界

| 边界 | 输入 | 输出 | Adapter 责任 |
| --- | --- | --- | --- |
| AgentRuntime -> Adapter | `Info`、`StartThread`、`StartTurn`、`CancelTurn`、`Events`、`Respond` | ref、event channel、error | 实现统一接口，调用 SDK。 |
| Adapter -> SDK | SDK typed params、context | SDK typed result、SDK event、SDK error | 使用 SDK，不重复协议能力。 |
| SDK -> Adapter | notification、server request、error | mapped model | 转换为 AgentRuntime 模型。 |
| Adapter -> AgentRuntime | `RuntimeEvent`、`PendingRequest`、`RuntimeError` | 统一模型 | 不生成 HTTP/SSE payload。 |
| Adapter -> Diagnostics | adapter id、health、last error、raw summary | 诊断输入 | 不决定日志落盘位置。 |

### 4.2 职责边界

| 能力 | Adapter | AgentRuntime | 底层 SDK | AgentHost 上层 |
| --- | --- | --- | --- | --- |
| 统一接口 | 实现 | 定义 | 不负责 | 调用 |
| 后端连接 | 不直接实现 | 不负责 | 负责 | 配置生命周期 |
| 请求映射 | 负责 | 定义模型 | 接收后端 params | 发起调用 |
| 事件映射 | 负责 | 定义事件模型 | 提供后端事件 | 投影和展示 |
| pending request 映射 | 负责创建和回复 | 定义模型 | 提供 request/response 机制 | 保存和审批 |
| 错误映射 | 负责 | 定义错误模型 | 提供底层错误 | 展示和日志 |
| capability 声明 | 负责 | 定义 capability | 可提供原始能力 | 控制 API/UI |
| 持久化 | 不负责 | 不负责 | 不负责 | 负责 |

## 5. 总体技术架构

```mermaid
flowchart LR
  subgraph AgentHost["AgentHost"]
    Runtime["AgentRuntime"]
    EventMux["Runtime Event Mux"]
    PendingStore["Pending Store"]
    Projection["Projection Store"]
  end

  subgraph Adapter["CodexRuntimeAdapter"]
    AdapterCore["Adapter Core"]
    RequestMapper["Request Mapper"]
    ResultMapper["Result Mapper"]
    EventMapper["Event Mapper"]
    PendingMapper["Pending Mapper"]
    ResponseMapper["Response Mapper"]
    ErrorMapper["Error Mapper"]
    CapabilityMapper["Capability Mapper"]
    EventPump["Event Pump"]
  end

  subgraph SDK["codexapp-go"]
    Facade["Thin Facades"]
    SDKEvents["Event Bus"]
    SDKPending["Server Request Bus"]
    Transport["Transport"]
  end

  Backend["Codex app-server"]

  Runtime --> AdapterCore
  AdapterCore --> RequestMapper
  RequestMapper --> Facade
  Facade --> Transport
  Transport --> Backend
  Backend --> Transport
  Transport --> SDKEvents
  Transport --> SDKPending
  SDKEvents --> EventPump
  EventPump --> EventMapper
  EventMapper --> EventMux
  SDKPending --> PendingMapper
  PendingMapper --> PendingStore
  PendingStore --> Runtime
  Runtime --> ResponseMapper
  ResponseMapper --> SDKPending
  Facade --> ResultMapper
  ResultMapper --> AdapterCore
  AdapterCore --> ErrorMapper
  CapabilityMapper --> AdapterCore
  EventMux --> Projection
```

### 5.1 数据流

| 路径 | 流程 |
| --- | --- |
| 创建 thread | AgentRuntime -> Adapter Core -> RequestMapper -> SDK -> ResultMapper -> ThreadRef |
| 启动 turn | AgentRuntime -> Adapter Core -> RequestMapper -> SDK -> ResultMapper -> TurnRef |
| 后端事件 | SDK Event Bus -> EventPump -> EventMapper -> RuntimeEvent -> EventMux |
| pending request | SDK Server Request Bus -> PendingMapper -> PendingRequest -> PendingStore |
| pending response | AgentRuntime -> ResponseMapper -> SDK server request response |
| 错误 | SDK/mapper error -> ErrorMapper -> RuntimeError |

## 6. 包结构

首版包结构：

```text
agent-host/
  internal/
    agentruntime/
      runtime.go
      model.go
      events.go
      pending.go
      errors.go
    codexruntime/
      adapter.go
      config.go
      mapper_request.go
      mapper_result.go
      mapper_event.go
      mapper_pending.go
      mapper_error.go
      capability.go
```

不要提前加：

```text
registry.go
plugin.go
loader.go
marketplace.go
```

```go
// ponytail: one adapter exists, so hardcode it; add registry when a second adapter ships.
runtime := codexruntime.New(client, cfg)
```

### 6.1 `adapter.go`

负责组合 SDK client，实现 `AgentRuntime` 方法。

```go
type Adapter struct {
    runtimeID string
    client    *codexapp.Client
    cfg       Config
    events    chan agentruntime.RuntimeEvent
}
```

字段保持少。需要第二个 runtime 或真实性能瓶颈时再拆更细。

### 6.2 `config.go`

Adapter 配置只包含 adapter 运行所需字段。

```go
type Config struct {
    RuntimeID string
    BufferSize int
}
```

不放 HTTP 路由、SSE 配置、UI 配置、持久化配置。

### 6.3 `mapper_request.go`

负责把 AgentRuntime request 转成 SDK params。

示例职责：

- `StartThreadRequest` -> Codex thread start params。
- `StartTurnRequest` -> Codex turn start params。
- `CancelTurnRequest` -> Codex cancel/interrupt params。

### 6.4 `mapper_result.go`

负责把 SDK result 转成 AgentRuntime ref。

示例职责：

- Codex thread result -> `ThreadRef`。
- Codex turn result -> `TurnRef`。
- initialize/version/capability -> `RuntimeInfo`。

### 6.5 `mapper_event.go`

负责把 SDK notification 转成 `RuntimeEvent`。

该文件不能访问 HTTP/SSE 层，也不能写 Projection Store。

### 6.6 `mapper_pending.go`

负责后端 server request 与 `PendingRequest` 的双向转换。

职责：

- server request -> `PendingRequest`。
- `RuntimeResponse` -> SDK response。
- request id 映射和一次性响应校验。

### 6.7 `mapper_error.go`

负责后端错误到 `RuntimeError` 的转换。

必须保留：

- stable code。
- retryable。
- cause。
- raw summary。

### 6.8 `capability.go`

负责声明 adapter 能力。

首版可静态声明 Codex capabilities。动态能力等真实需要再加。

## 7. 核心实现接口

### 7.1 Adapter 构造

```go
func New(client *codexapp.Client, cfg Config) *Adapter
```

构造函数只接收已创建好的 SDK client。启动 app-server 进程、读取用户配置、选择模型默认值都属于 AgentHost 上层。

### 7.2 Info

```go
func (a *Adapter) Info(ctx context.Context) (agentruntime.RuntimeInfo, error)
```

实现要求：

- 返回 runtime id。
- 返回 kind。
- 返回 display name。
- 返回 health。
- 返回 capabilities。
- 返回后端 version 或 unknown。
- 后端不可用时返回 `runtime_unavailable`。

### 7.3 StartThread

```go
func (a *Adapter) StartThread(ctx context.Context, req agentruntime.StartThreadRequest) (agentruntime.ThreadRef, error)
```

实现要求：

- 校验必填字段。
- 检查 `thread.start` capability。
- 调用 `codexapp-go` thread facade。
- 映射 SDK result 为 `ThreadRef`。
- 不保存 UI 状态。

### 7.4 StartTurn

```go
func (a *Adapter) StartTurn(ctx context.Context, req agentruntime.StartTurnRequest) (agentruntime.TurnRef, error)
```

实现要求：

- 校验 thread id。
- 检查 `turn.start` capability。
- 映射 input、model、profile、context。
- 调用 `codexapp-go` turn facade。
- 返回 `TurnRef`。

### 7.5 CancelTurn

```go
func (a *Adapter) CancelTurn(ctx context.Context, req agentruntime.CancelTurnRequest) error
```

实现要求：

- 检查 `turn.cancel` capability。
- 映射到底层 cancel、interrupt 或 abort。
- 重复取消尽量幂等。
- 后端不支持时返回 `capability_unsupported`。

### 7.6 Events

```go
func (a *Adapter) Events(ctx context.Context, req agentruntime.EventSubscribeRequest) (<-chan agentruntime.RuntimeEvent, error)
```

首版可以返回 adapter 级事件 channel。按 thread/turn 过滤可以先由 AgentHost EventMux 做。

要求：

- 不让 SDK reader 被慢消费者阻塞。
- channel 关闭可被消费者识别。
- ctx cancel 后停止向调用方发送。

### 7.7 Respond

```go
func (a *Adapter) Respond(ctx context.Context, req agentruntime.RuntimeResponse) error
```

实现要求：

- 校验 request id。
- 校验 decision。
- 校验 payload。
- 调用 SDK server request response。
- 重复响应返回幂等结果或 conflict。

## 8. Request Mapping

### 8.1 StartThreadRequest 映射

| AgentRuntime 字段 | Codex 映射 | 规则 |
| --- | --- | --- |
| `WorkspacePath` | cwd/workspace | 必须非空，路径合法性由 AgentHost API 先校验。 |
| `InitialInput` | initial prompt/input | 可空。 |
| `Model` | model | 不支持时返回 capability error。 |
| `Profile` | approval/sandbox profile | 映射失败返回 invalid_request。 |
| `Metadata` | adapter internal metadata | 不透传未知敏感字段。 |

### 8.2 StartTurnRequest 映射

| AgentRuntime 字段 | Codex 映射 | 规则 |
| --- | --- | --- |
| `ThreadID` | Codex thread id | 必须可映射。 |
| `Input` | turn input | 必须符合 Codex 输入要求。 |
| `Model` | model override | 可选。 |
| `Profile` | permission/sandbox profile | 可选。 |
| `Context` | adapter context | 只传白名单字段。 |

### 8.3 CancelTurnRequest 映射

| AgentRuntime 字段 | Codex 映射 | 规则 |
| --- | --- | --- |
| `ThreadID` | Codex thread id | 必填。 |
| `TurnID` | Codex turn id | 必填或按 Codex 能力映射。 |
| `Reason` | cancel reason | 可选。 |

## 9. Result Mapping

### 9.1 ThreadRef

| Codex 结果 | AgentRuntime 字段 |
| --- | --- |
| Codex thread id | `ThreadID` |
| adapter runtime id | `RuntimeID` |
| Codex thread status | `Status` |
| raw result summary | `Raw` |

### 9.2 TurnRef

| Codex 结果 | AgentRuntime 字段 |
| --- | --- |
| Codex turn id | `TurnID` |
| Codex thread id | `ThreadID` |
| adapter runtime id | `RuntimeID` |
| Codex turn state | `Status` |
| raw result summary | `Raw` |

### 9.3 RuntimeInfo

| Codex 来源 | AgentRuntime 字段 |
| --- | --- |
| initialize result/version | `Version` |
| static adapter id | `RuntimeID` |
| static kind | `Kind=codex` |
| health check | `Health` |
| capability mapper | `Capabilities` |
| raw summary | `Raw` |

## 10. Event Mapping

### 10.1 RuntimeEvent 生成规则

| 字段 | 规则 |
| --- | --- |
| `EventID` | 优先使用后端 id；无 id 时用 runtime/thread/turn/type/sequence 生成。 |
| `RuntimeID` | 使用 adapter runtime id。 |
| `ThreadID` | 从 Codex event 或 adapter mapping 提取。 |
| `TurnID` | turn 相关事件必填。 |
| `Type` | 映射为 AgentRuntime event type。 |
| `Time` | 优先使用后端时间；没有则用接收时间。 |
| `Sequence` | 同一 adapter event stream 内递增。 |
| `Payload` | typed AgentRuntime payload。 |
| `Raw` | 脱敏后的底层事件摘要。 |

### 10.2 Codex event 映射表

| Codex 类别 | RuntimeEvent |
| --- | --- |
| thread created | `thread.created` |
| thread updated | `thread.updated` |
| turn started | `turn.started` |
| assistant/user message | `turn.message` |
| reasoning/delta | `turn.delta` |
| command started | `turn.command.started` |
| command output | `turn.command.output` |
| command finished | `turn.command.finished` |
| file change | `turn.file_change` |
| tool call started | `turn.tool_call.started` |
| tool call updated | `turn.tool_call.updated` |
| tool call finished | `turn.tool_call.finished` |
| server request | `turn.waiting_for_input` |
| turn completed | `turn.completed` |
| turn failed | `turn.failed` |
| turn cancelled | `turn.cancelled` |

### 10.3 缺失字段处理

- 缺少 id：生成稳定 id。
- 缺少时间：使用接收时间。
- 缺少 turn id：仅 thread 级事件允许为空。
- 缺少 payload 字段：保留 raw，输出较粗粒度事件。
- 无法安全映射：输出 `RuntimeError`，不伪造精确信息。

## 11. Event Pump

### 11.1 职责

Event Pump 从 SDK event source 读取后端事件，调用 EventMapper，写入 adapter event channel。

它负责：

- 解耦 SDK reader 和 AgentHost 消费者。
- 控制缓冲。
- 处理 ctx cancel。
- 记录映射失败。
- 合并高频 delta。

它不负责：

- SSE 序列化。
- Projection 更新。
- pending 持久化。
- UI 文案。

### 11.2 Goroutine 边界

```text
codexapp-go reader
  -> codexapp-go event bus
    -> CodexRuntimeAdapter Event Pump
      -> EventMapper
        -> adapter events channel
          -> AgentHost EventMux
```

### 11.3 背压策略

| 事件类型 | 策略 |
| --- | --- |
| lifecycle event | 不丢弃。 |
| pending request event | 不丢弃。 |
| delta event | 可合并。 |
| command output | 可按 chunk 合并。 |
| diagnostic raw | 可采样。 |

## 12. Pending Mapping

### 12.1 PendingRequest 创建

Adapter 接到后端 server request 后，创建 `PendingRequest`。

字段规则：

| 字段 | 规则 |
| --- | --- |
| `RequestID` | 来自后端 request id 或 adapter 生成映射 id。 |
| `RuntimeID` | adapter runtime id。 |
| `ThreadID` | 从 request context 提取。 |
| `TurnID` | 从 request context 提取。 |
| `Type` | 映射为统一 pending type。 |
| `Title` | 给 UI 投影使用的简短标题。 |
| `Summary` | 给 UI 投影使用的摘要。 |
| `Payload` | typed payload。 |
| `Raw` | 脱敏 raw summary。 |
| `IdempotencyKey` | request id + runtime id 或后端幂等 id。 |

### 12.2 Pending 类型映射

| Codex server request | PendingRequest |
| --- | --- |
| command approval | `approval.command` |
| file change approval | `approval.file_change` |
| permission approval | `approval.permission` |
| request user input | `input.user` |
| dynamic tool call | `tool.dynamic_call` |
| token refresh | `auth.refresh` |

### 12.3 Response 映射

| RuntimeResponse decision | 后端响应 |
| --- | --- |
| `approve` | approve/allow |
| `deny` | deny/reject |
| `cancel` | cancel |
| `answer` | user input answer |
| `error` | error response |

规则：

- decision 必须匹配 pending type。
- payload 必须按 pending type 校验。
- response 只能发送一次。
- SDK 返回错误时映射为 `RuntimeError`。

## 13. Error Mapping

### 13.1 RuntimeError 转换表

| 来源 | RuntimeError code |
| --- | --- |
| SDK transport disconnected | `transport_error` |
| SDK request timeout | `runtime_unavailable` 或 `transport_error` |
| SDK protocol mismatch | `protocol_error` |
| backend method unsupported | `capability_unsupported` |
| invalid adapter mapping | `internal_error` |
| invalid AgentRuntime request | `invalid_request` |
| user/backend denied | `permission_denied` |
| turn terminal failure | `turn_failed` |

### 13.2 错误字段

| 字段 | 来源 |
| --- | --- |
| `Code` | mapper 决定。 |
| `Message` | 面向开发者的摘要。 |
| `UserMessage` | 可空，由上层覆盖。 |
| `Retryable` | mapper 根据错误类型判断。 |
| `RuntimeID` | adapter runtime id。 |
| `ThreadID` | 可从 context 提取。 |
| `TurnID` | 可从 context 提取。 |
| `Cause` | 原始 error。 |
| `Raw` | 脱敏 raw summary。 |

## 14. Capability Mapping

### 14.1 Codex 首版 capability

| Capability | 首版状态 |
| --- | --- |
| `thread.start` | 支持 |
| `thread.resume` | 视 Codex 能力支持 |
| `turn.start` | 支持 |
| `turn.cancel` | 视 Codex cancel/interrupt 能力支持 |
| `event.stream` | 支持 |
| `event.replay` | 首版不支持 |
| `approval.command` | 支持 |
| `approval.file_change` | 支持 |
| `approval.permission` | 支持 |
| `input.user` | 支持 |
| `tool.call` | 支持事件映射 |
| `model.select` | 视 Codex 能力支持 |
| `workspace.fs` | 支持 |

### 14.2 校验规则

- Adapter 对每个外部调用检查 capability。
- Capability 不支持时不调用 SDK。
- Capability 状态可以来自静态声明。
- 后端版本差异明确后，再做动态 capability。

## 15. 状态管理

Adapter 只维护必要的短生命周期映射和事件通道，不拥有产品状态。

### 15.1 可维护状态

| 状态 | 说明 |
| --- | --- |
| runtime id | adapter 实例标识。 |
| health cache | 最近一次 health。 |
| event sequence | 生成 event sequence。 |
| pending response map | request id 到底层 responder 的短期映射。 |
| last error | 最近错误摘要，用于诊断。 |

### 15.2 不维护状态

| 状态 | 归属 |
| --- | --- |
| thread UI 列表 | AgentHost Projection Store |
| turn 展示状态 | AgentHost Projection Store |
| pending request 持久化 | AgentHost Pending Store |
| 用户设置 | AgentHost config |
| HTTP session | AgentHost API |
| SSE cursor | AgentHost SSE/EventMux |

## 16. 并发与关闭

### 16.1 并发模型

首版并发模型：

```text
API call goroutine
  -> Adapter method
    -> SDK request

SDK event goroutine
  -> EventPump
    -> adapter event channel

SDK server request goroutine
  -> PendingMapper
    -> PendingStore
```

### 16.2 线程安全要求

- event sequence 使用 mutex 或 atomic。
- pending response map 必须受 mutex 保护。
- event channel 关闭只能执行一次。
- Adapter shutdown 后新调用返回 `runtime_unavailable`。

### 16.3 关闭流程

```text
1. AgentHost cancel runtime context.
2. Adapter 停止接收新的 AgentRuntime 调用.
3. Adapter 停止 EventPump.
4. Adapter 停止 pending request listener.
5. Adapter 关闭 event channel.
6. SDK client 按自己的 Close 语义关闭.
```

## 17. 配置架构

### 17.1 Adapter Config

```go
type Config struct {
    RuntimeID  string
    BufferSize int
}
```

首版配置保持少。默认值由构造函数处理。

| 配置 | 默认值 | 说明 |
| --- | --- | --- |
| `RuntimeID` | `codex` | 单 runtime 首版固定即可。 |
| `BufferSize` | 256 | 事件缓冲大小。 |

### 17.2 不进入 Adapter Config 的配置

| 配置 | 所属层 |
| --- | --- |
| HTTP listen address | AgentHost API |
| SSE retry interval | AgentHost SSE |
| app-server command path | AgentHost 启动链路 |
| workspace allowlist | AgentHost 安全配置 |
| user settings | AgentHost config |
| log path | AgentHost logging |

## 18. 安全架构

### 18.1 输入校验

| 输入 | 校验 |
| --- | --- |
| `StartThreadRequest` | workspace、model、profile、metadata 白名单。 |
| `StartTurnRequest` | thread id、input、context 白名单。 |
| `CancelTurnRequest` | thread id、turn id。 |
| `RuntimeResponse` | request id、decision、payload type。 |
| SDK event | type、required id、payload shape。 |
| SDK server request | request id、request type、context。 |

### 18.2 脱敏

Raw 信息必须脱敏：

- token。
- command env。
- credential path。
- auth header。
- user secret。
- 过长 command output。

Adapter 可以返回 raw summary，但完整 raw dump 是否落盘由 AgentHost 决定。

### 18.3 禁止行为

- 不自动 approve。
- 不绕过 AgentHost permission profile。
- 不执行 HTTP handler 传来的任意后端 method 名称。
- 不把 SDK raw object 直接传给 Electron。
- 不把 secret 写进普通日志。

## 19. 可观测性

### 19.1 Adapter metrics

| 指标 | 说明 |
| --- | --- |
| `adapter_events_received_total` | 从 SDK 收到的事件数。 |
| `adapter_events_mapped_total` | 成功映射事件数。 |
| `adapter_events_dropped_total` | 丢弃或合并事件数。 |
| `adapter_pending_created_total` | 创建 pending request 数。 |
| `adapter_pending_responded_total` | 响应 pending request 数。 |
| `adapter_errors_mapped_total` | 映射错误数。 |
| `adapter_sdk_calls_total` | SDK 调用数。 |

### 19.2 Diagnostic snapshot

Adapter 可提供诊断快照：

| 字段 | 说明 |
| --- | --- |
| `adapter_id` | adapter id。 |
| `runtime_id` | runtime id。 |
| `runtime_kind` | runtime kind。 |
| `health` | 当前健康状态。 |
| `backend_version` | 后端版本。 |
| `capabilities` | capability 列表。 |
| `last_error` | 最近错误摘要。 |
| `event_buffer_len` | 当前事件缓冲长度。 |
| `pending_open_count` | 当前打开 pending 数。 |

Adapter 不决定 metrics backend。

## 20. 测试架构

### 20.1 单元测试

| 测试 | 目的 |
| --- | --- |
| request mapper test | AgentRuntime request 正确转换为 SDK params。 |
| result mapper test | SDK result 正确转换为 ref。 |
| event mapper test | SDK event 正确转换为 RuntimeEvent。 |
| pending mapper test | server request 正确转换为 PendingRequest。 |
| response mapper test | RuntimeResponse 正确转换为 SDK response。 |
| error mapper test | SDK error 正确转换为 RuntimeError。 |
| capability test | 不支持能力返回 capability error。 |

### 20.2 最小自检

首版至少保留一条可运行自检：

```text
CodexRuntimeAdapter.Info
CodexRuntimeAdapter.StartThread
CodexRuntimeAdapter.StartTurn
receive turn.started
receive turn.completed or turn.failed
```

如果真实 Codex app-server 不能稳定进入 CI，自检可作为手动或 nightly。

### 20.3 不需要的测试

首版不需要：

- registry 测试。
- plugin loader 测试。
- 多 runtime 切换测试。
- 远程 worker 测试。

## 21. 实施分期

### 21.1 M1: Adapter 骨架

- 新增 `internal/codexruntime` 包。
- 实现 `Adapter` 结构。
- 实现 `Info`。
- 静态声明 capabilities。

### 21.2 M2: Thread/Turn 写路径

- 实现 `StartThread`。
- 实现 `StartTurn`。
- 实现 `CancelTurn`。
- 完成 request/result mapper。

### 21.3 M3: Event Pump

- 接入 `codexapp-go` event subscription。
- 实现 EventPump。
- 完成基础 event mapper。
- 输出 RuntimeEvent。

### 21.4 M4: PendingRequest

- 接入 `codexapp-go` server request。
- 实现 PendingMapper。
- 实现 ResponseMapper。
- 保证一次性响应。

### 21.5 M5: 错误、诊断、测试

- 实现 ErrorMapper。
- 增加 diagnostic snapshot。
- 补最小 mapper 单测。
- 补 Codex contract check。

## 22. 验收标准

### 22.1 架构验收

- `agentruntime` 包不 import `codexapp-go`。
- `codexruntime` 包只通过 `codexapp-go` 接入 Codex app-server。
- AgentHost HTTP handler 不引用 Codex protocol 类型。
- AgentHost SSE payload 不直接使用 Codex notification 类型。
- Adapter 不包含 HTTP/SSE/DB 代码。
- 首版没有 registry/plugin/dynamic loader。

### 22.2 行为验收

- `Info` 返回 runtime info、health、capability。
- `StartThread` 返回 `ThreadRef`。
- `StartTurn` 返回 `TurnRef`。
- `Events` 输出 RuntimeEvent。
- `Respond` 能回复 pending request。
- SDK transport/protocol error 被映射为 RuntimeError。
- 不支持能力返回 `capability_unsupported`。
- Adapter 不自动 approve。

### 22.3 扩展验收

- 新增 OtherAgentRuntimeAdapter 时，只新增新 adapter 包和薄 SDK。
- 不修改 `codexapp-go`。
- 不修改 Electron API。
- 不把 OtherAgent 专属字段放入 AgentRuntime 核心模型。

## 23. 风险与对策

| 风险 | 影响 | 对策 |
| --- | --- | --- |
| Adapter 重写 SDK 能力 | 协议逻辑重复，维护困难 | Adapter 只能调用 SDK。 |
| Adapter 泄漏后端类型 | AgentHost 被后端绑定 | 对上只返回 AgentRuntime 模型。 |
| EventPump 阻塞 | 后端输出卡住 | reader、pump、mux 分层，有限缓冲。 |
| pending response 重复 | 后端 request 状态错乱 | pending map 加锁，一次性响应。 |
| capability 不准 | UI/API 暴露不可用功能 | Adapter 执行前再次校验。 |
| raw 信息泄漏 | 安全风险 | raw summary 脱敏，完整 dump 交给 AgentHost 策略。 |
| 过早 registry | 首版复杂度上升 | 第二个 adapter 出现后再加。 |

## 24. 最终架构结论

`AgentRuntimeAdapter` 的技术角色是具体后端到 `AgentRuntime` 统一模型的翻译实现。首版 `CodexRuntimeAdapter` 直接实现 `AgentRuntime`，通过 `codexapp-go` 接入 Codex app-server。

Adapter 内部只需要 Adapter Core、RequestMapper、ResultMapper、EventMapper、PendingMapper、ResponseMapper、ErrorMapper、CapabilityMapper 和 EventPump。它不需要 HTTP、SSE、DB、registry、plugin loader。

第二个真实 runtime 接入前，不新增通用 adapter registry。新增 OtherAgent 时，按同样结构新增 `otheragentruntime` 包和薄 `OtherAgent SDK`。
