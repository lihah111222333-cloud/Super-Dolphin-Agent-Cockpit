# AgentHost 数据库设计说明

整理日期：2026-06-23

## 1. 定位

本文是 `agent-host` 本地 SQLite 数据库的唯一结构事实源，覆盖数据表、字段、约束、索引、表关系、阶段归属和 GORM model 边界。

其他文档只描述产品语义、API 行为或阶段目标，不再展开库表字段、索引和约束。

## 2. 基础约定

| 项 | 约定 |
| --- | --- |
| 数据库 | SQLite |
| ORM | GORM |
| SQLite driver | `github.com/glebarez/sqlite` |
| 主键 | `id TEXT PRIMARY KEY`，由应用生成稳定字符串 ID。 |
| 时间字段 | 使用 UTC 时间，GORM 类型为 `time.Time` 或 `*time.Time`，SQLite 类型为 `DATETIME`。 |
| 创建/更新时间 | 普通业务表使用 `created_at`、`updated_at`。 |
| 软删 | 用户可删除且需要恢复或避免物理破坏的表使用 `deleted_at`。 |
| JSON 字段 | SQLite 使用 `TEXT`，GORM 使用结构体字段配合 `serializer:json` 或明确的 JSON 字符串类型。 |
| 布尔字段 | SQLite 使用 `INTEGER`，GORM 使用 `bool`。 |
| 枚举字段 | SQLite 使用 `TEXT`，枚举值由应用层校验；必要时用 GORM check tag。 |
| 外键 | 任务内强关系使用外键；远程对象 ID 只保存引用，不建本地外键。 |

SQLite 默认启用：

```text
foreign_keys = ON
journal_mode = WAL
busy_timeout = 5000
```

创建脚本：

```bash
mkdir -p ./agent-host/.local
sqlite3 ./agent-host/.local/agent-host.db < ./agent-host/scripts/sqlite/create-database.sql
```

使用时机：

- P0 本地存储初始化前，用于创建 SQLite schema。
- 数据库结构调整后，用于空库验证建表和索引是否可执行。
- Go 工程接入 GORM 前，用于人工核对 GORM model 与 schema 是否一致。

## 3. GORM Model 边界

GORM model 是持久化模型，不直接等于以下模型：

- Host API request/response DTO。
- AgentRuntime 统一模型。
- Codex app-server protocol 类型。
- Electron UI view model。

边界规则：

- `internal/store` 拥有 GORM model。
- Host API 通过 service 层读取 store，不直接暴露 GORM model。
- AgentRuntime 不依赖 GORM model。
- CodexRuntimeAdapter 不依赖 GORM model。
- 数据库 JSON 字段只保存本地持久化需要的快照，不作为上层业务判断的唯一来源。

## 4. 阶段与表归属

| 阶段 | 表 |
| --- | --- |
| P0 | `user_sessions`、`settings`、`remote_cache` |
| P1 | `workspaces`、`tasks`、`task_messages`、`task_runs`、`run_events`、`runtime_actions` |
| P2 | `context_refs`、`artifacts`、`file_changes`、`custom_models`、`installed_skills`、`local_skill_drafts`、`local_experts`、`automations`、`automation_runs`、`memories` |
| P3 | `remote_sync_queue` |
| P4 | 不新增核心表，只补迁移、索引、回归测试和文档一致性。 |

## 5. 表关系

```text
user_sessions
settings
remote_cache

workspaces 1 -> n tasks
tasks 1 -> n task_messages
tasks 1 -> n task_runs
task_runs 1 -> n run_events
task_runs 1 -> n runtime_actions
tasks 1 -> n context_refs
tasks 1 -> n artifacts
task_runs 1 -> n file_changes

automations 1 -> n automation_runs
tasks 0..1 -> n automation_runs

remote_sync_queue 通过 payload_json 引用本地业务对象，不建立严格外键。
```

## 6. 表设计

### 6.1 `user_sessions` P0

用途：保存本地 session hash 和远程 token 密文。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `id` | TEXT | string | PK | 本地 session 记录 ID。 |
| `user_id` | TEXT | string | NOT NULL, index | 当前用户 ID。 |
| `local_session_hash` | TEXT | string | NOT NULL, UNIQUE | Electron 调本地 API 的 session token hash。 |
| `remote_access_token_enc` | TEXT | string | nullable | 远程 access token 密文。 |
| `remote_refresh_token_enc` | TEXT | string | nullable | 远程 refresh token 密文。 |
| `expires_at` | DATETIME | time.Time | NOT NULL, index | 本地 session 过期时间。 |
| `revoked_at` | DATETIME | *time.Time | nullable | 登出或撤销时间。 |
| `created_at` | DATETIME | time.Time | NOT NULL | 创建时间。 |
| `updated_at` | DATETIME | time.Time | NOT NULL | 更新时间。 |

索引：

- `uniq_user_sessions_local_session_hash(local_session_hash)`。
- `idx_user_sessions_user_id(user_id)`。
- `idx_user_sessions_expires_at(expires_at)`。

### 6.2 `settings` P0

用途：保存系统、用户、任务默认值等本地配置。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `id` | TEXT | string | PK | 设置记录 ID。 |
| `scope` | TEXT | string | NOT NULL | `system`、`security`、`task_defaults` 等。 |
| `user_id` | TEXT | string | nullable, index | 用户级设置的用户 ID。 |
| `key` | TEXT | string | NOT NULL | 设置项名称。 |
| `value_json` | TEXT | struct/string | NOT NULL | 设置值 JSON。 |
| `updated_at` | DATETIME | time.Time | NOT NULL | 更新时间。 |

索引：

- `uniq_settings_scope_user_key(scope, user_id, key)`。

### 6.3 `remote_cache` P0

用途：缓存远程动态数据，如模型、技能市场、专家、连接器、灵感、套餐。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `key` | TEXT | string | PK | `{domain}:{userId}:{orgId}:{queryHash}`。 |
| `domain` | TEXT | string | NOT NULL, index | 缓存域，如 `models`、`skills_market`。 |
| `user_id` | TEXT | string | nullable, index | 用户 ID。 |
| `org_id` | TEXT | string | nullable, index | 组织 ID。 |
| `payload_json` | TEXT | struct/string | NOT NULL | 远程响应快照。 |
| `etag` | TEXT | string | nullable | 远程 ETag。 |
| `last_modified` | TEXT | string | nullable | 远程 Last-Modified。 |
| `version` | TEXT | string | nullable | 远程版本号或业务版本。 |
| `fetched_at` | DATETIME | time.Time | NOT NULL | 最近拉取时间。 |
| `expires_at` | DATETIME | time.Time | NOT NULL, index | TTL 过期时间。 |
| `stale_at` | DATETIME | time.Time | NOT NULL, index | stale 窗口结束时间。 |
| `sync_status` | TEXT | string | NOT NULL | `fresh`、`stale`、`error`。 |
| `error_json` | TEXT | struct/string | nullable | 最近刷新错误。 |
| `created_at` | DATETIME | time.Time | NOT NULL | 创建时间。 |
| `updated_at` | DATETIME | time.Time | NOT NULL | 更新时间。 |

索引：

- `idx_remote_cache_domain_user_org(domain, user_id, org_id)`。
- `idx_remote_cache_expires_at(expires_at)`。
- `idx_remote_cache_stale_at(stale_at)`。

### 6.4 `workspaces` P1

用途：登记本地工作区。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `id` | TEXT | string | PK | 工作区 ID。 |
| `user_id` | TEXT | string | NOT NULL, index | 所属用户。 |
| `name` | TEXT | string | NOT NULL | 显示名。 |
| `path` | TEXT | string | NOT NULL | 本地路径。 |
| `last_opened_at` | DATETIME | *time.Time | nullable, index | 最近打开时间。 |
| `created_at` | DATETIME | time.Time | NOT NULL | 创建时间。 |
| `updated_at` | DATETIME | time.Time | NOT NULL | 更新时间。 |
| `deleted_at` | DATETIME | gorm.DeletedAt | nullable, index | 软删时间。 |

索引：

- `idx_workspaces_user_updated(user_id, updated_at)`。
- `idx_workspaces_user_path(user_id, path)`。

### 6.5 `tasks` P1

用途：保存一次用户任务和工作区上下文。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `id` | TEXT | string | PK | 任务 ID。 |
| `user_id` | TEXT | string | NOT NULL, index | 所属用户。 |
| `workspace_id` | TEXT | string | nullable, FK | 工作区 ID。 |
| `title` | TEXT | string | NOT NULL | 任务标题。 |
| `status` | TEXT | string | NOT NULL, index | `draft`、`running`、`paused`、`done`、`error`、`stopped`、`archived`。 |
| `mode` | TEXT | string | NOT NULL | `ask`、`plan`、`craft`。 |
| `permission_mode` | TEXT | string | NOT NULL | `default`、`full_access`。 |
| `project_id` | TEXT | string | nullable, index | 远程项目 ID 快照。 |
| `pinned` | INTEGER | bool | NOT NULL | 是否置顶。 |
| `archived` | INTEGER | bool | NOT NULL, index | 是否归档。 |
| `summary` | TEXT | string | nullable | 任务摘要。 |
| `created_at` | DATETIME | time.Time | NOT NULL | 创建时间。 |
| `updated_at` | DATETIME | time.Time | NOT NULL, index | 更新时间。 |
| `deleted_at` | DATETIME | gorm.DeletedAt | nullable, index | 软删时间。 |

索引：

- `idx_tasks_user_status_updated(user_id, status, updated_at)`。
- `idx_tasks_workspace_updated(workspace_id, updated_at)`。
- `idx_tasks_project_updated(project_id, updated_at)`。

### 6.6 `task_messages` P1

用途：保存任务对话消息。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `id` | TEXT | string | PK | 消息 ID。 |
| `task_id` | TEXT | string | NOT NULL, FK, index | 任务 ID。 |
| `role` | TEXT | string | NOT NULL | `user`、`assistant`、`system`、`tool`。 |
| `content` | TEXT | string | NOT NULL | 消息正文。 |
| `attachments_json` | TEXT | struct/string | nullable | 附件快照。 |
| `created_at` | DATETIME | time.Time | NOT NULL, index | 创建时间。 |

索引：

- `idx_task_messages_task_created(task_id, created_at)`。

### 6.7 `task_runs` P1

用途：保存一次 Agent 执行。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `id` | TEXT | string | PK | run ID。 |
| `task_id` | TEXT | string | NOT NULL, FK, index | 任务 ID。 |
| `runtime` | TEXT | string | NOT NULL | `codex` 等 runtime 名。 |
| `thread_id` | TEXT | string | nullable | runtime thread ID。 |
| `turn_id` | TEXT | string | nullable | runtime turn ID。 |
| `status` | TEXT | string | NOT NULL, index | `queued`、`running`、`waiting`、`done`、`error`、`stopped`。 |
| `model_id` | TEXT | string | nullable | 使用的模型 ID。 |
| `started_at` | DATETIME | *time.Time | nullable, index | 开始时间。 |
| `ended_at` | DATETIME | *time.Time | nullable | 结束时间。 |
| `error_json` | TEXT | struct/string | nullable | 错误快照。 |
| `created_at` | DATETIME | time.Time | NOT NULL | 创建时间。 |
| `updated_at` | DATETIME | time.Time | NOT NULL | 更新时间。 |

索引：

- `idx_task_runs_task_started(task_id, started_at)`。
- `idx_task_runs_status_updated(status, updated_at)`。

### 6.8 `run_events` P1

用途：保存 runtime 事件，用于 SSE 恢复和历史查看。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `id` | TEXT | string | PK | 事件 ID。 |
| `task_id` | TEXT | string | NOT NULL, FK, index | 任务 ID。 |
| `run_id` | TEXT | string | NOT NULL, FK, index | run ID。 |
| `sequence` | INTEGER | int64 | NOT NULL | run 内递增序号。 |
| `type` | TEXT | string | NOT NULL, index | 事件类型。 |
| `payload_json` | TEXT | struct/string | NOT NULL | 事件 payload。 |
| `created_at` | DATETIME | time.Time | NOT NULL, index | 创建时间。 |

索引：

- `uniq_run_events_run_sequence(run_id, sequence)`。
- `idx_run_events_task_created(task_id, created_at)`。
- `idx_run_events_run_created(run_id, created_at)`。

### 6.9 `runtime_actions` P1

用途：保存需要用户确认或 Host 决策的 runtime action。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `id` | TEXT | string | PK | action ID。 |
| `task_id` | TEXT | string | NOT NULL, FK, index | 任务 ID。 |
| `run_id` | TEXT | string | NOT NULL, FK, index | run ID。 |
| `risk_level` | TEXT | string | NOT NULL | `low`、`medium`、`high`。 |
| `action_json` | TEXT | struct/string | NOT NULL | 待确认动作。 |
| `status` | TEXT | string | NOT NULL, index | `pending`、`approved`、`denied`、`expired`。 |
| `decision_json` | TEXT | struct/string | nullable | 用户或策略决策。 |
| `created_at` | DATETIME | time.Time | NOT NULL | 创建时间。 |
| `updated_at` | DATETIME | time.Time | NOT NULL | 更新时间。 |
| `resolved_at` | DATETIME | *time.Time | nullable | 完成决策时间。 |

索引：

- `idx_runtime_actions_status_created(status, created_at)`。
- `idx_runtime_actions_task_run(task_id, run_id)`。

### 6.10 `context_refs` P2

用途：保存本地文件、云资料、项目资产等上下文引用。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `id` | TEXT | string | PK | 引用 ID。 |
| `task_id` | TEXT | string | NOT NULL, FK, index | 任务 ID。 |
| `ref_type` | TEXT | string | NOT NULL, index | `local_file`、`cloud_file`、`project_asset`。 |
| `provider` | TEXT | string | nullable | 云资料或连接器提供方。 |
| `ref_id` | TEXT | string | NOT NULL | 外部或本地引用 ID。 |
| `title` | TEXT | string | nullable | 展示标题。 |
| `metadata_json` | TEXT | struct/string | nullable | 权限、路径、快照等元数据。 |
| `created_at` | DATETIME | time.Time | NOT NULL | 创建时间。 |
| `deleted_at` | DATETIME | gorm.DeletedAt | nullable, index | 软删时间。 |

索引：

- `idx_context_refs_task_type(task_id, ref_type)`。

### 6.11 `artifacts` P2

用途：保存任务产物元数据。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `id` | TEXT | string | PK | 产物 ID。 |
| `task_id` | TEXT | string | NOT NULL, FK, index | 任务 ID。 |
| `path` | TEXT | string | NOT NULL | 本地文件路径。 |
| `type` | TEXT | string | NOT NULL, index | 文档、图片、网页、代码等类型。 |
| `title` | TEXT | string | nullable | 展示标题。 |
| `preview_status` | TEXT | string | NOT NULL | `pending`、`ready`、`error`。 |
| `metadata_json` | TEXT | struct/string | nullable | 预览、大小、mime 等元数据。 |
| `created_at` | DATETIME | time.Time | NOT NULL | 创建时间。 |
| `updated_at` | DATETIME | time.Time | NOT NULL | 更新时间。 |
| `deleted_at` | DATETIME | gorm.DeletedAt | nullable, index | 软删时间。 |

索引：

- `idx_artifacts_task_type_created(task_id, type, created_at)`。
- `idx_artifacts_task_path(task_id, path)`。

### 6.12 `file_changes` P2

用途：保存文件变更和 diff 摘要。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `id` | TEXT | string | PK | 变更 ID。 |
| `task_id` | TEXT | string | NOT NULL, FK, index | 任务 ID。 |
| `run_id` | TEXT | string | nullable, FK, index | run ID。 |
| `path` | TEXT | string | NOT NULL | 文件路径。 |
| `change_type` | TEXT | string | NOT NULL | `created`、`modified`、`deleted`。 |
| `diff` | TEXT | string | nullable | diff 文本或摘要。 |
| `created_at` | DATETIME | time.Time | NOT NULL | 创建时间。 |

索引：

- `idx_file_changes_task_created(task_id, created_at)`。
- `idx_file_changes_run_created(run_id, created_at)`。

### 6.13 `custom_models` P2

用途：保存用户本地自定义模型配置。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `id` | TEXT | string | PK | 自定义模型 ID。 |
| `user_id` | TEXT | string | NOT NULL, index | 所属用户。 |
| `provider` | TEXT | string | NOT NULL | provider 名。 |
| `base_url` | TEXT | string | nullable | 自定义 base URL。 |
| `model_name` | TEXT | string | NOT NULL | 模型名。 |
| `capabilities_json` | TEXT | struct/string | nullable | 能力描述。 |
| `encrypted_api_key` | TEXT | string | nullable | API key 密文。 |
| `created_at` | DATETIME | time.Time | NOT NULL | 创建时间。 |
| `updated_at` | DATETIME | time.Time | NOT NULL | 更新时间。 |
| `deleted_at` | DATETIME | gorm.DeletedAt | nullable, index | 软删时间。 |

索引：

- `idx_custom_models_user_updated(user_id, updated_at)`。
- `uniq_custom_models_user_provider_model(user_id, provider, base_url, model_name)`。

### 6.14 `installed_skills` P2

用途：保存本地已安装技能。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `id` | TEXT | string | PK | 安装记录 ID。 |
| `user_id` | TEXT | string | NOT NULL, index | 所属用户。 |
| `name` | TEXT | string | NOT NULL | 技能名。 |
| `version` | TEXT | string | NOT NULL | 版本。 |
| `path` | TEXT | string | NOT NULL | 本地安装路径。 |
| `enabled` | INTEGER | bool | NOT NULL, index | 是否启用。 |
| `permissions_json` | TEXT | struct/string | nullable | 权限声明。 |
| `risk_json` | TEXT | struct/string | nullable | 风险元数据。 |
| `created_at` | DATETIME | time.Time | NOT NULL | 创建时间。 |
| `updated_at` | DATETIME | time.Time | NOT NULL | 更新时间。 |
| `deleted_at` | DATETIME | gorm.DeletedAt | nullable, index | 软删时间。 |

索引：

- `idx_installed_skills_user_enabled(user_id, enabled)`。
- `uniq_installed_skills_user_path(user_id, path)`。

### 6.15 `local_skill_drafts` P2

用途：保存用户本地创建或生成中的技能草稿。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `id` | TEXT | string | PK | 草稿 ID。 |
| `user_id` | TEXT | string | NOT NULL, index | 所属用户。 |
| `name` | TEXT | string | NOT NULL | 草稿名。 |
| `manifest_json` | TEXT | struct/string | NOT NULL | skill manifest 草稿。 |
| `path` | TEXT | string | nullable | 本地草稿路径。 |
| `created_at` | DATETIME | time.Time | NOT NULL | 创建时间。 |
| `updated_at` | DATETIME | time.Time | NOT NULL | 更新时间。 |
| `deleted_at` | DATETIME | gorm.DeletedAt | nullable, index | 软删时间。 |

索引：

- `idx_local_skill_drafts_user_updated(user_id, updated_at)`。
- `idx_local_skill_drafts_user_path(user_id, path)`。

### 6.16 `local_experts` P2

用途：保存用户本地创建的专家。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `id` | TEXT | string | PK | 本地专家 ID。 |
| `user_id` | TEXT | string | NOT NULL, index | 所属用户。 |
| `name` | TEXT | string | NOT NULL | 专家名。 |
| `prompt` | TEXT | string | NOT NULL | 专家提示词。 |
| `skill_ids_json` | TEXT | []string/string | nullable | 绑定技能 ID 列表。 |
| `connector_policy_json` | TEXT | struct/string | nullable | 连接器策略。 |
| `created_at` | DATETIME | time.Time | NOT NULL | 创建时间。 |
| `updated_at` | DATETIME | time.Time | NOT NULL | 更新时间。 |
| `deleted_at` | DATETIME | gorm.DeletedAt | nullable, index | 软删时间。 |

索引：

- `idx_local_experts_user_updated(user_id, updated_at)`。

### 6.17 `automations` P2

用途：保存本地自动化配置。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `id` | TEXT | string | PK | 自动化 ID。 |
| `user_id` | TEXT | string | NOT NULL, index | 所属用户。 |
| `name` | TEXT | string | NOT NULL | 自动化名。 |
| `prompt` | TEXT | string | NOT NULL | 执行提示词。 |
| `schedule_json` | TEXT | struct/string | NOT NULL | 调度配置。 |
| `status` | TEXT | string | NOT NULL, index | `enabled`、`disabled`。 |
| `workspace_id` | TEXT | string | nullable, FK | 默认工作区。 |
| `model_id` | TEXT | string | nullable | 默认模型。 |
| `skill_ids_json` | TEXT | []string/string | nullable | 技能列表。 |
| `connector_ids_json` | TEXT | []string/string | nullable | 连接器列表。 |
| `created_at` | DATETIME | time.Time | NOT NULL | 创建时间。 |
| `updated_at` | DATETIME | time.Time | NOT NULL | 更新时间。 |
| `deleted_at` | DATETIME | gorm.DeletedAt | nullable, index | 软删时间。 |

索引：

- `idx_automations_user_status(user_id, status)`。
- `idx_automations_workspace(workspace_id)`。

### 6.18 `automation_runs` P2

用途：保存自动化执行历史。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `id` | TEXT | string | PK | 自动化 run ID。 |
| `automation_id` | TEXT | string | NOT NULL, FK, index | 自动化 ID。 |
| `task_id` | TEXT | string | nullable, FK, index | 关联任务 ID。 |
| `status` | TEXT | string | NOT NULL, index | `running`、`done`、`error`、`stopped`。 |
| `started_at` | DATETIME | *time.Time | nullable, index | 开始时间。 |
| `ended_at` | DATETIME | *time.Time | nullable | 结束时间。 |
| `error_json` | TEXT | struct/string | nullable | 错误快照。 |
| `created_at` | DATETIME | time.Time | NOT NULL | 创建时间。 |

索引：

- `idx_automation_runs_automation_started(automation_id, started_at)`。
- `idx_automation_runs_status_started(status, started_at)`。

### 6.19 `memories` P2

用途：保存本地记忆。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `id` | TEXT | string | PK | 记忆 ID。 |
| `user_id` | TEXT | string | NOT NULL, index | 所属用户。 |
| `content` | TEXT | string | NOT NULL | 记忆内容。 |
| `tags_json` | TEXT | []string/string | nullable | 标签。 |
| `enabled` | INTEGER | bool | NOT NULL, index | 是否启用。 |
| `source` | TEXT | string | NOT NULL | `manual`、`imported`、`generated`。 |
| `created_at` | DATETIME | time.Time | NOT NULL | 创建时间。 |
| `updated_at` | DATETIME | time.Time | NOT NULL | 更新时间。 |
| `deleted_at` | DATETIME | gorm.DeletedAt | nullable, index | 软删时间。 |

索引：

- `idx_memories_user_enabled_updated(user_id, enabled, updated_at)`。

### 6.20 `remote_sync_queue` P3

用途：保存需要上云的本地动作、审计、反馈和项目任务摘要。

| 字段 | SQLite | GORM | 约束 | 含义 |
| --- | --- | --- | --- | --- |
| `id` | TEXT | string | PK | 队列记录 ID。 |
| `user_id` | TEXT | string | NOT NULL, index | 所属用户。 |
| `domain` | TEXT | string | NOT NULL, index | 同步域。 |
| `action` | TEXT | string | NOT NULL | 远程动作。 |
| `payload_json` | TEXT | struct/string | NOT NULL | 同步 payload。 |
| `status` | TEXT | string | NOT NULL, index | `pending`、`running`、`done`、`failed`。 |
| `retry_count` | INTEGER | int | NOT NULL | 已重试次数。 |
| `next_retry_at` | DATETIME | *time.Time | nullable, index | 下次重试时间。 |
| `idempotency_key` | TEXT | string | nullable, index | 幂等键。 |
| `error_json` | TEXT | struct/string | nullable | 最近错误。 |
| `created_at` | DATETIME | time.Time | NOT NULL | 创建时间。 |
| `updated_at` | DATETIME | time.Time | NOT NULL | 更新时间。 |
| `completed_at` | DATETIME | *time.Time | nullable | 完成时间。 |

索引：

- `idx_remote_sync_queue_status_next_retry(status, next_retry_at)`。
- `idx_remote_sync_queue_domain_status(domain, status)`。
- `idx_remote_sync_queue_idempotency_key(idempotency_key)`。

## 7. 查询与索引策略

| 查询场景 | 主要索引 |
| --- | --- |
| 任务列表 | `idx_tasks_user_status_updated` |
| 工作区任务 | `idx_tasks_workspace_updated` |
| SSE 断线恢复 | `idx_run_events_task_created`、`idx_run_events_run_created` |
| run 内事件顺序 | `uniq_run_events_run_sequence` |
| 待审批动作 | `idx_runtime_actions_status_created` |
| 远程缓存读取 | `remote_cache.key` |
| 远程缓存批量失效 | `idx_remote_cache_domain_user_org` |
| 过期缓存扫描 | `idx_remote_cache_expires_at`、`idx_remote_cache_stale_at` |
| 同步队列 worker | `idx_remote_sync_queue_status_next_retry` |
| 自动化调度 | `idx_automations_user_status`、`idx_automation_runs_status_started` |

## 8. 约束策略

- 任务子表通过 `task_id` 关联 `tasks.id`。
- run 子表通过 `run_id` 关联 `task_runs.id`。
- 本地用户数据通过 `user_id` 做归属控制。
- 远程对象只保存远程 ID 或 payload 快照，不建立外键。
- 软删表默认查询必须排除 `deleted_at IS NOT NULL`。
- 高风险动作、同步队列、事件表不物理删除，优先保留审计记录。

## 9. 待确认项

| 项 | 影响 |
| --- | --- |
| 远程 token 加密落点使用 Keychain 还是本地加密字段 | `user_sessions` token 字段实现。 |
| 是否需要对 `memories.content` 建 FTS | 影响 P2 记忆搜索实现。 |
| 软删后是否允许同名/同路径重建 | 影响唯一约束是否需要部分索引。 |
| 远程同步队列最大重试次数 | 影响 `remote_sync_queue` worker 策略。 |
