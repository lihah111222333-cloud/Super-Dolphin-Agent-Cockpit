# AgentHost 产品说明书

整理日期：2026-06-22

| 项目 | 内容 |
| --- | --- |
| 产品名称 | AgentHost |
| 所属系统 | 桌面 Agent 应用 |
| 文档类型 | 产品说明书 |
| 当前状态 | 产品定义稿 |
| 核心职责 | 本地 HTTP REST/SSE 服务、AgentRuntime 编排入口、远程 API 代理、本地缓存与安全边界 |

## 0. 总体定义

`agent-host` 是桌面 Agent 应用唯一的本地项目主体。Host API、AgentRuntime、AgentRuntimeAdapter 不是三个并列项目，而是 `agent-host` 内部的三个核心需求域。

三个需求域可以分阶段建设，但必须服从同一套 AgentHost 项目边界、依赖顺序、阶段门禁和验收逻辑。

| 需求域 | 在 AgentHost 内的职责 | 不独立承担什么 |
| --- | --- | --- |
| Host API | 对 Electron 提供本地 HTTP REST/SSE，投影任务、事件、状态、审批和远程代理能力。 | 不直接调用 Codex JSON-RPC，不绕过 AgentRuntime 控制 runtime。 |
| AgentRuntime | 定义 AgentHost 内部统一 runtime 模型，包括 thread、turn、event、pending request、capability、error。 | 不暴露 HTTP/SSE，不实现具体后端协议。 |
| AgentRuntimeAdapter | 把具体 agent 后端接入 AgentRuntime。首版为 CodexRuntimeAdapter。 | 不定义产品 API，不替代 `codexapp-go`，不做动态插件系统。 |

统一依赖方向：

```text
Electron
  -> AgentHost Host API
  -> AgentRuntime
  -> CodexRuntimeAdapter
  -> codexapp-go
  -> Codex app-server
```

`codexapp-go` 不并入 AgentHost。它只作为 CodexRuntimeAdapter 的底层 SDK 依赖，继续保持纯 Go JSON-RPC client SDK 边界。

## 0.1 基础技术栈

AgentHost 采用轻量 Go 单体服务，不按微服务平台或高并发服务设计。

| 层 | 选型 |
| --- | --- |
| HTTP API | Gin |
| 事件流 | SSE |
| 本地存储 | SQLite |
| ORM | GORM |
| SQLite driver | `github.com/glebarez/sqlite` |
| 日志 | 标准库 `log/slog` |
| 配置 | `config.yaml` |
| 后台任务 | 进程内 goroutine + `context.Context` + SQLite 状态表 |

不使用 Redis、Kafka、PostgreSQL、独立队列系统和微服务拆分。详细取舍见 `../architecture/technology-stack.md`。

本文重点区分三类内容：

1. 无需后端接口，Electron 前端枚举/常量即可。
2. 本地 App 应用服务 API，由 Electron 薄前端调用本地服务端执行。
3. 远程端 API，必须由云端提供，但由本地 Go 服务请求，Electron 不直接请求远程 API。

注意：不要过度本地枚举化。凡是会运营配置、按账号权限变化、按版本动态更新、依赖市场内容或云端授权状态的内容，都不应硬编码在 Electron 前端。

## 1. 边界原则

### 1.1 三类边界

| 边界 | 放什么 | 不放什么 |
| --- | --- | --- |
| Electron 前端常量 | 固定枚举、纯 UI 展示、不会运营变化的文案 | 模型列表、专家中心、技能市场、灵感场景、连接器目录 |
| 本地 App 服务 API | 任务执行、文件系统、产物预览、本地配置、本地技能、本地自动化、权限确认、远程数据代理和缓存 | 直接暴露远程 refresh token 给 Electron |
| 远程端 API | 账号、项目、市场、专家中心、灵感、连接器 OAuth、云资料库、助理网关、计费 | 前端直连调用、前端持有远程 token |

### 1.2 Electron 前端职责

Electron 只做薄前端：

- 渲染 UI。
- 保存纯 UI 状态。
- 调用本地服务 API。
- 打开系统选择器、复制剪贴板、系统通知等轻量壳能力。
- 所有需要远程数据的页面也只调用本地服务，由本地服务代理远程 API 并处理缓存。

Electron 不直接：

- 执行 Agent Runtime。
- 读写任意本地文件内容。
- 执行 shell 命令。
- 保存第三方密钥明文。
- 直连第三方 OAuth 回调。
- 直接请求远程 API。
- 持有远程 refresh token。

### 1.3 本地服务职责

本地服务是桌面 Agent 的核心运行时：

- 管理本地任务、消息、run、event。
- 调度 Agent Runtime。
- 管理工作区和文件读写。
- 生成产物、diff、预览。
- 执行权限策略与高风险动作确认。
- 管理本地模型配置和 API Key。
- 安装、启停、卸载本地 Skill。
- 执行本地自动化调度。
- 使用 Go 实现远程 API 客户端，代理模型列表、专家中心、技能市场、灵感、连接器目录、自动化模板、套餐价格等动态数据。
- 使用 SQLite 缓存远程数据，并负责缓存刷新、过期降级和本地/远程数据合并。
- 保存远程 access token / refresh token，并向 Electron 签发本地 session token。

### 1.4 远程端职责

远程端负责所有需要账号、协作、运营、第三方网关或公网能力的部分。远程端是本地 Go 服务的上游，不是 Electron 的直接上游：

- 登录、设备、套餐、计费。
- 项目、成员、资产库、协作任务。
- 专家中心、技能市场、灵感案例。
- 连接器目录、OAuth 授权、云资料库。
- 远程助理平台网关。
- 分享文件的公网访问。

## 2. 本地服务通用约定

### 2.1 运行方式

本地服务可以是独立进程，也可以是 Electron 主进程启动的 sidecar。建议先实现 HTTP API，后续可替换为 IPC。

| 项 | 建议 |
| --- | --- |
| 监听地址 | `127.0.0.1:{randomPort}` |
| API 前缀 | `/api/local/v1` |
| 鉴权 | Electron 请求本地 API 时携带本地服务签发的 `local_session_token`；远程 access/refresh token 只由本地服务保存和使用 |
| 数据库 | SQLite |
| 事件流 | SSE 优先，路径 `GET /tasks/{taskId}/events` |
| 幂等 | 创建类接口支持 `Idempotency-Key` |
| 文件访问 | 所有文件读写必须经本地服务，Electron 不直接读写 |

### 2.2 登录和 token 策略

暂不考虑扫码登录。当前阶段采用“本地服务代理登录”的模式：

1. Electron 调用本地服务登录接口。
2. 本地服务请求远程用户系统。
3. 远程登录成功后返回短期 `access_token`、长期 `refresh_token` 和 `user` 信息。
4. 本地服务加密保存远程 token，并创建本地用户会话。
5. Electron 后续调用本地 API 只携带 `local_session_token`。
6. 本地服务访问远程 API 时使用远程 `access_token`；过期后用 `refresh_token` 刷新。

推荐 token 形态：

| token | 形态 | 保存位置 | 用途 |
| --- | --- | --- | --- |
| `access_token` | JWT，短期有效 | 本地服务加密保存 | 本地服务请求远程 API |
| `refresh_token` | opaque token，长期但可轮换 | 本地服务加密保存，不能暴露给 Electron renderer | 刷新远程 access token |
| `local_session_token` | 本地服务签发的短期 token | Electron 内存态保存 | Electron 调本地 API |

本地 API 即使只操作本地资源，也必须校验 `local_session_token`，并基于 token 中的 `userId` 校验任务、工作区、模型配置、技能和自动化归属。

本地登录 API：

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `POST` | `/auth/login` | `account`, `password` 或 `phone`, `code` | `user`, `localSessionToken`, `expiresAt` | 本地服务代理远程登录 |
| `POST` | `/auth/logout` | - | `ok=true` | 清理本地 session，可选择清理远程 token |
| `GET` | `/auth/session` | - | `user`, `expiresAt`, `remoteStatus` | 当前本地会话 |
| `POST` | `/auth/refresh-local` | - | `localSessionToken`, `expiresAt` | 刷新本地 session |

远程登录上游 API：

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `POST` | `/auth/login` | `account`, `password` 或 `phone`, `code` | `accessToken`, `refreshToken`, `user` | 远程用户系统登录 |
| `POST` | `/auth/refresh` | `refreshToken` | `accessToken`, `refreshToken?` | 刷新远程 token |

### 2.3 通用响应

```json
{
  "data": {},
  "error": null,
  "requestId": "req_xxx"
}
```

错误响应：

```json
{
  "data": null,
  "error": {
    "code": "VALIDATION_FAILED",
    "message": "workspacePath is required",
    "details": {}
  },
  "requestId": "req_xxx"
}
```

### 2.4 通用错误码

| code | 场景 |
| --- | --- |
| `UNAUTHORIZED` | 本地 session token 缺失或失效 |
| `FORBIDDEN` | 当前任务/路径/动作无权限 |
| `NOT_FOUND` | 任务、文件、产物等资源不存在 |
| `VALIDATION_FAILED` | 入参错误 |
| `RUNTIME_BUSY` | 当前任务已有 run 在执行 |
| `ACTION_APPROVAL_REQUIRED` | 工具调用被权限策略拦截，等待用户确认 |
| `ACTION_DENIED` | 用户拒绝高风险动作 |
| `MODEL_UNAVAILABLE` | 模型配置不可用或连通失败 |
| `SKILL_INSTALL_FAILED` | 技能安装失败 |
| `FILE_TOO_LARGE` | 文件超过读取/预览限制 |
| `PATH_OUTSIDE_WORKSPACE` | 默认权限下访问工作区外路径 |
| `REMOTE_TOKEN_EXPIRED` | 远程 access token 失效且 refresh 失败 |
| `REMOTE_UNAVAILABLE` | 远程 API 不可用，且没有可用缓存 |

### 2.5 分页和时间

| 项 | 约定 |
| --- | --- |
| 分页参数 | `cursor`, `limit` |
| 分页返回 | `items[]`, `nextCursor` |
| 时间格式 | ISO 8601 字符串 |
| ID 格式 | 使用稳定字符串 ID，例如 `task_`, `run_`, `evt_` 前缀 |

### 2.6 SSE 事件格式

```json
{
  "id": "evt_123",
  "type": "tool_call",
  "taskId": "task_123",
  "runId": "run_123",
  "createdAt": "2026-06-22T08:00:00Z",
  "payload": {
    "tool": "write_file",
    "summary": "写入分析报告",
    "riskLevel": "low"
  }
}
```

事件类型：

| type | 说明 |
| --- | --- |
| `message` | Agent 输出消息 |
| `stage` | 执行阶段变化 |
| `tool_call` | 准备调用工具 |
| `tool_result` | 工具调用结果 |
| `artifact_created` | 生成产物 |
| `file_changed` | 文件发生变化 |
| `approval_required` | 需要用户确认 |
| `done` | run 完成 |
| `error` | run 出错 |

## 3. 本地存储和目录

### 3.1 本地目录建议

| 目录 | 用途 |
| --- | --- |
| `~/AgentApp/tasks/{taskId}` | 未指定工作区时自动创建的任务工作区 |
| `~/AgentApp/data/app.db` | SQLite 数据库 |
| `~/AgentApp/uploads/{taskId}` | 任务上传附件 |
| `~/AgentApp/previews/{artifactId}` | 产物预览缓存 |
| `~/AgentApp/skills` | 已安装技能 |
| `~/AgentApp/models.json` | 自定义模型配置，API Key 加密 |
| `~/AgentApp/logs` | 本地服务日志 |

### 3.2 数据库设计入口

SQLite 表、字段、类型、索引、外键、唯一约束、软删策略、阶段归属和 GORM model 边界统一见 `../architecture/database-design.md`。

本产品说明书只保留存储产品语义：

- 远程动态数据由本地服务请求远程 API 后缓存，再返回给 Electron。
- 用户本地创建数据只保存在本机，不默认上云。
- 需要上云的动作由本地服务写入同步队列，再由后台 worker 使用远程 token 上传。
- Electron 不直接访问 SQLite，不直接持有远程 token。

### 3.3 远程数据缓存策略

模型列表、专家中心、技能市场、灵感场景、连接器目录、自动化模板、套餐价格等远程数据由本地 Go 服务代理和缓存。缓存 key、TTL、stale 窗口、索引和表结构以 `../architecture/database-design.md` 为准。

关键约束：

- 缓存只是远程数据副本，不是本地枚举。
- 价格、权益、权限类数据不能只依赖长期缓存；购买、扣费、权限判断前必须请求远程或使用极短 TTL。
- 远程返回下架、删除、禁用时，本地缓存不能继续展示成可用。

### 3.4 本地数据与远程数据合并

专家中心、技能市场等除了远程数据，还可能存在用户本地创建的数据。本地数据只存本机，不默认上云。

合并策略：

1. 远程数据标记 `source=remote`。
2. 本地用户创建数据标记 `source=local`。
3. 对 Electron 返回统一列表，但 ID 必须带来源前缀，避免冲突。
4. 排序上优先展示本地用户创建项，再展示远程推荐项，或按页面需求配置。

涉及的本地持久化结构见 `../architecture/database-design.md`。

### 3.5 用户动作上云同步队列

如果用户动作、运行审计、公共连接器调用日志等需要同步云端，必须由本地服务使用远程 `access_token` 上传。Electron 不直接同步。

同步策略、重试状态、索引和表结构见 `../architecture/database-design.md`。

需要 token 的场景：

| 场景 | 是否需要远程 token |
| --- | --- |
| Electron 调本地文件树 | 不需要远程 token，但需要本地 session token |
| 本地任务执行 | 不需要远程 token，但需要本地 session token |
| 同步动作记录到云端 | 需要远程 access token |
| 同步项目任务状态 | 需要远程 access token |
| 公共连接器审计上报 | 需要远程 access token |
| 查询模型/专家/技能/灵感远程列表 | 需要远程 access token，或匿名接口按产品策略放开 |

## 4. 本地核心对象模型

| 对象 | 说明 |
| --- | --- |
| `Task` | 一个对话和工作空间上下文。 |
| `TaskMessage` | 对话消息。 |
| `TaskRun` | 一次 Agent 执行。 |
| `RunEvent` | 执行过程事件。 |
| `Workspace` | 本地工作区。 |
| `ContextRef` | 本地文件、云资料或项目资产引用。 |
| `Artifact` | 任务产物。 |
| `FileChange` | 文件变更。 |
| `RuntimeAction` | 需要确认的动作。 |
| `CustomModel` | 自定义模型。 |
| `InstalledSkill` | 本地技能。 |
| `Automation` | 本地自动化。 |
| `Memory` | 本地记忆。 |

对象字段、数据库字段和 GORM model 边界见 `../architecture/database-design.md`。

## 5. 任务状态机与执行流程

### 5.1 任务状态

| 状态 | 含义 |
| --- | --- |
| `pending` | 已创建，尚未执行 |
| `planning` | Agent 正在生成计划 |
| `waiting_approval` | 等待用户确认计划或高风险动作 |
| `running` | 正在执行 |
| `stopped` | 用户中断 |
| `completed` | 完成 |
| `failed` | 失败 |
| `archived` | 已归档 |

状态流转：

```mermaid
stateDiagram-v2
  [*] --> pending
  pending --> planning
  planning --> waiting_approval
  waiting_approval --> running
  planning --> running
  running --> waiting_approval
  running --> completed
  running --> failed
  running --> stopped
  stopped --> running
  completed --> archived
  failed --> archived
```

### 5.2 Agent run 流程

1. 接收 `POST /tasks` 或 `POST /tasks/{taskId}/messages`。
2. 创建 `TaskRun`，状态为 `running` 或 `planning`。
3. 聚合上下文：用户输入、消息历史、附件、上下文引用、记忆、技能 manifest、专家快照。
4. 调用模型生成下一步计划或工具调用。
5. 工具调用先进入权限策略：
   - 低风险直接执行。
   - 高风险创建 `RuntimeAction`，推送 `approval_required` 事件，run 暂停。
6. 工具执行必须通过本地服务封装：文件服务、命令服务、预览服务、技能服务。
7. 工具结果写入事件流。
8. 文件写入后生成文件变更记录，符合规则的文件生成产物。
9. 结束时写入 `done` 或 `error` 事件，并更新 `TaskRun` 和 `Task` 状态。

### 5.3 任务模式策略

`ask / plan / craft` 是前端常量，但本地服务必须按字段执行策略。

| 模式 | 本地服务策略 |
| --- | --- |
| `ask` | 禁用写文件、删文件、执行命令、外部发送类工具；只允许读上下文和回答 |
| `plan` | 首轮只生成计划；用户确认后才执行写入/命令类动作 |
| `craft` | 可直接执行，但仍受权限策略拦截 |

## 6. 无需后端接口：Electron 前端常量/本地 UI 状态

以下内容从原接口文档中移除，不再作为后端 API 设计。

| 原接口/内容 | 处理方式 | 原因 |
| --- | --- | --- |
| `GET /task-modes` | 前端常量 | `ask / plan / craft` 是固定产品模式，展示说明可写在 Electron 前端 |
| `GET /permission-modes` | 前端常量 + 本地任务字段 | `default / full_access` 是固定枚举；真正需要接口的是高风险动作确认 |
| `deployment` 枚举 | 文档常量 | 仅用于架构说明，不需要运行时接口 |
| `taskStatus`, `runEventType`, `artifactType` 枚举 | 前后端共享 schema | 不需要独立 API，可由代码共享类型或 OpenAPI schema 生成 |
| 侧边栏展开/收起 | 前端状态 | 纯 UI |
| 右侧栏 Tab 切换 | 前端状态 | 纯 UI |
| 历史提问点击跳转 | 前端基于消息列表处理 | 不必单独提供 `/history-questions`，除非消息量大到需要后端聚合 |
| 打开 Finder/系统文件夹 | Electron 壳能力 | 本地 OS 操作，不走后端 API |
| 固定显示模式选项 | 前端常量 | 如简洁模式开关名称、字体大小选项 |
| 固定文件类型图标 | 前端常量 | doc/pdf/xlsx 等图标映射不需要后端 |
| 实践案例分类静态介绍 | 前端内容或远程 CMS 二选一 | 不为每个实践案例建后端模块 |

不要本地枚举化的内容：

| 内容 | 必须保留远程 API 的原因 |
| --- | --- |
| 模型列表 | 可运营增删、按账号套餐/地区/灰度变化 |
| 专家中心和专家分类 | 运营配置，可能按账号权限和企业版本变化 |
| 专家团 | 成员、流程、价格和权限可能动态更新 |
| 技能市场 | 市场内容、版本、安全状态动态变化 |
| 灵感场景和案例 | 运营内容，需搜索、精选、收藏 |
| 连接器目录 | 支持的连接器、授权方式、权限范围会变 |
| 项目模板 | 团队/行业模板可能运营更新 |
| 自动化模板 | 模板内容可运营更新 |
| 套餐/价格/Credits 规则 | 商业配置，必须远程 |

## 7. 本地 App 服务 API 总览

本地服务建议使用 `127.0.0.1` 随机端口或进程内 IPC 暴露。Electron 所有业务请求都访问本地服务，路径可统一使用 `/api/local/v1`。

| 功能域 | 本地 API 范围 |
| --- | --- |
| 任务执行 | 创建任务、继续对话、run、event stream、中断、恢复、重试 |
| 工作区和上下文 | 本地 workspace、附件、本地文件引用、上下文引用 |
| 文件和产物 | 文件树、文件内容、产物列表、产物预览、diff、网页预览 |
| 权限确认 | 待确认动作、批准、拒绝、运行时审计 |
| 本地模型 | 自定义模型、本地供应商、Key 加密、连通性测试、Auto 解析 |
| 远程数据代理 | 模型列表、专家中心、技能市场、灵感、连接器目录、自动化模板、套餐价格的本地代理和缓存 |
| 本地技能 | 上传、安装、扫描、启停、卸载、执行权限 |
| 自动化 | 本地调度、试运行、执行历史、日志 |
| 本地设置 | UI 偏好、默认工作目录、默认模型、默认权限、防休眠 |
| 本地数据管理 | 本地归档任务、未上传产物、缓存清理 |

## 8. 远程端 API 总览

远程 API 使用 `/api/v1`。远程 API 由本地 Go 服务调用，Electron 不直接调用。所有远程接口按账号鉴权，企业能力按组织/项目角色鉴权。

| 功能域 | 远程 API 范围 |
| --- | --- |
| 账号设备 | 登录、token、设备注册、心跳、套餐上下文 |
| 项目协作 | 项目、成员、邀请、审批、项目任务、任务分享、任务流转 |
| 项目资产 | 云资产上传、预览、配额、RAG 索引 |
| 专家中心 | 专家列表、分类、详情、专家团 |
| 技能市场 | 市场列表、技能详情、版本、风险元数据 |
| 灵感 | 场景、案例、收藏、制作同款 |
| 连接器 | 目录、OAuth、连接状态、公共授权、审计 |
| 云资料库 | 腾讯文档/ima/乐享等授权、搜索、引用、回写 |
| 远程助理 | 平台注册、消息回调、设备转发 |
| 分享 | 产物公网分享、取消分享、下载 |
| 计费 | 套餐、Credits、订单、发票、购买 |
| 反馈 | 意见反馈、日志附件上传 |

远程 API 响应除实时写操作外，优先进入本地缓存，再由本地 API 返回给 Electron。

## 9. 任务创建与执行

### 边界结论

- `ask / plan / craft` 模式枚举不需要接口，放 Electron 前端常量。
- 任务创建、执行、run、事件流必须走本地 App 服务。
- 如果任务属于云项目，云端只保存项目任务摘要、协作关系和必要同步状态；实际本地文件操作仍由本地服务执行。

### 本地 App 服务 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `POST` | `/tasks` | `prompt`, `mode`, `workspacePath`, `modelId`, `permissionMode`, `skillIds`, `expertIds`, `connectorIds`, `contextRefs`, `projectId` | `task`, `run` | 创建本地任务并启动首轮执行 |
| `GET` | `/tasks` | `q`, `status`, `dateFrom`, `dateTo`, `workspaceId`, `projectId`, `cursor`, `limit` | `tasks[]`, `nextCursor` | 本地任务列表 |
| `GET` | `/tasks/{taskId}` | - | `task`, `workspace`, `latestRun`, `summary` | 任务详情 |
| `PATCH` | `/tasks/{taskId}` | `title`, `pinned`, `archived`, `status` | `task` | 本地重命名、置顶、归档 |
| `DELETE` | `/tasks/{taskId}` | `deleteFiles=false` | `deleted=true` | 默认只删记录 |
| `POST` | `/tasks/{taskId}/messages` | `content`, `attachments`, `contextRefs`, `run=true` | `message`, `run` | 继续追问 |
| `GET` | `/tasks/{taskId}/messages` | `cursor`, `limit` | `messages[]`, `nextCursor` | 对话历史 |
| `GET` | `/tasks/{taskId}/runs` | `cursor`, `limit` | `runs[]` | 运行记录 |
| `GET` | `/runs/{runId}` | - | `run` | 运行详情 |
| `GET` | `/tasks/{taskId}/events` | `sinceEventId` | SSE stream | 执行事件流 |
| `GET` | `/runs/{runId}/events` | `cursor`, `limit` | `events[]` | 事件历史 |
| `GET` | `/tasks/{taskId}/steps` | `includeToolCalls` | `steps[]` | 展示中间步骤 |
| `POST` | `/tasks/{taskId}/stop` | `reason` | `run.status=stopped` | 中断执行 |
| `POST` | `/tasks/{taskId}/resume` | `message` | `run` | 继续执行 |
| `POST` | `/runs/{runId}/retry` | `fromEventId` 可选 | `run` | 失败重试 |

### 远程端 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `POST` | `/projects/{projectId}/tasks` | `prompt`, `metadata`, `localTaskId` | `projectTask` | 项目任务云端摘要，不替代本地执行 |
| `PATCH` | `/projects/{projectId}/tasks/{taskId}` | `status`, `title`, `summary` | `projectTask` | 同步项目任务状态 |

## 10. 工作空间、附件与上下文引用

### 边界结论

- 本地文件、工作区、附件暂存走本地服务。
- 云资料库文件、项目资产引用由本地服务代理远程端获取。
- 本地文件不默认上传云端。

### 本地 App 服务 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/workspaces` | `q`, `recent` | `workspaces[]` | 本地工作区列表 |
| `POST` | `/workspaces` | `name`, `path` | `workspace` | 登记/创建工作区 |
| `PATCH` | `/workspaces/{workspaceId}` | `name`, `path` | `workspace` | 修改工作区 |
| `DELETE` | `/workspaces/{workspaceId}` | `removeFiles=false` | `deleted=true` | 默认只移除记录 |
| `POST` | `/uploads` | `file`, `purpose=task_context` | `uploadId`, `fileMeta` | 本地任务附件 |
| `POST` | `/tasks/{taskId}/context-refs` | `refType`, `refId`, `provider`, `title` | `contextRef` | 添加本地文件或远程引用 |
| `GET` | `/tasks/{taskId}/context-refs` | - | `contextRefs[]` | 上下文列表 |
| `DELETE` | `/tasks/{taskId}/context-refs/{refId}` | - | `deleted=true` | 移除引用 |

### 远程端 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/projects/{projectId}/assets` | `q`, `fileType`, `cursor` | `assets[]` | 项目资产引用来源 |
| `GET` | `/knowledge-sources/{provider}/files` | `q`, `owner`, `spaceId`, `fileType`, `cursor` | `files[]` | 云资料库引用来源 |

## 11. 结果区：产物、文件、变更、预览

### 边界结论

- 文件树、文件内容、diff、预览转换走本地服务。
- 分享链接和云端下载由本地服务代理远程端。
- 产物回写云资料库是 Hybrid：本地读取产物，远程调用 provider。

### 本地 App 服务 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/tasks/{taskId}/artifacts` | `type`, `cursor` | `artifacts[]` | 本地产物列表 |
| `GET` | `/artifacts/{artifactId}` | - | `artifact` | 产物元数据 |
| `GET` | `/artifacts/{artifactId}/preview` | `format=html/image/text` | `preview` | 本地预览转换 |
| `GET` | `/artifacts/{artifactId}/download` | - | 文件流 | 本地产物下载 |
| `GET` | `/tasks/{taskId}/files/tree` | `path` | `nodes[]` | 工作区文件树 |
| `GET` | `/tasks/{taskId}/files/content` | `path`, `encoding` | `content`, `mime` | 工作区文件内容 |
| `GET` | `/tasks/{taskId}/changes` | `cursor` | `changes[]` | 变更列表 |
| `GET` | `/tasks/{taskId}/changes/{changeId}/diff` | - | `diff` | 文件差异 |
| `GET` | `/tasks/{taskId}/preview` | - | `url`, `status`, `server` | 本地网页预览 |
| `POST` | `/tasks/{taskId}/preview/refresh` | `previewId` | `status` | 刷新预览 |

### 远程端 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `POST` | `/artifacts/{artifactId}/share` | `expiresAt`, `accessScope` | `shareId`, `url` | 上传并生成公网分享 |
| `DELETE` | `/shared-files/{shareId}` | - | `deleted=true` | 取消分享 |
| `GET` | `/shared-files/{shareId}/download` | - | 文件流或 URL | 分享文件下载 |
| `POST` | `/artifacts/{artifactId}/upload-to-cloud` | `provider`, `targetFolderId`, `title` | `externalFile` | 产物回写云资料库 |

## 12. 权限确认与审计

### 边界结论

- `default / full_access` 模式说明不需要接口，前端常量即可。
- 运行时待确认动作、批准、拒绝必须是本地服务 API。
- 如果是项目公共连接器或云端协作任务，审计日志还要同步云端。

### 本地 App 服务 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/runtime-actions` | `taskId`, `status=pending` | `actions[]` | 待确认动作 |
| `GET` | `/runtime-actions/{actionId}` | - | `action` | 动作详情、风险原因、影响范围 |
| `POST` | `/runtime-actions/{actionId}/approve` | `rememberForRun=false` | `action.status=approved` | 批准 |
| `POST` | `/runtime-actions/{actionId}/deny` | `reason` | `action.status=denied` | 拒绝 |
| `GET` | `/audit/runtime-actions` | `taskId`, `riskLevel`, `cursor` | `logs[]` | 本地运行时审计 |

### 远程端 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `POST` | `/audit/runtime-actions` | `projectId`, `taskId`, `action`, `result` | `logId` | 项目/公共连接器审计同步 |
| `GET` | `/projects/{projectId}/connector-audit-logs` | `cursor`, `limit` | `logs[]` | 管理员查看公共授权连接器审计 |

## 13. 模型配置

### 边界结论

- 模型列表不要硬编码到 Electron；内置模型、可用模型、账号套餐可见性都应远程配置。
- Electron 请求本地模型 API；本地服务请求远程 API、写入本地缓存，再返回给 Electron。
- 本地自定义模型、Ollama、本地 API Key 由本地服务管理。
- 前端可以硬编码的只有模型能力图标的展示映射，不是模型清单。

### 本地 App 服务 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/models/built-in` | `forceRefresh=false` | `models[]`, `cache` | 本地代理远程模型清单，带 SQLite 缓存 |
| `GET` | `/models/providers` | `forceRefresh=false` | `providers[]`, `cache` | 本地代理远程供应商预设 |
| `GET` | `/models/entitlements` | `forceRefresh=false` | `modelIds[]`, `limits`, `cache` | 当前用户可用模型和限制 |
| `GET` | `/models/custom` | - | `models[]` | 本地自定义模型，不返回明文 Key |
| `POST` | `/models/custom` | `provider`, `baseUrl`, `apiKey`, `modelName`, `capabilities`, `customProtocol` | `model` | API Key 本地加密保存 |
| `PATCH` | `/models/custom/{modelId}` | 可选字段 | `model` | 编辑 |
| `DELETE` | `/models/custom/{modelId}` | - | `deleted=true` | 删除 |
| `POST` | `/models/custom/{modelId}/test` | `testPrompt` 可选 | `ok`, `latency`, `error` | 连通性测试 |
| `POST` | `/models/resolve` | `taskType`, `mode`, `capabilitiesNeeded` | `modelId`, `reason` | 本地 Auto 选型，基于远程模型缓存和本地自定义模型 |

### 远程端 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/models/built-in` | `appVersion`, `orgId` | `models[]`, `etag/version` | 动态内置模型清单，上游接口 |
| `GET` | `/models/providers` | `region`, `plan` | `providers[]`, `etag/version` | 供应商预设和能力标记，上游接口 |
| `GET` | `/models/entitlements` | - | `modelIds[]`, `limits`, `etag/version` | 当前账号可用模型和限制，上游接口 |

## 14. 技能 Skill

### 边界结论

- 技能市场、技能详情、版本和风险元数据来自远程端，但由本地服务代理和缓存后返回给 Electron。
- 本地技能包上传、安装、扫描、启停、卸载走本地服务。
- 自然语言查找/创建技能若依赖市场和模型生成，属于 Hybrid。
- 用户本地创建的技能草稿和本地上传的技能只存在本地，不上云。

### 本地 App 服务 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/skills/marketplace` | `q`, `category`, `cursor`, `forceRefresh=false` | `skills[]`, `cache` | 本地代理远程技能市场 |
| `GET` | `/skills/{skillId}` | - | `skill`, `versions`, `permissions`, `risk`, `source` | 远程技能走缓存，本地技能读 SQLite |
| `POST` | `/skills/{skillId}/install-package` | `version` | `installationJob` | 本地服务从远程获取包并安装 |
| `POST` | `/skills/find` | `taskDescription` | `matches[]`, `cache` | 本地服务请求远程查找 |
| `POST` | `/skills/generate` | `taskDescription`, `constraints` | `skillDraft` | 本地服务请求远程生成草稿后保存本地 |
| `POST` | `/skills/uploads` | `file` | `installationJob` | 上传本地技能包 |
| `GET` | `/skills/installations/{jobId}` | - | `status`, `riskReport` | 本地解包/扫描/安装状态 |
| `POST` | `/skills/installations/{jobId}/approve` | - | `status=installed` | 高风险安装确认 |
| `GET` | `/skills/installed` | `q`, `enabled` | `skills[]` | 已安装技能 |
| `GET` | `/skills/local-drafts` | `q`, `cursor` | `drafts[]` | 本地创建/生成的技能草稿 |
| `POST` | `/skills/local-drafts` | `name`, `manifest`, `files` | `draft` | 创建本地技能草稿，不上云 |
| `PATCH` | `/skills/local-drafts/{draftId}` | 可选字段 | `draft` | 编辑本地技能草稿 |
| `DELETE` | `/skills/local-drafts/{draftId}` | - | `deleted=true` | 删除本地技能草稿 |
| `PATCH` | `/skills/installed/{skillId}` | `enabled` | `skill` | 启用/关闭 |
| `DELETE` | `/skills/installed/{skillId}` | `removeData=false` | `deleted=true` | 卸载 |
| `POST` | `/skills/installed/bulk-delete` | `skillIds[]` | `deletedIds[]` | 批量卸载 |

### 远程端 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/skills/marketplace` | `q`, `category`, `cursor` | `skills[]` | 技能市场 |
| `GET` | `/skills/{skillId}` | - | `skill`, `versions`, `permissions`, `risk` | 市场技能详情 |
| `POST` | `/skills/{skillId}/install-package` | `version` | `downloadUrl`, `checksum` | 获取安装包，由本地服务下载/安装 |
| `POST` | `/skills/find` | `taskDescription` | `matches[]` | 查找技能 |
| `POST` | `/skills/generate` | `taskDescription`, `constraints` | `skillDraft` | 生成技能草稿 |

## 15. 专家与专家团

### 边界结论

- 专家中心、专家分类、专家团全部来自远程 API，不能本地硬编码。
- Electron 请求本地专家 API；本地服务代理远程 API、读取缓存，并合并用户本地创建专家。
- 用户本地创建的专家仅保存在本地，不上云。
- 召唤专家后的任务执行仍走本地任务 API。

### 本地 App 服务 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/experts/categories` | `forceRefresh=false` | `categories[]`, `cache` | 本地代理远程专家分类 |
| `GET` | `/experts` | `category`, `q`, `cursor`, `includeLocal=true`, `forceRefresh=false` | `experts[]`, `cache` | 合并远程专家和本地专家 |
| `GET` | `/experts/{expertId}` | - | `expert`, `source` | 远程专家读缓存，本地专家读 SQLite |
| `GET` | `/expert-teams` | `category`, `q`, `forceRefresh=false` | `teams[]`, `cache` | 本地代理远程专家团 |
| `GET` | `/expert-teams/{teamId}` | - | `team`, `members`, `workflow` | 专家团详情缓存 |
| `POST` | `/experts/{expertId}/summon-local` | `expertSnapshot?`, `prompt`, `workspacePath`, `modelId` | `task`, `run` | 使用远程或本地专家快照创建本地任务 |
| `GET` | `/my-experts/local` | `q`, `cursor` | `experts[]` | 本机私有专家 |
| `POST` | `/my-experts/local` | `name`, `prompt`, `skillIds`, `connectorPolicy` | `expert` | 创建本机专家，不上云 |
| `PATCH` | `/my-experts/local/{expertId}` | 可选字段 | `expert` | 编辑本机专家 |
| `DELETE` | `/my-experts/local/{expertId}` | - | `deleted=true` | 删除本机专家 |

### 远程端 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/experts/categories` | - | `categories[]`, `etag/version` | 专家分类，上游接口 |
| `GET` | `/experts` | `category`, `q`, `cursor` | `experts[]`, `etag/version` | 专家中心，上游接口 |
| `GET` | `/experts/{expertId}` | - | `expert`, `etag/version` | 专家详情和 prompt 策略快照，上游接口 |
| `GET` | `/expert-teams` | `category`, `q` | `teams[]`, `etag/version` | 专家团列表，上游接口 |
| `GET` | `/expert-teams/{teamId}` | - | `team`, `members`, `workflow`, `etag/version` | 专家团详情，上游接口 |

## 16. 连接器

### 边界结论

- 连接器目录、OAuth、授权状态、公共授权审计来自远程端，但 Electron 只能调用本地连接器 API。
- 本地服务代理远程连接器目录、详情、授权状态和 OAuth 发起接口，并把目录/状态摘要写入本地缓存。
- 个人连接器凭证如果是本地执行型，可加密存在本地；OAuth 回调和授权发起由远程网关处理，本地服务只保存授权结果快照。
- 自定义本地 MCP 连接器配置可由本地服务管理；项目级自定义连接器由本地服务代理远程端管理。
- 不开放任意 `/invoke` 给前端，具体调用由 Agent 工具层受控执行。

### 本地 App 服务 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/connectors/catalog` | `q`, `category`, `forceRefresh=false` | `connectors[]`, `cache` | 本地代理远程连接器目录 |
| `GET` | `/connectors/{connectorId}` | - | `connector`, `authMethods`, `scopes`, `cache` | 本地代理远程连接器详情 |
| `GET` | `/connector-connections` | `scope=personal/project`, `projectId`, `forceRefresh=false` | `connections[]`, `cache` | 本地代理远程授权状态，并合并本地连接 |
| `POST` | `/connectors/{connectorId}/auth/start` | `scope`, `projectId`, `redirectUri` | `authUrl`, `sessionId` | 本地服务请求远程 OAuth 发起 |
| `GET` | `/connectors/auth-sessions/{sessionId}` | - | `status`, `connection` | 本地服务查询远程授权状态并落库 |
| `GET` | `/connector-connections/{connectionId}/audit-logs` | `cursor`, `limit` | `logs[]` | 本地代理远程审计日志 |
| `PATCH` | `/connector-connections/{connectionId}` | `enabled` | `connection` | 本机启用/禁用 |
| `DELETE` | `/connector-connections/{connectionId}` | - | `deleted=true` | 本机断开 |
| `POST` | `/connectors/custom/local` | `name`, `mcpConfig` | `connector` | 本地自定义 MCP |
| `PATCH` | `/connectors/custom/local/{connectorId}` | `name`, `mcpConfig` | `connector` | 修改本地 MCP |
| `DELETE` | `/connectors/custom/local/{connectorId}` | - | `deleted=true` | 删除本地 MCP |
| `POST` | `/connectors/custom/project` | `name`, `mcpConfig`, `projectId` | `connector` | 本地服务代理远程创建项目级连接器 |
| `PATCH` | `/connectors/custom/project/{connectorId}` | `name`, `mcpConfig` | `connector` | 本地服务代理远程修改项目级连接器 |
| `DELETE` | `/connectors/custom/project/{connectorId}` | - | `deleted=true` | 本地服务代理远程删除项目级连接器 |
| `POST` | `/connectors/{connectorId}/test-local` | `connectionId` | `ok`, `error` | 本地连通测试 |

### 远程端 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/connectors/catalog` | `q`, `category` | `connectors[]` | 连接器目录，动态运营 |
| `GET` | `/connectors/{connectorId}` | - | `connector`, `authMethods`, `scopes` | 连接器详情 |
| `GET` | `/connector-connections` | `scope=personal/project`, `projectId` | `connections[]` | 云端授权状态 |
| `POST` | `/connectors/{connectorId}/auth/start` | `scope`, `projectId`, `redirectUri` | `authUrl`, `sessionId` | 发起 OAuth |
| `GET` | `/connectors/auth-sessions/{sessionId}` | - | `status`, `connection` | 查询授权状态 |
| `POST` | `/connectors/{connectorId}/auth/callback` | 第三方回调参数 | `ok=true` | OAuth 回调 |
| `POST` | `/connectors/{connectorId}/test` | `connectionId` | `ok`, `error` | 云端连通测试 |
| `GET` | `/connector-connections/{connectionId}/audit-logs` | `cursor`, `limit` | `logs[]` | 审计日志 |
| `POST` | `/connectors/custom` | `name`, `mcpConfig`, `scope`, `projectId` | `connector` | 项目级自定义连接器 |
| `PATCH` | `/connectors/custom/{connectorId}` | `name`, `mcpConfig` | `connector` | 修改项目级连接器 |
| `DELETE` | `/connectors/custom/{connectorId}` | - | `deleted=true` | 删除 |

## 17. 资料库

### 边界结论

- 腾讯文档、ima、乐享等云资料库来自远程 API，但 Electron 只调用本地资料库 API。
- 本地服务代理远程资料库授权、空间列表、文件搜索、文件详情，并对列表/搜索结果做短期缓存。
- 添加资料库文件到本地任务时，本地保存引用快照；执行时由本地服务按需通过远程端拉取内容或摘要。
- 产物回写云资料库由本地服务读取本地产物，再使用远程 token 调用远程端完成上传/创建。

### 本地 App 服务 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/knowledge-sources` | `forceRefresh=false` | `sources[]`, `cache` | 本地代理远程资料库来源 |
| `POST` | `/knowledge-sources/{provider}/auth/start` | `redirectUri` | `authUrl`, `sessionId` | 本地服务请求远程授权 |
| `DELETE` | `/knowledge-sources/{provider}/binding` | - | `deleted=true` | 本地服务代理远程解除绑定 |
| `GET` | `/knowledge-sources/{provider}/spaces` | `cursor`, `forceRefresh=false` | `spaces[]`, `cache` | 本地代理远程空间列表 |
| `GET` | `/knowledge-sources/{provider}/files` | `q`, `owner`, `spaceId`, `fileType`, `cursor`, `forceRefresh=false` | `files[]`, `cache` | 本地代理远程文件搜索 |
| `GET` | `/knowledge-sources/{provider}/files/{fileId}` | - | `file`, `preview`, `cache` | 本地代理远程文件详情 |
| `POST` | `/tasks/{taskId}/context-refs` | `provider`, `externalFileId`, `title`, `permissionSnapshot` | `contextRef` | 保存资料库引用到本地任务 |
| `GET` | `/tasks/{taskId}/context-refs` | - | `contextRefs[]` | 查看任务引用 |
| `POST` | `/artifacts/{artifactId}/upload-to-cloud` | `provider`, `targetFolderId`, `title` | `externalFile` | 本地读取产物并代理远程回写 |

### 远程端 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/knowledge-sources` | - | `sources[]` | 已接入资料库 |
| `POST` | `/knowledge-sources/{provider}/auth/start` | `redirectUri` | `authUrl`, `sessionId` | 授权 |
| `DELETE` | `/knowledge-sources/{provider}/binding` | - | `deleted=true` | 解除绑定 |
| `GET` | `/knowledge-sources/{provider}/spaces` | `cursor` | `spaces[]` | 空间/知识库列表 |
| `GET` | `/knowledge-sources/{provider}/files` | `q`, `owner`, `spaceId`, `fileType`, `cursor` | `files[]` | 搜索文件 |
| `GET` | `/knowledge-sources/{provider}/files/{fileId}` | - | `file`, `preview` | 文件详情 |
| `POST` | `/knowledge-sources/{provider}/files/{fileId}/references` | `taskId`, `deviceId` | `contextRefPayload` | 生成可下发给本地的引用载荷 |
| `POST` | `/artifacts/{artifactId}/upload-to-cloud` | `provider`, `targetFolderId`, `title`, `deviceId` | `externalFile` | 产物回写 |

## 18. 项目与团队协作

### 边界结论

- 项目、成员、邀请、审批、项目资产、项目配置属于远程数据，但 Electron 仍只调用本地项目 API。
- 本地服务代理远程项目 API，并缓存项目列表、项目详情、模板和成员摘要。
- 项目任务执行仍依赖本地设备；云端保存协作元数据和同步摘要。
- 项目资产是云数据，不在 Electron 前端硬编码。

### 本地 App 服务 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/projects` | `q`, `cursor`, `forceRefresh=false` | `projects[]`, `cache` | 本地代理远程项目列表 |
| `POST` | `/projects` | `name`, `instructions`, `connectorIds`, `skillIds`, `expertIds`, `templateId` | `project` | 本地服务代理远程创建项目 |
| `GET` | `/projects/{projectId}` | - | `project`, `cache` | 本地代理远程项目详情 |
| `PATCH` | `/projects/{projectId}` | `name`, `instructions` | `project` | 本地服务代理远程更新项目 |
| `DELETE` | `/projects/{projectId}` | - | `deleted=true` | 本地服务代理远程删除/退出 |
| `GET` | `/project-templates` | `scene`, `forceRefresh=false` | `templates[]`, `cache` | 本地代理远程项目模板 |
| `GET` | `/projects/{projectId}/activity` | `type`, `cursor` | `activities[]` | 本地代理远程项目动态 |
| `GET` | `/projects/{projectId}/members` | `role` | `members[]`, `cache` | 本地代理远程成员列表 |
| `POST` | `/projects/{projectId}/invites` | `role` | `inviteUrl`, `inviteId` | 本地服务代理远程邀请 |
| `POST` | `/project-invites/{inviteId}/apply` | `remark` | `requestId` | 本地服务代理远程申请加入 |
| `POST` | `/project-join-requests/{requestId}/approve` | `role` | `member` | 本地服务代理远程审批 |
| `POST` | `/project-join-requests/{requestId}/reject` | `reason` | `rejected=true` | 本地服务代理远程拒绝 |
| `GET` | `/projects/{projectId}/assets` | `q`, `fileType`, `cursor` | `assets[]`, `cache` | 本地代理远程项目资产 |
| `POST` | `/projects/{projectId}/assets` | `file`, `tags` | `asset` | 本地服务上传到远程项目资产 |
| `POST` | `/tasks` | `projectId`, `projectContextSnapshot`, 其他同任务创建 | `task`, `run` | 执行项目任务 |
| `PATCH` | `/tasks/{taskId}` | `status`, `summary` | `task` | 本地状态更新后可同步云端 |
| `POST` | `/projects/{projectId}/tasks/sync` | `localTaskId`, `status`, `summary` | `projectTask` | 本地服务同步项目任务摘要 |

### 远程端 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/projects` | `q`, `cursor` | `projects[]` | 我的项目 |
| `POST` | `/projects` | `name`, `instructions`, `connectorIds`, `skillIds`, `expertIds`, `templateId` | `project` | 创建 |
| `GET` | `/projects/{projectId}` | - | `project` | 详情 |
| `PATCH` | `/projects/{projectId}` | `name`, `instructions` | `project` | 更新 |
| `DELETE` | `/projects/{projectId}` | - | `deleted=true` | 删除/退出 |
| `GET` | `/project-templates` | `scene` | `templates[]` | 动态项目模板 |
| `GET` | `/projects/{projectId}/activity` | `type`, `cursor` | `activities[]` | 项目动态 |
| `GET` | `/projects/{projectId}/members` | `role` | `members[]` | 成员 |
| `POST` | `/projects/{projectId}/invites` | `role` | `inviteUrl`, `inviteId` | 邀请 |
| `POST` | `/project-invites/{inviteId}/apply` | `remark` | `requestId` | 申请加入 |
| `POST` | `/project-join-requests/{requestId}/approve` | `role` | `member` | 审批 |
| `POST` | `/project-join-requests/{requestId}/reject` | `reason` | `rejected=true` | 拒绝 |
| `POST` | `/projects/{projectId}/tasks` | `prompt`, `deviceId`, `metadata` | `projectTask`, `dispatch` | 创建项目任务并下发设备 |
| `GET` | `/projects/{projectId}/tasks` | `q`, `status`, `cursor` | `tasks[]` | 项目任务列表 |
| `PATCH` | `/projects/{projectId}/tasks/{taskId}` | `status`, `summary`, `localTaskId` | `projectTask` | 同步任务摘要 |
| `POST` | `/tasks/{taskId}/collaborators` | `memberIds`, `role` | `collaborators[]` | 分享任务 |
| `POST` | `/tasks/{taskId}/handoffs` | `assigneeId`, `title`, `description`, `status`, `dueAt`, `attachments` | `handoff` | 任务流转 |
| `POST` | `/handoffs/{handoffId}/accept` | `targetProjectId` | `task` | 接收流转 |

### 项目资产远程 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/projects/{projectId}/assets` | `q`, `fileType`, `cursor` | `assets[]` | 资产列表 |
| `POST` | `/projects/{projectId}/assets` | `file`, `tags` | `asset` | 上传资产 |
| `GET` | `/projects/{projectId}/assets/{assetId}` | - | `asset`, `preview` | 资产详情 |
| `DELETE` | `/projects/{projectId}/assets/{assetId}` | - | `deleted=true` | 删除 |
| `GET` | `/projects/{projectId}/assets/quota` | - | `usedBytes`, `limitBytes` | 配额 |
| `POST` | `/artifacts/{artifactId}/save-to-project-assets` | `projectId`, `folderId`, `deviceId` | `asset` | 产物保存为项目资产 |

## 19. 助理与远程任务

### 边界结论

- 平台接入、回调验签、消息网关必须远程，但 Electron 只调用本地助理 API。
- 暂不实现扫码绑定类业务。
- 远程消息最终下发到本地服务执行。
- 助理专属 workspace、助理会话本地副本由本地服务保存。

### 本地 App 服务 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/assistant/settings` | - | `enabled`, `workspacePath`, `bindingsCache` | 本地助理设置 |
| `PATCH` | `/assistant/settings` | `enabled`, `workspacePath` | `settings` | 更新本地设置 |
| `GET` | `/assistant/integrations` | `forceRefresh=false` | `integrations[]`, `cache` | 本地代理远程平台接入状态 |
| `POST` | `/assistant/integrations/{platform}/register` | 平台凭据、`mode` | `integration`, `webhookUrl` | 本地服务代理远程注册平台 |
| `DELETE` | `/assistant/integrations/{platform}` | - | `deleted=true` | 本地服务代理远程解绑 |
| `GET` | `/assistant/session/messages` | `cursor` | `messages[]` | 本地助理会话 |
| `POST` | `/assistant/session/messages` | `content`, `sourcePlatform`, `remoteMessageId` | `message`, `task` | 远程消息落地并执行 |
| `GET` | `/assistant/tasks` | `cursor`, `status` | `tasks[]` | 本地远程任务 |
| `GET` | `/assistant/tasks/{taskId}/events` | `sinceEventId` | event stream | 远程任务执行进度 |

### 远程端 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/assistant/integrations` | - | `integrations[]` | 平台状态 |
| `POST` | `/assistant/integrations/{platform}/register` | 平台凭据、`mode`, `deviceId` | `integration`, `webhookUrl` | 企微/飞书/钉钉/QQ/元宝等注册 |
| `DELETE` | `/assistant/integrations/{platform}` | - | `deleted=true` | 解绑 |
| `POST` | `/assistant/callbacks/{platform}` | 第三方消息体 | `ok=true` | 消息/卡片/事件回调 |
| `POST` | `/assistant/dispatch` | `deviceId`, `platform`, `message` | `dispatchId` | 云端下发本地设备 |
| `POST` | `/assistant/replies` | `platform`, `remoteConversationId`, `content`, `attachments` | `sent=true` | 本地执行结果回传平台 |

## 20. 自动化

### 边界结论

- 本地个人自动化调度走本地服务。
- 自动化模板如果会运营更新，由本地服务代理远程端并缓存；不要硬编码在 Electron。
- 项目自动化配置由本地服务代理远程端，但触发执行仍可下发到本地设备。

### 本地 App 服务 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/automation-templates` | `scene`, `forceRefresh=false` | `templates[]`, `cache` | 本地代理远程自动化模板 |
| `GET` | `/automations` | `status`, `cursor` | `automations[]` | 本地自动化列表 |
| `POST` | `/automations` | `name`, `prompt`, `schedule`, `workspacePath`, `modelId`, `skillIds`, `connectorIds`, `pushToMiniProgram` | `automation` | 创建本地自动化 |
| `GET` | `/automations/{automationId}` | - | `automation` | 详情 |
| `PATCH` | `/automations/{automationId}` | 可选字段、`status` | `automation` | 编辑/启停 |
| `DELETE` | `/automations/{automationId}` | - | `deleted=true` | 删除 |
| `POST` | `/automations/{automationId}/run-now` | - | `run` | 试运行 |
| `GET` | `/automations/{automationId}/runs` | `cursor` | `runs[]` | 历史执行 |
| `GET` | `/automation-runs/{runId}` | - | `run`, `task` | 单次执行 |
| `GET` | `/automation-runs/{runId}/logs` | `cursor` | `logs[]` | 日志 |
| `GET` | `/projects/{projectId}/automations` | `status`, `cursor` | `automations[]` | 本地代理远程项目自动化 |
| `POST` | `/projects/{projectId}/automations` | `name`, `prompt`, `schedule`, `deviceId`, `connectorIds` | `automation` | 本地服务代理远程创建项目自动化 |
| `PATCH` | `/projects/{projectId}/automations/{automationId}` | 可选字段、`status` | `automation` | 本地服务代理远程编辑/启停 |
| `DELETE` | `/projects/{projectId}/automations/{automationId}` | - | `deleted=true` | 本地服务代理远程删除 |

### 远程端 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/automation-templates` | `scene` | `templates[]` | 动态模板 |
| `GET` | `/projects/{projectId}/automations` | `status`, `cursor` | `automations[]` | 项目自动化 |
| `POST` | `/projects/{projectId}/automations` | `name`, `prompt`, `schedule`, `deviceId`, `connectorIds` | `automation` | 创建项目自动化配置 |
| `PATCH` | `/projects/{projectId}/automations/{automationId}` | 可选字段、`status` | `automation` | 编辑/启停 |
| `DELETE` | `/projects/{projectId}/automations/{automationId}` | - | `deleted=true` | 删除 |

## 21. 灵感

### 边界结论

- 灵感场景、案例、精选、收藏来自远程 API，但 Electron 只调用本地灵感 API。
- 本地服务代理远程灵感接口，并对场景、列表、详情做 SQLite 缓存。
- 不能把灵感场景写死在 Electron；这是运营配置。
- “制作我的版本”生成任务草稿后，本地服务负责执行。

### 本地 App 服务 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/inspirations/categories` | `forceRefresh=false` | `categories[]`, `cache` | 本地代理远程灵感场景 |
| `GET` | `/inspirations` | `q`, `category`, `featured`, `cursor`, `forceRefresh=false` | `items[]`, `cache` | 本地代理远程案例列表 |
| `GET` | `/inspirations/{inspirationId}` | - | `inspiration`, `promptTemplate`, `skillIds`, `expertIds`, `cache` | 本地代理远程案例详情 |
| `POST` | `/inspirations/{inspirationId}/favorite` | - | `favorited=true` | 本地服务代理远程收藏 |
| `DELETE` | `/inspirations/{inspirationId}/favorite` | - | `favorited=false` | 本地服务代理远程取消收藏 |
| `POST` | `/inspirations/{inspirationId}/clone` | `overrides` | `draftId`, `draft` | 本地服务读取远程载荷并创建本地草稿 |
| `POST` | `/tasks/drafts` | `prompt`, `skillIds`, `expertIds`, `connectorIds`, `source=inspiration` | `draftId`, `draft` | 根据远程灵感载荷创建本地草稿 |
| `POST` | `/tasks/drafts/{draftId}/run` | `overrides` | `task`, `run` | 执行草稿 |

### 远程端 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/inspirations/categories` | - | `categories[]` | 动态场景 |
| `GET` | `/inspirations` | `q`, `category`, `featured`, `cursor` | `items[]` | 案例列表 |
| `GET` | `/inspirations/{inspirationId}` | - | `inspiration`, `promptTemplate`, `skillIds`, `expertIds` | 案例详情 |
| `POST` | `/inspirations/{inspirationId}/favorite` | - | `favorited=true` | 收藏 |
| `DELETE` | `/inspirations/{inspirationId}/favorite` | - | `favorited=false` | 取消收藏 |
| `POST` | `/inspirations/{inspirationId}/clone` | `mode=draft`, `deviceId`, `overrides` | `taskDraftPayload` | 生成可下发本地的草稿载荷 |

## 22. 记忆

### 边界结论

- 如果产品要跨设备个性化，记忆由本地服务代理远程端同步。
- 如果产品强调本地隐私，可只走本地服务。
- 不建议 Electron 前端直接保存记忆内容；至少走本地服务，便于检索、删除和注入上下文。

### 本地 App 服务 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/memory/settings` | - | `enabled`, `lastGeneratedAt`, `storage=local/cloud` | 记忆设置 |
| `PATCH` | `/memory/settings` | `enabled` | `settings` | 开关 |
| `GET` | `/memories` | `q`, `cursor` | `memories[]` | 本地记忆 |
| `POST` | `/memories` | `content`, `tags` | `memory` | 新增 |
| `PATCH` | `/memories/{memoryId}` | `content`, `tags`, `enabled` | `memory` | 编辑 |
| `DELETE` | `/memories/{memoryId}` | - | `deleted=true` | 删除 |
| `POST` | `/memories/import` | `content`, `source` | `imported[]` | 导入 |
| `GET` | `/memories/search` | `q`, `limit` | `memories[]` | 执行前检索 |

### 远程端 API

远程记忆使用同名路径即可，仅在启用云同步或多端一致时开放：

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| `GET/PATCH` | `/memory/settings` | 云端记忆设置 |
| `GET/POST/PATCH/DELETE` | `/memories` | 云端记忆 CRUD |
| `POST` | `/memories/import` | 云端导入 |
| `GET` | `/memories/search` | 云端检索 |

## 23. 系统设置

### 边界结论

- 固定选项说明放前端常量。
- 设置值持久化走本地服务。
- 账号级设置才需要远程同步。

### 本地 App 服务 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/settings/system` | - | `language`, `fontSize`, `displayMode`, `compactMode` | 系统设置值 |
| `PATCH` | `/settings/system` | 可选字段 | `settings` | 更新 |
| `GET` | `/settings/security` | - | `autoInstallLowRiskSkill`, `preventSleep`, `defaultPermissionMode` | 安全与运行设置 |
| `PATCH` | `/settings/security` | 可选字段 | `settings` | 更新 |
| `GET` | `/settings/task-defaults` | - | `mode`, `modelId`, `workspacePath`, `permissionMode` | 新建任务默认值 |
| `PATCH` | `/settings/task-defaults` | 可选字段 | `settings` | 更新默认值 |

## 24. 数据管理与反馈

### 边界结论

- 已归档本地任务走本地服务。
- 已分享文件、反馈、日志上传由本地服务代理远程端。

### 本地 App 服务 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/data/archived-tasks` | `cursor` | `tasks[]` | 本地归档任务 |
| `POST` | `/data/archived-tasks/{taskId}/restore` | - | `task` | 取消归档 |
| `DELETE` | `/data/archived-tasks/{taskId}` | `deleteFiles=false` | `deleted=true` | 删除归档 |
| `POST` | `/feedback/log-bundles` | `includeLogs`, `includeConfig` | `bundleId`, `redactionSummary` | 本地打包并脱敏日志 |
| `GET` | `/data/shared-files` | `cursor`, `forceRefresh=false` | `files[]`, `cache` | 本地代理远程分享文件列表 |
| `POST` | `/data/shared-files/{shareId}/copy-link` | - | `url` | 本地服务代理远程刷新分享链接 |
| `GET` | `/data/shared-files/{shareId}/download` | - | 文件流或 URL | 本地服务代理远程下载 |
| `DELETE` | `/data/shared-files/{shareId}` | - | `deleted=true` | 本地服务代理远程取消分享 |
| `POST` | `/feedback` | `content`, `uploadLogs`, `attachmentIds`, `logBundleId` | `feedbackId` | 本地服务上传反馈和脱敏日志 |
| `POST` | `/feedback/{feedbackId}/attachments` | `file` | `attachment` | 本地服务代理远程附件上传 |

### 远程端 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/data/shared-files` | `cursor` | `files[]` | 我分享的文件 |
| `POST` | `/data/shared-files/{shareId}/copy-link` | - | `url` | 复制/刷新分享链接 |
| `GET` | `/data/shared-files/{shareId}/download` | - | 文件流或 URL | 下载 |
| `DELETE` | `/data/shared-files/{shareId}` | - | `deleted=true` | 取消分享 |
| `POST` | `/feedback` | `content`, `uploadLogs`, `attachmentIds`, `logBundleId` | `feedbackId` | 提交反馈 |
| `POST` | `/feedback/{feedbackId}/attachments` | `file` | `attachment` | 附件上传 |

## 25. 账号、套餐、积分、账单、发票

### 边界结论

账号、套餐、积分、账单、发票都来自远程端，但 Electron 只调用本地账号/计费 API。本地服务负责远程登录、token 刷新、设备注册、套餐价格缓存和计费查询代理。Electron 不保存套餐规则，不硬编码价格，不本地计算最终扣费。

登录接口以第 2.2 节为准，暂不实现扫码登录。

### 本地 App 服务 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/account/me` | `forceRefresh=false` | `user`, `org`, `plan`, `roles`, `cache` | 本地代理远程账号信息 |
| `POST` | `/auth/login` | `account`, `password` 或 `phone`, `code` | `user`, `localSessionToken`, `expiresAt` | 本地服务代理远程登录 |
| `POST` | `/auth/logout` | - | `ok=true` | 清理本地 session 和可选远程 token |
| `GET` | `/auth/session` | - | `user`, `expiresAt`, `remoteStatus` | 当前本地会话 |
| `POST` | `/auth/refresh-local` | - | `localSessionToken`, `expiresAt` | 刷新本地 session |
| `POST` | `/devices/register` | `deviceName`, `platform`, `appVersion`, `localAgentVersion` | `deviceId` | 本地服务代理远程设备注册 |
| `PATCH` | `/devices/{deviceId}/heartbeat` | `status`, `localEndpointVersion` | `serverTime` | 本地服务代理远程心跳 |
| `GET` | `/devices` | `forceRefresh=false` | `devices[]`, `cache` | 本地代理远程设备列表 |
| `DELETE` | `/devices/{deviceId}` | - | `deleted=true` | 本地服务代理远程解绑设备 |
| `GET` | `/plans` | `audience=personal/enterprise`, `forceRefresh=false` | `plans[]`, `cache` | 本地代理远程套餐价格，短 TTL |
| `GET` | `/credits/balance` | `forceRefresh=true` | `balance`, `packages[]` | 本地代理远程积分余额 |
| `GET` | `/credits/usage` | `dateFrom`, `dateTo`, `cursor` | `usage[]` | 本地代理远程用量 |
| `GET` | `/orders` | `cursor` | `orders[]` | 本地代理远程订单 |
| `GET` | `/invoices` | `cursor` | `invoices[]`, `externalConsoleUrl` | 本地代理远程发票 |
| `POST` | `/checkout/packages` | `packageId`, `quantity` | `checkoutUrl`, `orderId` | 本地服务代理远程购买 |

### 远程端 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/account/me` | - | `user`, `org`, `plan`, `roles` | 当前账号 |
| `POST` | `/auth/login` | `account`, `password` 或 `phone`, `code` | `accessToken`, `refreshToken`, `user` | 远程用户系统登录 |
| `POST` | `/auth/refresh` | `refreshToken` | `accessToken` | 刷新 |
| `POST` | `/devices/register` | `deviceName`, `platform`, `appVersion`, `localAgentVersion` | `deviceId`, `deviceToken` | 设备注册 |
| `PATCH` | `/devices/{deviceId}/heartbeat` | `status`, `localEndpointVersion` | `serverTime` | 设备心跳 |
| `GET` | `/devices` | - | `devices[]` | 设备列表 |
| `DELETE` | `/devices/{deviceId}` | - | `deleted=true` | 解绑设备 |
| `GET` | `/plans` | `audience=personal/enterprise` | `plans[]` | 套餐 |
| `GET` | `/credits/balance` | - | `balance`, `packages[]` | 余额 |
| `GET` | `/credits/usage` | `dateFrom`, `dateTo`, `cursor` | `usage[]` | 用量 |
| `POST` | `/usage/ledger` | `taskId`, `runId`, `modelTokens`, `credits`, `source` | `ledgerId` | 服务端内部记账 |
| `GET` | `/orders` | `cursor` | `orders[]` | 订单 |
| `GET` | `/invoices` | `cursor` | `invoices[]`, `externalConsoleUrl` | 发票 |
| `POST` | `/checkout/packages` | `packageId`, `quantity` | `checkoutUrl`, `orderId` | 购买 |

## 26. 最小落地边界

| 阶段 | 本地服务必须有 | 本地服务上游远程 API 必须有 | 前端常量即可 |
| --- | --- | --- | --- |
| P0 | 本地 session、任务、消息、run、events、工作区、文件树、产物、diff、权限确认、本地模型配置 | 登录、token 刷新、设备注册、账号信息 | taskMode、permissionMode、基础状态枚举、UI 文案 |
| P1 | 本地远程数据代理缓存、本地技能安装、自动化、本地连接器配置、本地记忆 | 模型列表、技能市场、连接器目录、自动化模板、云资料库授权、套餐价格 | 固定图标和能力 badge 映射 |
| P2 | 项目任务本地执行、项目上下文快照 | 项目、成员、资产库、分享、流转、公共连接器审计 | 项目页静态布局 |
| P3 | 助理本地会话、远程任务落地 | 助理网关、专家中心、灵感、计费、反馈 | 固定空状态文案 |

## 27. 从原文档移除/调整的接口

| 原接口 | 调整结果 |
| --- | --- |
| `GET /task-modes` | 移除，前端常量 |
| `GET /permission-modes` | 移除，前端常量；保留 runtime action APIs |
| `GET /tasks/{taskId}/history-questions` | 移除，先由前端基于消息列表聚合 |
| Electron 直连远程 API | 移除；统一改为 Electron -> 本地 Go 服务 -> 远程 API |
| 扫码登录/扫码绑定相关接口 | 暂不实现 |
| `GET /models/built-in` 的 Local 归属 | 保留本地 API，但语义改为本地代理远程 + SQLite 缓存 |
| `GET /models/providers` 的 Local 归属 | 保留本地 API，但语义改为本地代理远程；本地另管 custom/Ollama 配置 |
| `GET /automation-templates` 的 Local 归属 | 保留本地 API，但语义改为本地代理远程，避免模板运营时发版 |
| 专家分类、灵感分类 | 保留本地代理 API，数据源为远程，不本地枚举 |
| 连接器目录 | 保留本地代理 API，数据源为远程，不本地枚举 |
| 任意连接器 invoke | 保持不开放给前端 |
