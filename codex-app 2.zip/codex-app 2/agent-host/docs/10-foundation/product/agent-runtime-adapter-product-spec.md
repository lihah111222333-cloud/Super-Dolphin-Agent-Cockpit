# AgentRuntimeAdapter 产品说明书

| 项目 | 内容 |
| --- | --- |
| 产品名称 | AgentRuntimeAdapter |
| 所属产品 | AgentHost |
| 产品形态 | AgentHost 内部 runtime 适配实现单元 |
| 文档类型 | 产品说明书 |
| 文档版本 | v0.1 |
| 日期 | 2026-06-22 |
| 当前状态 | 产品定义稿 |
| 首版实现 | CodexRuntimeAdapter |
| 首版底层 SDK | `codexapp-go` |
| 主要使用方 | AgentRuntime、AgentHost runtime 接入模块 |
| 上游依赖 | 具体 agent 后端 SDK 或协议客户端 |
| 下游消费者 | AgentHost 内部模块，不直接面向 Electron |
| 参考文档 | `agent-runtime-product-spec.md`、`../architecture/agent-runtime-technical-architecture.md`、`../../../../codexapp-go/docs/10-foundation/product/codexapp-go-product-spec.md` |

## 1. 产品定义

`AgentRuntimeAdapter` 是 AgentHost 内部用于接入具体 agent 后端的适配实现单元。它把某个后端的 SDK、协议、事件、错误和交互请求翻译成 AgentHost 统一的 `AgentRuntime` 模型。

首版 `AgentRuntimeAdapter` 是 `CodexRuntimeAdapter`。它通过 `codexapp-go` 调用 Codex app-server，并把 Codex 的 thread、turn、notification、server request 和 error 映射为 AgentHost 可消费的统一模型。

`AgentRuntimeAdapter` 不是独立产品，不是独立进程，不是通用 SDK，不直接暴露 HTTP API，也不直接面向 Electron。它是具体 runtime 后端进入 AgentHost 的最薄翻译层。

```mermaid
flowchart TB
  Electron["Electron 桌面客户端"]
  AgentHost["AgentHost 本地宿主/承载层"]
  Runtime["AgentRuntime 抽象"]
  Adapter["AgentRuntimeAdapter"]
  SDK["后端 SDK / 协议客户端"]
  Backend["Agent 后端"]

  Electron -->|"HTTP REST / SSE"| AgentHost
  AgentHost --> Runtime
  Runtime --> Adapter
  Adapter --> SDK
  SDK --> Backend
  Backend --> SDK
  SDK --> Adapter
  Adapter --> Runtime
  Runtime --> AgentHost
```

在 Go 实现上，首版不需要单独发明一个 `AgentRuntimeAdapter` 接口。具体 adapter 直接实现 `AgentRuntime` 即可。

```text
AgentRuntime interface
  CodexRuntimeAdapter implements AgentRuntime
    codexapp-go
      Codex app-server
```

## 2. 产品定位

### 2.1 一句话定位

`AgentRuntimeAdapter` 是把具体 agent 后端接入 AgentHost 的翻译层。

### 2.2 核心价值

- 隔离 AgentHost 与具体 agent 后端协议。
- 避免 Codex、OtherAgent 等后端专属类型泄漏到 AgentHost 上层。
- 让不同后端都能映射到统一的 thread、turn、event、pending request、capability 和 error 模型。
- 保持底层 SDK 纯粹，只做协议和基础调用，不承载 AgentHost 产品语义。
- 降低未来接入非 Codex agent 后端的成本。

### 2.3 产品边界

| 维度 | 是什么 | 不是什么 |
| --- | --- | --- |
| 产品形态 | AgentHost 内部适配实现 | 独立服务、插件市场、外部 SDK |
| 主要职责 | 翻译具体后端能力到 AgentRuntime 模型 | 定义 AgentHost 产品逻辑 |
| 实现方式 | 每个后端一个 adapter | 一个大而全的通用 adapter |
| 首版范围 | CodexRuntimeAdapter | 多 runtime 动态切换系统 |
| 对上依赖 | `AgentRuntime` 统一模型 | Electron UI 模型 |
| 对下依赖 | 具体后端 SDK 或协议客户端 | AgentHost HTTP API |

## 3. 背景与问题

AgentHost 需要接入 agent 后端。首版后端是 Codex app-server，未来可能接入其他 agent 后端。

如果 AgentHost 上层直接依赖具体后端 SDK，会产生以下问题：

- HTTP API 和 SSE 事件会被某个后端协议绑定。
- 后端事件命名、错误模型、审批模型会扩散到 AgentHost 各模块。
- 未来接入第二个 agent 后端时，需要改动大量业务代码。
- 底层 SDK 可能被迫加入 AgentHost 产品语义。
- 测试边界不清，协议问题、翻译问题、产品问题混在一起。

`AgentRuntimeAdapter` 的存在是为了把这些变化收敛到一个具体实现单元中。

## 4. 设计原则

| 原则 | 说明 |
| --- | --- |
| 一个后端一个 adapter | Codex 用 CodexRuntimeAdapter，OtherAgent 用 OtherAgentRuntimeAdapter。 |
| adapter 只翻译 | 不实现后端协议底层通信，不做 AgentHost 产品策略。 |
| SDK 保持基础 | 后端 SDK 只提供基础调用和事件订阅。 |
| 统一模型对上 | adapter 对 AgentHost 只输出 AgentRuntime 模型。 |
| raw 可诊断 | 保留底层 raw 摘要，但不让 raw 成为上层业务依赖。 |
| capability 表达差异 | 后端能力差异通过 capability 暴露，不污染核心接口。 |
| 首版不抽 registry | 只有 Codex 一个后端时硬编码即可。 |

## 5. 产品目标

### 5.1 核心目标

- 定义具体 agent 后端接入 AgentHost 的适配边界。
- 支持首版 CodexRuntimeAdapter 接入 Codex app-server。
- 将后端 thread/session 概念映射为 AgentRuntime thread。
- 将后端 turn/run/job 概念映射为 AgentRuntime turn。
- 将后端事件映射为 `RuntimeEvent`。
- 将后端审批、输入、工具调用等交互请求映射为 `PendingRequest`。
- 将后端错误映射为 `RuntimeError`。
- 声明 runtime capability，支持 AgentHost 判断能力是否可用。
- 保留 raw 信息，支持诊断和协议兼容。
- 为未来 OtherAgentRuntimeAdapter 提供一致接入模式。

### 5.2 质量目标

- AgentHost 上层不直接引用具体后端 SDK 类型。
- adapter 不重复实现底层 SDK 已经提供的通信能力。
- adapter 映射逻辑可单独测试。
- 后端事件读取不能被 AgentHost 慢消费者阻塞。
- pending request 必须可追踪、可恢复、可幂等响应。
- 不支持的能力必须明确返回 capability error。
- 错误必须保留底层 cause。

### 5.3 非目标

- 不提供 Electron API。
- 不提供 HTTP REST API。
- 不提供 SSE 序列化。
- 不做 UI 状态投影。
- 不做持久化数据库。
- 不做 runtime registry。
- 不做动态 adapter 加载。
- 不做远程 worker 调度。
- 不自研 agent loop。
- 不替代 `codexapp-go` 或未来 OtherAgent SDK。
- 不在首版支持多个 runtime 并行运行。

## 6. 目标用户与使用场景

### 6.1 目标用户

| 用户 | 需求 |
| --- | --- |
| AgentHost runtime 开发者 | 接入具体 agent 后端并保持上层模型稳定。 |
| CodexRuntimeAdapter 开发者 | 使用 `codexapp-go` 映射 Codex app-server 能力。 |
| OtherAgentRuntimeAdapter 开发者 | 用薄 SDK 快速接入非 Codex 后端。 |
| AgentRuntime 维护者 | 确保 adapter 不污染统一模型。 |
| 测试和诊断开发者 | 在 adapter 边界定位协议、映射和运行错误。 |

### 6.2 核心使用场景

| 场景 | Adapter 输入 | Adapter 输出 |
| --- | --- | --- |
| 查询 runtime 信息 | 后端版本、配置、握手结果 | `RuntimeInfo` |
| 创建 thread | `StartThreadRequest` | `ThreadRef` |
| 启动 turn | `StartTurnRequest` | `TurnRef` |
| 取消 turn | `CancelTurnRequest` | nil 或 `RuntimeError` |
| 接收后端事件 | SDK notification/event | `RuntimeEvent` |
| 处理审批请求 | SDK server request/input request | `PendingRequest` |
| 回复 pending request | `RuntimeResponse` | 后端 request response |
| 映射错误 | SDK error/protocol error | `RuntimeError` |

## 7. 架构边界

### 7.1 AgentRuntimeAdapter 与 AgentRuntime

`AgentRuntime` 定义 AgentHost 需要什么能力。`AgentRuntimeAdapter` 说明某个具体后端如何提供这些能力。

| 维度 | AgentRuntime | AgentRuntimeAdapter |
| --- | --- | --- |
| 类型 | 统一能力契约 | 具体后端实现 |
| 关注点 | thread、turn、event、pending、capability、error | 后端 SDK/protocol 到统一模型的映射 |
| 稳定性 | 面向 AgentHost 稳定 | 随后端协议变化调整 |
| 依赖 | 不依赖具体 SDK | 依赖具体 SDK |
| 数量 | 一个统一抽象 | 每个后端一个 adapter |

### 7.2 AgentRuntimeAdapter 与 CodexRuntimeAdapter

`CodexRuntimeAdapter` 是首版 `AgentRuntimeAdapter` 的具体实现。

| 能力 | AgentRuntimeAdapter 通用要求 | CodexRuntimeAdapter 首版要求 |
| --- | --- | --- |
| 后端 SDK | 依赖具体 SDK | 依赖 `codexapp-go` |
| thread 映射 | 后端会话映射为 thread | Codex thread 映射为 thread |
| turn 映射 | 后端执行单元映射为 turn | Codex turn 映射为 turn |
| 事件映射 | 后端事件映射为 RuntimeEvent | Codex notification 映射为 RuntimeEvent |
| request 映射 | 后端交互请求映射为 PendingRequest | Codex server request 映射为 PendingRequest |
| 错误映射 | 后端错误映射为 RuntimeError | Codex/JSON-RPC/transport error 映射为 RuntimeError |

### 7.3 AgentRuntimeAdapter 与 codexapp-go

`codexapp-go` 是 Codex app-server 的基础 SDK。`CodexRuntimeAdapter` 使用它，但不替代它。

| 能力 | codexapp-go | CodexRuntimeAdapter |
| --- | --- | --- |
| JSON-RPC transport | 负责 | 不负责 |
| request id 匹配 | 负责 | 不负责 |
| Codex 协议类型 | 负责 | 使用 |
| notification 订阅 | 负责 | 消费并翻译 |
| server request 回复机制 | 负责 | 映射为 PendingRequest 并调用回复 |
| AgentRuntime 模型 | 不负责 | 负责映射 |
| AgentHost capability | 不负责 | 负责声明 |

### 7.4 AgentRuntimeAdapter 与 AgentHost 上层

Adapter 不直接服务 Electron。AgentHost 上层负责 HTTP、SSE、状态投影、持久化和用户交互。

| 能力 | Adapter | AgentHost 上层 |
| --- | --- | --- |
| HTTP 路由 | 不负责 | 负责 |
| SSE payload | 不负责 | 负责 |
| UI 状态投影 | 不负责 | 负责 |
| pending request 持久化 | 不负责 | 负责 |
| 用户审批策略 | 不负责 | 负责 |
| 底层 request 翻译 | 负责 | 不负责 |

## 8. 核心概念模型

### 8.1 Adapter Identity

每个 adapter 必须有稳定身份。

| 字段 | 说明 |
| --- | --- |
| `adapter_id` | AgentHost 内部 adapter id，例如 `codex`。 |
| `runtime_kind` | runtime 类型，例如 `codex`、`other_agent`。 |
| `display_name` | 诊断和设置页展示名。 |
| `version` | adapter 版本或后端 SDK 版本。 |
| `backend_version` | 后端 runtime 版本，可空。 |

### 8.2 Provider SDK

Provider SDK 是 adapter 的下游依赖。

首版：

```text
CodexRuntimeAdapter -> codexapp-go -> Codex app-server
```

未来：

```text
OtherAgentRuntimeAdapter -> OtherAgent SDK -> OtherAgent backend
```

SDK 只负责基础通信和协议类型。adapter 负责产品模型翻译。

### 8.3 Mapping

Mapping 是 adapter 的核心工作。

| 映射类型 | 说明 |
| --- | --- |
| request mapping | AgentRuntime request -> 后端 SDK request。 |
| result mapping | 后端 SDK result -> AgentRuntime ref/model。 |
| event mapping | 后端 event -> `RuntimeEvent`。 |
| pending mapping | 后端 request -> `PendingRequest`。 |
| response mapping | `RuntimeResponse` -> 后端 response。 |
| error mapping | 后端 error -> `RuntimeError`。 |
| capability mapping | 后端能力 -> AgentRuntime capability。 |

### 8.4 Raw

Raw 是底层信息摘要，用于诊断和兼容。

Raw 规则：

- Raw 可以保存到 `RuntimeEvent.Raw`、`PendingRequest.Raw`、`RuntimeError.Raw`。
- Raw 不直接展示给普通用户。
- Raw 不作为 AgentHost 上层业务逻辑判断依据。
- Raw 必须经过脱敏策略控制。

## 9. 功能范围

### 9.1 MVP 范围

首版只实现 `CodexRuntimeAdapter`。

必须覆盖：

- 初始化 Codex runtime。
- 读取 Codex runtime info。
- 声明 Codex capabilities。
- 创建 thread。
- 启动 turn。
- 取消 turn。
- 订阅 Codex notifications。
- 映射基础 thread/turn lifecycle event。
- 映射 assistant message、delta、command、file change、tool call event。
- 映射 Codex server request 为 PendingRequest。
- 通过 `codexapp-go` 回复 Codex server request。
- 映射 Codex transport/protocol/runtime error。
- 保留 raw 摘要供诊断。

### 9.2 后续范围

- OtherAgentRuntimeAdapter。
- 更完整的 capability 映射。
- 更细粒度的模型选择能力。
- 更细粒度的 permission profile 映射。
- event replay 能力适配。
- runtime 诊断面板字段补充。

### 9.3 明确不在当前范围

- 动态 adapter 注册。
- adapter 插件市场。
- 外部 adapter 进程。
- 多 runtime 热切换。
- 同一个 turn 同时跑多个 runtime。
- 跨 runtime thread 迁移。
- 把 adapter 发布为外部 SDK。

## 10. 通用能力要求

### 10.1 Info

Adapter 必须提供 runtime 基础信息。

输出：

- runtime id。
- runtime kind。
- display name。
- adapter version。
- backend version。
- health。
- capabilities。
- raw diagnostic summary。

### 10.2 StartThread

Adapter 必须把 `StartThreadRequest` 映射为后端会话创建能力。

要求：

- 校验 workspace path 已由 AgentHost 处理，但 adapter 仍要拒绝空值或不支持值。
- 不支持模型选择时返回 `capability_unsupported`。
- 返回 AgentRuntime `ThreadRef`。
- 保留底层 thread/session id 映射。

### 10.3 StartTurn

Adapter 必须把 `StartTurnRequest` 映射为后端执行能力。

要求：

- thread id 必须可映射到底层后端 id。
- 输入 payload 必须符合后端要求。
- 后端不支持追加输入时返回明确错误。
- 返回 AgentRuntime `TurnRef`。

### 10.4 CancelTurn

Adapter 必须把 `CancelTurnRequest` 映射为后端取消、interrupt 或 abort 能力。

要求：

- 后端支持取消时调用后端取消。
- 后端不支持取消时返回 `capability_unsupported`。
- 重复取消应尽量幂等。

### 10.5 Events

Adapter 必须输出统一 runtime event。

要求：

- 事件必须包含稳定 event id。
- 同一 thread/turn 内尽量保持顺序。
- 状态事件不可随意丢弃。
- 高频 delta 可以合并。
- 底层 reader 不得被慢消费者阻塞。

### 10.6 Respond

Adapter 必须支持对 pending request 的一次性响应。

要求：

- request id 必须存在。
- response decision 必须匹配 request type。
- 重复响应必须幂等或明确 conflict。
- adapter 负责把 response 翻译为后端 SDK response。

## 11. Capability 要求

### 11.1 基础 capability

| capability | 说明 |
| --- | --- |
| `thread.start` | 支持创建 thread。 |
| `thread.resume` | 支持恢复 thread。 |
| `turn.start` | 支持启动 turn。 |
| `turn.cancel` | 支持取消 turn。 |
| `event.stream` | 支持事件流。 |
| `event.replay` | 支持事件回放。 |
| `approval.command` | 支持命令审批。 |
| `approval.file_change` | 支持文件变更审批。 |
| `approval.permission` | 支持权限审批。 |
| `input.user` | 支持用户输入请求。 |
| `tool.call` | 支持工具调用事件。 |
| `model.select` | 支持模型选择。 |
| `workspace.fs` | 支持工作目录和文件事件。 |

### 11.2 Capability 规则

- Adapter 必须声明真实支持的能力。
- AgentHost 可以用 capability 控制 API 和 UI。
- Adapter 执行前仍必须校验 capability。
- 不支持能力返回 `capability_unsupported`。
- 不得为了某个后端新增大量核心接口。

## 12. 事件映射要求

### 12.1 基础事件

| RuntimeEvent | Adapter 映射来源 |
| --- | --- |
| `thread.created` | 后端会话创建成功。 |
| `thread.updated` | 后端会话元信息变化。 |
| `turn.started` | 后端执行开始。 |
| `turn.delta` | 后端流式输出或推理增量。 |
| `turn.message` | 后端消息事件。 |
| `turn.tool_call.started` | 工具调用开始。 |
| `turn.tool_call.updated` | 工具调用更新。 |
| `turn.tool_call.finished` | 工具调用结束。 |
| `turn.command.started` | 命令执行开始。 |
| `turn.command.output` | 命令输出。 |
| `turn.command.finished` | 命令执行结束。 |
| `turn.file_change` | 文件变更。 |
| `turn.waiting_for_input` | 等待审批或用户输入。 |
| `turn.completed` | 执行成功完成。 |
| `turn.failed` | 执行失败。 |
| `turn.cancelled` | 执行取消。 |
| `runtime.health_changed` | runtime 健康状态变化。 |

### 12.2 事件缺失处理

如果后端不提供某类事件：

- 不伪造精确事件。
- 可以通过 capability 表达不支持。
- 可以用更粗粒度事件映射，但必须保留 raw。
- 不允许让 AgentHost 上层依赖后端专属事件补洞。

## 13. PendingRequest 映射要求

### 13.1 请求类型

| PendingRequest 类型 | 后端来源 |
| --- | --- |
| `approval.command` | 命令执行审批请求。 |
| `approval.file_change` | 文件写入或修改审批请求。 |
| `approval.permission` | 权限、sandbox 或工具权限请求。 |
| `input.user` | 用户输入请求。 |
| `tool.dynamic_call` | 动态工具调用请求。 |
| `auth.refresh` | 认证刷新请求。 |

### 13.2 创建要求

Adapter 创建 PendingRequest 时必须提供：

- request id。
- runtime id。
- thread id。
- turn id。
- request type。
- title。
- summary。
- structured payload。
- raw payload。
- idempotency key。

### 13.3 响应要求

Adapter 处理 RuntimeResponse 时必须：

- 验证 request id。
- 验证 decision。
- 验证 payload。
- 调用底层 SDK response。
- 返回成功、失败或 conflict。
- 不自动 approve。

## 14. 错误映射要求

### 14.1 错误分类

| RuntimeError code | Adapter 映射来源 |
| --- | --- |
| `runtime_unavailable` | 后端不可用、初始化失败。 |
| `capability_unsupported` | 后端不支持该能力。 |
| `invalid_request` | AgentRuntime request 无法映射。 |
| `permission_denied` | 后端拒绝、用户拒绝或权限不足。 |
| `turn_failed` | 后端执行失败。 |
| `transport_error` | SDK transport 错误。 |
| `protocol_error` | SDK protocol 错误。 |
| `internal_error` | adapter 映射或状态错误。 |

### 14.2 错误规则

- 错误必须保留底层 cause。
- 错误必须带稳定 code。
- retryable 必须明确。
- 用户可展示文案由 AgentHost 上层决定，adapter 可提供摘要。
- raw error 默认只用于诊断。

## 15. CodexRuntimeAdapter 首版说明

### 15.1 定位

`CodexRuntimeAdapter` 是 Codex app-server 的 AgentRuntimeAdapter 实现。它依赖 `codexapp-go`，不直接手写 JSON-RPC。

```text
CodexRuntimeAdapter
  -> codexapp-go
    -> Codex app-server
```

### 15.2 主要职责

- 调用 `codexapp-go` 初始化 Codex app-server。
- 调用 `codexapp-go` 创建 thread。
- 调用 `codexapp-go` 启动 turn。
- 调用 `codexapp-go` 取消 turn。
- 订阅 `codexapp-go` notification。
- 将 Codex notification 映射为 RuntimeEvent。
- 将 Codex server request 映射为 PendingRequest。
- 调用 `codexapp-go` 回复 server request。
- 将 Codex error 映射为 RuntimeError。
- 声明 Codex capabilities。

### 15.3 不负责

- 不实现 JSON-RPC transport。
- 不复制 Codex protocol generated types。
- 不管理 Electron。
- 不生成 SSE payload。
- 不保存 thread UI 投影。
- 不保存 pending request 持久化状态。
- 不自动批准审批。

## 16. OtherAgentRuntimeAdapter 未来说明

未来接入 OtherAgent 时，必须新增对应 adapter。

```text
OtherAgentRuntimeAdapter
  -> OtherAgent SDK
    -> OtherAgent backend
```

要求：

- OtherAgent SDK 保持薄，只封装基础调用。
- OtherAgentRuntimeAdapter 实现 AgentRuntime。
- 后端 session/run/job 映射为 thread/turn。
- 后端 event 映射为 RuntimeEvent。
- 后端 interaction request 映射为 PendingRequest。
- 后端 error 映射为 RuntimeError。
- 不修改 Electron API。
- 不修改 `codexapp-go`。

## 17. 数据所有权

| 数据 | 权威来源 | Adapter 是否持久化 |
| --- | --- | --- |
| 后端原始 thread/session id | 后端 SDK | 不持久化，可返回映射信息 |
| AgentRuntime thread id | AgentHost/Adapter 映射 | 不持久化，交给 AgentHost |
| 后端 turn/run/job id | 后端 SDK | 不持久化 |
| RuntimeEvent | Adapter 翻译 | 不持久化 |
| PendingRequest | Adapter 创建，AgentHost 保存 | 不持久化 |
| Capability | Adapter 声明 | 可缓存 |
| Raw payload | SDK/后端 | 不持久化，交给诊断模块处理 |

原则：

- Adapter 不拥有产品状态。
- AgentHost 拥有 UI 投影和 pending 状态。
- 后端 runtime 拥有执行事实。
- SDK 拥有协议事实。

## 18. 安全与权限边界

Adapter 处于 AgentHost 内部，但仍必须处理不可信输入和不可信后端数据。

必须遵守：

- 不自动 approve。
- 不绕过 AgentHost 权限策略。
- 不把 raw 直接展示给用户。
- 不把底层 token 写入普通日志。
- 不把后端路径、命令、环境变量未经脱敏写入诊断信息。
- 不接受不属于当前 runtime/thread/turn 的 response。

AgentHost 上层负责：

- HTTP 请求校验。
- workspace path 校验。
- 用户审批策略。
- pending 状态持久化。
- 日志脱敏和落盘。

## 19. 可观测性与诊断

Adapter 必须提供足够信息帮助定位问题。

### 19.1 最小诊断字段

| 字段 | 说明 |
| --- | --- |
| `adapter_id` | adapter id。 |
| `runtime_id` | runtime id。 |
| `runtime_kind` | runtime 类型。 |
| `backend_version` | 后端版本。 |
| `capabilities` | 当前能力列表。 |
| `health` | 当前健康状态。 |
| `last_error` | 最近错误摘要。 |

### 19.2 最小计数

| 计数 | 说明 |
| --- | --- |
| `events_mapped_total` | 已映射事件数。 |
| `events_dropped_total` | 丢弃或合并事件数。 |
| `pending_created_total` | 创建 pending request 数。 |
| `pending_responded_total` | 已响应 pending request 数。 |
| `errors_mapped_total` | 映射错误数。 |

Adapter 不决定指标系统和日志落盘位置。

## 20. 验收标准

### 20.1 文档验收

- 明确 AgentRuntimeAdapter 是具体后端适配实现单元。
- 明确 CodexRuntimeAdapter 是首版实现。
- 明确 Adapter 与 AgentRuntime、SDK、AgentHost 上层的边界。
- 明确不做 registry、插件系统、HTTP/SSE、持久化。
- 明确未来 OtherAgentRuntimeAdapter 接入方式。

### 20.2 实现验收

- CodexRuntimeAdapter 通过 `codexapp-go` 调用 Codex app-server。
- CodexRuntimeAdapter 实现 AgentRuntime。
- AgentRuntime 包不依赖 `codexapp-go`。
- AgentHost HTTP handler 不引用 Codex protocol 类型。
- Codex notification 能映射为 RuntimeEvent。
- Codex server request 能映射为 PendingRequest。
- RuntimeResponse 能通过 `codexapp-go` 回复 Codex server request。
- Codex error 能映射为 RuntimeError。
- 不支持能力返回 `capability_unsupported`。

### 20.3 扩展验收

- 新增 OtherAgentRuntimeAdapter 时，不修改 Electron API。
- 新增 OtherAgentRuntimeAdapter 时，不修改 `codexapp-go`。
- 新增 OtherAgentRuntimeAdapter 时，只新增对应 SDK 和 adapter。
- 不把 OtherAgent 专属字段加入 AgentRuntime 核心模型。

## 21. 风险与对策

| 风险 | 影响 | 对策 |
| --- | --- | --- |
| Adapter 变成第二个 SDK | 重复协议逻辑，维护成本高 | Adapter 只用 SDK，不重写 SDK 能力。 |
| Adapter 泄漏后端类型 | AgentHost 被具体后端绑定 | 对上只输出 AgentRuntime 模型。 |
| AgentRuntime 抽象过大 | 每个 adapter 实现困难 | 差异走 capability，不扩核心接口。 |
| pending request 丢失 | 用户审批无法恢复 | AgentHost 持久化 pending，adapter 只创建和回复。 |
| raw 信息滥用 | UI 依赖底层协议 | raw 只用于诊断，不作业务判断。 |
| 过早 registry | 首版复杂度上升 | 首版硬编码 CodexRuntimeAdapter。 |

## 22. 开放问题

| 问题 | 默认决策 |
| --- | --- |
| 是否需要单独 `AgentRuntimeAdapter` 接口 | 首版不需要，adapter 直接实现 `AgentRuntime`。 |
| 是否支持多个 adapter 同时启用 | 首版不支持。 |
| 是否需要 adapter registry | 首版不需要。 |
| Adapter 是否持久化 id 映射 | 首版不持久化，交给 AgentHost 状态层。 |
| OtherAgent SDK 是否必须开源或独立发布 | 不要求，先按内部薄 SDK 处理。 |
| 后端不支持 thread/turn 概念怎么办 | adapter 必须映射为 thread/turn，否则不能接入 AgentHost。 |

## 23. 最终边界声明

`AgentRuntimeAdapter` 是 AgentHost 内部面向具体 agent 后端的适配实现单元。它负责把后端 SDK、协议、事件、请求和错误翻译为 AgentRuntime 统一模型。

`CodexRuntimeAdapter` 是首版实现，必须通过 `codexapp-go` 接入 Codex app-server，不重复实现 JSON-RPC。

`AgentRuntime` 是上层统一契约，`AgentRuntimeAdapter` 是具体实现，底层 SDK 是基础协议能力。三者不能混成一个包。

首版只实现 CodexRuntimeAdapter，不做 registry、插件系统或动态加载。第二个真实 runtime 开始接入时，再增加最小必要的 factory 或 registry。
