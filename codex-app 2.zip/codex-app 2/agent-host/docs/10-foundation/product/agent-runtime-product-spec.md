# AgentRuntime 产品说明书

| 项目 | 内容 |
| --- | --- |
| 产品名称 | AgentRuntime |
| 所属产品 | AgentHost |
| 产品形态 | AgentHost 内部 runtime 抽象能力 |
| 文档类型 | 产品说明书 |
| 文档版本 | v0.1 |
| 日期 | 2026-06-22 |
| 当前状态 | 产品定义稿 |
| 主要使用方 | AgentHost HTTP API、事件投影、状态聚合、审批处理模块 |
| 上游实现 | CodexRuntime Adapter、未来 OtherAgentRuntime Adapter |
| 下游消费者 | AgentHost 内部模块，不直接面向 Electron |
| 参考依赖 | `codexapp-go`、Codex app-server、未来 OtherAgent SDK |

## 1. 产品定义

`AgentRuntime` 是 AgentHost 内部面向 agent 后端的统一能力抽象。它不是独立进程，不是 HTTP 服务，不是 SDK，也不是 Electron 可直接调用的 API。

AgentHost 通过 `AgentRuntime` 创建 thread、启动 turn、取消 turn、订阅 runtime 事件、处理审批和用户输入请求。具体 agent 后端由 runtime adapter 实现，例如首版的 `CodexRuntime Adapter` 使用 `codexapp-go` 接入 Codex app-server。

`AgentRuntime` 的核心作用是把 AgentHost 的产品能力和具体 agent 后端隔离：

```mermaid
flowchart TB
  Electron["Electron 桌面客户端"]
  AgentHost["AgentHost 本地宿主/承载层"]
  Runtime["AgentRuntime 抽象"]
  CodexAdapter["CodexRuntime Adapter"]
  CodexSDK["codexapp-go"]
  CodexServer["Codex app-server"]
  OtherAdapter["OtherAgentRuntime Adapter"]
  OtherSDK["OtherAgent SDK"]
  OtherBackend["OtherAgent 后端"]

  Electron -->|"HTTP REST / SSE"| AgentHost
  AgentHost --> Runtime
  Runtime --> CodexAdapter
  CodexAdapter --> CodexSDK
  CodexSDK --> CodexServer
  Runtime -. "未来" .-> OtherAdapter
  OtherAdapter -. "薄 SDK" .-> OtherSDK
  OtherSDK -.-> OtherBackend
```

## 2. 产品定位

### 2.1 一句话定位

`AgentRuntime` 是 AgentHost 内部用于接入不同 agent 后端的最小稳定能力契约。

### 2.2 核心价值

- 隔离 Electron 与具体 agent runtime 的协议差异。
- 隔离 AgentHost 产品逻辑与 Codex app-server JSON-RPC 细节。
- 为未来接入非 Codex agent 后端保留稳定边界。
- 让 AgentHost 的 thread、turn、事件、审批、错误和能力发现拥有统一模型。
- 避免把 Codex 专属概念扩散到 AgentHost 的 HTTP API、SSE 事件和状态投影中。

### 2.3 产品边界

| 维度 | 是什么 | 不是什么 |
| --- | --- | --- |
| 产品形态 | AgentHost 内部 Go 抽象能力 | 独立服务、独立进程、通用 SDK |
| 使用者 | AgentHost 内部模块 | Electron、第三方远程客户端、最终用户 |
| 抽象对象 | agent thread、turn、事件、请求、能力、错误 | 完整复制某个 runtime 的全部协议 |
| 实现方式 | 由 runtime adapter 实现 | 由 Electron 或 HTTP handler 直接实现 |
| 首版实现 | CodexRuntime Adapter | 多 runtime 插件市场 |
| 未来扩展 | OtherAgentRuntime Adapter | 抽象所有可能 agent 平台的超级框架 |

## 3. 背景与问题

AgentHost 是 CodexApp 的本地宿主/承载层，负责 runtime 接入、适配、控制和事件转发。首版 runtime 是 Codex app-server，但产品不应把所有内部模型都绑定到 Codex app-server。

如果 AgentHost 直接依赖 `codexapp-go` 和 Codex 原生类型，会产生以下问题：

- AgentHost HTTP API 会泄漏 Codex JSON-RPC 字段。
- SSE 事件模型会被 Codex notification 命名和结构绑定。
- 审批、用户输入、工具请求等交互难以复用。
- 未来接入其他 agent 后端时，需要重写大量 AgentHost 业务代码。
- `codexapp-go` 容易被迫加入 AgentHost 产品语义，破坏 SDK 边界。

`AgentRuntime` 解决的是 AgentHost 内部能力边界问题，不解决底层协议封装问题。底层协议仍由对应 SDK 或 adapter 处理。

## 4. 设计原则

| 原则 | 说明 |
| --- | --- |
| 最小共性 | 只抽象 AgentHost 已经需要的 thread、turn、事件、请求、健康状态和能力。 |
| 实现后置 | 首版只实现 CodexRuntime Adapter，不提前开发 runtime registry 或插件系统。 |
| 协议隔离 | `AgentRuntime` 不暴露 Codex JSON-RPC method、notification、request id 等低层细节。 |
| 原始信息保留 | 统一事件和错误允许携带 raw payload，便于诊断和兼容。 |
| 能力发现 | 非共性能力通过 capability 暴露，不塞进核心接口。 |
| 产品稳定 | AgentHost 对 Electron 的 HTTP/SSE 模型不随底层 runtime 变化而频繁变化。 |
| 责任单一 | `AgentRuntime` 定义能力，adapter 翻译能力，SDK 封装协议。 |

## 5. 产品目标

### 5.1 核心目标

- 定义 AgentHost 内部统一 runtime 能力模型。
- 支持首版 Codex app-server 接入。
- 支持 thread 创建、恢复、查询和基础状态投影。
- 支持 turn 启动、追加输入、取消和生命周期事件。
- 支持 runtime 事件订阅，并转为 AgentHost 稳定事件。
- 支持 approval、user input、tool request 等 pending request。
- 支持 runtime health、version、capability 查询。
- 支持错误归一化和可诊断 raw 信息保留。
- 支持未来通过薄 `OtherAgent SDK` 加 adapter 接入其他 agent 后端。

### 5.2 质量目标

- AgentHost 业务代码不直接依赖 Codex 原生协议类型。
- CodexRuntime Adapter 不复制 `codexapp-go` 的 JSON-RPC client 能力。
- `AgentRuntime` 接口保持小而稳定。
- 事件分发不能阻塞底层 runtime reader。
- pending request 必须可恢复、可追踪、可幂等处理。
- 所有 trust boundary 输入必须校验。
- 错误必须包含可展示信息、可诊断 code 和底层原因。

### 5.3 非目标

- 不做独立 runtime 服务。
- 不做远程 agent worker 调度系统。
- 不做多租户、团队协作或云端控制面。
- 不做动态插件加载系统。
- 不在首版支持多个 runtime 同时热切换。
- 不把 Codex app-server 的完整协议重新定义一遍。
- 不让 Electron 直接调用 `AgentRuntime`。
- 不让 `AgentRuntime` 负责 UI 展示、SSE 序列化或 HTTP 路由。
- 不让 `AgentRuntime` 启动模型推理或自研 agent loop。

## 6. 目标用户与使用场景

### 6.1 目标用户

| 用户 | 需求 |
| --- | --- |
| AgentHost HTTP API 开发者 | 用统一能力创建 thread、启动 turn、取消 turn，不关心底层 runtime。 |
| AgentHost 事件投影开发者 | 消费稳定 runtime event，转换成 Electron SSE 事件。 |
| AgentHost 审批模块开发者 | 处理统一 pending request，不关心 Codex server request 细节。 |
| Runtime adapter 开发者 | 实现 `AgentRuntime`，把具体 agent 后端接入 AgentHost。 |
| SDK 开发者 | 保持底层 SDK 只封装协议，不吸收 AgentHost 产品模型。 |

### 6.2 核心使用场景

| 场景 | AgentRuntime 职责 | Adapter 职责 |
| --- | --- | --- |
| 创建 thread | 提供统一 `StartThread` 语义 | 映射到底层 runtime 的会话创建能力 |
| 启动 turn | 提供统一输入、模型、工作目录、权限 profile | 映射到底层 turn/run/job 调用 |
| 取消 turn | 提供统一取消入口 | 映射到底层 cancel/interrupt/abort 能力 |
| 订阅事件 | 输出统一 `RuntimeEvent` | 把底层 notification 转成统一事件 |
| 处理审批 | 暴露统一 pending request | 把底层 approval/input request 转成 pending request |
| 查询能力 | 输出 runtime version 和 capability | 读取底层版本、配置或静态声明 |
| 错误处理 | 输出统一错误模型 | 保留底层错误、code 和 raw 信息 |

## 7. 架构边界

### 7.1 AgentRuntime 与 AgentHost

`AgentRuntime` 属于 AgentHost 内部能力。AgentHost 负责调用它，并把结果转换成 HTTP response、SSE event、本地状态投影和日志。

| 能力 | AgentRuntime | AgentHost |
| --- | --- | --- |
| HTTP 路由 | 不负责 | 负责 |
| SSE 序列化 | 不负责 | 负责 |
| 本地状态投影 | 提供事件和查询结果 | 负责聚合和存储 |
| 用户审批策略 | 暴露 pending request 和响应入口 | 负责产品策略和用户交互 |
| runtime 连接 | 通过 adapter 实现 | 负责生命周期协调 |
| 诊断日志 | 提供错误和 raw 信息 | 负责脱敏、落盘和展示 |

### 7.2 AgentRuntime 与 CodexRuntime Adapter

`AgentRuntime` 是抽象契约，`CodexRuntime Adapter` 是 Codex app-server 的实现。

| 维度 | AgentRuntime | CodexRuntime Adapter |
| --- | --- | --- |
| 角色 | 定义 AgentHost 需要什么能力 | 说明 Codex 如何提供这些能力 |
| 类型 | 内部接口和统一模型 | 具体实现 |
| 依赖 | 不依赖 `codexapp-go` | 依赖 `codexapp-go` |
| 稳定性 | 面向 AgentHost 稳定 | 可随 Codex 协议适配调整 |
| 关注点 | thread、turn、event、request、capability | JSON-RPC method、notification、server request 映射 |

### 7.3 CodexRuntime Adapter 与 codexapp-go

`codexapp-go` 是 Codex app-server JSON-RPC 的基础 SDK。它负责连接、请求响应、通知订阅、server request 回复、协议类型和错误封装。

`CodexRuntime Adapter` 使用 `codexapp-go`，但不替代它：

| 能力 | codexapp-go | CodexRuntime Adapter |
| --- | --- | --- |
| JSON-RPC transport | 负责 | 不负责 |
| request id 匹配 | 负责 | 不负责 |
| Codex 协议类型 | 负责 | 使用 |
| Codex notification 接收 | 负责 | 消费并翻译 |
| AgentRuntime 事件模型 | 不负责 | 负责 |
| AgentHost pending request | 不负责 | 负责映射 |
| AgentHost capability | 不负责 | 负责声明和转换 |

不融合二者的原因：

- `codexapp-go` 必须忠实于 Codex app-server 协议。
- `CodexRuntime Adapter` 必须忠实于 AgentHost 的 runtime 抽象。
- 融合会让 SDK 携带 AgentHost 产品语义，未来接入非 Codex runtime 时会产生耦合。

### 7.4 AgentRuntime 与 OtherAgent SDK

未来接入非 Codex 后端时，应新增薄 `OtherAgent SDK` 和 `OtherAgentRuntime Adapter`：

```text
AgentHost
  AgentRuntime
    OtherAgentRuntime Adapter
      OtherAgent SDK
        OtherAgent backend
```

`OtherAgent SDK` 只封装对方后端的基础调用能力。`OtherAgentRuntime Adapter` 负责把该后端翻译成 AgentHost 的 `AgentRuntime` 模型。

## 8. 核心概念模型

### 8.1 Runtime

Runtime 表示一个可被 AgentHost 控制的 agent 后端能力实例。它可以来自 Codex app-server，也可以来自未来其他 agent 后端。

Runtime 必须提供：

- 唯一 runtime id。
- runtime kind，例如 `codex`、`other_agent`。
- display name。
- version。
- health 状态。
- capabilities。

### 8.2 Thread

Thread 表示一次长期 agent 会话。它是 AgentHost 对用户展示和恢复历史的核心对象。

Thread 统一字段：

| 字段 | 说明 |
| --- | --- |
| `thread_id` | AgentHost 稳定 thread id，可以映射到底层 runtime id。 |
| `runtime_id` | 创建该 thread 的 runtime。 |
| `title` | 可选展示标题。 |
| `created_at` | 创建时间。 |
| `updated_at` | 最近更新时间。 |
| `status` | `active`、`idle`、`archived`、`unavailable`。 |
| `raw` | 可选底层原始信息。 |

### 8.3 Turn

Turn 表示用户对 thread 发起的一次 agent 执行。不同后端可能叫 run、job、step 或 task，但 AgentHost 内统一称为 turn。

Turn 统一字段：

| 字段 | 说明 |
| --- | --- |
| `turn_id` | AgentHost 稳定 turn id。 |
| `thread_id` | 所属 thread。 |
| `runtime_id` | 执行 runtime。 |
| `input` | 用户输入或结构化输入摘要。 |
| `status` | `queued`、`running`、`waiting`、`completed`、`failed`、`cancelled`。 |
| `started_at` | 启动时间。 |
| `finished_at` | 结束时间，可空。 |
| `raw` | 可选底层原始信息。 |

### 8.4 RuntimeEvent

RuntimeEvent 是 AgentRuntime 向 AgentHost 输出的统一事件。AgentHost 再把它投影为 Electron SSE 事件。

事件必须具备：

- 稳定 event id。
- runtime id。
- thread id。
- 可选 turn id。
- event type。
- event time。
- typed payload。
- raw payload。

基础事件类型：

| 类型 | 说明 |
| --- | --- |
| `thread.created` | thread 创建完成。 |
| `thread.updated` | thread 元信息变化。 |
| `turn.started` | turn 开始执行。 |
| `turn.delta` | 流式输出或 reasoning 增量。 |
| `turn.message` | assistant/user/system 消息。 |
| `turn.tool_call.started` | 工具调用开始。 |
| `turn.tool_call.updated` | 工具调用状态变化。 |
| `turn.tool_call.finished` | 工具调用结束。 |
| `turn.command.started` | 命令执行开始。 |
| `turn.command.output` | 命令输出增量。 |
| `turn.command.finished` | 命令执行结束。 |
| `turn.file_change` | 文件变更事件。 |
| `turn.waiting_for_input` | runtime 等待用户输入或审批。 |
| `turn.completed` | turn 成功完成。 |
| `turn.failed` | turn 失败。 |
| `turn.cancelled` | turn 被取消。 |
| `runtime.health_changed` | runtime 健康状态变化。 |

### 8.5 PendingRequest

PendingRequest 表示 runtime 需要 AgentHost 或用户给出决策的请求。

统一请求类型：

| 类型 | 说明 |
| --- | --- |
| `approval.command` | 命令执行审批。 |
| `approval.file_change` | 文件变更审批。 |
| `approval.permission` | 权限或 sandbox 审批。 |
| `input.user` | 用户输入请求。 |
| `tool.dynamic_call` | 动态工具调用请求。 |
| `auth.refresh` | 认证 token 刷新请求。 |

PendingRequest 必须支持：

- request id。
- thread id。
- turn id。
- request type。
- display payload。
- structured payload。
- timeout policy。
- idempotency key。
- raw payload。
- 一次性响应。

### 8.6 Capability

Capability 表示 runtime 支持哪些能力。AgentHost 用它决定 UI 是否展示入口、HTTP API 是否允许调用、错误信息如何提示。

基础 capability：

| 能力 | 说明 |
| --- | --- |
| `thread.start` | 支持创建 thread。 |
| `thread.resume` | 支持恢复已有 thread。 |
| `turn.start` | 支持启动 turn。 |
| `turn.cancel` | 支持取消 turn。 |
| `event.stream` | 支持事件流。 |
| `approval.command` | 支持命令审批。 |
| `approval.file_change` | 支持文件变更审批。 |
| `input.user` | 支持用户输入请求。 |
| `tool.call` | 支持工具调用事件。 |
| `model.select` | 支持模型选择。 |
| `workspace.fs` | 支持工作目录和文件事件。 |

## 9. 功能范围

### 9.1 MVP 范围

MVP 必须覆盖：

- 单 runtime：CodexRuntime Adapter。
- runtime health 查询。
- runtime capability 查询。
- 创建 Codex thread。
- 启动 Codex turn。
- 取消 Codex turn。
- 订阅 Codex runtime 事件。
- 将 Codex notification 映射为 `RuntimeEvent`。
- 将 Codex server request 映射为 `PendingRequest`。
- 将 AgentHost 用户决策回复给 Codex app-server。
- 将 Codex 错误映射为统一 runtime error。
- 保留 raw event、raw request 和 raw error 供诊断。

### 9.2 后续范围

- 多 runtime 配置文件。
- OtherAgentRuntime Adapter。
- runtime capability 与 Electron UI 控件联动。
- runtime 迁移或 thread import。
- 更完整的模型、工具、权限 profile 差异表达。
- runtime 级诊断面板。

### 9.3 明确不在当前范围

- runtime 插件市场。
- 动态加载外部二进制 adapter。
- 同一个 thread 跨 runtime 无缝迁移。
- 多 runtime 并行调度同一个 turn。
- 跨机器远程 runtime。
- AgentHost 之外的公共 runtime SDK。

## 10. 内部接口建议

接口只作为产品边界说明，不要求一次性实现所有方法签名。

```go
type AgentRuntime interface {
    Info(ctx context.Context) (RuntimeInfo, error)
    StartThread(ctx context.Context, req StartThreadRequest) (ThreadRef, error)
    StartTurn(ctx context.Context, req StartTurnRequest) (TurnRef, error)
    CancelTurn(ctx context.Context, req CancelTurnRequest) error
    Events(ctx context.Context, req EventSubscribeRequest) (<-chan RuntimeEvent, error)
    Respond(ctx context.Context, req RuntimeResponse) error
}
```

首版不要拆成多个接口。等出现第二个真实 runtime，且某些能力确实不是所有 runtime 都支持，再按 capability 拆分。

### 10.1 RuntimeInfo

```go
type RuntimeInfo struct {
    RuntimeID    string
    Kind         string
    DisplayName  string
    Version      string
    Health       RuntimeHealth
    Capabilities []RuntimeCapability
    Raw          any
}
```

### 10.2 StartThreadRequest

```go
type StartThreadRequest struct {
    WorkspacePath string
    InitialInput  string
    Model         string
    Profile       string
    Metadata      map[string]string
}
```

字段说明：

| 字段 | 说明 |
| --- | --- |
| `WorkspacePath` | 本地工作目录。必须经过 AgentHost 校验。 |
| `InitialInput` | 可选初始用户输入。 |
| `Model` | 可选模型标识。runtime 不支持时返回 capability error。 |
| `Profile` | 权限或运行 profile。 |
| `Metadata` | AgentHost 内部扩展字段，不面向 Electron 直接透传。 |

### 10.3 StartTurnRequest

```go
type StartTurnRequest struct {
    ThreadID string
    Input    string
    Model    string
    Profile  string
    Context  map[string]string
}
```

### 10.4 RuntimeResponse

```go
type RuntimeResponse struct {
    RequestID string
    Decision  string
    Payload   any
}
```

`Decision` 的基础值：

| 值 | 说明 |
| --- | --- |
| `approve` | 批准。 |
| `deny` | 拒绝。 |
| `cancel` | 取消当前请求或 turn。 |
| `answer` | 提交用户输入。 |
| `error` | AgentHost 无法处理该请求。 |

## 11. 状态与生命周期

### 11.1 Runtime 生命周期

```mermaid
stateDiagram-v2
  [*] --> Uninitialized
  Uninitialized --> Connecting
  Connecting --> Ready
  Connecting --> Unavailable
  Ready --> Degraded
  Ready --> Unavailable
  Degraded --> Ready
  Degraded --> Unavailable
  Unavailable --> Connecting
```

| 状态 | 说明 |
| --- | --- |
| `uninitialized` | AgentHost 尚未初始化 runtime。 |
| `connecting` | 正在连接或握手。 |
| `ready` | 可创建 thread 和 turn。 |
| `degraded` | 部分能力不可用。 |
| `unavailable` | runtime 不可用。 |

### 11.2 Thread 生命周期

```mermaid
stateDiagram-v2
  [*] --> Creating
  Creating --> Idle
  Idle --> Running
  Running --> Waiting
  Waiting --> Running
  Running --> Idle
  Idle --> Archived
  Running --> Unavailable
  Waiting --> Unavailable
```

### 11.3 Turn 生命周期

```mermaid
stateDiagram-v2
  [*] --> Queued
  Queued --> Running
  Running --> Waiting
  Waiting --> Running
  Running --> Completed
  Running --> Failed
  Running --> Cancelled
  Waiting --> Cancelled
```

## 12. 事件与转发规则

### 12.1 事件顺序

- 同一 thread 内事件必须尽量保持底层 runtime 顺序。
- 同一 turn 内事件必须保留顺序号或可排序时间。
- 跨 thread 不要求全局严格排序。
- Adapter 不应因为单个慢消费者阻塞底层事件读取。

### 12.2 事件去重

AgentRuntime 输出事件必须带稳定 id。若底层 runtime 不提供 id，adapter 可以用 runtime id、thread id、turn id、event type、sequence 组合生成。

### 12.3 Raw 信息

`RuntimeEvent.Raw` 应保留底层原始事件摘要。Raw 用于诊断，不直接展示给普通用户。

### 12.4 AgentHost 投影

AgentRuntime 不负责生成 Electron SSE payload。AgentHost 事件投影模块负责：

- 筛选 UI 需要的字段。
- 合并高频 delta。
- 处理断线重连游标。
- 对敏感字段脱敏。
- 输出稳定 SSE event name。

## 13. PendingRequest 处理规则

### 13.1 创建规则

Adapter 接到底层 approval、input、tool 或 auth request 后，必须创建统一 `PendingRequest`。

PendingRequest 创建时必须包含：

- request id。
- runtime id。
- thread id。
- turn id。
- request type。
- 用户可理解的标题和摘要。
- 结构化 payload。
- raw payload。

### 13.2 响应规则

- 每个 PendingRequest 只能响应一次。
- 重复响应必须返回 idempotent result 或明确错误。
- request 超时策略由 AgentHost 产品层决定。
- Adapter 负责把统一 response 翻译回底层 runtime。

### 13.3 恢复规则

AgentHost 刷新或 Electron 重连后，必须能重新展示未完成 PendingRequest。AgentRuntime 应提供足够事件和 request 信息，AgentHost 负责本地保存 pending 状态。

## 14. 错误模型

### 14.1 错误分类

| 错误类型 | 说明 |
| --- | --- |
| `runtime_unavailable` | runtime 不可连接或握手失败。 |
| `capability_unsupported` | 当前 runtime 不支持请求能力。 |
| `invalid_request` | AgentHost 传入参数无效。 |
| `permission_denied` | 权限或审批拒绝。 |
| `turn_failed` | turn 执行失败。 |
| `transport_error` | 底层连接错误。 |
| `protocol_error` | 底层协议错误。 |
| `internal_error` | adapter 或 AgentHost 内部错误。 |

### 14.2 错误字段

| 字段 | 说明 |
| --- | --- |
| `code` | 稳定错误码。 |
| `message` | 面向开发者和高级用户的摘要。 |
| `user_message` | 可选 UI 展示文案。 |
| `retryable` | 是否可重试。 |
| `runtime_id` | 相关 runtime。 |
| `thread_id` | 可选相关 thread。 |
| `turn_id` | 可选相关 turn。 |
| `cause` | 底层错误摘要。 |
| `raw` | 可选底层原始错误。 |

## 15. 安全与权限边界

AgentRuntime 位于本地 trust boundary 内，但所有来自 Electron、HTTP request、runtime event 和底层 SDK 的数据仍必须按边界校验。

### 15.1 AgentRuntime 不负责

- 不决定用户是否批准命令。
- 不决定文件变更是否安全。
- 不直接展示敏感信息。
- 不存储长期 token。
- 不绕过 AgentHost 权限策略。

### 15.2 Adapter 必须负责

- 不自动 approve 任何审批。
- 不吞掉底层权限请求。
- 不把底层敏感字段无过滤传给 UI。
- 保留足够 raw 信息供诊断。

### 15.3 AgentHost 必须负责

- 校验 workspace path。
- 校验 HTTP 请求参数。
- 管理审批策略。
- 管理本地配置和密钥存储。
- 对日志和诊断信息脱敏。

## 16. 可观测性与诊断

AgentRuntime 必须支持 AgentHost 诊断以下问题：

- runtime 是否可用。
- 当前 runtime kind 和 version。
- 当前 capabilities。
- 最近连接错误。
- 最近 protocol 或 adapter 错误。
- thread/turn 事件是否持续到达。
- pending request 是否积压。

最小诊断数据：

| 数据 | 来源 |
| --- | --- |
| runtime health | Adapter |
| runtime version | Adapter 或底层 SDK |
| capability list | Adapter |
| last error | Adapter |
| event counters | AgentHost 事件模块 |
| pending request counters | AgentHost pending 模块 |

## 17. 数据所有权

| 数据 | 权威来源 | AgentHost 是否可缓存 |
| --- | --- | --- |
| runtime health | Adapter | 可以 |
| capability | Adapter | 可以 |
| thread 原始历史 | 底层 runtime | 可以投影 |
| thread UI 状态 | AgentHost | 是 |
| turn 原始执行状态 | 底层 runtime | 可以投影 |
| pending request | AgentHost + Adapter | 必须缓存 |
| Electron 展示状态 | AgentHost | 是 |
| raw protocol message | 底层 SDK/Adapter | 只用于诊断 |

原则：

- AgentRuntime 不做持久化数据库。
- AgentHost 负责持久化策略。
- 底层 runtime 是执行事实源。
- AgentHost 是 UI 投影和 pending 状态事实源。

## 18. CodexRuntime Adapter 首版要求

CodexRuntime Adapter 必须基于 `codexapp-go` 实现，不手写 JSON-RPC。

### 18.1 必须映射的能力

| AgentRuntime 能力 | Codex 实现来源 |
| --- | --- |
| `Info` | app-server initialize result、version、静态 capability |
| `StartThread` | `codexapp-go` thread API |
| `StartTurn` | `codexapp-go` turn API |
| `CancelTurn` | `codexapp-go` cancel/interrupt API |
| `Events` | `codexapp-go` notification subscription |
| `Respond` | `codexapp-go` server request response |

### 18.2 必须映射的事件

- thread 创建和更新事件。
- turn 开始、完成、失败、取消事件。
- assistant message 事件。
- reasoning 或 delta 事件。
- command 执行事件。
- file change 事件。
- MCP/tool call 事件。
- approval 和 input request 事件。
- runtime error 事件。

### 18.3 不允许

- 不允许在 adapter 中重新实现 JSON-RPC transport。
- 不允许在 adapter 中复制 `codexapp-go` 协议类型定义。
- 不允许让 AgentHost HTTP handler 直接依赖 Codex protocol 类型。
- 不允许自动批准 Codex server request。

## 19. 未来 OtherAgent 接入要求

未来新增 `OtherAgent SDK` 时，应满足：

- SDK 只封装 OtherAgent 的基础调用和事件订阅。
- SDK 不依赖 AgentHost。
- Adapter 实现 `AgentRuntime`。
- Adapter 负责把 OtherAgent 的 session/run/job 映射成 thread/turn。
- Adapter 负责把 OtherAgent 的事件映射成 `RuntimeEvent`。
- Adapter 负责把 OtherAgent 的交互请求映射成 `PendingRequest`。
- 不为了一个新 runtime 改动 Electron API。
- 不为了一个新 runtime 改动 `codexapp-go`。

最小接入路径：

```text
1. 新增 OtherAgent SDK。
2. 新增 OtherAgentRuntime Adapter。
3. 实现 AgentRuntime 的最小方法。
4. 声明 capabilities。
5. 补一条 thread -> turn -> event -> pending request 的端到端检查。
```

## 20. 验收标准

### 20.1 文档验收

- 清楚说明 `AgentRuntime` 属于 AgentHost。
- 清楚说明 `AgentRuntime` 不是 SDK、不是服务、不是 Electron API。
- 清楚说明 `CodexRuntime Adapter` 与 `codexapp-go` 的关系。
- 清楚说明为什么 adapter 不与 SDK 融合。
- 清楚说明未来 OtherAgent 接入方式。
- 明确 MVP、后续范围和非目标。

### 20.2 实现验收

- AgentHost HTTP handler 不直接引用 Codex protocol 类型。
- CodexRuntime Adapter 通过 `codexapp-go` 调用 Codex app-server。
- AgentRuntime 可以创建 thread、启动 turn、取消 turn。
- AgentRuntime 可以输出统一 runtime event。
- AgentRuntime 可以暴露 pending request 并支持一次性 response。
- 错误能被归一化并保留底层 cause。
- runtime capability 能控制不支持能力的错误返回。

### 20.3 未来扩展验收

- 新增第二个 runtime 时，Electron API 不需要大改。
- 新增第二个 runtime 时，AgentHost 事件投影模型不需要大改。
- 新增第二个 runtime 时，只需新增 SDK 和 adapter，不改 `codexapp-go`。
- 新增第二个 runtime 时，不能把 Codex 专属字段塞进 `AgentRuntime` 核心模型。

## 21. 风险与对策

| 风险 | 影响 | 对策 |
| --- | --- | --- |
| 过度抽象 | 首版复杂度变高 | 只定义 Codex MVP 已使用能力。 |
| 抽象过薄 | 未来接入 OtherAgent 要大改 | 保留 thread、turn、event、pending request、capability 五个稳定概念。 |
| Codex 字段泄漏 | Electron 和 AgentHost 被 Codex 绑定 | HTTP/SSE 只使用 AgentHost 投影模型。 |
| Adapter 变成 SDK | 重复实现 JSON-RPC | CodexRuntime Adapter 必须通过 `codexapp-go`。 |
| pending request 丢失 | 用户无法恢复审批 | AgentHost 持久化 pending 状态。 |
| 高频事件阻塞 | turn 输出卡顿 | Adapter 和 AgentHost 事件模块使用有限缓冲和背压策略。 |

## 22. 开放问题

| 问题 | 默认决策 |
| --- | --- |
| 首版是否支持多个 runtime 实例 | 不支持，只支持 CodexRuntime。 |
| Runtime id 是否用户可见 | 不直接展示，只用于诊断和内部路由。 |
| Thread id 是否复用底层 id | 可以，但 AgentHost 应允许映射层。 |
| 是否需要 runtime registry | 首版不需要，硬编码 CodexRuntime。 |
| 是否需要动态 adapter 插件 | 首版不需要。 |
| OtherAgent 是否必须支持 thread/turn | 不必须，但 adapter 必须映射成 thread/turn。 |

## 23. 最终边界声明

`AgentRuntime` 是 AgentHost 内部的最小 runtime 抽象，负责定义 AgentHost 如何创建 thread、启动 turn、取消 turn、订阅事件、处理 pending request、查询健康状态和能力。

`CodexRuntime Adapter` 是 `AgentRuntime` 的 Codex 实现，负责把 AgentHost 的统一 runtime 模型翻译为 Codex app-server 能力。

`codexapp-go` 是 Codex app-server JSON-RPC 的基础 Go SDK，负责协议连接、类型、请求响应、通知和 server request 机制。它不承载 AgentHost 的产品模型。

未来接入其他 agent 后端时，应新增薄 `OtherAgent SDK` 和对应 `OtherAgentRuntime Adapter`，而不是改造 `codexapp-go` 或让 Electron 直接理解新的 runtime 协议。

