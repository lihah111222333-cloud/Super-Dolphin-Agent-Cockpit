# AgentHost 功能列表

整理日期：2026-06-24

状态：当前有效功能监管清单

归属目录：`docs/20-delivery/`

上游依据：

- `../00-start/current-status.md`
- `../10-foundation/product/agent-host-product-spec.md`
- `../10-foundation/architecture/agent-host-technical-architecture.md`
- `../10-foundation/architecture/technology-stack.md`
- `../10-foundation/architecture/database-design.md`
- `../10-foundation/product/agent-runtime-product-spec.md`
- `../10-foundation/product/agent-runtime-adapter-product-spec.md`
- `execution/execution-spec.md`
- `iterations/01-agent-host-core/master-plan.md`
- `../30-release/host-api-spec.md`

## 1. 定位

本文是 `agent-host` 当前完整产品范围内的功能监管清单，覆盖 Local API / Host API、AgentRuntime、CodexRuntimeAdapter、Store、同步队列和发布收敛能力。

本文不是 `01-agent-host-core` 迭代的私有清单。`01-agent-host-core`、`02-host-api-core`、`03-runtime-adapter-core` 只能引用本文进行阶段拆解，不能各自维护一套并列功能编号。

`agent-host` 是唯一的本地项目主体。Host API、AgentRuntime、CodexRuntimeAdapter 是同一项目内的需求域，不是三个并列项目。

迭代序号说明：

- `01-agent-host-core` 是主线迭代，定义 P0 -> P4 的唯一推进顺序。
- `02-host-api-core` 是 Host API 专项视图，只用于定位 Host API 责任。
- `03-runtime-adapter-core` 是 Runtime/Adapter 专项视图，只用于定位 AgentRuntime 和 CodexRuntimeAdapter 责任。

功能项后续可以继续拆成任务，但任务不得扩大本文功能范围，也不得制造依赖倒置。

## 2. 功能列表

| 序号 | 迭代序号 | 功能域 | 功能点 | 功能说明 | 实现阶段 | 前置功能 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| AH-F01 | 01 / 02 | Local API / Host API | 本地服务启动基线 | 建立 Go 单体服务、Gin 路由、健康检查、`config.yaml` 配置读取和 `slog` 日志。 | P0 / H0 | 无 | 服务可启动；`/healthz` 可测；配置和日志行为可验证。 |
| AH-F02 | 01 / 02 | Local API / Host API | SQLite 数据库初始化 | 使用 GORM + 纯 Go SQLite driver，执行本地建库脚本并打开外键检查。 | P0 / H0 | AH-F01 | 空库可创建；`PRAGMA foreign_key_check` 通过；业务代码不散落 raw SQL。 |
| AH-F03 | 01 / 02 | Local API / Host API | 统一响应和错误 envelope | 统一本地 API 成功、失败、requestId、错误码和日志脱敏格式。 | P0 / H0 | AH-F01 | 受保护接口无 token 返回 `UNAUTHORIZED`；错误响应结构稳定；日志不输出 token。 |
| AH-F04 | 01 / 02 | Local API / Host API | 本地 session 鉴权 | 代理远程登录后签发本地 session，Electron 后续只携带本地 session token。 | P0 / H0 | AH-F01, AH-F02, AH-F03 | Electron 拿不到远程 refresh token；有效 session 可访问受保护 API；失效 session 被拒绝。 |
| AH-F05 | 01 / 02 | Local API / Host API | 远程 token 保存和刷新 | 本地保存远程 access/refresh token，并在远程 401 时刷新一次。 | P0 / H0 | AH-F04 | 远程 access token 过期后只 refresh 一次；refresh 失败返回稳定错误；日志不泄露明文 token。 |
| AH-F06 | 01 / 02 | Local API / Host API | Remote API Client | 统一封装远程 base URL、鉴权注入、超时、一次重试、错误映射和条件请求头。 | P0 / H0 | AH-F05 | 所有远程代理经过同一 client；远程不可用返回统一错误；远程 304 可交给 cache 处理。 |
| AH-F07 | 01 / 02 | Local API / Host API | SQLite 远程缓存 | 为远程动态数据提供 cache hit、stale、miss、TTL、ETag 和 `forceRefresh` 能力。 | P0 / H0 | AH-F02, AH-F06 | 同一 query 可命中缓存；`forceRefresh=true` 绕过缓存；远程 304 不覆盖 payload。 |
| AH-F08 | 01 / 02 | Local API / Host API | 账号和设备基础代理 | 代理账号上下文、设备注册、心跳、设备列表和解绑。 | P0 / H0 | AH-F04, AH-F06, AH-F07 | Electron 不持有远程 token；设备注册和心跳可通过 Host API 完成；远程错误可识别。 |
| AH-F09 | 01 / 03 | AgentRuntime | Runtime 最小 contract | 定义 AgentRuntime interface、ThreadRef、TurnRef、RuntimeInfo 和 fake runtime。 | P1 / R0 | AH-F01 | Host API 可基于 contract 编译调用；AgentRuntime 包不依赖 `codexapp-go`。 |
| AH-F10 | 01 / 03 | AgentRuntime | Runtime 统一事件模型 | 定义 RuntimeEvent、事件类型、增量载荷、完成事件和错误事件。 | P1 / R0 | AH-F09 | fake runtime 可驱动最小事件流测试；事件模型不包含 Codex 原生 protocol 类型。 |
| AH-F11 | 01 / 03 | AgentRuntime | PendingRequest 统一模型 | 定义审批、输入补充、工具确认等 pending request 的统一模型和响应入口。 | P1 / R0 | AH-F09 | Host API 可查询和响应 pending request；模型不绑定 Codex 原生字段。 |
| AH-F12 | 01 / 03 | AgentRuntime | Runtime capability 和 error 基线 | 定义 RuntimeCapability、RuntimeError 和 unsupported capability 行为。 | P1 / R0 | AH-F09 | 不支持能力返回稳定错误；Host API 可按统一 error code 映射 HTTP 响应。 |
| AH-F13 | 01 / 03 | CodexRuntimeAdapter | Codex adapter 初始化 | 通过 `codexapp-go` 初始化 CodexRuntimeAdapter，注入 client 和配置。 | P1 / R1 | AH-F09 | Adapter 可建立最小连接；未重复实现 JSON-RPC transport。 |
| AH-F14 | 01 / 03 | CodexRuntimeAdapter | thread/turn/cancel 映射 | 将 AgentRuntime 的 thread、turn、cancel/interrupt 调用映射到底层 Codex 能力。 | P1 / R1 | AH-F13 | 可发起一次最小 turn；Adapter 输出 AgentRuntime 类型；AgentRuntime 不引用 `codexapp-go`。 |
| AH-F15 | 01 / 03 | CodexRuntimeAdapter | Codex event 映射 | 将 Codex notification、delta、completed、error 映射为 RuntimeEvent。 | P1 / R2 | AH-F14 | SSE 上层可消费稳定 RuntimeEvent；Codex protocol 不泄漏到 Host API。 |
| AH-F16 | 01 / 03 | CodexRuntimeAdapter | Codex server request 映射 | 将 Codex server request 映射为 PendingRequest，并支持 response 回写。 | P1 / R2 | AH-F15, AH-F11 | pending request 可识别、可响应；重复 response 不产生不可控副作用。 |
| AH-F17 | 01 / 02 | Local API / Host API | runtime REST endpoint | 提供创建 thread、启动 turn、取消 turn、查询 runtime 状态的本地 API。 | P1 / H1 | AH-F09, AH-F14 | Host API 只调用 AgentRuntime；不直接调用 `codexapp-go`；权限校验可测。 |
| AH-F18 | 01 / 02 | Local API / Host API | runtime SSE bridge | 将 RuntimeEvent 序列化为 Electron 可消费的 SSE 事件流。 | P1 / H1 | AH-F10, AH-F15, AH-F17 | SSE 可收到 started/delta/completed/error；输出不包含 Codex 原生 payload。 |
| AH-F19 | 01 / 02 | Local API / Host API | pending request API | 提供 pending request 查询、状态投影和用户响应 API。 | P1 / H1 | AH-F11, AH-F16, AH-F17 | pending request 可查询、可响应、可回到底层 runtime；未响应状态可追踪。 |
| AH-F20 | 01 / 02 | Local API / Host API | 任务基础投影 | 将 thread、turn、runtime event 写入本地任务投影，供后续查询和恢复。 | P1 / H1 | AH-F18 | 事件可落本地投影；任务状态可从事件恢复；不把投影职责放进 Adapter。 |
| AH-F21 | 01 / 02 | Local API / Host API | 模型代理和自定义模型 | 代理远程模型、供应商、权益，并合并本地自定义模型。 | P2 / H2 | AH-F04, AH-F06, AH-F07 | 模型列表可缓存和强刷；自定义模型不返回明文 key；无权益模型不会被选中。 |
| AH-F22 | 01 / 02 | Local API / Host API | 技能市场和本地技能 | 代理技能市场、详情、安装包、查找/生成，并管理本地草稿和已安装技能。 | P2 / H2 | AH-F04, AH-F06, AH-F07 | 市场列表可缓存分页；安装包 checksum 可校验；本地草稿不上云。 |
| AH-F23 | 01 / 02 | Local API / Host API | 专家中心和本地专家 | 代理远程专家、专家团，并合并本地专家。 | P2 / H2 | AH-F04, AH-F06, AH-F07, AH-F20 | 远程/本地专家以 source 区分；本地专家 CRUD 不调用远程；召唤专家保留快照。 |
| AH-F24 | 01 / 02 | Local API / Host API | 连接器目录和本地 MCP | 代理连接器目录、详情，并管理本地 MCP 连接器配置。 | P2 / H2 | AH-F04, AH-F06, AH-F07 | 连接器目录可缓存；本地 MCP 连接器不上云；不开放任意 connector invoke。 |
| AH-F25 | 01 / 02 | Local API / Host API | 连接器授权状态代理 | 代理 OAuth 发起、授权 session 查询、授权状态和审计日志。 | P2 / H2 | AH-F24 | 授权开始返回远程 authUrl/sessionId；授权状态可刷新；第三方 token 不明文返回。 |
| AH-F26 | 01 / 02 | Local API / Host API | 资料库代理和上下文引用 | 代理资料库来源、授权、空间、文件搜索和详情，并保存任务上下文引用。 | P2 / H2 | AH-F04, AH-F06, AH-F07, AH-F20, AH-F25 | 文件搜索可缓存；上下文引用不包含远程 token；解绑后缓存不可继续展示为可用。 |
| AH-F27 | 01 / 02 | Local API / Host API | 自动化模板代理 | 代理远程自动化模板，供本地或项目自动化配置选择。 | P2 / H2 | AH-F04, AH-F06, AH-F07 | 模板可按 scene 查询；远程不可用时可按策略返回 stale cache；前端不硬编码模板。 |
| AH-F28 | 01 / 02 | Local API / Host API | 灵感场景和任务草稿 | 代理灵感分类、案例、收藏、clone，并将 clone 结果保存为本地任务草稿。 | P2 / H2 | AH-F04, AH-F06, AH-F07, AH-F20 | 灵感列表可缓存；收藏失败返回明确错误；clone 后生成草稿但不自动运行。 |
| AH-F29 | 01 / 02 | Local API / Host API | 任务事件历史查询 | 提供任务事件、turn 历史、SSE 恢复基础查询。 | P2 / H2 | AH-F20 | 任务事件可按 task/thread 查询；重启后可恢复查看；不依赖 P3 同步队列。 |
| AH-F30 | 01 / 02 | Local API / Host API | 产物、文件变更和上下文查询 | 提供任务产物、文件变更、上下文引用查询。 | P2 / H2 | AH-F20, AH-F26 | 产物可按任务查询；文件变更不越权；远程回写失败不破坏本地产物。 |
| AH-F31 | 01 / 03 | AgentRuntime / Adapter | capability、error 和诊断映射 | 把底层 capability、transport/protocol/runtime error、request id 和 raw cause 摘要映射到统一模型。 | P2 / R3 | AH-F12, AH-F15, AH-F16 | unsupported capability 和底层错误可稳定映射；raw 信息只用于诊断，不做业务依赖。 |
| AH-F32 | 01 / 02 | Local API / Host API | 远程同步队列 | 用 SQLite 状态表保存需要上云的动作，支持待同步、成功、失败和重试状态。 | P3 / H3 | AH-F04, AH-F06, AH-F02 | 远程离线时任务保留；状态和失败原因可查；不引入 Redis/Kafka/外部队列。 |
| AH-F33 | 01 / 02 | Local API / Host API | 进程内同步 worker | 使用 goroutine + context 扫描同步队列，执行退避重试和停止控制。 | P3 / H3 | AH-F32 | 网络恢复后可重试成功；token 过期可 refresh 后继续；退出时不会丢已入库任务。 |
| AH-F34 | 01 / 02 | Local API / Host API | 反馈和日志同步代理 | 生成脱敏日志包，代理反馈和附件上传，失败时可入队。 | P3 / H3 | AH-F32, AH-F33 | 反馈成功返回 feedbackId；失败可重试；不上传 token/API key 明文。 |
| AH-F35 | 01 / 02 | Local API / Host API | 分享文件代理 | 代理分享复制链接、下载或取消分享等远程写操作。 | P3 / H3 | AH-F32, AH-F33 | 远程失败时状态可追踪；重复同步不产生重复副作用；Electron 不直连远程。 |
| AH-F36 | 01 / 02 | Local API / Host API | 项目协作代理 | 代理项目、成员、邀请、审批、活动、模板等协作 API。 | P3 / H3 | AH-F04, AH-F06, AH-F07, AH-F32 | 项目读接口可缓存；写接口走 Remote Client；权限和远程错误可映射。 |
| AH-F37 | 01 / 02 | Local API / Host API | 项目资产和任务摘要同步 | 代理项目资产上传、列表和项目任务摘要同步。 | P3 / H3 | AH-F30, AH-F32, AH-F36 | 资产上传失败不破坏本地产物；任务摘要同步失败可重试。 |
| AH-F38 | 01 / 02 | Local API / Host API | 助理网关代理 | 代理助理平台相关远程接口，并与本地任务投影衔接。 | P3 / H3 | AH-F20, AH-F32 | 助理相关远程调用不绕过 Remote Client；离线时可记录状态；错误可诊断。 |
| AH-F39 | 01 / 02 | Local API / Host API | 账号计费代理 | 代理套餐、积分、用量、订单、发票和购买入口。 | P3 / H3 | AH-F04, AH-F06, AH-F07 | 价格和权益不硬编码；购买入口来自远程；余额/权益按短 TTL 或强刷策略处理。 |
| AH-F40 | 01 / 02 | Local API / Host API | 运行审计代理 | 记录并同步 runtime action、连接器动作和关键本地操作审计。 | P3 / H3 | AH-F20, AH-F32, AH-F33 | 审计事件先落本地；远程不可用可重试；敏感信息已脱敏。 |
| AH-F41 | 01 / 02 | Local API / Host API | Host API 发布校准 | 校准 Host API spec、响应 envelope、错误码、SSE event 和兼容说明。 | P4 / H4 | AH-F01 ~ AH-F40 | `30-release/host-api-spec.md` 与实现一致；关键 HTTP/SSE 链路回归通过。 |
| AH-F42 | 01 | Store / Local API | schema 与 GORM 一致性校准 | 校准 SQLite schema、GORM model、索引、外键、软删和时间字段约定。 | P4 | AH-F02, AH-F07, AH-F20, AH-F32 | 建库脚本、GORM model 和数据库设计一致；外键检查通过。 |
| AH-F43 | 01 / 03 | AgentRuntime / Adapter | Runtime/Adapter contract 回归 | 校准 AgentRuntime contract、fake runtime、CodexRuntimeAdapter 映射测试。 | P4 / R4 | AH-F09 ~ AH-F16, AH-F31 | Runtime 不依赖具体 SDK；Adapter 不承担 HTTP/SSE/持久化职责；映射测试通过。 |
| AH-F44 | 01 / 03 | AgentRuntime / Adapter | capability/error 文档校准 | 补齐 runtime capability、RuntimeError、诊断字段和边界说明。 | P4 / R4 | AH-F12, AH-F31 | 文档与实现一致；raw 诊断不成为 Host API 业务判断依据。 |
| AH-F45 | 01 | 全域 | 最小回归和验收证据归档 | 汇总 P0-P4 验收证据，固定后续增强必须另建规划。 | P4 | AH-F41, AH-F42, AH-F43, AH-F44 | 主线关键链路回归通过；入口文档指向当前状态；未新增未来 runtime 或 P5 能力。 |

## 3. 拆解和监管规则

- 阶段任务拆解必须引用本文序号，不再另造一套功能编号。
- Host API、AgentRuntime、CodexRuntimeAdapter 可以分工开发，但仍属于 `agent-host` 单一项目。
- 任一功能若需要 runtime 能力，必须先满足对应 `AH-F09` 到 `AH-F16` 或 `AH-F31` 的前置功能。
- 任一功能若需要远程代理，必须先满足 `AH-F04` 到 `AH-F07` 的前置功能。
- P3 同步队列能力不得前移到 P0-P2。
- P4 只做校准、回归和发布收敛，不新增 P5 范围功能。
