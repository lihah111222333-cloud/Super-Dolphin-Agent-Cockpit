# H3 Sync Complex Proxy 阶段目标

整理日期：2026-06-23

阶段目录：`h3-sync-complex-proxy/`

上级规划：`../master-plan.md`

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | H3 |
| 阶段名称 | Sync Complex Proxy |
| 所属迭代 | `20-delivery/iterations/02-host-api-core` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | Host API 视角的 P3 同步队列入口和复杂远程代理。 |

## 1. 计划目标

完成需要上云的 Host API 写入口、同步队列触发和复杂远程代理接口。

## 2. 阶段内容

- 同步队列写入口。
- 反馈、日志、分享代理 API。
- 项目协作代理 API。
- 助理网关代理 API。
- 账号计费代理 API。

## 3. 范围边界

允许：

- Host API 写入本地同步队列。
- 调用进程内 worker 暴露的同步能力。
- 代理远程复杂业务 API。

禁止：

- 自建队列系统。
- 绕过 Remote API Client。
- Electron 直连远程 API。

## 4. 责任归属

| 责任 | 内容 |
| --- | --- |
| Host API | 复杂代理 API 和队列写入口。 |
| Worker | 实际同步执行。 |
| Store | 队列状态。 |
| 测试 | 离线、重试、错误映射。 |

## 5. 前置依赖

- H2 已通过验收。
- 主线 P3 已进入开发。
- `../../01-agent-host-core/p3-host-api-sync-complex-proxy/goal.md`

## 6. 交付物

- 同步触发 API。
- 复杂远程代理 API。
- 失败状态查询能力。

## 7. 验收方式

- 远程离线时写入队列。
- 网络恢复后可重试。
- 错误原因可查询。

## 8. 进入下一阶段门禁

- H3 不引入 Redis、Kafka 或独立队列。
- 主线 P3 已通过验收。
