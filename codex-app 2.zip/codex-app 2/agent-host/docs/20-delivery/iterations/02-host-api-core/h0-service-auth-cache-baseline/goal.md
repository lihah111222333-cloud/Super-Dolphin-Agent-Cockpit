# H0 Service Auth Cache Baseline 阶段目标

整理日期：2026-06-23

阶段目录：`h0-service-auth-cache-baseline/`

上级规划：`../master-plan.md`

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | H0 |
| 阶段名称 | Service Auth Cache Baseline |
| 所属迭代 | `20-delivery/iterations/02-host-api-core` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | Host API 视角的 P0 基础服务、鉴权、远程 client 和 cache 基线。 |

## 1. 计划目标

完成 Host API 最小服务骨架，使本地服务具备可启动、可鉴权、可访问远程 API、可读取和写入本地 cache 的基础能力。

## 2. 阶段内容

- Gin server 和基础路由。
- middleware、错误响应和日志。
- 本地 session API。
- Remote API Client 调用入口。
- SQLite cache API/service。
- `config.yaml` 读取入口。

## 3. 范围边界

允许：

- Host API P0 handler/service/store 调用。
- 远程 token refresh 入口。
- cache hit/stale/miss 行为。

禁止：

- Runtime API。
- SSE runtime event。
- 动态数据完整代理。
- 同步队列。

## 4. 责任归属

| 责任 | 内容 |
| --- | --- |
| Host API | 路由、鉴权、错误响应和基础代理。 |
| Store | session/cache 数据访问。 |
| Remote Client | 远程请求、refresh 和错误映射。 |
| 测试 | handler/service 基础验证。 |

## 5. 前置依赖

- `../../01-agent-host-core/p0-host-api-foundation/goal.md`
- `../../../../10-foundation/architecture/technology-stack.md`
- `../../../../10-foundation/architecture/database-design.md`

## 6. 交付物

- Host API P0 路由。
- 本地 session 接口。
- Remote API Client 接入。
- cache service。

## 7. 验收方式

- 本地服务可启动。
- 无 token 访问受保护接口返回 `UNAUTHORIZED`。
- 远程 client 错误可映射。
- cache 行为可测试。

## 8. 进入下一阶段门禁

- 主线 P0 已通过验收。
- Host API 未出现 runtime 或 Adapter 直接依赖。
