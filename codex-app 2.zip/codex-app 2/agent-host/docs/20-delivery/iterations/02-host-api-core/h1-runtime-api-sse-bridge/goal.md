# H1 Runtime API SSE Bridge 阶段目标

整理日期：2026-06-23

阶段目录：`h1-runtime-api-sse-bridge/`

上级规划：`../master-plan.md`

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | H1 |
| 阶段名称 | Runtime API SSE Bridge |
| 所属迭代 | `20-delivery/iterations/02-host-api-core` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | Host API 视角的 P1 runtime endpoint 和 SSE 桥接。 |

## 1. 计划目标

在不实现 AgentRuntime 和 Adapter 的前提下，让 Host API 能调用 AgentRuntime，并把 runtime event 序列化为 Electron 可消费的 SSE。

## 2. 阶段内容

- 创建任务/thread 的 Host API。
- 启动 turn 的 Host API。
- 取消 turn 的 Host API。
- runtime event SSE endpoint。
- pending request 查询和响应 API。
- Host API 层状态投影入口。

## 3. 范围边界

允许：

- 调用 AgentRuntime interface。
- 序列化统一 RuntimeEvent。
- 做 HTTP/SSE 错误映射。

禁止：

- 调用 `codexapp-go`。
- 引用 Codex protocol 类型。
- 实现 CodexRuntimeAdapter。
- 自己构造 runtime event。

## 4. 责任归属

| 责任 | 内容 |
| --- | --- |
| Host API | runtime REST/SSE endpoint。 |
| AgentRuntime | 提供可调用 contract。 |
| Store | task/run/event 投影入口。 |
| 测试 | HTTP/SSE contract 和权限校验。 |

## 5. 前置依赖

- H0 已通过验收。
- 主线 P1 的 AgentRuntime 最小 contract 已可用。
- `../../03-runtime-adapter-core/r0-runtime-contract-baseline/goal.md`

## 6. 交付物

- Runtime 相关 Host API。
- SSE endpoint。
- Pending request Host API。
- Host API contract 测试。

## 7. 验收方式

- Host API 可通过 AgentRuntime 启动 turn。
- SSE 输出不泄漏 Codex 原生 protocol。
- pending request 可查询和响应。

## 8. 进入下一阶段门禁

- 主线 P1 已通过最小闭环验收。
- Host API 未绕过 AgentRuntime。
