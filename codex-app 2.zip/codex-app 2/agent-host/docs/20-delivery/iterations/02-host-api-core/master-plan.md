# Host API Core 专项迭代总规划

整理日期：2026-06-23

状态：专项迭代视图

迭代目录：`docs/20-delivery/iterations/02-host-api-core/`

上游主线：`../01-agent-host-core/master-plan.md`

## 1. 规划目标

本文定义 Host API 需求域的专项阶段视图。它只聚焦 HTTP REST、SSE、鉴权、远程代理、本地状态投影、同步队列入口和发布 API 文档。

本文不能推翻 `01-agent-host-core` 的 P0 -> P4 主线顺序。Host API 阶段必须映射到主线阶段，不能提前依赖未来 AgentRuntime、Adapter 或同步队列能力。

## 2. 总体推进原则

- Host API 专项阶段只描述 Host API 责任，不实现 AgentRuntime 或 CodexRuntimeAdapter。
- H0-H4 必须按顺序推进。
- H1 的 runtime API 只能依赖主线 P1 已完成的 AgentRuntime 能力。
- H2 只能使用 P0 cache 和 P1 runtime event。
- H3 才能使用同步队列。
- Host API 不直接调用 `codexapp-go`，不引用 Codex protocol 类型。

## 3. 阶段视图

```text
H0 Service Auth Cache Baseline
  -> H1 Runtime API SSE Bridge
  -> H2 Dynamic Data Task Projection
  -> H3 Sync Complex Proxy
  -> H4 API Release Hardening
```

| 阶段 | 映射主线 | 阶段目标 | 阶段目标文件 |
| --- | --- | --- | --- |
| H0 | P0 | 建立 Host API 服务、鉴权、远程 client 和 cache 基线。 | `h0-service-auth-cache-baseline/goal.md` |
| H1 | P1 | 暴露 runtime HTTP/SSE 桥接，不实现 runtime。 | `h1-runtime-api-sse-bridge/goal.md` |
| H2 | P2 | 完成动态数据代理和任务投影 API。 | `h2-dynamic-data-task-projection/goal.md` |
| H3 | P3 | 完成同步队列入口和复杂远程代理 API。 | `h3-sync-complex-proxy/goal.md` |
| H4 | P4 | 收敛 Host API 文档、错误码和回归验证。 | `h4-api-release-hardening/goal.md` |

## 4. 范围边界

Host API 负责：

- Gin 路由和 middleware。
- REST request/response。
- SSE event 输出。
- 本地 session 校验。
- Remote API Client 调用。
- Store/service 调用。
- AgentRuntime 调用入口。

Host API 不负责：

- AgentRuntime contract 实现。
- CodexRuntimeAdapter 映射。
- `codexapp-go` JSON-RPC 调用。
- Electron UI。
- AgentCloud 云端实现。

## 5. 阶段详情

| 阶段 | 内容 | 范围边界 | 责任 | 前置 | 交付物 | 验收 |
| --- | --- | --- | --- | --- | --- | --- |
| H0 | Gin、session、remote client、cache。 | 不做 runtime API、SSE runtime event、同步队列。 | Host API、Store、Remote Client。 | 主线 P0。 | P0 路由、session、remote client、cache service。 | 服务可启动，鉴权、错误映射和 cache 可测。 |
| H1 | runtime REST、SSE、pending request API。 | 只调用 AgentRuntime，不实现 runtime，不碰 `codexapp-go`。 | Host API、AgentRuntime 调用方、Store 投影入口。 | H0、主线 P1、Runtime R0/R1/R2。 | runtime endpoint、SSE endpoint、pending API。 | 可启动 turn、输出 SSE、pending 可响应。 |
| H2 | 动态数据代理、任务事件、产物和上下文查询。 | 不做同步队列，不直接远程上云。 | Host API、Store、Remote Client。 | H1、主线 P2。 | 模型、技能、专家、连接器、资料库、自动化模板、灵感和任务体验 API。 | Host API 可读动态数据和任务投影。 |
| H3 | 同步队列入口、复杂远程代理。 | 不引入外部队列，不绕过 Remote Client。 | Host API、Worker、Store、Remote Client。 | H2、主线 P3。 | 同步触发、反馈、日志、分享、项目、助理、计费 API。 | 离线入队、恢复重试、错误可查。 |
| H4 | API 文档、错误码、SSE、回归。 | 不新增核心 API 域。 | Host API、测试、文档。 | H3、主线 P4。 | Host API spec、错误码、回归结果。 | 文档与实现一致，关键链路通过。 |

各阶段详细目标、前置依赖和门禁以对应 `goal.md` 为准。

## 6. 后续阶段计划拆分规则

- 每个 H 阶段必须对应主线 P 阶段。
- 每个阶段目录只放 Host API 相关目标和验收。
- 阶段任务拆分必须引用本迭代 `goal.md` 和主线对应 P 阶段 `goal.md`。
- 如果 Host API 需求需要 runtime 能力，必须先确认 `03-runtime-adapter-core` 对应阶段已经在主线允许范围内完成。

## 7. 总结

`02-host-api-core` 是 Host API 的专项管理视图，不是独立主线。它用于让 Host API 开发者快速知道自己在每个主线阶段该交付什么、不能做什么。
