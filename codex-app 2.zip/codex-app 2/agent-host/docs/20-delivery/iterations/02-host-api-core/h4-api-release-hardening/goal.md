# H4 API Release Hardening 阶段目标

整理日期：2026-06-23

阶段目录：`h4-api-release-hardening/`

上级规划：`../master-plan.md`

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | H4 |
| 阶段名称 | API Release Hardening |
| 所属迭代 | `20-delivery/iterations/02-host-api-core` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | Host API 视角的 P4 文档、错误码、兼容和回归收敛。 |

## 1. 计划目标

把 Host API 已实现接口收敛到可发布状态，确保文档、错误码、鉴权、SSE 和回归测试一致。

## 2. 阶段内容

- Host API spec 校准。
- 错误码和响应 envelope 校准。
- SSE event 文档校准。
- 鉴权和权限回归。
- cache 和同步代理回归。

## 3. 范围边界

允许：

- 修正已实现 Host API 缺口。
- 补齐 API 文档和测试。

禁止：

- 新增核心 API 域。
- 引入第二 runtime 或新远程代理类别。

## 4. 责任归属

| 责任 | 内容 |
| --- | --- |
| Host API | API 文档、错误码和兼容性。 |
| 测试 | HTTP/SSE 回归。 |
| 文档 | `30-release/host-api-spec.md` 校准。 |

## 5. 前置依赖

- H3 已通过验收。
- 主线 P4 已进入发布稳定化。

## 6. 交付物

- 更新后的 Host API spec。
- 错误码说明。
- Host API 回归测试结果。

## 7. 验收方式

- Host API 文档与实现一致。
- 鉴权、cache、SSE、同步代理关键链路回归通过。
- 未新增未来阶段 API。

## 8. 进入下一阶段门禁

- Host API Core 视图完成。
- 后续 Host API 增强必须另建专项规划。
