# H2 Dynamic Data Task Projection 阶段目标

整理日期：2026-06-23

阶段目录：`h2-dynamic-data-task-projection/`

上级规划：`../master-plan.md`

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | H2 |
| 阶段名称 | Dynamic Data Task Projection |
| 所属迭代 | `20-delivery/iterations/02-host-api-core` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | Host API 视角的 P2 动态数据代理和任务投影。 |

## 1. 计划目标

完成 Electron 高频读取的动态数据代理和任务体验 API，让前端不直接访问远程 API。

## 2. 阶段内容

- 模型、技能、专家 API。
- 连接器、资料库 API。
- 自动化模板、灵感 API。
- 任务事件查询。
- 产物、文件变更、上下文引用查询。

## 3. 范围边界

允许：

- 使用 Remote API Client 和 SQLite cache。
- 使用 P1 runtime event 投影。
- 管理本地技能、专家、自定义模型等本地对象。

禁止：

- 同步队列。
- 复杂远程写代理。
- Electron 远程 token 暴露。

## 4. 责任归属

| 责任 | 内容 |
| --- | --- |
| Host API | 动态数据和任务体验 API。 |
| Store | 本地投影和对象读取。 |
| Remote Client | 远程目录读取和缓存刷新。 |
| 测试 | cache、权限、投影查询。 |

## 5. 前置依赖

- H1 已通过验收。
- 主线 P2 已进入开发。
- `../../01-agent-host-core/p2-host-api-dynamic-task-experience/goal.md`

## 6. 交付物

- 动态数据代理 API。
- 任务事件和产物查询 API。
- 本地对象管理 API。

## 7. 验收方式

- 动态数据可从 Host API 读取。
- 远程不可用时可按策略返回 stale cache。
- 任务事件和产物可按任务查询。

## 8. 进入下一阶段门禁

- H2 不依赖 H3 同步队列。
- 主线 P2 已通过验收。
