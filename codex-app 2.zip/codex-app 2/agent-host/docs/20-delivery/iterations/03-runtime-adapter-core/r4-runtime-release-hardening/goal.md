# R4 Runtime Release Hardening 阶段目标

整理日期：2026-06-23

阶段目录：`r4-runtime-release-hardening/`

上级规划：`../master-plan.md`

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | R4 |
| 阶段名称 | Runtime Release Hardening |
| 所属迭代 | `20-delivery/iterations/03-runtime-adapter-core` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | Runtime/Adapter 视角的 P4 发布前稳定化。 |

## 1. 计划目标

收敛 AgentRuntime 和 CodexRuntimeAdapter 的 contract、映射、错误、capability 和测试，确保发布前边界稳定。

## 2. 阶段内容

- AgentRuntime contract 校准。
- Adapter 映射覆盖校准。
- pending request 响应幂等校准。
- error/capability 文档校准。
- runtime mock 和 adapter 测试补齐。

## 3. 范围边界

允许：

- 修正已实现 Runtime/Adapter 缺口。
- 补齐测试和文档。

禁止：

- 引入第二 runtime。
- 引入 runtime registry。
- 改写 Host API 或 Store 职责。

## 4. 责任归属

| 责任 | 内容 |
| --- | --- |
| AgentRuntime | contract 稳定。 |
| CodexRuntimeAdapter | 映射稳定。 |
| 测试 | contract、mapping、error、capability 回归。 |
| 文档 | Runtime/Adapter 文档校准。 |

## 5. 前置依赖

- R3 已通过验收。
- 主线 P4 已进入发布稳定化。

## 6. 交付物

- 稳定 AgentRuntime contract。
- CodexRuntimeAdapter 映射测试。
- capability/error 文档。
- Runtime/Adapter 回归结果。

## 7. 验收方式

- Runtime/Adapter 测试通过。
- AgentRuntime 不依赖具体 SDK。
- Adapter 不承担 HTTP/SSE/持久化职责。
- `codexapp-go` 边界未被复制进 AgentHost 上层。

## 8. 进入下一阶段门禁

- Runtime Adapter Core 视图完成。
- 第二 runtime 或 registry 必须另建后续规划，不在本迭代补入。
