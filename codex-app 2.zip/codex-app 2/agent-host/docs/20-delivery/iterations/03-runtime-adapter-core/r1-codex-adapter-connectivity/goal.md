# R1 Codex Adapter Connectivity 阶段目标

整理日期：2026-06-23

阶段目录：`r1-codex-adapter-connectivity/`

上级规划：`../master-plan.md`

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | R1 |
| 阶段名称 | Codex Adapter Connectivity |
| 所属迭代 | `20-delivery/iterations/03-runtime-adapter-core` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | 接入 CodexRuntimeAdapter 与 `codexapp-go`，完成 P1 最小连接能力。 |

## 1. 计划目标

让 CodexRuntimeAdapter 能通过 `codexapp-go` 建立底层连接，并把 thread/turn 的最小调用映射到 AgentRuntime contract。

## 2. 阶段内容

- CodexRuntimeAdapter 初始化。
- `codexapp-go` client 注入。
- runtime info/version 查询。
- thread 创建映射。
- turn 启动映射。
- cancel/interrupt 最小映射。

## 3. 范围边界

允许：

- Adapter 依赖 `codexapp-go`。
- Adapter 使用 Codex protocol 类型并转换为 AgentRuntime 类型。

禁止：

- 在 AgentRuntime 中泄漏 Codex 类型。
- Adapter 自己实现 JSON-RPC transport。
- Adapter 写数据库。
- Adapter 输出 HTTP/SSE。

## 4. 责任归属

| 责任 | 内容 |
| --- | --- |
| CodexRuntimeAdapter | SDK 调用和最小映射。 |
| codexapp-go | JSON-RPC client、协议类型和事件订阅。 |
| AgentRuntime | 接收统一模型。 |
| 测试 | adapter connectivity 和错误路径。 |

## 5. 前置依赖

- R0 已通过验收。
- `codexapp-go` 已具备所需 JSON-RPC client 能力。
- 主线 P1 已进入 runtime 最小闭环。

## 6. 交付物

- CodexRuntimeAdapter 初始化能力。
- thread/turn 最小映射。
- runtime info 查询。
- cancel/interrupt 最小能力。

## 7. 验收方式

- Adapter 可通过 `codexapp-go` 发起一次最小 turn。
- Adapter 输出 AgentRuntime 类型。
- AgentRuntime 包仍不依赖 `codexapp-go`。

## 8. 进入下一阶段门禁

- R1 最小连接能力可测。
- 未重复实现 `codexapp-go` 的 transport 或 request id 管理。
