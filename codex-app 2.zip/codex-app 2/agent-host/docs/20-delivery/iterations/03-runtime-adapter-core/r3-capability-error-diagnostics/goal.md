# R3 Capability Error Diagnostics 阶段目标

整理日期：2026-06-23

阶段目录：`r3-capability-error-diagnostics/`

上级规划：`../master-plan.md`

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | R3 |
| 阶段名称 | Capability Error Diagnostics |
| 所属迭代 | `20-delivery/iterations/03-runtime-adapter-core` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | 完成 capability、error 和诊断映射，支撑主线 P2 任务体验。 |

## 1. 计划目标

让 Host API 可以基于 AgentRuntime capability 判断能力可用性，并基于 RuntimeError 展示稳定错误和诊断信息。

## 2. 阶段内容

- capability 声明。
- unsupported capability 错误。
- transport/protocol/runtime error 映射。
- raw cause 和 request id 诊断摘要。
- runtime health/version 输出。

## 3. 范围边界

允许：

- Adapter 保留 raw 诊断摘要。
- RuntimeError 包含可展示信息和可诊断 code。

禁止：

- 把 raw payload 变成 Host API 业务依赖。
- 在 Adapter 内做 UI 展示文案策略。
- 引入多 runtime registry。

## 4. 责任归属

| 责任 | 内容 |
| --- | --- |
| AgentRuntime | capability 和 error 统一模型。 |
| CodexRuntimeAdapter | Codex 错误和能力映射。 |
| Host API | 错误 envelope 和展示策略。 |
| 测试 | 错误映射和 capability 分支。 |

## 5. 前置依赖

- R2 已通过验收。
- 主线 P2 需要 runtime 诊断和 capability。

## 6. 交付物

- capability mapper。
- error mapper。
- runtime health/version 输出。
- 诊断 raw 摘要。

## 7. 验收方式

- 不支持能力返回明确 capability error。
- Codex/JSON-RPC/transport 错误映射为 RuntimeError。
- raw 信息仅用于诊断，不进入 Host API 业务判断。

## 8. 进入下一阶段门禁

- R3 可支撑 P2 任务体验和诊断。
- 未引入多 runtime 系统。
