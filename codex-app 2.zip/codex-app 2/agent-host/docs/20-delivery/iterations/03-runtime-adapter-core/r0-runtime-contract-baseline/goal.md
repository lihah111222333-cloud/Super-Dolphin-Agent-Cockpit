# R0 Runtime Contract Baseline 阶段目标

整理日期：2026-06-23

阶段目录：`r0-runtime-contract-baseline/`

上级规划：`../master-plan.md`

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | R0 |
| 阶段名称 | Runtime Contract Baseline |
| 所属迭代 | `20-delivery/iterations/03-runtime-adapter-core` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | 固定 AgentRuntime 最小 contract，作为主线 P1 的 runtime 前置。 |

## 1. 计划目标

定义 AgentRuntime 最小稳定模型，使 Host API 可以依赖统一 thread、turn、event、pending request、capability 和 error，不接触 Codex protocol。

## 2. 阶段内容

- AgentRuntime interface。
- ThreadRef、TurnRef。
- RuntimeEvent。
- PendingRequest。
- RuntimeError。
- RuntimeCapability。
- RuntimeInfo。

## 3. 范围边界

允许：

- 定义 AgentRuntime 统一模型。
- 提供测试用 fake runtime。

禁止：

- 依赖 `codexapp-go`。
- 引用 Codex protocol 类型。
- 实现 HTTP/SSE。
- 实现 Adapter 连接。

## 4. 责任归属

| 责任 | 内容 |
| --- | --- |
| AgentRuntime | contract 和统一模型。 |
| Host API | 只作为未来调用方校验需求。 |
| 测试 | fake runtime 和 contract 测试。 |

## 5. 前置依赖

- `../../../../10-foundation/product/agent-runtime-product-spec.md`
- `../../../../10-foundation/architecture/agent-runtime-technical-architecture.md`
- `../../01-agent-host-core/p1-runtime-adapter-minimal-loop/goal.md`

## 6. 交付物

- AgentRuntime 最小接口。
- 统一模型类型。
- fake runtime 测试辅助。
- contract 测试。

## 7. 验收方式

- AgentRuntime 包不依赖 `codexapp-go`。
- Host API 可基于 contract 编译调用。
- fake runtime 可驱动最小 thread/turn/event 测试。

## 8. 进入下一阶段门禁

- R0 contract 已满足主线 P1 最小闭环。
- 未出现 Adapter、HTTP 或数据库职责。
