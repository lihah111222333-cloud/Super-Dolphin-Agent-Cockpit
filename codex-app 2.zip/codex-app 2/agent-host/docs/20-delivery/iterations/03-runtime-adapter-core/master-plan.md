# Runtime Adapter Core 专项迭代总规划

整理日期：2026-06-23

状态：专项迭代视图

迭代目录：`docs/20-delivery/iterations/03-runtime-adapter-core/`

上游主线：`../01-agent-host-core/master-plan.md`

## 1. 规划目标

本文定义 AgentRuntime + CodexRuntimeAdapter 的专项阶段视图。它聚焦 runtime 抽象、Codex adapter、`codexapp-go` 接入边界、事件映射、pending request、错误映射和 capability 映射。

本文不能推翻 `01-agent-host-core` 的 P0 -> P4 主线顺序，也不能把 Runtime/Adapter 变成独立项目。

## 2. 总体推进原则

- Runtime/Adapter 专项阶段只服务 AgentHost 主线。
- AgentRuntime 不依赖 `codexapp-go` 或 Codex protocol 类型。
- CodexRuntimeAdapter 才能依赖 `codexapp-go`。
- Adapter 只做翻译，不做 HTTP、SSE、数据库持久化或 UI 投影。
- 首版不做 runtime registry、插件系统或多 adapter 热切换。
- H1 Host API runtime bridge 只能调用已完成的 AgentRuntime contract。

## 3. 阶段视图

```text
R0 Runtime Contract Baseline
  -> R1 Codex Adapter Connectivity
  -> R2 Event Pending Mapping
  -> R3 Capability Error Diagnostics
  -> R4 Runtime Release Hardening
```

| 阶段 | 映射主线 | 阶段目标 | 阶段目标文件 |
| --- | --- | --- | --- |
| R0 | P1 前置/开始 | 固定 AgentRuntime 最小 contract。 | `r0-runtime-contract-baseline/goal.md` |
| R1 | P1 | 接入 CodexRuntimeAdapter 与 `codexapp-go`。 | `r1-codex-adapter-connectivity/goal.md` |
| R2 | P1 | 完成事件和 pending request 映射。 | `r2-event-pending-mapping/goal.md` |
| R3 | P2 | 完成 capability、error 和诊断映射。 | `r3-capability-error-diagnostics/goal.md` |
| R4 | P4 | Runtime/Adapter 发布前稳定化。 | `r4-runtime-release-hardening/goal.md` |

## 4. 范围边界

Runtime/Adapter 负责：

- AgentRuntime contract。
- CodexRuntimeAdapter。
- `codexapp-go` 调用边界。
- runtime event 映射。
- pending request 映射。
- error/capability 映射。
- raw 诊断信息保留。

Runtime/Adapter 不负责：

- HTTP REST。
- SSE 序列化。
- SQLite 持久化。
- Electron UI。
- Remote API Client。
- 同步队列。

## 5. 阶段详情

| 阶段 | 内容 | 范围边界 | 责任 | 前置 | 交付物 | 验收 |
| --- | --- | --- | --- | --- | --- | --- |
| R0 | AgentRuntime interface、thread、turn、event、pending、error、capability。 | 不依赖 SDK，不实现 Adapter、HTTP、数据库。 | AgentRuntime、测试。 | 主线 P1 前置。 | Runtime contract、统一模型、fake runtime。 | Host API 可基于 contract 调用，Runtime 不依赖 `codexapp-go`。 |
| R1 | CodexRuntimeAdapter 初始化、SDK 注入、thread/turn/cancel 映射。 | Adapter 可依赖 `codexapp-go`，不自写 transport。 | CodexRuntimeAdapter、codexapp-go、测试。 | R0、主线 P1。 | Codex adapter 连接和最小调用。 | 可发起最小 turn，输出 AgentRuntime 类型。 |
| R2 | notification/event、server request/pending request、response 映射。 | 不持久化，不决定审批策略，不序列化 SSE。 | CodexRuntimeAdapter、AgentRuntime、Host API 调用方。 | R1、主线 P1。 | RuntimeEvent、PendingRequest、response 映射。 | 事件和 pending 可映射，慢消费者不阻塞底层 reader。 |
| R3 | capability、RuntimeError、health/version、raw 诊断摘要。 | raw 只做诊断，不成为上层业务依赖。 | AgentRuntime、CodexRuntimeAdapter、测试。 | R2、主线 P2。 | capability mapper、error mapper、诊断输出。 | unsupported capability 和底层错误可稳定映射。 |
| R4 | contract、mapping、pending 幂等、error/capability 文档和回归。 | 不引入第二 runtime 或 registry。 | AgentRuntime、CodexRuntimeAdapter、测试、文档。 | R3、主线 P4。 | Runtime/Adapter 回归结果和文档校准。 | Runtime 不依赖 SDK，Adapter 不承担 HTTP/SSE/持久化。 |

各阶段详细目标、前置依赖和门禁以对应 `goal.md` 为准。

## 6. 后续阶段计划拆分规则

- 每个 R 阶段必须映射到主线 P 阶段。
- 每个阶段目录只放 Runtime/Adapter 目标和验收。
- 任何需要 HTTP/SSE 的内容归 `02-host-api-core`。
- 任何需要持久化的内容只能声明输出模型，由 Host API/Store 负责落库。

## 7. 总结

`03-runtime-adapter-core` 是 Runtime/Adapter 的专项管理视图。它保证 runtime 能力可独立设计和测试，但不允许脱离 AgentHost 主线成为另一个项目。
