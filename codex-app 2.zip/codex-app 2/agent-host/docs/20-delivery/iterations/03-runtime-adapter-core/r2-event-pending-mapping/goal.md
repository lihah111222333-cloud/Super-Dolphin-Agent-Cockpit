# R2 Event Pending Mapping 阶段目标

整理日期：2026-06-23

阶段目录：`r2-event-pending-mapping/`

上级规划：`../master-plan.md`

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | R2 |
| 阶段名称 | Event Pending Mapping |
| 所属迭代 | `20-delivery/iterations/03-runtime-adapter-core` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | 完成 Codex notification/server request 到 AgentRuntime event/pending request 的映射。 |

## 1. 计划目标

让 CodexRuntimeAdapter 能持续读取底层事件，并转换成 AgentHost 可消费的 RuntimeEvent 和 PendingRequest。

## 2. 阶段内容

- notification 到 RuntimeEvent 映射。
- server request 到 PendingRequest 映射。
- pending request response 映射。
- event reader 与上层 consumer 解耦。
- raw 诊断摘要保留。

## 3. 范围边界

允许：

- Adapter 内部做轻量缓冲和背压策略。
- 保留 raw 摘要用于诊断。

禁止：

- Adapter 直接持久化 pending request。
- Adapter 决定审批策略。
- Adapter 序列化 SSE payload。

## 4. 责任归属

| 责任 | 内容 |
| --- | --- |
| CodexRuntimeAdapter | 事件、pending request 和 response 映射。 |
| AgentRuntime | 定义统一事件和 pending 模型。 |
| Host API | 负责持久化和用户交互。 |
| 测试 | 映射表、背压和响应幂等。 |

## 5. 前置依赖

- R1 已通过验收。
- Host API H1 可以消费 AgentRuntime event。

## 6. 交付物

- RuntimeEvent 映射。
- PendingRequest 映射。
- Pending response 映射。
- 事件读取不阻塞底层 reader 的测试。

## 7. 验收方式

- Codex 事件可转换为稳定 RuntimeEvent。
- pending request 可转换、可响应。
- Adapter 不持久化 pending request。
- 慢消费者不会直接阻塞底层 reader。

## 8. 进入下一阶段门禁

- R2 可支撑主线 P1 端到端 turn。
- 映射不泄漏 Codex protocol 到 Host API。
