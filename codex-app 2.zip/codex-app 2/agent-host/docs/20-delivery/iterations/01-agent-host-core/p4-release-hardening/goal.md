# P4 Release Hardening 阶段目标

整理日期：2026-06-23

阶段目录：`p4-release-hardening/`

上级规划：`../master-plan.md`

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | P4 |
| 阶段名称 | Release Hardening |
| 所属迭代 | `20-delivery/iterations/01-agent-host-core` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | 收敛 P0-P3 已实现能力，完成发布前稳定化。 |

## 1. 计划目标

完成 AgentHost Core 发布前文档、错误码、兼容说明、回归测试和实现一致性校准。

## 2. 阶段内容

- Host API 文档校准。
- 错误码和响应 envelope 校准。
- 数据库 schema 与 GORM model 一致性校准。
- Runtime capability 文档校准。
- Adapter 映射和诊断校准。
- 最小回归测试。

## 3. 范围边界

允许：

- 修正 P0-P3 已实现能力缺口。
- 补齐文档、测试和兼容说明。
- 统一错误码和诊断输出。

禁止：

- 新增 P5 范围能力。
- 引入第二 runtime。
- 改写 P0-P3 阶段边界。

## 4. 责任归属

| 责任 | 内容 |
| --- | --- |
| Host API | API 文档、错误码、兼容说明。 |
| AgentRuntime | contract 稳定性和 capability 文档。 |
| CodexRuntimeAdapter | 映射一致性和诊断信息。 |
| 测试 | 最小回归和验收证据。 |

## 5. 前置依赖

- P3 已通过验收。
- P0-P3 实现与文档差异已列出。

## 6. 交付物

- 发布前 Host API 文档。
- 错误码和兼容说明。
- 最小回归测试集。
- P0-P4 验收记录。

## 7. 验收方式

- 关键链路回归通过。
- 文档与实现一致。
- 入口文档指向当前阶段。
- 未新增 P5 或未来 runtime 能力。

## 8. 进入下一阶段门禁

P4 完成后才能进入 AgentHost Core 后续增强迭代。后续增强必须新增独立规划，不得回填修改 P0-P4 已冻结边界。
