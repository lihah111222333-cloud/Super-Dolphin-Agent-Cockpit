# AgentHost Core P0-P4 总阶段规划

整理日期：2026-06-23

状态：当前有效主线总阶段规划

迭代目录：`docs/20-delivery/iterations/01-agent-host-core/`

上游依据：

- `../../../00-start/current-status.md`
- `../../../10-foundation/product/agent-host-product-spec.md`
- `../../../10-foundation/architecture/agent-host-technical-architecture.md`
- `../../../10-foundation/architecture/technology-stack.md`
- `../../../10-foundation/architecture/database-design.md`
- `../../../10-foundation/product/agent-runtime-product-spec.md`
- `../../../10-foundation/product/agent-runtime-adapter-product-spec.md`
- `../../execution/execution-spec.md`
- `../../feature-plan.md`
- `../../../30-release/host-api-spec.md`

## 1. 规划目标

本文定义 `agent-host` 从 P0 到 P4 的主线开发顺序。Host API、AgentRuntime、AgentRuntimeAdapter 是 AgentHost 内部需求域，必须服从本主线阶段门禁。

本文不替代产品规格、技术架构、数据库设计或 Host API 规格。各阶段的详细目标和门禁以阶段目录下 `goal.md` 为准。

AgentHost 全局功能监管清单以 `../../feature-plan.md` 为准；后续任务拆解应引用其中的功能编号。

目标：

- 固定 AgentHost P0 -> P4 的严格推进顺序。
- 明确每个阶段的目标、内容、边界、责任、依赖、交付物和验收方式。
- 防止专项迭代视图反向修改主线顺序。
- 为后续阶段任务拆解提供统一边界。

## 2. 总体推进原则

- 阶段必须严格顺序推进，不做并行阶段假设。
- 当前阶段只能依赖已经完成的阶段产物。
- Host API 只能通过 AgentRuntime 触达 runtime。
- AgentRuntime 不依赖 `codexapp-go` 或 Codex protocol 类型。
- CodexRuntimeAdapter 是首版唯一 adapter，可以依赖 `codexapp-go`。
- 未进入当前阶段的接口不得用空实现、假实现或 panic stub 占位。
- 本地服务保持 Go 单体进程，不引入 Redis、Kafka、PostgreSQL、独立队列系统或微服务拆分。
- SQLite schema 以 `../../../10-foundation/architecture/database-design.md` 和 `../../../../scripts/sqlite/create-database.sql` 为准。

## 3. 总阶段视图

```text
P0 Host API Foundation
  -> P1 Runtime Adapter Minimal Loop
  -> P2 Host API Dynamic Task Experience
  -> P3 Host API Sync Complex Proxy
  -> P4 Release Hardening
```

| 阶段 | 阶段目标 | 覆盖需求域 | 最小可验证产物 | 阶段目标文件 |
| --- | --- | --- | --- | --- |
| P0 | 建立本地服务、安全和远程代理基础。 | Host API | Gin、config、slog、SQLite、session、remote client、cache。 | `p0-host-api-foundation/goal.md` |
| P1 | 建立 runtime 最小闭环。 | Host API、AgentRuntime、CodexRuntimeAdapter | thread/turn、事件订阅、pending request、Codex 接入。 | `p1-runtime-adapter-minimal-loop/goal.md` |
| P2 | 完成动态数据代理和任务体验投影。 | Host API、AgentRuntime | 模型、技能、连接器、资料库、自动化模板、灵感、任务事件和产物投影。 | `p2-host-api-dynamic-task-experience/goal.md` |
| P3 | 完成同步队列和复杂远程代理。 | Host API | 同步队列、反馈、日志、分享、项目协作、助理网关、账号计费。 | `p3-host-api-sync-complex-proxy/goal.md` |
| P4 | 发布前稳定化。 | 全域 | API 文档、错误码、兼容说明、回归测试。 | `p4-release-hardening/goal.md` |

## 4. P0 Host API Foundation

### 4.1 阶段目标

建立 AgentHost 本地服务基础，使 Electron 可以通过本地 Host API 完成登录态校验、远程 API 代理和远程动态数据缓存读取。

### 4.2 阶段内容

- Go module 和 Gin HTTP server。
- `config.yaml` 配置加载。
- `log/slog` 结构化日志。
- GORM + `github.com/glebarez/sqlite`。
- SQLite 空库创建脚本验证。
- 本地 session 与远程 token 保存。
- Remote API Client。
- SQLite cache hit/stale/miss。

### 4.3 范围边界

允许：

- Host API 基础骨架。
- 本地鉴权、错误响应和远程代理基础能力。
- P0 表和最小 store/service/handler。

禁止：

- Runtime thread/turn 执行。
- AgentRuntimeAdapter 接入。
- 动态数据完整业务代理。
- 同步队列 worker。

### 4.4 责任归属

- Host API：HTTP、session、错误响应、远程代理入口。
- Store：SQLite 初始化、GORM model、缓存读写。
- Remote Client：远程 token 注入、refresh、错误映射。
- 测试：鉴权、token refresh、cache hit/stale/miss。

### 4.5 前置依赖

- 技术栈说明已确认。
- 数据库设计和创建脚本已确认。
- 执行规格 P0 范围已确认。

### 4.6 交付物

- 可启动的 AgentHost 本地 Go 服务。
- 可执行 SQLite 创建脚本。
- 本地 session 能力。
- Remote API Client。
- SQLite cache 基础能力。

### 4.7 验收方式

- SQLite 创建脚本可创建空库并通过 `PRAGMA foreign_key_check`。
- 鉴权接口和受保护接口行为可测。
- 远程 token refresh 只重试一次。
- cache hit/stale/miss/forceRefresh 可测。
- P0 不依赖 P1/P2/P3 能力。

## 5. P1 Runtime Adapter Minimal Loop

### 5.1 阶段目标

建立 AgentRuntime 与 CodexRuntimeAdapter 的最小闭环，使 Host API 可以启动一次 Codex turn 并通过 SSE 收到 runtime 事件。

### 5.2 阶段内容

- AgentRuntime 最小接口和统一模型。
- CodexRuntimeAdapter 首版接入。
- thread 创建和 turn 启动。
- runtime event 订阅。
- pending request 映射和响应入口。
- Host API runtime endpoint 和 SSE bridge。

### 5.3 范围边界

允许：

- 首版只接入 CodexRuntimeAdapter。
- Adapter 依赖 `codexapp-go`。
- Host API 通过 AgentRuntime 调用 runtime。

禁止：

- runtime registry。
- 多 adapter 动态加载。
- Host API 直接调用 `codexapp-go`。
- P2 动态数据代理。

### 5.4 责任归属

- AgentRuntime：统一接口、thread/turn/event/pending/error/capability 模型。
- CodexRuntimeAdapter：Codex SDK 调用和映射。
- Host API：runtime endpoint、SSE、状态投影入口。
- 测试：runtime mock、adapter mapping、最小端到端 turn。

### 5.5 前置依赖

- P0 已通过验收。
- `codexapp-go` 已具备 P1 所需底层 JSON-RPC client 能力。
- AgentRuntime 产品和架构边界已确认。

### 5.6 交付物

- AgentRuntime 最小接口。
- CodexRuntimeAdapter 首版实现。
- Host API runtime endpoint。
- SSE runtime event 输出。
- pending request 回复路径。

### 5.7 验收方式

- Host API 通过 AgentRuntime 启动 Codex turn。
- SSE 可收到 runtime started/delta/completed/error 类事件。
- pending request 可被识别并响应。
- AgentRuntime 不引用 Codex protocol 类型。

## 6. P2 Host API Dynamic Task Experience

### 6.1 阶段目标

完成常用动态数据代理和任务执行体验投影，使 Electron 只通过 Host API 即可读取配置、启动任务、查看事件和产物。

### 6.2 阶段内容

- 模型代理。
- 技能市场代理。
- 专家中心代理。
- 连接器代理。
- 资料库代理。
- 自动化模板代理。
- 灵感场景代理。
- 任务事件、产物、文件变更和上下文引用投影。

### 6.3 范围边界

允许：

- 使用 P0 cache 和 P1 runtime event 形成本地投影。
- 本地技能、专家、自定义模型和任务上下文持久化。
- 远程动态数据代理和缓存刷新。

禁止：

- 云同步队列最终一致性能力。
- 项目协作复杂代理。
- 助理网关和计费闭环。

### 6.4 责任归属

- Host API：动态数据代理和任务查询接口。
- Store：P2 本地对象持久化和投影。
- AgentRuntime：提供稳定 runtime event。
- Remote Client：远程目录类 API 代理。

### 6.5 前置依赖

- P1 runtime 最小闭环通过验收。
- P0 cache 可复用。
- P2 表结构和 GORM model 已按数据库设计落地。

### 6.6 交付物

- 动态数据代理接口。
- 任务事件和产物投影。
- 本地模型、技能、专家等本地对象管理。
- 资料库上下文引用保存。

### 6.7 验收方式

- Electron 不持有远程 token 即可读取动态数据。
- 远程不可用时可返回合规 stale cache。
- 任务事件可恢复查看。
- 产物和文件变更可按任务查询。
- P2 不依赖 P3 同步队列。

## 7. P3 Host API Sync Complex Proxy

### 7.1 阶段目标

完成需要上云的同步队列和复杂远程代理，使离线动作可记录、可重试、可追踪。

### 7.2 阶段内容

- 远程数据同步队列。
- 反馈、日志、分享同步代理。
- 项目协作代理。
- 助理网关代理。
- 账号计费代理。
- 进程内 worker 和 SQLite 状态表。

### 7.3 范围边界

允许：

- 使用进程内 worker + context + SQLite 状态表。
- 对需要上云的本地动作做重试。
- 代理项目、反馈、分享、计费等复杂远程 API。

禁止：

- Redis、Kafka、独立队列系统。
- 多进程分布式调度。
- Electron 直接调用远程 API。

### 7.4 责任归属

- Host API：复杂代理接口和同步触发。
- Worker：同步队列扫描、重试、失败记录。
- Store：`remote_sync_queue` 状态持久化。
- Remote Client：远程写接口调用和错误映射。

### 7.5 前置依赖

- P2 已通过验收。
- P0 Remote API Client 可复用。
- P3 同步队列表结构已落地。

### 7.6 交付物

- 同步队列。
- 同步 worker。
- 反馈、日志、分享、项目、助理和计费代理接口。
- 失败重试和错误记录。

### 7.7 验收方式

- 远程离线时同步任务保留。
- 网络恢复后同步任务可重试成功。
- token 过期时 refresh 后继续同步。
- 失败原因写入本地状态。
- P3 不引入独立队列系统。

## 8. P4 Release Hardening

### 8.1 阶段目标

收敛 P0-P3 已实现能力，完成发布前文档、错误码、兼容性和回归验证。

### 8.2 阶段内容

- Host API 文档校准。
- 错误码和错误 envelope 校准。
- 数据库 schema 与 GORM model 一致性校准。
- Runtime/Adapter capability 文档校准。
- 最小回归测试。

### 8.3 范围边界

允许：

- 修正 P0-P3 已实现能力的缺口。
- 补齐测试和文档。
- 做兼容性说明。

禁止：

- 新增核心需求域。
- 引入第二 runtime。
- 大规模重构阶段边界。

### 8.4 责任归属

- Host API：API 文档、错误码和兼容性。
- AgentRuntime：runtime contract 稳定性。
- CodexRuntimeAdapter：映射和诊断一致性。
- 测试：回归和验收证据。

### 8.5 前置依赖

- P3 已通过验收。
- P0-P3 文档和实现差异已列出。

### 8.6 交付物

- 发布前 Host API 文档。
- 错误码和兼容说明。
- 最小回归测试集。
- P0-P4 验收记录。

### 8.7 验收方式

- 关键链路回归通过。
- 文档与实现一致。
- 入口文档指向当前阶段。
- 未新增 P5 范围能力。

## 9. 后续阶段计划拆分规则

- 每个阶段必须有独立目录和 `goal.md`。
- `goal.md` 必须包含阶段序号、阶段名称、所属迭代、上游总规划、阶段定位、计划目标、阶段内容、范围边界、责任归属、前置依赖、交付物、验收方式、进入下一阶段门禁。
- 阶段任务清单只能在对应阶段 `goal.md` 完成后再拆。
- 任务不得依赖尚未进入的后续阶段。
- 专项迭代 `02-host-api-core` 和 `03-runtime-adapter-core` 只能作为视图，不能推翻本主线 P0-P4。

## 10. 总结

`01-agent-host-core` 是 AgentHost 的唯一主线总迭代。P0 先建立本地服务基础，P1 建立 runtime 闭环，P2 完成动态数据和任务体验，P3 补齐同步和复杂代理，P4 做发布前稳定化。后续所有专项规划都必须映射到该顺序。
