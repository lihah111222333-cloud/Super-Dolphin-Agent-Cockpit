# P0 Host API Foundation 阶段目标

整理日期：2026-06-23

阶段目录：`p0-host-api-foundation/`

上级规划：`../master-plan.md`

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | P0 |
| 阶段名称 | Host API Foundation |
| 所属迭代 | `20-delivery/iterations/01-agent-host-core` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | 建立 AgentHost 本地服务、安全、配置、日志、SQLite 和远程代理基础。 |

## 1. 计划目标

完成 AgentHost P0 基础能力，使 Electron 后续可以只通过本地 Host API 访问登录态、远程账号上下文和远程动态数据缓存。

## 2. 阶段内容

- Go module 和 Gin HTTP server。
- `config.yaml` 配置加载。
- `log/slog` 日志。
- GORM + `github.com/glebarez/sqlite`。
- SQLite 创建脚本和 P0 schema 验证。
- 本地 session。
- 远程 token 保存与 refresh。
- Remote API Client。
- SQLite cache hit/stale/miss/forceRefresh。

## 3. 范围边界

允许：

- Host API 基础骨架、错误响应、鉴权中间件。
- P0 store、service、handler 和测试。
- 远程 API client 的超时、鉴权注入和错误映射。

禁止：

- AgentRuntime thread/turn。
- CodexRuntimeAdapter 接入。
- P2 动态数据完整代理。
- P3 同步队列 worker。

## 4. 责任归属

| 责任 | 内容 |
| --- | --- |
| Host API | Gin 路由、鉴权、错误响应、本地 session API。 |
| Store | SQLite 初始化、GORM model、session 和 cache 持久化。 |
| Remote Client | token 注入、refresh、超时、错误映射和日志脱敏。 |
| 测试 | 鉴权、refresh、cache hit/stale/miss 和建库脚本验证。 |

## 5. 前置依赖

- `../../../../10-foundation/architecture/technology-stack.md`
- `../../../../10-foundation/architecture/database-design.md`
- `../../../../../scripts/sqlite/create-database.sql`
- `../../../execution/execution-spec.md`

## 6. 交付物

- 可启动的 AgentHost 本地 Go 服务。
- SQLite 创建脚本可执行。
- 本地 session 和受保护 API。
- Remote API Client。
- SQLite cache 基础能力。

## 7. 验收方式

- SQLite 创建脚本可创建空库并通过 `PRAGMA foreign_key_check`。
- 受保护接口无 token 返回 `UNAUTHORIZED`。
- 远程 access token 过期后只 refresh 一次。
- 远程不可用能返回统一错误。
- cache hit/stale/miss/forceRefresh 可通过测试验证。

## 8. 进入下一阶段门禁

进入 P1 前必须满足：

- P0 基础服务可运行。
- P0 不依赖 AgentRuntime、CodexRuntimeAdapter 或 P2/P3 表。
- P0 测试和建库脚本验证通过。
