# P2 Host API Dynamic Task Experience 阶段目标

整理日期：2026-06-23

阶段目录：`p2-host-api-dynamic-task-experience/`

上级规划：`../master-plan.md`

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | P2 |
| 阶段名称 | Host API Dynamic Task Experience |
| 所属迭代 | `20-delivery/iterations/01-agent-host-core` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | 完成常用动态数据代理和任务执行体验投影。 |

## 1. 计划目标

让 Electron 只调用 Host API 即可完成模型、技能、专家、连接器、资料库、自动化模板、灵感读取，并查看任务事件、产物和文件变更。

## 2. 阶段内容

- 模型代理。
- 技能市场代理。
- 专家中心代理。
- 连接器代理。
- 资料库代理。
- 自动化模板代理。
- 灵感场景代理。
- 任务事件投影。
- 产物、文件变更、上下文引用。

## 3. 范围边界

允许：

- 使用 P0 cache 代理远程动态数据。
- 使用 P1 runtime event 形成任务投影。
- 保存本地自定义模型、技能草稿、已安装技能、本地专家和记忆。

禁止：

- P3 同步队列。
- 助理网关、账号计费和项目协作复杂代理。
- Electron 直接请求远程 API。

## 4. 责任归属

| 责任 | 内容 |
| --- | --- |
| Host API | 动态数据代理、任务查询、产物查询。 |
| Store | P2 本地对象、事件投影、产物和上下文引用。 |
| Remote Client | 动态目录类 API 代理和 cache 刷新。 |
| AgentRuntime | 提供稳定 runtime event。 |

## 5. 前置依赖

- P1 已通过验收。
- P0 cache 可用。
- P2 表结构按 `../../../../10-foundation/architecture/database-design.md` 落地。

## 6. 交付物

- 动态数据代理接口。
- 任务事件历史和 SSE 恢复基础。
- 产物和文件变更查询。
- 本地模型、技能、专家和记忆对象。

## 7. 验收方式

- 模型、技能、专家、连接器、资料库、自动化模板、灵感接口可通过 Host API 访问。
- 远程不可用时可返回合规 stale cache。
- 任务事件可查询和恢复。
- 产物和文件变更可按任务查询。
- P2 不依赖 P3 同步队列。

## 8. 进入下一阶段门禁

进入 P3 前必须满足：

- 动态数据代理和任务投影可验证。
- 本地对象不错误上云。
- P2 未引入 P3 worker 或复杂代理依赖。
