# P1 Runtime Adapter Minimal Loop 阶段目标

整理日期：2026-06-23

阶段目录：`p1-runtime-adapter-minimal-loop/`

上级规划：`../master-plan.md`

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | P1 |
| 阶段名称 | Runtime Adapter Minimal Loop |
| 所属迭代 | `20-delivery/iterations/01-agent-host-core` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | 建立 AgentRuntime、CodexRuntimeAdapter 和 Host API runtime endpoint 的最小闭环。 |

## 1. 计划目标

让 Host API 能通过 AgentRuntime 启动一次 Codex turn，并通过 SSE 接收 runtime 事件和 pending request。

## 2. 阶段内容

- AgentRuntime 最小接口。
- thread、turn、event、pending request、capability、error 统一模型。
- CodexRuntimeAdapter 首版接入。
- `codexapp-go` 调用边界。
- Host API runtime endpoint。
- SSE runtime event bridge。
- pending request 回复入口。

## 3. 范围边界

允许：

- 首版只实现 CodexRuntimeAdapter。
- Adapter 依赖 `codexapp-go`。
- Host API 只通过 AgentRuntime 调用 runtime。

禁止：

- 多 runtime registry。
- 动态 adapter 加载。
- Host API 直接引用 Codex protocol 类型。
- P2 动态数据代理。

## 4. 责任归属

| 责任 | 内容 |
| --- | --- |
| AgentRuntime | 定义统一模型和最小接口。 |
| CodexRuntimeAdapter | 调用 `codexapp-go` 并完成首版映射。 |
| Host API | 提供 runtime endpoint 和 SSE 输出。 |
| 测试 | runtime mock、adapter mapping、最小端到端 turn。 |

## 5. 前置依赖

- P0 已通过验收。
- `../../../../10-foundation/product/agent-runtime-product-spec.md`
- `../../../../10-foundation/product/agent-runtime-adapter-product-spec.md`
- `../../../../10-foundation/architecture/agent-runtime-technical-architecture.md`
- `../../../../10-foundation/architecture/agent-runtime-adapter-technical-architecture.md`
- `../../../../../../codexapp-go/docs/10-foundation/product/codexapp-go-product-spec.md`

## 6. 交付物

- AgentRuntime 最小 contract。
- CodexRuntimeAdapter 首版实现。
- Host API runtime endpoint。
- SSE runtime event 输出。
- pending request 响应链路。

## 7. 验收方式

- Host API 可通过 AgentRuntime 启动一次 Codex turn。
- SSE 可收到 runtime 事件。
- pending request 可被识别、持久化入口可用、响应可回到底层。
- AgentRuntime 不依赖 `codexapp-go`。
- Host API 不直接调用 `codexapp-go`。

## 8. 进入下一阶段门禁

进入 P2 前必须满足：

- P1 最小 runtime 闭环可端到端验证。
- Runtime event 模型足以支撑任务事件投影。
- P1 未引入 P2/P3 业务代理或同步队列。
