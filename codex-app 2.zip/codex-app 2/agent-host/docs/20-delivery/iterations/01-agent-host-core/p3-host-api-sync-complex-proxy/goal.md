# P3 Host API Sync Complex Proxy 阶段目标

整理日期：2026-06-23

阶段目录：`p3-host-api-sync-complex-proxy/`

上级规划：`../master-plan.md`

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | P3 |
| 阶段名称 | Host API Sync Complex Proxy |
| 所属迭代 | `20-delivery/iterations/01-agent-host-core` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | 完成同步队列和复杂远程代理，支持离线重试和上云同步。 |

## 1. 计划目标

让需要上云的本地动作、运行审计、反馈、分享、项目状态等可以先落本地，再由进程内 worker 可靠重试同步。

## 2. 阶段内容

- 远程数据同步队列。
- 进程内 worker。
- 反馈、日志、分享同步代理。
- 项目协作代理。
- 助理网关代理。
- 账号计费代理。

## 3. 范围边界

允许：

- 使用 SQLite 状态表做同步队列。
- 使用 goroutine + context 做进程内 worker。
- 对远程写操作做重试和错误记录。

禁止：

- Redis、Kafka、独立队列系统。
- 多实例分布式调度。
- Electron 持有远程 token 或直连远程 API。

## 4. 责任归属

| 责任 | 内容 |
| --- | --- |
| Host API | 复杂代理接口和同步触发。 |
| Worker | 队列扫描、重试、失败记录。 |
| Store | `remote_sync_queue` 状态持久化。 |
| Remote Client | 远程写接口、token refresh、错误映射。 |

## 5. 前置依赖

- P2 已通过验收。
- P0 Remote API Client 可复用。
- P3 表结构按 `../../../../10-foundation/architecture/database-design.md` 落地。

## 6. 交付物

- `remote_sync_queue` 写入和读取能力。
- 同步 worker。
- 反馈、日志、分享、项目、助理、计费代理接口。
- 同步失败原因记录。

## 7. 验收方式

- 远程离线时同步任务保留。
- 网络恢复后可重试成功。
- token 过期时 refresh 后继续。
- 队列失败原因可查询。
- 不引入独立队列系统。

## 8. 进入下一阶段门禁

进入 P4 前必须满足：

- P3 同步队列和复杂代理主流程可验证。
- P3 未引入微服务或外部队列依赖。
- P0-P3 文档差异已记录。
