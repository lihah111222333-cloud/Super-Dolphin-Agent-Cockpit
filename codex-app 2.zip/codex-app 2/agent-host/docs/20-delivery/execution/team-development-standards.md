# AgentHost 开发团队规范

## 1. 适用范围

本文约束 `agent-host` 的日常开发、评审、测试、文档和发布协作。

`agent-host` 是桌面 Agent 应用唯一的本地项目主体。Host API、AgentRuntime、AgentRuntimeAdapter 是内部需求域，不是独立项目。Electron 只调用 AgentHost；AgentHost 上层不得直接调用 `codexapp-go` 或 Codex app-server JSON-RPC。

## 2. 开发顺序

- 主线按 P0 -> P1 -> P2 -> P3 -> P4 推进。
- 开始阶段开发前，先读 `docs/00-start/current-status.md`、主线 `master-plan.md`、相关专项 `master-plan.md` 和当前阶段 `goal.md`。
- 后续阶段不能成为前置阶段的编译、测试或验收依赖。
- Host API 只能通过 AgentRuntime 触达 runtime。
- AgentRuntime 只定义统一模型，不依赖 `codexapp-go`。
- CodexRuntimeAdapter 才能依赖 `codexapp-go`。
- 禁止写未来 runtime、adapter 或远程代理能力的空实现、假实现或 panic stub。

## 3. 代码规范

- 技术栈以 `docs/10-foundation/architecture/technology-stack.md` 为准。
- SQLite schema 以 `docs/10-foundation/architecture/database-design.md` 和 `scripts/sqlite/create-database.sql` 为准。
- HTTP API 使用 Gin，事件流使用 SSE，日志使用标准库 `slog`。
- 后台任务使用进程内 goroutine、`context.Context` 和 SQLite 状态表，不引入 Redis、Kafka、PostgreSQL 或独立队列系统。
- 远程 access/refresh token 只在本地服务内保存和使用，不返回 Electron。
- Host API 不泄露 Codex protocol 类型；Adapter 对上只输出 AgentRuntime 模型。

## 4. 测试规范

- 每个阶段必须留下最小可运行验证。
- P0 至少覆盖本地 session、远程 token 保存/刷新、远程 API client、SQLite cache 和错误映射。
- P1 至少覆盖 AgentRuntime thread/turn/event/pending request 最小闭环。
- CodexRuntimeAdapter 测试必须覆盖 SDK 注入、thread/turn/cancel 映射、事件和 pending request 映射。
- SQLite 变更必须验证建库脚本和 `PRAGMA foreign_key_check`。
- API 测试必须覆盖鉴权、错误响应、缓存 hit/stale/miss 和 SSE 断开。

## 5. 文档规范

- 产品范围以 `docs/10-foundation/product/agent-host-product-spec.md` 为准。
- 技术架构以 `docs/10-foundation/architecture/agent-host-technical-architecture.md` 为准。
- 数据库事实以 `docs/10-foundation/architecture/database-design.md` 为准。
- Host API 发布口径以 `docs/30-release/host-api-spec.md` 为准。
- 开发顺序和门禁以 `docs/20-delivery/execution/execution-spec.md` 为准。
- 新增文档按 `docs/00-start/doc-governance.md` 放置，不在 `docs/` 根目录平铺。

## 6. 评审规范

变更进入评审前必须说明：

- 影响哪个主线阶段、专项阶段和功能项。
- 是否修改 Host API、AgentRuntime contract、Adapter 映射、SQLite schema 或远程代理行为。
- 是否引入未来阶段依赖。
- 运行了哪些验证命令。
- 是否需要更新 README、Host API 规格、阶段目标、compatibility、changelog 或飞书映射。

评审优先检查：

- 是否让 Electron 直连远程 API 或持有远程 refresh token。
- 是否让 Host API 直接依赖 `codexapp-go` 或 Codex protocol 类型。
- 是否把 Adapter 写成动态插件系统或多 runtime registry。
- 是否引入超出当前技术栈的基础设施。
- 是否缺少最小验证。

## 7. 发布规范

- P4 前 public Host API 允许按阶段收敛，但变更必须同步 `docs/30-release/host-api-spec.md`。
- 发布前必须完成错误码、兼容说明、最小回归测试和实现一致性校准。
- 发布后新增能力进入新迭代规划，不回写改变 P0-P4 已冻结边界。
