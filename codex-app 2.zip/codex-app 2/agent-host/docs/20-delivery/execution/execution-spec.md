# AgentHost 开发执行规格

整理日期：2026-06-23

依据文档：`../../10-foundation/product/agent-host-product-spec.md`、`../../10-foundation/architecture/database-design.md`、`../iterations/01-agent-host-core/master-plan.md`、`../feature-plan.md`

定位：本文是面向 AgentHost 开发的门禁、依赖约束和实施拆解。Host API、AgentRuntime、AgentRuntimeAdapter 是 `agent-host` 内部需求域，不能各自形成独立项目或独立阶段线。

功能项监管清单以 `../feature-plan.md` 为准；本文保留执行门禁和拆解约束。

## 1. 范围

### 覆盖范围

- 本地 Go 服务中的远程 API 代理。
- SQLite 远程数据缓存。
- 本地 session / 远程 token 鉴权。
- 远程数据同步队列。
- 动态远程数据的本地代理能力。
- AgentRuntime 最小 thread/turn/event/pending request 闭环。
- CodexRuntimeAdapter 对 `codexapp-go` 的首版接入。

### 不覆盖范围

- Electron UI、路由、状态管理。
- 云端服务的完整实现。
- 本地 Agent Runtime、文件树、产物预览等非远程代理能力。
- API DTO 字段设计；数据库字段、索引和约束以 `../../10-foundation/architecture/database-design.md` 为准。

### 基本边界

所有链路统一为：

```text
Electron -> 本地 Go API 服务 -> 远程 API
```

Electron 不直接请求远程 API，不持有远程 `refresh_token`。固定枚举仍由前端常量处理；模型列表、专家中心、技能市场、灵感、连接器目录、自动化模板、套餐价格等动态数据必须保留本地代理和远程缓存。

## 2. 统一依赖门禁

- Host API 只能通过 AgentRuntime 触达 runtime。
- Host API 不能直接调用 `codexapp-go` 或引用 Codex app-server protocol 类型。
- AgentRuntime 只定义统一模型，不依赖具体后端 SDK。
- CodexRuntimeAdapter 是首版唯一 adapter，可以依赖 `codexapp-go`。
- `codexapp-go` 不并入 AgentHost，不吸收 AgentHost 产品语义。
- 后续阶段不能成为前置阶段依赖。
- 阶段内不能写未来能力的空实现、假实现或 panic stub。

## 2.1 技术栈门禁

- HTTP API 使用 Gin。
- SSE 基于 Gin handler 实现。
- 数据访问使用 GORM，业务代码不散落手写 raw SQL。
- SQLite driver 使用 `github.com/glebarez/sqlite`，默认避免 CGO。
- 日志使用标准库 `log/slog`。
- 配置使用 `config.yaml`。
- 后台任务使用进程内 goroutine、`context.Context` 和 SQLite 状态表。
- 不引入 Redis、Kafka、PostgreSQL、独立队列系统或微服务拆分。

## 3. 阶段顺序

| 阶段 | 目标 | 说明 |
| --- | --- | --- |
| P0 | 鉴权基础 | 本地 session、远程 token 存储、远程 token 刷新 |
| P0 | 远程 API client | 统一鉴权、超时、错误、重试、日志 |
| P0 | SQLite cache | GORM、纯 Go SQLite driver、远程缓存表、TTL、stale、forceRefresh |
| P1 | Runtime 最小闭环 | AgentRuntime thread/turn/event/pending request、CodexRuntimeAdapter 接入 |
| P2 | 动态数据代理 | 模型、技能、专家、连接器、资料库、自动化模板、灵感 |
| P3 | 云同步队列和复杂代理 | 同步队列、审计/反馈/状态同步、项目协作、助理网关、账号计费 |
| P4 | 发布前稳定化 | API 文档、错误码、兼容说明、最小回归测试 |

## 4. 核心需求域交付物

| 编号 | 交付物 | 阶段 | 验收方式 |
| --- | --- | --- | --- |
| D01 | Host API 基础骨架 | P0 | Gin、slog、config.yaml、GORM + SQLite、本地鉴权、错误响应和远程代理基础可测；`../../../scripts/sqlite/create-database.sql` 可创建空库并通过外键检查。 |
| D02 | AgentRuntime 最小闭环 | P1 | Host API 通过 AgentRuntime 创建 thread、启动 turn、订阅事件。 |
| D03 | CodexRuntimeAdapter 首版接入 | P1 | Adapter 通过 `codexapp-go` 接入 Codex app-server，并映射事件和 pending request。 |

## 5. 功能总览

| 编号 | 功能项 | 阶段 | 依赖 |
| --- | --- | --- | --- |
| F01 | 登录鉴权与本地 session | P0 | 无 |
| F02 | 远程 API client | P0 | F01 |
| F03 | SQLite 远程缓存 | P0 | F01, F02 |
| F04 | 模型代理 | P2 | F01, F02, F03 |
| F05 | 技能市场代理 | P2 | F01, F02, F03 |
| F06 | 专家中心代理 | P2 | F01, F02, F03 |
| F07 | 连接器代理 | P2 | F01, F02, F03 |
| F08 | 资料库代理 | P2 | F01, F02, F03, F07 |
| F09 | 自动化模板代理 | P2 | F01, F02, F03 |
| F10 | 灵感场景代理 | P2 | F01, F02, F03 |
| F11 | 远程数据同步队列 | P3 | F01, F02 |
| F12 | 反馈、日志、分享同步代理 | P3 | F01, F02, F11 |
| F13 | 项目协作代理 | P3 | F01, F02, F03, F11 |
| F14 | 助理网关代理 | P3 | F01, F02, F11 |
| F15 | 账号计费代理 | P3 | F01, F02, F03 |

## 6. 功能拆解

### F01. 登录鉴权与本地 session

| 项 | 内容 |
| --- | --- |
| 功能说明 | 本地服务代理远程登录，保存远程 `access_token` / `refresh_token`，向 Electron 签发 `local_session_token`。所有本地 API 都校验本地 session。 |
| 涉及本地 API | `POST /auth/login`、`POST /auth/logout`、`GET /auth/session`、`POST /auth/refresh-local`、`GET /account/me`、`POST /devices/register`、`PATCH /devices/{deviceId}/heartbeat` |
| 涉及远程上游 API | `POST /auth/login`、`POST /auth/refresh`、`GET /account/me`、`POST /devices/register`、`PATCH /devices/{deviceId}/heartbeat` |
| 实现要点 | `local_session_token` 只代表本机登录态；远程 token 只在本地服务内使用；`refresh_token` 不返回 Electron；session 校验要绑定 `userId`；登出清理本地 session 和可选远程 token。 |
| 依赖关系 | 无。 |
| 阶段优先级 | P0。 |
| 验收标准 | 登录成功后 Electron 只拿到 `localSessionToken`；本地 API 无 token 返回 `UNAUTHORIZED`；远程 access token 过期后可自动 refresh；日志不输出明文 token。 |

待确认：

- 远程 token 加密落点：系统 Keychain，还是 SQLite 中加密字段。
- `local_session_token` 是否使用 JWT，还是随机 opaque token + hash 存库。

### F02. 远程 API client

| 项 | 内容 |
| --- | --- |
| 功能说明 | 封装本地服务访问远程 API 的统一 HTTP client，负责鉴权注入、token refresh、超时、错误映射、请求日志。 |
| 涉及本地 API | 无直接对外 API，被所有代理接口调用。 |
| 涉及远程上游 API | 所有 `/api/v1` 上游接口。 |
| 实现要点 | 自动附加远程 `access_token`；遇到 401 尝试 refresh 一次；统一映射 `REMOTE_TOKEN_EXPIRED`、`REMOTE_UNAVAILABLE`；记录上游路径、状态码、耗时、requestId；不记录敏感 header/body。 |
| 依赖关系 | F01。 |
| 阶段优先级 | P0。 |
| 验收标准 | 任意代理接口都通过该 client；401 refresh 只重试一次；远程不可用能返回统一错误；日志可定位上游失败。 |

待确认：

- 远程 base URL、超时、代理配置来源。
- 远程错误响应 envelope 是否固定。

### F03. SQLite 远程缓存

| 项 | 内容 |
| --- | --- |
| 功能说明 | 用 SQLite 缓存远程动态数据，支持 TTL、stale-while-revalidate、ETag/Last-Modified/version 和 `forceRefresh`。 |
| 涉及本地 API | 无独立 API；被带 `forceRefresh=false`、返回 `cache` 的代理接口使用。 |
| 涉及远程上游 API | 模型、技能、专家、连接器、资料库、项目、自动化模板、灵感、套餐等读接口。 |
| 实现要点 | 缓存键、TTL、stale、索引、字段和约束统一见 `../../10-foundation/architecture/database-design.md`；空库创建脚本为 `../../../scripts/sqlite/create-database.sql`；本处只约束缓存行为。 |
| 依赖关系 | F01, F02。 |
| 阶段优先级 | P0。 |
| 验收标准 | 同一 query 第二次请求命中缓存；`forceRefresh=true` 绕过缓存；远程 304 不覆盖 payload；缓存过期策略可通过单元测试覆盖 hit/stale/miss。 |

### F04. 模型代理

| 项 | 内容 |
| --- | --- |
| 功能说明 | 本地服务代理远程模型清单、供应商预设、账号可用模型，并与本地自定义模型合并用于模型选择和 Auto 解析。 |
| 涉及本地 API | `GET /models/built-in`、`GET /models/providers`、`GET /models/entitlements`、`GET /models/custom`、`POST /models/resolve` |
| 涉及远程上游 API | `GET /models/built-in`、`GET /models/providers`、`GET /models/entitlements` |
| 实现要点 | 远程模型数据进入缓存；自定义模型按数据库设计读取且不返回明文 Key；`/models/resolve` 基于远程缓存和本地自定义模型选择。 |
| 依赖关系 | F01, F02, F03。 |
| 阶段优先级 | P2。 |
| 验收标准 | Electron 不需要远程 token 即可读取模型列表；远程不可用时可返回未过 stale 的缓存；账号权益变化后 `forceRefresh=true` 能刷新。 |

### F05. 技能市场代理

| 项 | 内容 |
| --- | --- |
| 功能说明 | 本地服务代理技能市场、技能详情、安装包获取、自然语言查找/生成，并把用户本地创建技能草稿和已安装技能合并展示。 |
| 涉及本地 API | `GET /skills/marketplace`、`GET /skills/{skillId}`、`POST /skills/{skillId}/install-package`、`POST /skills/find`、`POST /skills/generate`、`GET /skills/local-drafts`、`GET /skills/installed` |
| 涉及远程上游 API | `GET /skills/marketplace`、`GET /skills/{skillId}`、`POST /skills/{skillId}/install-package`、`POST /skills/find`、`POST /skills/generate` |
| 实现要点 | 市场列表/详情走缓存；远程安装包只返回下载信息，本地服务下载、校验 checksum、安装；本地草稿和已安装技能按数据库设计保存，不上云。 |
| 依赖关系 | F01, F02, F03。 |
| 阶段优先级 | P2。 |
| 验收标准 | 市场列表有 cache 状态；安装包 checksum 不匹配时失败；本地草稿和远程技能 ID 不冲突；本地草稿不会写入远程 API。 |

### F06. 专家中心代理

| 项 | 内容 |
| --- | --- |
| 功能说明 | 本地服务代理专家分类、专家列表、专家详情、专家团，并合并用户本地创建专家。 |
| 涉及本地 API | `GET /experts/categories`、`GET /experts`、`GET /experts/{expertId}`、`GET /expert-teams`、`GET /expert-teams/{teamId}`、`GET /my-experts/local`、`POST /my-experts/local`、`PATCH /my-experts/local/{expertId}`、`DELETE /my-experts/local/{expertId}` |
| 涉及远程上游 API | `GET /experts/categories`、`GET /experts`、`GET /experts/{expertId}`、`GET /expert-teams`、`GET /expert-teams/{teamId}` |
| 实现要点 | 远程专家进入缓存；本地专家按数据库设计保存，不上云；列表返回 `source=remote/local`；本地 ID 使用 `local_` 前缀避免和远程 ID 冲突。 |
| 依赖关系 | F01, F02, F03。 |
| 阶段优先级 | P2。 |
| 验收标准 | `includeLocal=true` 时合并展示；本地专家 CRUD 不请求远程；远程专家缓存过期可刷新；删除本地专家不影响远程缓存。 |

### F07. 连接器代理

| 项 | 内容 |
| --- | --- |
| 功能说明 | 本地服务代理连接器目录、详情、授权状态、OAuth 发起、授权会话查询、审计日志，并管理本地 MCP 连接器。 |
| 涉及本地 API | `GET /connectors/catalog`、`GET /connectors/{connectorId}`、`GET /connector-connections`、`POST /connectors/{connectorId}/auth/start`、`GET /connectors/auth-sessions/{sessionId}`、`GET /connector-connections/{connectionId}/audit-logs`、`POST/PATCH/DELETE /connectors/custom/local` |
| 涉及远程上游 API | `GET /connectors/catalog`、`GET /connectors/{connectorId}`、`GET /connector-connections`、`POST /connectors/{connectorId}/auth/start`、`GET /connectors/auth-sessions/{sessionId}`、`POST /connectors/{connectorId}/auth/callback`、`GET /connector-connections/{connectionId}/audit-logs` |
| 实现要点 | 目录/详情/状态走缓存；OAuth 发起由本地服务请求远程，上游返回 `authUrl/sessionId`；OAuth 回调由远程网关处理；本地服务保存授权结果快照；不开放任意 connector invoke 给 Electron。 |
| 依赖关系 | F01, F02, F03。 |
| 阶段优先级 | P2。 |
| 验收标准 | 连接器目录可离线读 stale 缓存；授权状态刷新能更新本地快照；本地 MCP 连接器不上云；前端无法通过通用 invoke 调用连接器。 |

待确认：

- OAuth 成功后远程如何通知本地服务刷新授权状态：轮询 session，还是远程设备消息。

### F08. 资料库代理

| 项 | 内容 |
| --- | --- |
| 功能说明 | 本地服务代理云资料库授权、来源、空间、文件搜索、文件详情，并把文件引用保存到本地任务上下文。 |
| 涉及本地 API | `GET /knowledge-sources`、`POST /knowledge-sources/{provider}/auth/start`、`DELETE /knowledge-sources/{provider}/binding`、`GET /knowledge-sources/{provider}/spaces`、`GET /knowledge-sources/{provider}/files`、`GET /knowledge-sources/{provider}/files/{fileId}`、`POST /tasks/{taskId}/context-refs`、`POST /artifacts/{artifactId}/upload-to-cloud` |
| 涉及远程上游 API | `GET /knowledge-sources`、`POST /knowledge-sources/{provider}/auth/start`、`DELETE /knowledge-sources/{provider}/binding`、`GET /knowledge-sources/{provider}/spaces`、`GET /knowledge-sources/{provider}/files`、`GET /knowledge-sources/{provider}/files/{fileId}`、`POST /knowledge-sources/{provider}/files/{fileId}/references`、`POST /artifacts/{artifactId}/upload-to-cloud` |
| 实现要点 | 来源/空间/搜索/详情可短期缓存；任务只保存引用快照，不默认下载或上传原文件；产物回写由本地读取文件后走远程 token 上传。 |
| 依赖关系 | F01, F02, F03, F07。 |
| 阶段优先级 | P2。 |
| 验收标准 | 文件搜索能返回 cache 状态；上下文引用保存后可在任务中读取；解绑后缓存状态不可继续展示为可用；产物回写失败不破坏本地产物。 |

### F09. 自动化模板代理

| 项 | 内容 |
| --- | --- |
| 功能说明 | 本地服务代理远程自动化模板，供创建本地自动化或项目自动化时选择。 |
| 涉及本地 API | `GET /automation-templates` |
| 涉及远程上游 API | `GET /automation-templates` |
| 实现要点 | 模板走本地缓存；模板只作为创建配置的输入，不在前端硬编码。 |
| 依赖关系 | F01, F02, F03。 |
| 阶段优先级 | P2。 |
| 验收标准 | 模板列表可缓存；`forceRefresh=true` 能刷新；远程模板下架后本地缓存不能继续展示为可用。 |

### F10. 灵感场景代理

| 项 | 内容 |
| --- | --- |
| 功能说明 | 本地服务代理灵感场景、案例、详情、收藏、克隆，并把“制作我的版本”落成本地任务草稿。 |
| 涉及本地 API | `GET /inspirations/categories`、`GET /inspirations`、`GET /inspirations/{inspirationId}`、`POST /inspirations/{inspirationId}/favorite`、`DELETE /inspirations/{inspirationId}/favorite`、`POST /inspirations/{inspirationId}/clone`、`POST /tasks/drafts`、`POST /tasks/drafts/{draftId}/run` |
| 涉及远程上游 API | `GET /inspirations/categories`、`GET /inspirations`、`GET /inspirations/{inspirationId}`、`POST /inspirations/{inspirationId}/favorite`、`DELETE /inspirations/{inspirationId}/favorite`、`POST /inspirations/{inspirationId}/clone` |
| 实现要点 | 场景/列表/详情走缓存；收藏是远程写操作，不使用长期缓存判断最终状态；clone 读取远程载荷后创建本地草稿。 |
| 依赖关系 | F01, F02, F03。 |
| 阶段优先级 | P2。 |
| 验收标准 | 灵感列表支持缓存和刷新；收藏失败能回滚本地状态；clone 生成的是本地 draft，不直接启动任务，除非调用 `/tasks/drafts/{draftId}/run`。 |

### F11. 远程数据同步队列

| 项 | 内容 |
| --- | --- |
| 功能说明 | 用本地同步队列处理需要上云的本地动作、运行审计、项目任务状态、公共连接器审计等，支持离线重试。 |
| 涉及本地 API | 无统一对外 API；由业务接口写队列，例如项目任务同步、反馈上传、审计上报。 |
| 涉及远程上游 API | `POST /audit/runtime-actions`、`PATCH /projects/{projectId}/tasks/{taskId}`、`POST /feedback`、`POST /feedback/{feedbackId}/attachments` 等需要上云的写接口。 |
| 实现要点 | 本地动作先落 SQLite；需要上云再写同步队列；后台 worker 使用远程 `access_token` 上传；队列表结构和索引见 `../../10-foundation/architecture/database-design.md`。 |
| 依赖关系 | F01, F02。 |
| 阶段优先级 | P3。 |
| 验收标准 | 远程离线时队列保留任务；恢复网络后可重试成功；token 过期时能 refresh 后继续；失败原因写入 `error_json`。 |

待确认：

- 哪些业务动作必须上云，哪些只保留本地。
- 队列最大重试次数和最终失败展示方式。

### F12. 反馈、日志、分享同步代理

| 项 | 内容 |
| --- | --- |
| 功能说明 | 本地服务负责日志打包脱敏，并代理反馈、附件、分享文件列表、复制链接、下载、取消分享等远程能力。 |
| 涉及本地 API | `POST /feedback/log-bundles`、`POST /feedback`、`POST /feedback/{feedbackId}/attachments`、`GET /data/shared-files`、`POST /data/shared-files/{shareId}/copy-link`、`GET /data/shared-files/{shareId}/download`、`DELETE /data/shared-files/{shareId}` |
| 涉及远程上游 API | `POST /feedback`、`POST /feedback/{feedbackId}/attachments`、`GET /data/shared-files`、`POST /data/shared-files/{shareId}/copy-link`、`GET /data/shared-files/{shareId}/download`、`DELETE /data/shared-files/{shareId}` |
| 实现要点 | 日志包必须脱敏；反馈上传可进入同步队列；分享文件列表可短期缓存；下载和取消分享按实时远程结果为准。 |
| 依赖关系 | F01, F02, F11。 |
| 阶段优先级 | P3。 |
| 验收标准 | 日志包不含 token/API Key；远程不可用时反馈进入队列；分享文件取消后本地缓存更新或失效。 |

### F13. 项目协作代理

| 项 | 内容 |
| --- | --- |
| 功能说明 | 本地服务代理项目列表、详情、模板、成员、邀请、审批、资产、项目任务摘要同步。实际任务执行仍走本地任务系统。 |
| 涉及本地 API | `GET /projects`、`POST /projects`、`GET /projects/{projectId}`、`PATCH /projects/{projectId}`、`DELETE /projects/{projectId}`、`GET /project-templates`、`GET /projects/{projectId}/activity`、`GET /projects/{projectId}/members`、`POST /projects/{projectId}/invites`、`POST /project-invites/{inviteId}/apply`、`POST /project-join-requests/{requestId}/approve`、`POST /project-join-requests/{requestId}/reject`、`GET /projects/{projectId}/assets`、`POST /projects/{projectId}/assets`、`POST /projects/{projectId}/tasks/sync` |
| 涉及远程上游 API | `GET /projects`、`POST /projects`、`GET /projects/{projectId}`、`PATCH /projects/{projectId}`、`DELETE /projects/{projectId}`、`GET /project-templates`、`GET /projects/{projectId}/activity`、`GET /projects/{projectId}/members`、`POST /projects/{projectId}/invites`、`POST /project-invites/{inviteId}/apply`、`POST /project-join-requests/{requestId}/approve`、`POST /project-join-requests/{requestId}/reject`、`GET /projects/{projectId}/assets`、`POST /projects/{projectId}/assets`、`PATCH /projects/{projectId}/tasks/{taskId}` |
| 实现要点 | 项目列表/详情/模板/成员可缓存；邀请、审批、资产上传、任务同步是远程写操作；项目任务只同步摘要，不替代本地执行。 |
| 依赖关系 | F01, F02, F03, F11。 |
| 阶段优先级 | P3。 |
| 验收标准 | 项目列表可缓存刷新；任务摘要同步失败进入队列；项目资产上传失败不影响本地文件；成员权限错误映射为 `FORBIDDEN`。 |

待确认：

- 云端项目角色和本地任务权限的映射规则。

### F14. 助理网关代理

| 项 | 内容 |
| --- | --- |
| 功能说明 | 本地服务代理助理平台接入状态、平台注册/解绑，并承接远程下发消息落地为本地任务。暂不实现扫码绑定。 |
| 涉及本地 API | `GET /assistant/settings`、`PATCH /assistant/settings`、`GET /assistant/integrations`、`POST /assistant/integrations/{platform}/register`、`DELETE /assistant/integrations/{platform}`、`GET /assistant/session/messages`、`POST /assistant/session/messages`、`GET /assistant/tasks`、`GET /assistant/tasks/{taskId}/events` |
| 涉及远程上游 API | `GET /assistant/integrations`、`POST /assistant/integrations/{platform}/register`、`DELETE /assistant/integrations/{platform}`、`POST /assistant/callbacks/{platform}`、`POST /assistant/dispatch`、`POST /assistant/replies` |
| 实现要点 | 平台接入状态可缓存；远程消息落地后创建本地消息和任务；执行结果通过远程 replies 回传；扫码绑定接口不做。 |
| 依赖关系 | F01, F02, F11。 |
| 阶段优先级 | P3。 |
| 验收标准 | 可查询平台接入状态；注册/解绑走本地服务代理；远程消息能生成本地任务；结果回传失败可入队重试。 |

待确认：

- 远程 `/assistant/dispatch` 到本地服务的连接方式：轮询、长连接、还是云端推送到设备通道。

### F15. 账号计费代理

| 项 | 内容 |
| --- | --- |
| 功能说明 | 本地服务代理账号、设备、套餐、积分、用量、订单、发票、购买入口。价格和权益不能硬编码。 |
| 涉及本地 API | `GET /account/me`、`GET /devices`、`DELETE /devices/{deviceId}`、`GET /plans`、`GET /credits/balance`、`GET /credits/usage`、`GET /orders`、`GET /invoices`、`POST /checkout/packages` |
| 涉及远程上游 API | `GET /account/me`、`GET /devices`、`DELETE /devices/{deviceId}`、`GET /plans`、`GET /credits/balance`、`GET /credits/usage`、`GET /orders`、`GET /invoices`、`POST /checkout/packages` |
| 实现要点 | 套餐价格走短 TTL 缓存；余额、购买、扣费相关判断尽量实时请求远程；本地不计算最终扣费；订单/发票只代理查询。 |
| 依赖关系 | F01, F02, F03。 |
| 阶段优先级 | P3。 |
| 验收标准 | `/plans` 支持短 TTL 缓存和强刷；余额查询默认实时；购买返回远程 checkout URL；远程权限错误能正确透传。 |

## 5. 监控和验收通用要求

每个功能项最少保留以下日志/指标：

| 类型 | 内容 |
| --- | --- |
| 请求日志 | 本地路径、上游路径、状态码、耗时、requestId |
| 缓存指标 | domain、hit/stale/miss、refresh 结果 |
| token 指标 | refresh 成功/失败次数，不记录 token 内容 |
| 队列指标 | pending/running/done/failed 数量、重试次数 |
| 错误映射 | `UNAUTHORIZED`、`REMOTE_TOKEN_EXPIRED`、`REMOTE_UNAVAILABLE`、`FORBIDDEN` |

验收时每个功能项至少覆盖：

- 正常远程成功。
- 本地 session 缺失。
- 远程 access token 过期后 refresh。
- 远程不可用。
- 缓存命中或队列重试，按功能项适用。

## 6. 待确认清单

| 编号 | 问题 | 影响 |
| --- | --- | --- |
| Q01 | 远程 token 加密方案 | 影响本地 session 持久化和跨平台实现 |
| Q02 | 远程 API base URL、超时、错误 envelope | 影响 F02 |
| Q03 | ETag/Last-Modified/version 的实际返回位置 | 影响 F03 |
| Q04 | OAuth 授权完成后本地刷新机制 | 影响 F07, F08 |
| Q05 | 哪些动作必须写入同步队列 | 影响 F11 |
| Q06 | 项目角色和本地任务权限映射 | 影响 F13 |
| Q07 | 助理 dispatch 到本地的传输方式 | 影响 F14 |
