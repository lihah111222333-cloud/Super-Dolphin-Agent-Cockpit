# agent-host 阅读路径

## 新开发者 15 分钟路径

1. `00-start/ai-project-context.md`
2. `00-start/current-status.md`
3. `10-foundation/product/agent-host-product-spec.md`
4. `10-foundation/architecture/agent-host-technical-architecture.md`
5. `10-foundation/architecture/technology-stack.md`
6. `10-foundation/architecture/database-design.md`
7. `20-delivery/iterations/01-agent-host-core/master-plan.md`
8. `20-delivery/feature-plan.md`
9. `20-delivery/execution/execution-spec.md`

目标：确认 `agent-host` 是唯一的本地项目主体，Host API、AgentRuntime、AgentRuntimeAdapter 只是内部需求域，不是并列项目。

## 阶段开发路径

1. `00-start/ai-project-context.md`
2. `00-start/current-status.md`
3. `20-delivery/iterations/01-agent-host-core/master-plan.md`
4. `20-delivery/feature-plan.md`
5. 当前主线阶段的 `goal.md`
6. `20-delivery/iterations/02-host-api-core/master-plan.md`
7. `20-delivery/iterations/03-runtime-adapter-core/master-plan.md`
8. `10-foundation/architecture/technology-stack.md`
9. `10-foundation/architecture/database-design.md`
10. `20-delivery/execution/execution-spec.md`
11. 阶段涉及的产品、架构或 API 文档。

目标：按统一 P0 -> P4 顺序推进，不让 Host API、Runtime、Adapter 各自形成独立阶段线。

P0 进入本地存储实现或 schema 校验时，从仓库根目录运行：

```bash
mkdir -p ./agent-host/.local
sqlite3 ./agent-host/.local/agent-host.db < ./agent-host/scripts/sqlite/create-database.sql
```

## Runtime 开发路径

1. `10-foundation/architecture/agent-host-technical-architecture.md`
2. `10-foundation/architecture/technology-stack.md`
3. `10-foundation/product/agent-runtime-product-spec.md`
4. `10-foundation/architecture/agent-runtime-technical-architecture.md`
5. `10-foundation/product/agent-runtime-adapter-product-spec.md`
6. `10-foundation/architecture/agent-runtime-adapter-technical-architecture.md`
7. `20-delivery/iterations/03-runtime-adapter-core/master-plan.md`
8. `20-delivery/feature-plan.md`
9. 仓库根目录下 `codexapp-go/docs/10-foundation/product/codexapp-go-product-spec.md`

目标：先固定 AgentRuntime 统一模型，再由 CodexRuntime Adapter 使用 `codexapp-go` 做底层接入，避免 AgentHost 上层直接绑定 Codex protocol。

## 本地 API 开发路径

1. `10-foundation/product/agent-host-product-spec.md`
2. `30-release/host-api-spec.md`
3. `10-foundation/architecture/technology-stack.md`
4. `10-foundation/architecture/database-design.md`
5. `20-delivery/iterations/02-host-api-core/master-plan.md`
6. `20-delivery/feature-plan.md`
7. `20-delivery/execution/execution-spec.md`
8. Runtime 或远程代理相关基础事实文档。

目标：本地 API 只表达 AgentHost 产品语义，远程 API 由 AgentHost 代理，runtime 能力通过 AgentRuntime 进入。

## 文档维护路径

1. `docs/README.md`
2. `00-start/ai-project-context.md`
3. `00-start/current-status.md`
4. `00-start/doc-governance.md`
5. `00-start/feishu-drive-mapping.md`

目标：新增文档先落到正确生命周期目录，避免恢复 `_meta/product/architecture/development/release` 的旧结构。
