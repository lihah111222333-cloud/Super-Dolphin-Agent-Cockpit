# agent-host 当前开发入口

| 项目 | 当前值 |
| --- | --- |
| 当前状态 | 文档结构已按生命周期整理；AgentHost 已明确为唯一本地项目主体，Host API、AgentRuntime、AgentRuntimeAdapter 是内部需求域。 |
| 当前开发阶段 | AgentHost Core P0 开发准备阶段。 |
| 主线阶段入口 | `20-delivery/iterations/01-agent-host-core/master-plan.md` |
| 功能列表 | `20-delivery/feature-plan.md` |
| Host API 专项入口 | `20-delivery/iterations/02-host-api-core/master-plan.md` |
| Runtime/Adapter 专项入口 | `20-delivery/iterations/03-runtime-adapter-core/master-plan.md` |
| 开发执行规格 | `20-delivery/execution/execution-spec.md` |
| 产品规格入口 | `10-foundation/product/agent-host-product-spec.md` |
| 技术架构入口 | `10-foundation/architecture/agent-host-technical-architecture.md` |
| 技术栈入口 | `10-foundation/architecture/technology-stack.md` |
| 数据库设计入口 | `10-foundation/architecture/database-design.md` |
| 数据库创建脚本 | `../../scripts/sqlite/create-database.sql` |
| Runtime 规格入口 | `10-foundation/product/agent-runtime-product-spec.md` |
| Adapter 规格入口 | `10-foundation/product/agent-runtime-adapter-product-spec.md` |
| Host API 入口 | `30-release/host-api-spec.md` |
| AI 启动上下文 | `00-start/ai-project-context.md` |
| 更新时间 | 2026-06-23 |

## 当前阶段目标

当前阶段的目标是把 AgentHost 的本地 API、runtime 抽象、CodexRuntime Adapter、远程 API 代理和本地缓存边界固定下来，形成可以进入 P0 开发的最小可验证范围。

P0 不应依赖未来 Electron UI 完整实现、云端完整服务、多个 runtime 动态切换或 `codexapp-go` 后续高级封装。

## 当前阶段允许做什么

- 明确本地 REST/SSE API 的 P0 范围。
- 明确 Gin、GORM、纯 Go SQLite driver、slog、config.yaml 和进程内 worker 的轻量技术栈。
- 明确本地 session、远程 token、远程 API client 和 SQLite cache 的 P0 落点。
- 可用 `../../scripts/sqlite/create-database.sql` 创建本地 SQLite 数据库，用于 P0 schema 验证和本地开发初始化。
- 明确 AgentRuntime 的最小 thread/turn/event/pending request 模型。
- 明确 CodexRuntime Adapter 只做 SDK 调用、事件映射、pending request 映射和错误映射。
- 明确 Host API、AgentRuntime、AgentRuntimeAdapter 服从同一套 AgentHost 阶段计划。
- 明确 Electron 只通过 AgentHost 访问本地和远程能力。
- 对已有规格做一致性修订，消除路径、命名和边界矛盾。

## 当前阶段禁止做什么

- 不实现 Electron UI。
- 不实现 AgentCloud 云端完整服务。
- 不让 Electron 直连远程 API。
- 不让 AgentHost 上层直接调用 Codex app-server JSON-RPC。
- 不把 `codexapp-go` 的 JSON-RPC SDK 能力复制进 AgentHost。
- 不引入多 runtime registry、动态 adapter 加载或插件市场。
- 不引入 Redis、Kafka、PostgreSQL、独立队列系统或微服务拆分。
- 不写未来 runtime 的空实现、假实现或 panic stub。

## 本阶段必读文档

1. `00-start/ai-project-context.md`
2. `00-start/reading-guide.md`
3. `10-foundation/product/agent-host-product-spec.md`
4. `10-foundation/architecture/agent-host-technical-architecture.md`
5. `10-foundation/architecture/technology-stack.md`
6. `10-foundation/architecture/database-design.md`
7. `20-delivery/iterations/01-agent-host-core/master-plan.md`
8. `20-delivery/feature-plan.md`
9. `20-delivery/iterations/02-host-api-core/master-plan.md`
10. `20-delivery/iterations/03-runtime-adapter-core/master-plan.md`
11. `10-foundation/product/agent-runtime-product-spec.md`
12. `10-foundation/product/agent-runtime-adapter-product-spec.md`
13. `20-delivery/execution/execution-spec.md`
14. `30-release/host-api-spec.md`

## 进入实现门禁

- P0 范围可从 `20-delivery/execution/execution-spec.md` 追踪到产品规格。
- P0 范围可从 `20-delivery/iterations/01-agent-host-core/master-plan.md` 追踪到统一阶段计划。
- REST/SSE API 与 AgentRuntime 职责边界一致。
- AgentRuntime 与 CodexRuntime Adapter 职责边界一致。
- AgentHost 上层不直接依赖 `codexapp-go` 或 Codex protocol 类型。
- P0 技术栈不引入 Redis、Kafka、PostgreSQL、CGO SQLite driver 或独立队列系统。
- 本地 token、缓存和远程代理策略已具备可测试验收标准。
- SQLite 初始化脚本可成功创建数据库并通过 `PRAGMA foreign_key_check`。
