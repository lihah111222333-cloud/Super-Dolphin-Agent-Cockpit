# agent-host 飞书云盘路径映射

| 项目 | 内容 |
| --- | --- |
| 本地项目目录 | `/Users/ai/Devlop/codex-app/agent-host/` |
| 云盘父目录 | `/CodexApp/` |
| 云盘父目录 token | `HRDUf6g80lQP4yds94IcIdt2nhn` |
| 云盘项目目录 | `/CodexApp/agent-host/` |
| 云盘项目目录 token | `VeGJf5hO5lz7JKdarUycHQQenXc` |
| 云盘项目目录 URL | `https://acn9ha4b3juy.feishu.cn/drive/folder/VeGJf5hO5lz7JKdarUycHQQenXc` |
| 云盘 docs 目录 | `/CodexApp/agent-host/docs/` |
| 云盘 docs 目录 token | `RrAAfqitJl9Qn4dOAllcUMWxnre` |
| 云盘 docs 目录 URL | `https://acn9ha4b3juy.feishu.cn/drive/folder/RrAAfqitJl9Qn4dOAllcUMWxnre` |
| 本地到云盘同步命令 | `lark-cli drive +push --as user --local-dir agent-host/docs --folder-token RrAAfqitJl9Qn4dOAllcUMWxnre --if-exists=smart --json` |
| 精确一致性校验命令 | `lark-cli drive +status --as user --local-dir agent-host/docs --folder-token RrAAfqitJl9Qn4dOAllcUMWxnre --json` |
| 映射更新日期 | 2026-06-24 |
| 说明 | `agent-host/` 的相对路径应同步到云盘 `/CodexApp/agent-host/` 下的同名相对路径。 |

## 目录映射

| 本地路径 | 云盘路径 | folder token |
| --- | --- | --- |
| `agent-host/` | `/CodexApp/agent-host/` | `VeGJf5hO5lz7JKdarUycHQQenXc` |
| `agent-host/docs/` | `/CodexApp/agent-host/docs/` | `RrAAfqitJl9Qn4dOAllcUMWxnre` |
| `agent-host/docs/00-start/` | `/CodexApp/agent-host/docs/00-start/` | `UHXbfhh7Ll1zZEdkTU9cXOClnUb` |
| `agent-host/docs/10-foundation/` | `/CodexApp/agent-host/docs/10-foundation/` | `ZavIfv7tUlNnUVdZ1eYcpJVhnQe` |
| `agent-host/docs/10-foundation/architecture/` | `/CodexApp/agent-host/docs/10-foundation/architecture/` | `Isubf1pgllrAnide2CycWUZqnVI` |
| `agent-host/docs/10-foundation/product/` | `/CodexApp/agent-host/docs/10-foundation/product/` | `PyZsfMwTyl9IBDdRqoJchHOknuf` |
| `agent-host/docs/10-foundation/protocol/` | `/CodexApp/agent-host/docs/10-foundation/protocol/` | `BmD8flJNglDX2Ldp7Qfc7ucRnJc` |
| `agent-host/docs/20-delivery/` | `/CodexApp/agent-host/docs/20-delivery/` | `BA2tfQ2EqlSQQodJFcwcbzSfnif` |
| `agent-host/docs/20-delivery/execution/` | `/CodexApp/agent-host/docs/20-delivery/execution/` | `FsTBfYm5OldKZOdn5MRc2iOWnNV` |
| `agent-host/docs/20-delivery/iterations/` | `/CodexApp/agent-host/docs/20-delivery/iterations/` | `NbSzfBWyMl1hZsda75mcm68qnCg` |
| `agent-host/docs/30-release/` | `/CodexApp/agent-host/docs/30-release/` | `NRMdfymJ8l0u3idEVfFczeKVnnK` |
| `agent-host/docs/99-archive/` | `/CodexApp/agent-host/docs/99-archive/` | `Pf0Nf2RzslpaI9dJqPMcGciJn9d` |

## 最近一次同步摘要

- 同步日期：2026-06-24
- 同步范围：`agent-host/docs/` -> `/CodexApp/agent-host/docs/`
- 最近推送：`uploaded=1`、`failed=0`、`skipped=35`、`deleted_remote=0`
- 精确校验：`detection=exact`、`modified=0`、`new_local=0`、`new_remote=0`、`unchanged=36`
- 文件 token：以 `lark-cli drive +status --as user --local-dir agent-host/docs --folder-token RrAAfqitJl9Qn4dOAllcUMWxnre --json` 的最新输出为准。

## 后续维护规则

- 新增文档先按 `docs/README.md` 和 `docs/00-start/doc-governance.md` 的放置规则落位。
- 后续常规同步优先使用增量同步，减少无意义覆盖。
- 若本地发生删除、重命名或目录迁移，远端同步必须以镜像校验收尾，并在执行后更新本文件。
- 本映射只覆盖 `agent-host/` 到 `/CodexApp/agent-host/`，不记录 `codexapp-go`、Electron 或其他项目目录。
