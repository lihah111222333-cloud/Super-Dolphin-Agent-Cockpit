# agent-host AI 项目上下文

## 一句话定义

`agent-host` 是桌面 Agent 应用唯一的本地项目主体，对 Electron 提供 HTTP REST/SSE，并通过 AgentRuntime 编排底层 agent runtime。

## 项目目标

- 为 Electron 提供稳定的本地 RESTful API。
- 为任务、工作区、消息、run、event、artifact、pending request 提供本地服务边界。
- 通过 AgentRuntime 统一管理 thread、turn、事件、审批和 runtime capability。
- 通过 CodexRuntime Adapter 接入 Codex app-server。
- 代理必要远程 API，并在本地管理 session、远程 token、SQLite 缓存和同步队列。
- 隔离 Electron 与远程 API、底层 runtime 协议、Codex JSON-RPC。
- 将 Host API、AgentRuntime、AgentRuntimeAdapter 作为同一项目下的内部需求域统一推进。

## 明确非目标

- 不实现 Electron UI。
- 不实现 AgentCloud 云端服务。
- 不直接作为 `codexapp-go` SDK。
- 不直接暴露 Codex app-server JSON-RPC 给 Electron。
- 不把 Codex protocol 类型泄漏到 REST/SSE API。
- 不让 Electron 持有远程 refresh token。
- 不在 AgentHost 上层绕过 AgentRuntime 直接调用 `codexapp-go`。
- 不把 runtime adapter 做成动态插件系统；首版只接入 CodexRuntime Adapter。

## 架构位置

```text
Electron
  -> AgentHost
  -> AgentRuntime
  -> CodexRuntime Adapter
  -> codexapp-go
  -> Codex app-server
```

远程能力链路：

```text
Electron
  -> AgentHost
  -> AgentCloud / remote APIs
```

Electron 只调用 AgentHost。AgentHost 上层只使用 AgentRuntime 统一模型，不直接绑定 Codex app-server JSON-RPC。

## 技术边界

| 项目 | 内容 |
| --- | --- |
| 语言 | Go |
| 对上接口 | Gin HTTP RESTful API、SSE event stream |
| 本地存储 | SQLite + GORM + `github.com/glebarez/sqlite` |
| 日志 | 标准库 `log/slog` |
| 配置 | `config.yaml` |
| 后台任务 | 进程内 goroutine + `context.Context` + SQLite 状态表 |
| runtime 抽象 | AgentRuntime |
| 首版 runtime 实现 | CodexRuntime Adapter |
| 首版底层 SDK | `codexapp-go` |
| 远程能力 | 由 AgentHost 代理 AgentCloud/remote APIs，并做本地缓存和 token 管理 |

## AI 启动必读

1. `00-start/current-status.md`
2. `00-start/reading-guide.md`
3. `10-foundation/product/agent-host-product-spec.md`
4. `10-foundation/architecture/agent-host-technical-architecture.md`
5. `10-foundation/architecture/technology-stack.md`
6. `10-foundation/architecture/database-design.md`
7. `20-delivery/iterations/01-agent-host-core/master-plan.md`
8. `20-delivery/feature-plan.md`
9. `10-foundation/product/agent-runtime-product-spec.md`
10. `10-foundation/product/agent-runtime-adapter-product-spec.md`
11. `20-delivery/execution/execution-spec.md`

## 常见误解禁止

- 不要把 `agent-host` 写成 Electron 前端。
- 不要把 `agent-host` 写成云端后端。
- 不要把 Host API、AgentRuntime、AgentRuntimeAdapter 写成三个并列项目。
- 不要让 Electron 直接请求远程 API。
- 不要让 Electron 直接调用 `codexapp-go` 或 Codex app-server JSON-RPC。
- 不要让 AgentHost HTTP handler 直接依赖 Codex protocol 类型。
- 不要把 CodexRuntime Adapter 的映射职责上移到 AgentHost API 层。
- 不要把 `codexapp-go` 的 SDK 责任放进 `agent-host` 文档或实现中。
- 不要新增未来 runtime 的假实现；第二个 runtime 出现前保持首版 CodexRuntime 简单边界。
- 不要引入 Redis、Kafka、PostgreSQL、微服务拆分或独立队列系统。
