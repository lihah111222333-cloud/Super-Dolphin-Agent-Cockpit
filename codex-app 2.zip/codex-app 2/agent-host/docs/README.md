# agent-host docs 入口

本目录按“入口 -> 基础事实 -> 交付推进 -> 发布材料 -> 归档”的生命周期组织。开发人员先读 `00-start/`，再按自己的任务进入对应目录。

## 先看这里

| 问题 | 文档 |
| --- | --- |
| AI 从 0 进入项目先读什么？ | `00-start/ai-project-context.md` |
| 当前项目做到哪一步？ | `00-start/current-status.md` |
| 新开发者应该按什么顺序读？ | `00-start/reading-guide.md` |
| 文档应该放在哪里？ | `00-start/doc-governance.md` |
| 本地和飞书云盘如何对应？ | `00-start/feishu-drive-mapping.md` |

## 推荐阅读顺序

```text
1. 00-start/ai-project-context.md
2. 00-start/current-status.md
3. 00-start/reading-guide.md
4. 10-foundation/product/agent-host-product-spec.md
5. 10-foundation/architecture/agent-host-technical-architecture.md
6. 10-foundation/architecture/technology-stack.md
7. 10-foundation/architecture/database-design.md
8. 20-delivery/iterations/01-agent-host-core/master-plan.md
9. 20-delivery/feature-plan.md
10. 20-delivery/iterations/02-host-api-core/master-plan.md
11. 20-delivery/iterations/03-runtime-adapter-core/master-plan.md
12. 10-foundation/product/agent-runtime-product-spec.md
13. 10-foundation/product/agent-runtime-adapter-product-spec.md
14. 20-delivery/execution/execution-spec.md
15. 30-release/host-api-spec.md
```

## 按诉求定位

| 我要做什么 | 看哪里 |
| --- | --- |
| AI 从 0 加载项目上下文 | `00-start/ai-project-context.md` |
| 判断当前阶段和下一步门禁 | `00-start/current-status.md` |
| 快速接手项目 | `00-start/reading-guide.md` |
| 确认 AgentHost 产品范围和非目标 | `10-foundation/product/agent-host-product-spec.md` |
| 确认 AgentHost 总技术架构 | `10-foundation/architecture/agent-host-technical-architecture.md` |
| 确认轻量技术栈 | `10-foundation/architecture/technology-stack.md` |
| 确认数据库表、字段和索引 | `10-foundation/architecture/database-design.md` |
| 创建本地 SQLite 数据库 | `../scripts/sqlite/create-database.sql` |
| 确认 AgentHost 主线阶段计划 | `20-delivery/iterations/01-agent-host-core/master-plan.md` |
| 查 AgentHost 功能列表 | `20-delivery/feature-plan.md` |
| 确认 Host API 专项阶段计划 | `20-delivery/iterations/02-host-api-core/master-plan.md` |
| 确认 Runtime/Adapter 专项阶段计划 | `20-delivery/iterations/03-runtime-adapter-core/master-plan.md` |
| 确认 AgentRuntime 抽象边界 | `10-foundation/product/agent-runtime-product-spec.md` |
| 确认 CodexRuntime Adapter 边界 | `10-foundation/product/agent-runtime-adapter-product-spec.md` |
| 理解 runtime 架构和包边界 | `10-foundation/architecture/agent-runtime-technical-architecture.md` |
| 理解 adapter 架构和映射边界 | `10-foundation/architecture/agent-runtime-adapter-technical-architecture.md` |
| 查本地 Host API 规格 | `30-release/host-api-spec.md` |
| 查开发执行和阶段拆解约束 | `20-delivery/execution/execution-spec.md` |
| 查开发团队规范 | `20-delivery/execution/team-development-standards.md` |
| 查发布 API、兼容和变更 | `30-release/` |
| 查历史材料 | `99-archive/` |

## 一级目录

| 目录 | 放置内容 |
| --- | --- |
| `00-start/` | 当前状态、阅读路径、文档治理、飞书映射。 |
| `10-foundation/` | 长期有效的产品、架构、协议事实。 |
| `20-delivery/` | 功能监管清单、开发执行规格、迭代计划、阶段目标、验收材料。 |
| `30-release/` | API reference、compatibility、changelog、release note。 |
| `99-archive/` | 已过期但需要追溯的历史文档。 |

## 责任边界速记

| 层级 | 责任 |
| --- | --- |
| Electron | 桌面 UI 和用户交互，只调用 AgentHost。 |
| AgentCloud | 云端远程 API 服务，负责账号、设备、运营配置、协作、第三方回调、计费、分享、反馈和跨设备同步。 |
| AgentHost | 本地宿主层，对上提供 HTTP REST/SSE，内部通过 AgentRuntime 控制 runtime，并代理必要远程 API。 |
| Host API | AgentHost 内部需求域，对 Electron 提供本地 API 和事件流。 |
| AgentRuntime | AgentHost 内部需求域，定义 thread、turn、事件、pending request、capability 和 error 的统一模型。 |
| CodexRuntime Adapter | AgentHost 内部需求域，是 AgentRuntime 的 Codex 实现，对下引用 `codexapp-go`。 |
| codexapp-go | 纯 Go SDK，只封装 Codex app-server JSON-RPC。 |
| Codex app-server | Agent runtime，负责 thread、turn、事件流、工具调用和审批等能力。 |
