# AgentHost Host API 规格

整理日期：2026-06-23

依据文件：`../20-delivery/execution/execution-spec.md`

定位：本文是面向 AgentHost Host API 开发的功能列表依据。它不覆盖 Electron 前端实现，也不设计云端完整服务。本文只拆分本地 Go 服务中与远程 API 代理、SQLite 缓存、本地 session / 远程 token、远程同步队列、动态远程数据代理相关的可开发任务。

## 1. 开发边界

本地 Go 服务统一承担以下职责：

- 接收 Electron 对本地 API 的请求。
- 校验本地 `local_session_token`。
- 保存和刷新远程 `access_token` / `refresh_token`。
- 通过远程 API client 请求云端上游。
- 将动态远程数据写入 SQLite 缓存。
- 将需要上云的本地动作写入同步队列并异步同步。

不做：

- 不让 Electron 直连远程 API。
- 不让 Electron 持有远程 refresh token。
- 不设计云端服务内部实现。
- 不新增当前规格里没有的业务能力。
- 不实现扫码登录/扫码绑定。

## 2. 阶段顺序

| 阶段 | 目标 | 原因 |
| --- | --- | --- |
| P0 | 本地 session / token | 所有本地 API 的安全入口 |
| P0 | 远程 API client | 所有远程代理能力的公共依赖 |
| P0 | SQLite 远程缓存 | 动态数据代理的公共依赖 |
| P1 | Runtime 最小闭环 | Host API 通过 AgentRuntime 启动 runtime 并接收事件 |
| P2 | 动态数据代理 | 模型、技能、专家、连接器、资料库、自动化模板、灵感 |
| P3 | 云同步队列和复杂代理 | 反馈、审计、项目协作、助理网关、账号计费 |

## 3. 功能清单

### 3.1 登录鉴权与本地 Session

**功能说明**

本地服务代理远程登录，保存远程 token，并向 Electron 签发 `local_session_token`。Electron 后续调用任何本地 API 都只携带本地 session token。

**涉及本地 API**

| 方法 | 路径 |
| --- | --- |
| `POST` | `/auth/login` |
| `POST` | `/auth/logout` |
| `GET` | `/auth/session` |
| `POST` | `/auth/refresh-local` |

**涉及远程上游 API**

| 方法 | 路径 |
| --- | --- |
| `POST` | `/auth/login` |
| `POST` | `/auth/refresh` |
| `GET` | `/account/me` |

**实现要点**

- `local_session_token` 只用于本地 API 鉴权。
- 远程 `access_token` / `refresh_token` 只由本地服务加密保存。
- 所有本地 API 都要校验本地 session，即使只读本地资源。
- 远程 access token 过期时用 refresh token 刷新。
- refresh 失败返回 `REMOTE_TOKEN_EXPIRED`，本地 session 可保留但远程能力不可用。

**依赖关系**

- 无前置业务依赖。
- 后续所有远程代理、同步队列都依赖本功能。

**阶段优先级**

P0

**验收标准**

- 登录成功后 Electron 只拿到 `localSessionToken`，拿不到远程 refresh token。
- 带有效本地 session 可访问受保护本地 API。
- 无本地 session 或失效 session 返回 `UNAUTHORIZED`。
- 远程 access token 过期时可自动刷新；刷新失败时返回可识别错误。

### 3.2 远程 API Client

**功能说明**

提供本地 Go 服务内部统一远程 HTTP client，封装远程 base URL、鉴权头、重试、超时、分页、错误映射和条件请求头。

**涉及本地 API**

无独立对外 API。被所有本地代理接口调用。

**涉及远程上游 API**

所有远程上游 API。

**实现要点**

- 自动附加远程 `Authorization: Bearer access_token`。
- 支持 `ETag` / `If-None-Match`、`Last-Modified` / `If-Modified-Since`。
- 统一映射远程 401 到 token refresh，再重试一次。
- 统一映射远程失败到 `REMOTE_UNAVAILABLE`、`REMOTE_TOKEN_EXPIRED`。
- 只做必要的短超时和一次重试，避免本地 UI 被远程长时间卡住。

**依赖关系**

- 依赖登录鉴权与远程 token 存储。
- 被 SQLite cache、模型、技能、专家、连接器等代理任务依赖。

**阶段优先级**

P0

**验收标准**

- 可用同一 client 请求任一远程上游。
- 远程 401 时能刷新 token 并重试一次。
- 远程 304 可返回给 cache 层处理。
- 超时、网络失败、远程错误都有统一错误结构。

### 3.3 SQLite 远程缓存

**功能说明**

用 SQLite 缓存动态远程数据，支持 TTL、stale 窗口、强制刷新、条件请求和缓存元信息返回。数据库表、字段、索引和约束见 `../10-foundation/architecture/database-design.md`。

**涉及本地 API**

无独立业务 API。被所有带 `forceRefresh=false`、返回 `cache` 的代理接口调用。

**涉及远程上游 API**

所有可缓存的远程读取接口，例如：

- `/models/built-in`
- `/models/providers`
- `/models/entitlements`
- `/skills/marketplace`
- `/experts`
- `/connectors/catalog`
- `/knowledge-sources`
- `/automation-templates`
- `/inspirations`
- `/plans`

**实现要点**

- 未过期直接返回缓存。
- 过期但未超过 stale 窗口时先返回旧缓存，后台刷新。
- 超过 stale 窗口时同步刷新；远程失败再按业务决定返回 stale 或错误。
- 价格、权益、权限类数据使用短 TTL，购买或权限判断前不能只信长期缓存。
- 远程删除/禁用要写入缓存状态，不能继续展示为可用。

**依赖关系**

- 依赖远程 API client。
- 被所有动态数据代理任务依赖。

**阶段优先级**

P0

**验收标准**

- 相同 query 可命中 SQLite 缓存。
- `forceRefresh=true` 会绕过 TTL 请求远程。
- 支持远程 304 后只更新时间戳。
- 返回体包含 `cache.hit`、`cache.stale`、`cache.fetchedAt`。

### 3.4 远程数据同步队列

**功能说明**

用 SQLite 保存需要上云的本地动作，后台 worker 使用远程 token 异步上传，失败后指数退避重试。数据库表、字段、索引和约束见 `../10-foundation/architecture/database-design.md`。

**涉及本地 API**

| 方法 | 路径 |
| --- | --- |
| `POST` | `/projects/{projectId}/tasks/sync` |
| `POST` | `/audit/runtime-actions` |
| `POST` | `/feedback` |
| `POST` | `/feedback/{feedbackId}/attachments` |
| `POST` | `/data/shared-files/{shareId}/copy-link` |
| `DELETE` | `/data/shared-files/{shareId}` |

**涉及远程上游 API**

| 方法 | 路径 |
| --- | --- |
| `PATCH` | `/projects/{projectId}/tasks/{taskId}` |
| `POST` | `/audit/runtime-actions` |
| `POST` | `/feedback` |
| `POST` | `/feedback/{feedbackId}/attachments` |
| `POST` | `/data/shared-files/{shareId}/copy-link` |
| `DELETE` | `/data/shared-files/{shareId}` |

**实现要点**

- 本地动作先落库，再入队，避免远程失败导致本地状态丢失。
- worker 只从本地同步队列取待同步记录。
- 上传失败更新重试状态和下次重试时间。
- token 过期时通过远程 API client 刷新。
- 不新增队列管理 API；先用日志和 SQLite 状态排查。

**依赖关系**

- 依赖登录鉴权、远程 API client。
- 项目任务同步、反馈、审计依赖本功能。

**阶段优先级**

P3

**验收标准**

- 离线时同步任务保留在队列中。
- 恢复网络后可继续同步。
- 重复执行不会重复创建远程副作用，或远程接口具备幂等约束。
- 同步失败可从 SQLite 看到错误和下次重试时间。

### 3.5 模型代理

**功能说明**

本地服务代理远程模型列表、供应商预设和模型权益，并与本地自定义模型一起供模型选择和 `Auto` 解析使用。

**涉及本地 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/models/built-in` |
| `GET` | `/models/providers` |
| `GET` | `/models/entitlements` |
| `GET` | `/models/custom` |
| `POST` | `/models/custom` |
| `PATCH` | `/models/custom/{modelId}` |
| `DELETE` | `/models/custom/{modelId}` |
| `POST` | `/models/custom/{modelId}/test` |
| `POST` | `/models/resolve` |

**涉及远程上游 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/models/built-in` |
| `GET` | `/models/providers` |
| `GET` | `/models/entitlements` |

**实现要点**

- 远程模型数据走本地缓存。
- 自定义模型和 API Key 只存在本地，加密保存。
- `/models/resolve` 只基于远程缓存 + 本地自定义模型做选择，不远程创建状态。
- 权益类数据 TTL 较短；模型是否可用以 `/models/entitlements` 为准。

**依赖关系**

- 依赖本地 session、远程 API client、SQLite cache。

**阶段优先级**

P2

**验收标准**

- 模型列表可缓存、可强制刷新。
- 无远程网络时可按 stale 策略返回旧模型列表。
- 自定义模型接口不返回明文 Key。
- 不具备权益的模型不会被 `/models/resolve` 选中。

### 3.6 技能市场代理

**功能说明**

本地服务代理远程技能市场、技能详情、安装包获取、技能查找和生成；本地技能上传、安装、启停、卸载仍只落本地。

**涉及本地 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/skills/marketplace` |
| `GET` | `/skills/{skillId}` |
| `POST` | `/skills/{skillId}/install-package` |
| `POST` | `/skills/find` |
| `POST` | `/skills/generate` |
| `GET` | `/skills/installed` |
| `GET` | `/skills/local-drafts` |
| `POST` | `/skills/local-drafts` |
| `PATCH` | `/skills/local-drafts/{draftId}` |
| `DELETE` | `/skills/local-drafts/{draftId}` |

**涉及远程上游 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/skills/marketplace` |
| `GET` | `/skills/{skillId}` |
| `POST` | `/skills/{skillId}/install-package` |
| `POST` | `/skills/find` |
| `POST` | `/skills/generate` |

**实现要点**

- 市场列表和详情走本地缓存。
- 远程安装包只下载到本地安装流程，不把远程技能当成本地已安装技能。
- `skills/generate` 返回的草稿保存到本地，不上云。
- 本地技能草稿与远程市场技能用 `source=local/remote` 区分。

**依赖关系**

- 依赖本地 session、远程 API client、SQLite cache。
- 安装包落地依赖本地技能安装流程，本文不展开。

**阶段优先级**

P2

**验收标准**

- 技能市场列表可缓存、搜索、分页。
- 远程技能详情可返回版本、权限、风险信息。
- 远程生成技能草稿只保存本地。
- 本地技能和远程技能 ID 不冲突。

### 3.7 专家中心代理

**功能说明**

本地服务代理专家分类、专家中心、专家详情、专家团，同时合并用户本地创建专家。本地专家只存在 SQLite，不上云。

**涉及本地 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/experts/categories` |
| `GET` | `/experts` |
| `GET` | `/experts/{expertId}` |
| `GET` | `/expert-teams` |
| `GET` | `/expert-teams/{teamId}` |
| `POST` | `/experts/{expertId}/summon-local` |
| `GET` | `/my-experts/local` |
| `POST` | `/my-experts/local` |
| `PATCH` | `/my-experts/local/{expertId}` |
| `DELETE` | `/my-experts/local/{expertId}` |

**涉及远程上游 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/experts/categories` |
| `GET` | `/experts` |
| `GET` | `/experts/{expertId}` |
| `GET` | `/expert-teams` |
| `GET` | `/expert-teams/{teamId}` |

**实现要点**

- 远程专家数据走本地缓存。
- 本地专家从本地持久化读取，返回时标记 `source=local`。
- 远程专家返回 `source=remote`，ID 使用来源前缀避免冲突。
- `summon-local` 创建本地任务，使用专家快照，不依赖远程持续可用。

**依赖关系**

- 依赖本地 session、远程 API client、SQLite cache。
- `summon-local` 依赖本地任务创建能力。

**阶段优先级**

P2

**验收标准**

- 专家列表可同时返回远程专家和本地专家。
- 本地专家创建、编辑、删除不会调用远程 API。
- 远程专家详情可缓存并按 TTL 刷新。
- 召唤专家后能创建本地任务并保留专家快照。

### 3.8 连接器代理

**功能说明**

本地服务代理远程连接器目录、详情、授权状态、OAuth 发起、授权会话状态和审计日志。本地 MCP 连接器配置只存在本地，项目级自定义连接器由本地服务代理远程管理。

**涉及本地 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/connectors/catalog` |
| `GET` | `/connectors/{connectorId}` |
| `GET` | `/connector-connections` |
| `POST` | `/connectors/{connectorId}/auth/start` |
| `GET` | `/connectors/auth-sessions/{sessionId}` |
| `GET` | `/connector-connections/{connectionId}/audit-logs` |
| `POST` | `/connectors/custom/local` |
| `PATCH` | `/connectors/custom/local/{connectorId}` |
| `DELETE` | `/connectors/custom/local/{connectorId}` |
| `POST` | `/connectors/custom/project` |
| `PATCH` | `/connectors/custom/project/{connectorId}` |
| `DELETE` | `/connectors/custom/project/{connectorId}` |

**涉及远程上游 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/connectors/catalog` |
| `GET` | `/connectors/{connectorId}` |
| `GET` | `/connector-connections` |
| `POST` | `/connectors/{connectorId}/auth/start` |
| `GET` | `/connectors/auth-sessions/{sessionId}` |
| `POST` | `/connectors/{connectorId}/auth/callback` |
| `GET` | `/connector-connections/{connectionId}/audit-logs` |
| `POST` | `/connectors/custom` |
| `PATCH` | `/connectors/custom/{connectorId}` |
| `DELETE` | `/connectors/custom/{connectorId}` |

**实现要点**

- 目录和详情走本地缓存。
- OAuth 回调由远程网关处理；本地只发起授权并查询授权状态。
- 本地连接和远程连接合并返回时必须区分 `source`。
- 不开放任意连接器 invoke 给前端。

**依赖关系**

- 依赖本地 session、远程 API client、SQLite cache。
- 项目级连接器依赖项目权限，后置验证。

**阶段优先级**

P2

**验收标准**

- 连接器目录可缓存、可强制刷新。
- 授权开始返回远程 `authUrl` 和 `sessionId`。
- 授权状态能同步到本地可用连接列表。
- 本地 MCP 连接器不调用远程 API。

### 3.9 资料库代理

**功能说明**

本地服务代理远程资料库来源、授权、空间、文件搜索、文件详情和产物回写；任务只保存资料库引用快照。

**涉及本地 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/knowledge-sources` |
| `POST` | `/knowledge-sources/{provider}/auth/start` |
| `DELETE` | `/knowledge-sources/{provider}/binding` |
| `GET` | `/knowledge-sources/{provider}/spaces` |
| `GET` | `/knowledge-sources/{provider}/files` |
| `GET` | `/knowledge-sources/{provider}/files/{fileId}` |
| `POST` | `/tasks/{taskId}/context-refs` |
| `GET` | `/tasks/{taskId}/context-refs` |
| `POST` | `/artifacts/{artifactId}/upload-to-cloud` |

**涉及远程上游 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/knowledge-sources` |
| `POST` | `/knowledge-sources/{provider}/auth/start` |
| `DELETE` | `/knowledge-sources/{provider}/binding` |
| `GET` | `/knowledge-sources/{provider}/spaces` |
| `GET` | `/knowledge-sources/{provider}/files` |
| `GET` | `/knowledge-sources/{provider}/files/{fileId}` |
| `POST` | `/knowledge-sources/{provider}/files/{fileId}/references` |
| `POST` | `/artifacts/{artifactId}/upload-to-cloud` |

**实现要点**

- 来源、空间、搜索结果可短期缓存。
- 任务上下文只保存引用和权限快照，不默认下载完整文件。
- 执行时按需通过远程 token 拉取详情或摘要。
- 回写云资料库时由本地读取产物，再调用远程上传。

**依赖关系**

- 依赖本地 session、远程 API client、SQLite cache。
- 回写依赖本地产物服务。

**阶段优先级**

P2

**验收标准**

- 可列出资料库来源和空间。
- 可搜索文件并添加为本地任务引用。
- 本地任务引用不包含远程 token。
- 产物回写失败不会破坏本地产物。

### 3.10 自动化模板代理

**功能说明**

本地服务代理远程自动化模板，避免 Electron 硬编码运营模板。本地个人自动化执行不在本文展开。

**涉及本地 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/automation-templates` |

**涉及远程上游 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/automation-templates` |

**实现要点**

- 模板列表走本地缓存。
- 支持 `scene` 查询和 `forceRefresh`。
- 模板只作为创建本地自动化的输入，不在本地当成固定枚举。

**依赖关系**

- 依赖本地 session、远程 API client、SQLite cache。

**阶段优先级**

P2

**验收标准**

- 可按 scene 获取模板。
- 缓存过期后可自动刷新。
- 远程不可用时按 stale 策略返回旧模板。

### 3.11 灵感场景代理

**功能说明**

本地服务代理远程灵感场景、案例列表、案例详情、收藏和 clone。clone 后生成本地任务草稿。

**涉及本地 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/inspirations/categories` |
| `GET` | `/inspirations` |
| `GET` | `/inspirations/{inspirationId}` |
| `POST` | `/inspirations/{inspirationId}/favorite` |
| `DELETE` | `/inspirations/{inspirationId}/favorite` |
| `POST` | `/inspirations/{inspirationId}/clone` |
| `POST` | `/tasks/drafts` |
| `POST` | `/tasks/drafts/{draftId}/run` |

**涉及远程上游 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/inspirations/categories` |
| `GET` | `/inspirations` |
| `GET` | `/inspirations/{inspirationId}` |
| `POST` | `/inspirations/{inspirationId}/favorite` |
| `DELETE` | `/inspirations/{inspirationId}/favorite` |
| `POST` | `/inspirations/{inspirationId}/clone` |

**实现要点**

- 场景、列表、详情走本地缓存。
- 收藏是远程写操作，不长期缓存最终状态。
- clone 获取远程草稿载荷后，保存为本地任务草稿。
- 不把灵感分类写死到前端或本地常量。

**依赖关系**

- 依赖本地 session、远程 API client、SQLite cache。
- 草稿运行依赖本地任务执行能力。

**阶段优先级**

P2

**验收标准**

- 灵感场景和案例列表可缓存、可刷新。
- 收藏/取消收藏远程失败时返回明确错误。
- clone 后生成本地草稿，不直接启动任务，除非调用 run。

### 3.12 账号计费代理

**功能说明**

本地服务代理账号信息、设备、套餐、积分、订单、发票和购买入口。价格、权益、扣费不在本地硬编码。

**涉及本地 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/account/me` |
| `POST` | `/devices/register` |
| `PATCH` | `/devices/{deviceId}/heartbeat` |
| `GET` | `/devices` |
| `DELETE` | `/devices/{deviceId}` |
| `GET` | `/plans` |
| `GET` | `/credits/balance` |
| `GET` | `/credits/usage` |
| `GET` | `/orders` |
| `GET` | `/invoices` |
| `POST` | `/checkout/packages` |

**涉及远程上游 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/account/me` |
| `POST` | `/devices/register` |
| `PATCH` | `/devices/{deviceId}/heartbeat` |
| `GET` | `/devices` |
| `DELETE` | `/devices/{deviceId}` |
| `GET` | `/plans` |
| `GET` | `/credits/balance` |
| `GET` | `/credits/usage` |
| `GET` | `/orders` |
| `GET` | `/invoices` |
| `POST` | `/checkout/packages` |

**实现要点**

- `/plans` 可短 TTL 缓存，domain 使用 `plans`。
- `/credits/balance` 默认强制刷新或极短 TTL。
- 购买、扣费、权益判断前必须请求远程，不依赖旧缓存。
- 设备注册和心跳属于远程写操作，不走长期缓存。

**依赖关系**

- 依赖登录鉴权、远程 API client、SQLite cache。

**阶段优先级**

P3

**验收标准**

- 本地可查看账号、套餐、积分余额。
- 套餐价格不硬编码，来自远程。
- 购买入口由远程返回 checkout URL。
- token 失效时能触发 refresh 或返回明确错误。

### 3.13 反馈与日志同步

**功能说明**

本地服务打包并脱敏日志，再代理远程反馈和附件上传。

**涉及本地 API**

| 方法 | 路径 |
| --- | --- |
| `POST` | `/feedback/log-bundles` |
| `POST` | `/feedback` |
| `POST` | `/feedback/{feedbackId}/attachments` |

**涉及远程上游 API**

| 方法 | 路径 |
| --- | --- |
| `POST` | `/feedback` |
| `POST` | `/feedback/{feedbackId}/attachments` |

**实现要点**

- `log-bundles` 只在本地生成脱敏包。
- 上传反馈需要远程 access token。
- 上传失败可进入同步队列，避免用户反馈丢失。
- 日志脱敏规则待确认，当前规格只明确需要 `redactionSummary`。

**依赖关系**

- 依赖本地 session、远程 API client。
- 异步重试依赖远程数据同步队列。

**阶段优先级**

P3

**验收标准**

- 可生成本地日志包和脱敏摘要。
- 反馈提交成功返回 `feedbackId`。
- 网络失败时反馈可入队重试。
- 不上传远程 token、API Key 明文。

### 3.14 项目协作代理

**功能说明**

本地服务代理远程项目、成员、邀请、审批、项目资产、项目任务摘要同步。项目任务实际执行仍走本地任务系统。

**涉及本地 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/projects` |
| `POST` | `/projects` |
| `GET` | `/projects/{projectId}` |
| `PATCH` | `/projects/{projectId}` |
| `DELETE` | `/projects/{projectId}` |
| `GET` | `/project-templates` |
| `GET` | `/projects/{projectId}/activity` |
| `GET` | `/projects/{projectId}/members` |
| `POST` | `/projects/{projectId}/invites` |
| `POST` | `/project-invites/{inviteId}/apply` |
| `POST` | `/project-join-requests/{requestId}/approve` |
| `POST` | `/project-join-requests/{requestId}/reject` |
| `GET` | `/projects/{projectId}/assets` |
| `POST` | `/projects/{projectId}/assets` |
| `POST` | `/projects/{projectId}/tasks/sync` |

**涉及远程上游 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/projects` |
| `POST` | `/projects` |
| `GET` | `/projects/{projectId}` |
| `PATCH` | `/projects/{projectId}` |
| `DELETE` | `/projects/{projectId}` |
| `GET` | `/project-templates` |
| `GET` | `/projects/{projectId}/activity` |
| `GET` | `/projects/{projectId}/members` |
| `POST` | `/projects/{projectId}/invites` |
| `POST` | `/project-invites/{inviteId}/apply` |
| `POST` | `/project-join-requests/{requestId}/approve` |
| `POST` | `/project-join-requests/{requestId}/reject` |
| `GET` | `/projects/{projectId}/assets` |
| `POST` | `/projects/{projectId}/assets` |
| `PATCH` | `/projects/{projectId}/tasks/{taskId}` |

**实现要点**

- 项目列表、详情、模板、成员摘要可缓存。
- 创建、更新、审批、邀请是远程写操作，不长期缓存。
- 项目任务同步可通过同步队列异步补偿。
- 项目资产上传失败不能影响本地任务产物。

**依赖关系**

- 依赖本地 session、远程 API client、SQLite cache。
- 任务摘要同步依赖远程数据同步队列。
- 项目任务执行依赖本地任务系统，本文不展开。

**阶段优先级**

P3

**验收标准**

- 可获取和缓存项目列表/详情。
- 可同步本地任务摘要到远程项目任务。
- 项目成员和权限由远程返回，不本地硬编码。
- 远程失败不会破坏本地任务状态。

### 3.15 助理网关代理

**功能说明**

本地服务代理远程助理平台接入状态、平台注册和解绑；远程消息落地为本地助理会话和本地任务。不实现扫码绑定。

**涉及本地 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/assistant/settings` |
| `PATCH` | `/assistant/settings` |
| `GET` | `/assistant/integrations` |
| `POST` | `/assistant/integrations/{platform}/register` |
| `DELETE` | `/assistant/integrations/{platform}` |
| `GET` | `/assistant/session/messages` |
| `POST` | `/assistant/session/messages` |
| `GET` | `/assistant/tasks` |
| `GET` | `/assistant/tasks/{taskId}/events` |

**涉及远程上游 API**

| 方法 | 路径 |
| --- | --- |
| `GET` | `/assistant/integrations` |
| `POST` | `/assistant/integrations/{platform}/register` |
| `DELETE` | `/assistant/integrations/{platform}` |
| `POST` | `/assistant/callbacks/{platform}` |
| `POST` | `/assistant/dispatch` |
| `POST` | `/assistant/replies` |

**实现要点**

- 本地只代理平台接入状态、注册、解绑。
- 远程回调验签和公网入口属于云端，不在本地实现。
- `/assistant/session/messages` 负责把远程消息保存为本地会话并触发本地任务。
- 执行结果通过远程 `/assistant/replies` 回传平台。

**依赖关系**

- 依赖本地 session、远程 API client。
- 消息落地依赖本地任务执行能力。
- 回复同步可依赖同步队列。

**阶段优先级**

P3

**验收标准**

- 可查看远程平台接入状态。
- 可注册/解绑平台集成。
- 远程消息可落地为本地任务。
- 执行结果可回传远程上游；失败可重试。

## 4. 待确认项

| 项 | 原因 |
| --- | --- |
| 日志脱敏字段规则 | 当前规格只要求 `redactionSummary`，未定义脱敏字段清单 |
| 远程写操作幂等键 | 当前规格未统一规定远程写 API 的幂等头或业务键 |
| 项目权限细则 | 当前规格列出项目 API，但未定义本地如何缓存角色权限 |
| 助理消息回传失败策略 | 当前规格有 `/assistant/replies`，未明确是否必须入同步队列 |
| 云记忆同步 | 当前规格说明可选启用，未要求本地项目必须实现 |

## 5. 最小可交付切片

| 切片 | 包含任务 |
| --- | --- |
| Slice 1 | 登录鉴权、远程 API client、SQLite 远程缓存 |
| Slice 2 | 模型代理、自动化模板代理、技能市场代理 |
| Slice 3 | 连接器目录代理、专家中心代理、灵感场景代理 |
| Slice 4 | 远程同步队列、反馈与日志同步、项目任务摘要同步 |
| Slice 5 | 资料库代理、项目协作代理、账号计费代理、助理网关代理 |
