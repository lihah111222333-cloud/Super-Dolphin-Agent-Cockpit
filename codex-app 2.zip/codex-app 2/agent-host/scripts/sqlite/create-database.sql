PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;
PRAGMA busy_timeout = 5000;

BEGIN;

CREATE TABLE IF NOT EXISTS user_sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  local_session_hash TEXT NOT NULL UNIQUE,
  remote_access_token_enc TEXT,
  remote_refresh_token_enc TEXT,
  expires_at DATETIME NOT NULL,
  revoked_at DATETIME,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_user_sessions_user_id ON user_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_user_sessions_expires_at ON user_sessions(expires_at);

CREATE TABLE IF NOT EXISTS settings (
  id TEXT PRIMARY KEY,
  scope TEXT NOT NULL,
  user_id TEXT,
  key TEXT NOT NULL,
  value_json TEXT NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_settings_user_id ON settings(user_id);
CREATE UNIQUE INDEX IF NOT EXISTS uniq_settings_scope_user_key ON settings(scope, COALESCE(user_id, ''), key);

CREATE TABLE IF NOT EXISTS remote_cache (
  key TEXT PRIMARY KEY,
  domain TEXT NOT NULL,
  user_id TEXT,
  org_id TEXT,
  payload_json TEXT NOT NULL,
  etag TEXT,
  last_modified TEXT,
  version TEXT,
  fetched_at DATETIME NOT NULL,
  expires_at DATETIME NOT NULL,
  stale_at DATETIME NOT NULL,
  sync_status TEXT NOT NULL CHECK (sync_status IN ('fresh', 'stale', 'error')),
  error_json TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_remote_cache_domain_user_org ON remote_cache(domain, user_id, org_id);
CREATE INDEX IF NOT EXISTS idx_remote_cache_expires_at ON remote_cache(expires_at);
CREATE INDEX IF NOT EXISTS idx_remote_cache_stale_at ON remote_cache(stale_at);

CREATE TABLE IF NOT EXISTS workspaces (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  path TEXT NOT NULL,
  last_opened_at DATETIME,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at DATETIME
);
CREATE INDEX IF NOT EXISTS idx_workspaces_user_updated ON workspaces(user_id, updated_at);
CREATE INDEX IF NOT EXISTS idx_workspaces_user_path ON workspaces(user_id, path);
CREATE INDEX IF NOT EXISTS idx_workspaces_deleted_at ON workspaces(deleted_at);

CREATE TABLE IF NOT EXISTS tasks (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  workspace_id TEXT,
  title TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('draft', 'running', 'paused', 'done', 'error', 'stopped', 'archived')),
  mode TEXT NOT NULL CHECK (mode IN ('ask', 'plan', 'craft')),
  permission_mode TEXT NOT NULL CHECK (permission_mode IN ('default', 'full_access')),
  project_id TEXT,
  pinned INTEGER NOT NULL DEFAULT 0 CHECK (pinned IN (0, 1)),
  archived INTEGER NOT NULL DEFAULT 0 CHECK (archived IN (0, 1)),
  summary TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at DATETIME,
  FOREIGN KEY (workspace_id) REFERENCES workspaces(id) ON UPDATE CASCADE ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_tasks_user_status_updated ON tasks(user_id, status, updated_at);
CREATE INDEX IF NOT EXISTS idx_tasks_workspace_updated ON tasks(workspace_id, updated_at);
CREATE INDEX IF NOT EXISTS idx_tasks_project_updated ON tasks(project_id, updated_at);
CREATE INDEX IF NOT EXISTS idx_tasks_archived ON tasks(archived);
CREATE INDEX IF NOT EXISTS idx_tasks_deleted_at ON tasks(deleted_at);

CREATE TABLE IF NOT EXISTS task_messages (
  id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('user', 'assistant', 'system', 'tool')),
  content TEXT NOT NULL,
  attachments_json TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (task_id) REFERENCES tasks(id) ON UPDATE CASCADE ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_task_messages_task_created ON task_messages(task_id, created_at);

CREATE TABLE IF NOT EXISTS task_runs (
  id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL,
  runtime TEXT NOT NULL,
  thread_id TEXT,
  turn_id TEXT,
  status TEXT NOT NULL CHECK (status IN ('queued', 'running', 'waiting', 'done', 'error', 'stopped')),
  model_id TEXT,
  started_at DATETIME,
  ended_at DATETIME,
  error_json TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (task_id) REFERENCES tasks(id) ON UPDATE CASCADE ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_task_runs_task_started ON task_runs(task_id, started_at);
CREATE INDEX IF NOT EXISTS idx_task_runs_status_updated ON task_runs(status, updated_at);

CREATE TABLE IF NOT EXISTS run_events (
  id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL,
  run_id TEXT NOT NULL,
  sequence INTEGER NOT NULL,
  type TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (task_id) REFERENCES tasks(id) ON UPDATE CASCADE ON DELETE CASCADE,
  FOREIGN KEY (run_id) REFERENCES task_runs(id) ON UPDATE CASCADE ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS uniq_run_events_run_sequence ON run_events(run_id, sequence);
CREATE INDEX IF NOT EXISTS idx_run_events_task_created ON run_events(task_id, created_at);
CREATE INDEX IF NOT EXISTS idx_run_events_run_created ON run_events(run_id, created_at);
CREATE INDEX IF NOT EXISTS idx_run_events_type ON run_events(type);

CREATE TABLE IF NOT EXISTS runtime_actions (
  id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL,
  run_id TEXT NOT NULL,
  risk_level TEXT NOT NULL CHECK (risk_level IN ('low', 'medium', 'high')),
  action_json TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending', 'approved', 'denied', 'expired')),
  decision_json TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  resolved_at DATETIME,
  FOREIGN KEY (task_id) REFERENCES tasks(id) ON UPDATE CASCADE ON DELETE CASCADE,
  FOREIGN KEY (run_id) REFERENCES task_runs(id) ON UPDATE CASCADE ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_runtime_actions_status_created ON runtime_actions(status, created_at);
CREATE INDEX IF NOT EXISTS idx_runtime_actions_task_run ON runtime_actions(task_id, run_id);

CREATE TABLE IF NOT EXISTS context_refs (
  id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL,
  ref_type TEXT NOT NULL CHECK (ref_type IN ('local_file', 'cloud_file', 'project_asset')),
  provider TEXT,
  ref_id TEXT NOT NULL,
  title TEXT,
  metadata_json TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at DATETIME,
  FOREIGN KEY (task_id) REFERENCES tasks(id) ON UPDATE CASCADE ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_context_refs_task_type ON context_refs(task_id, ref_type);
CREATE INDEX IF NOT EXISTS idx_context_refs_deleted_at ON context_refs(deleted_at);

CREATE TABLE IF NOT EXISTS artifacts (
  id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL,
  path TEXT NOT NULL,
  type TEXT NOT NULL,
  title TEXT,
  preview_status TEXT NOT NULL CHECK (preview_status IN ('pending', 'ready', 'error')),
  metadata_json TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at DATETIME,
  FOREIGN KEY (task_id) REFERENCES tasks(id) ON UPDATE CASCADE ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_artifacts_task_type_created ON artifacts(task_id, type, created_at);
CREATE INDEX IF NOT EXISTS idx_artifacts_task_path ON artifacts(task_id, path);
CREATE INDEX IF NOT EXISTS idx_artifacts_deleted_at ON artifacts(deleted_at);

CREATE TABLE IF NOT EXISTS file_changes (
  id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL,
  run_id TEXT,
  path TEXT NOT NULL,
  change_type TEXT NOT NULL CHECK (change_type IN ('created', 'modified', 'deleted')),
  diff TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (task_id) REFERENCES tasks(id) ON UPDATE CASCADE ON DELETE CASCADE,
  FOREIGN KEY (run_id) REFERENCES task_runs(id) ON UPDATE CASCADE ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_file_changes_task_created ON file_changes(task_id, created_at);
CREATE INDEX IF NOT EXISTS idx_file_changes_run_created ON file_changes(run_id, created_at);

CREATE TABLE IF NOT EXISTS custom_models (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  provider TEXT NOT NULL,
  base_url TEXT,
  model_name TEXT NOT NULL,
  capabilities_json TEXT,
  encrypted_api_key TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at DATETIME
);
CREATE INDEX IF NOT EXISTS idx_custom_models_user_updated ON custom_models(user_id, updated_at);
CREATE UNIQUE INDEX IF NOT EXISTS uniq_custom_models_user_provider_model ON custom_models(user_id, provider, COALESCE(base_url, ''), model_name);
CREATE INDEX IF NOT EXISTS idx_custom_models_deleted_at ON custom_models(deleted_at);

CREATE TABLE IF NOT EXISTS installed_skills (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  version TEXT NOT NULL,
  path TEXT NOT NULL,
  enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
  permissions_json TEXT,
  risk_json TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at DATETIME
);
CREATE INDEX IF NOT EXISTS idx_installed_skills_user_enabled ON installed_skills(user_id, enabled);
CREATE UNIQUE INDEX IF NOT EXISTS uniq_installed_skills_user_path ON installed_skills(user_id, path);
CREATE INDEX IF NOT EXISTS idx_installed_skills_deleted_at ON installed_skills(deleted_at);

CREATE TABLE IF NOT EXISTS local_skill_drafts (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  manifest_json TEXT NOT NULL,
  path TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at DATETIME
);
CREATE INDEX IF NOT EXISTS idx_local_skill_drafts_user_updated ON local_skill_drafts(user_id, updated_at);
CREATE INDEX IF NOT EXISTS idx_local_skill_drafts_user_path ON local_skill_drafts(user_id, path);
CREATE INDEX IF NOT EXISTS idx_local_skill_drafts_deleted_at ON local_skill_drafts(deleted_at);

CREATE TABLE IF NOT EXISTS local_experts (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  prompt TEXT NOT NULL,
  skill_ids_json TEXT,
  connector_policy_json TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at DATETIME
);
CREATE INDEX IF NOT EXISTS idx_local_experts_user_updated ON local_experts(user_id, updated_at);
CREATE INDEX IF NOT EXISTS idx_local_experts_deleted_at ON local_experts(deleted_at);

CREATE TABLE IF NOT EXISTS automations (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  prompt TEXT NOT NULL,
  schedule_json TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('enabled', 'disabled')),
  workspace_id TEXT,
  model_id TEXT,
  skill_ids_json TEXT,
  connector_ids_json TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at DATETIME,
  FOREIGN KEY (workspace_id) REFERENCES workspaces(id) ON UPDATE CASCADE ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_automations_user_status ON automations(user_id, status);
CREATE INDEX IF NOT EXISTS idx_automations_workspace ON automations(workspace_id);
CREATE INDEX IF NOT EXISTS idx_automations_deleted_at ON automations(deleted_at);

CREATE TABLE IF NOT EXISTS automation_runs (
  id TEXT PRIMARY KEY,
  automation_id TEXT NOT NULL,
  task_id TEXT,
  status TEXT NOT NULL CHECK (status IN ('running', 'done', 'error', 'stopped')),
  started_at DATETIME,
  ended_at DATETIME,
  error_json TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (automation_id) REFERENCES automations(id) ON UPDATE CASCADE ON DELETE CASCADE,
  FOREIGN KEY (task_id) REFERENCES tasks(id) ON UPDATE CASCADE ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_automation_runs_automation_started ON automation_runs(automation_id, started_at);
CREATE INDEX IF NOT EXISTS idx_automation_runs_status_started ON automation_runs(status, started_at);
CREATE INDEX IF NOT EXISTS idx_automation_runs_task_id ON automation_runs(task_id);

CREATE TABLE IF NOT EXISTS memories (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  content TEXT NOT NULL,
  tags_json TEXT,
  enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
  source TEXT NOT NULL CHECK (source IN ('manual', 'imported', 'generated')),
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at DATETIME
);
CREATE INDEX IF NOT EXISTS idx_memories_user_enabled_updated ON memories(user_id, enabled, updated_at);
CREATE INDEX IF NOT EXISTS idx_memories_deleted_at ON memories(deleted_at);

CREATE TABLE IF NOT EXISTS remote_sync_queue (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  domain TEXT NOT NULL,
  action TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending', 'running', 'done', 'failed')),
  retry_count INTEGER NOT NULL DEFAULT 0 CHECK (retry_count >= 0),
  next_retry_at DATETIME,
  idempotency_key TEXT,
  error_json TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at DATETIME
);
CREATE INDEX IF NOT EXISTS idx_remote_sync_queue_user_id ON remote_sync_queue(user_id);
CREATE INDEX IF NOT EXISTS idx_remote_sync_queue_status_next_retry ON remote_sync_queue(status, next_retry_at);
CREATE INDEX IF NOT EXISTS idx_remote_sync_queue_domain_status ON remote_sync_queue(domain, status);
CREATE INDEX IF NOT EXISTS idx_remote_sync_queue_idempotency_key ON remote_sync_queue(idempotency_key);

COMMIT;

PRAGMA foreign_key_check;
