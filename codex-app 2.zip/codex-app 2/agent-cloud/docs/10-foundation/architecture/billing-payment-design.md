# 计费和支付设计

整理日期：2026-06-23

适用阶段：P3

## 1. 定位

本文收口 P3 Credits、用量、订单、支付回调、权益发放和发票入口。P0 只做套餐展示，不做扣费和订单。

## 2. 核心对象

| 对象 | 表 |
| --- | --- |
| 套餐展示 | `plans` |
| Credits 流水 | `credit_ledgers` |
| 订单 | `orders` |
| 发票入口 | `invoices` |
| 支付回调事件 | `webhook_events` |

## 3. 订单状态

| 状态 | 含义 |
| --- | --- |
| `pending` | 已创建，等待支付。 |
| `paid` | 支付成功，权益已发放。 |
| `failed` | 支付失败。 |
| `cancelled` | 用户或系统取消。 |
| `refunded` | 已退款。 |

## 4. 幂等规则

- `POST /checkout/packages` 使用 `Idempotency-Key` 避免重复创建订单。
- 支付回调使用 provider event ID 去重。
- 权益发放必须以订单状态变更为事务边界。
- `POST /usage/ledger` 使用幂等键避免重复扣费。

## 5. 支付回调流程

```text
支付 provider -> /payments/callbacks/{provider}
  -> 验签
  -> event_id 去重
  -> 查找 order
  -> 状态变更
  -> 发放权益 / 记录 ledger
  -> 返回成功
```

## 6. 不做事项

- P3 不实现复杂财务后台。
- 发票接口可先返回外部控制台链接。
- 退款和争议处理只记录状态，不在 P3 首版做完整财务工作流。
