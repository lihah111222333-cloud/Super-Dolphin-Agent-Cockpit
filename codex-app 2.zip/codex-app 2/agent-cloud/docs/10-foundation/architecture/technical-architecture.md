# AgentCloud 技术架构说明书

整理日期：2026-06-23

状态：当前有效技术架构说明

依据：

- `../../30-release/cloud-api-spec.md`
- `technology-stack.md`
- `database-design.md`
- `../../20-delivery/iterations/01-agent-cloud-api-service/feature-plan.md`

架构图：

- Draw.io 源文件：`agent-cloud-architecture-diagrams.drawio`
- 业务架构图：`agent-cloud-business-architecture.png`
- 技术架构图：`agent-cloud-technical-architecture.png`

## 1. 架构定位

AgentCloud 是桌面 Agent 产品的云端远程 API 服务。它不承载本地 Agent runtime，不直接访问用户本机文件系统，不直接服务 Electron Renderer。它通过 HTTPS API、Webhook 和后台 Worker 支撑账号、设备、运营配置、协作、第三方授权、计费和同步类能力。

```mermaid
flowchart LR
  Electron["Electron 薄前端"]
  DeviceAgent["设备端代理服务"]
  AgentCloud["AgentCloud /api/v1"]
  ThirdParty["第三方平台"]
  Admin["云后台管理端"]
  Worker["云端 Worker"]

  Electron --> DeviceAgent
  DeviceAgent --> AgentCloud
  ThirdParty --> AgentCloud
  Admin --> AgentCloud
  Worker --> AgentCloud
  AgentCloud --> ThirdParty
  AgentCloud --> DeviceAgent
```

## 2. 架构原则

| 原则 | 说明 |
| --- | --- |
| 本地执行不进云 | shell、文件树、diff、预览、权限确认和完整任务过程归设备端。 |
| 远程身份归云 | 账号、组织、角色、套餐、token、设备 ID 归 AgentCloud。 |
| 运营配置归云 | 模型、专家、技能、灵感、连接器、模板、套餐由云端版本化下发。 |
| 协作事实归云 | 项目、成员、资产、任务摘要、分享、审计、计费记录归云端。 |
| 第三方回调进云 | OAuth、助理消息、支付回调只打到 AgentCloud。 |
| 第三方凭证不外泄 | OAuth token 用凭证引用或内部凭证引用，不明文返回调用方。 |

## 3. 逻辑分层

| 层 | 职责 |
| --- | --- |
| API Edge | HTTPS 入口、`/api/v1` 路由、请求 ID、响应 envelope、错误映射、分页、限流。 |
| Auth Context | access token 校验、refresh token 轮换、用户/组织/角色上下文注入。 |
| Device Context | `X-Device-Id` 校验、设备注册、心跳、在线状态、设备解绑。 |
| Domain Services | 账号、模型、专家、技能、灵感、连接器、项目、资产、助理、自动化、计费、反馈等业务服务。 |
| Provider Gateway | OAuth provider、云资料库 provider、支付 provider、助理平台 provider 的适配入口。 |
| Queue / Worker | Webhook 异步处理、消息派发、回调重试、计费记账、索引维护。 |
| Storage | 业务数据库、对象存储、审计日志、第三方凭证引用和幂等记录。 |

## 3.1 基础技术栈

基础技术栈已在 `technology-stack.md` 冻结，开发不得替换为约定外方案。

| 类别 | 选型 |
| --- | --- |
| 服务端 | Go + Gin |
| 数据库 | PostgreSQL + GORM + goose |
| 缓存 | Redis + go-redis |
| Token | JWT access token + opaque refresh token |
| 密码哈希 | bcrypt |
| 配置 | `config.yaml` + 环境变量覆盖 secret |
| 日志 | Go `slog` 结构化日志 |

## 4. 模块划分

| 模块 | 覆盖功能 ID | 主要职责 |
| --- | --- | --- |
| Core API | `CORE-01` ~ `CORE-04` | 响应格式、错误码、分页、幂等、条件缓存。 |
| Auth & Account | `AUTH-01` ~ `AUTH-04` | 登录、刷新、退出、账号上下文、组织和角色。 |
| Device | `DEV-01` ~ `DEV-03` | 设备注册、心跳、列表、解绑和在线状态。 |
| Billing Plan | `BILL-01` | 套餐展示和版本缓存。 |
| Model Catalog | `MODEL-01` ~ `MODEL-03` | 模型清单、供应商预设、模型权益。 |
| Expert Center | `EXP-01` ~ `EXP-04` | 专家分类、列表、详情快照、专家团。 |
| Skill Marketplace | `SKILL-01` ~ `SKILL-05` | 市场技能、安装包下载信息、风险元数据、草稿载荷。 |
| Inspiration | `INSP-01` ~ `INSP-05` | 灵感分类、案例、收藏、制作同款载荷。 |
| Connector | `CONN-01` ~ `CONN-04` | 连接器目录、OAuth、授权状态、连接器审计。 |
| Knowledge Source | `KS-01` ~ `KS-05` | 云资料库授权、搜索、引用、产物回写。 |
| Project Collaboration | `PROJ-01` ~ `PROJ-05` | 项目、成员、邀请、审批、任务摘要、协作流转。 |
| Asset & Share | `ASSET-01` ~ `ASSET-03`, `SHARE-01` ~ `SHARE-02` | 项目资产、配额、分享链接和分享文件管理。 |
| Audit | `AUDIT-01` ~ `AUDIT-02` | 运行时动作审计同步、连接器审计查询。 |
| Assistant Gateway | `ASST-01` ~ `ASST-04` | 助理平台接入、回调、设备下发、结果回传。 |
| Automation | `AUTO-01` ~ `AUTO-03` | 自动化模板、项目自动化配置和触发。 |
| Billing Runtime | `BILL-02` ~ `BILL-05`, `WEBHOOK-02` | 积分余额、用量、记账、订单、发票、支付回调。 |
| Memory & Feedback | `MEM-01` ~ `MEM-02`, `FB-01` ~ `FB-02` | 云记忆设置和 CRUD、反馈和附件。 |
| Webhook Runtime | `WEBHOOK-01` | 第三方回调验签、去重、队列化。 |

## 5. 通用 API 合约

| 项 | 约定 |
| --- | --- |
| API 前缀 | `/api/v1` |
| 传输 | HTTPS |
| 鉴权 | `Authorization: Bearer <accessToken>` |
| 设备头 | `X-Device-Id: dev_xxx` |
| 幂等 | 写接口支持 `Idempotency-Key` |
| 分页 | `cursor`, `limit` |
| 时间 | ISO 8601 |
| 条件缓存 | `ETag`、`Last-Modified`、业务 `version` |

成功响应：

```json
{
  "data": {},
  "error": null,
  "requestId": "req_xxx"
}
```

错误响应：

```json
{
  "data": null,
  "error": {
    "code": "UNAUTHORIZED",
    "message": "access token expired",
    "details": {}
  },
  "requestId": "req_xxx"
}
```

错误码需要覆盖鉴权、权限、校验、冲突、频控、套餐权益、设备离线、连接器授权、第三方 provider 和内部错误。

## 6. 核心数据域

| 数据域 | 关键对象 |
| --- | --- |
| 身份和组织 | 用户、组织、成员关系、refresh token。 |
| 设备 | 设备注册、心跳、解绑和在线状态。 |
| 套餐和计费 | 套餐、积分流水、订单和发票。 |
| 运营配置 | 模型、专家、技能、灵感、连接器和自动化模板。 |
| 连接器和授权 | 连接器授权、云资料库授权和凭证引用。 |
| 项目协作 | 项目、成员、邀请、任务摘要、资产和任务流转。 |
| 助理平台 | 助理接入、消息下发和结果回传。 |
| 分享和反馈 | 分享文件、反馈和附件。 |
| 审计 | 项目、连接器、计费和安全相关审计。 |

基础技术栈已冻结。数据库表、字段、索引、唯一约束、外键、软删和阶段建表计划统一见 `database-design.md`。

## 7. 关键数据流

### 7.1 登录和设备注册

```text
设备端代理服务 -> /auth/login -> Auth Service
Auth Service -> token store -> accessToken / refreshToken
设备端代理服务 -> /devices/register -> Device Service
Device Service -> device record -> deviceId
```

关键约束：

- refresh token 必须可撤销、可轮换、可按设备失效。
- 登录后业务接口通过 access token 注入用户、组织和角色上下文。
- 设备在线状态由心跳维护。

### 7.2 动态配置缓存

```text
设备端代理服务 -> 目录类 GET 接口 -> Catalog Service
Catalog Service -> version / ETag / Last-Modified
设备端代理服务 -> 条件请求
AgentCloud -> 304 Not Modified 或新版本数据
```

适用范围包括模型、专家、技能、灵感、连接器、自动化模板和套餐。权限判断、购买和扣费前不得长期依赖陈旧缓存。

### 7.3 OAuth 和云资料库授权

```text
设备端代理服务 -> auth/start
AgentCloud -> authUrl / sessionId
第三方平台 -> auth/callback
AgentCloud -> 验 state / 换 token / 存凭证引用
设备端代理服务 -> 查询授权状态或生成引用载荷
```

关键约束：

- 回调必须验签或校验 `state`。
- 第三方 token 不返回明文。
- provider 错误统一映射为云端错误码。

### 7.4 项目任务下发和摘要同步

```text
项目成员 -> 创建项目任务
AgentCloud -> 校验项目权限和设备状态
AgentCloud -> 下发目标设备或返回 DEVICE_OFFLINE
设备端代理服务 -> 本地执行
设备端代理服务 -> 同步任务摘要 / 资产 / 分享 / 审计
```

AgentCloud 保存协作事实和摘要，不保存完整本地执行轨迹。

### 7.5 Webhook 异步处理

```text
第三方平台 -> Webhook Endpoint
API Edge -> 签名校验 / eventId 去重
Webhook Runtime -> 原始事件摘要落库
Queue -> Worker
Worker -> OAuth / 助理 / 支付等业务处理
```

Webhook 必须快速返回，重活进入队列，重复事件不得重复处理。

### 7.6 计费闭环

```text
购买 -> checkout/packages -> 支付 provider
支付 provider -> payments/callbacks/{provider}
AgentCloud -> 验签 / 幂等 / 更新订单 / 发放权益
用量 -> usage/ledger -> CreditLedger
```

记账类写入必须依赖幂等键，避免重复扣费。

## 8. 横切机制

| 机制 | 要求 |
| --- | --- |
| 请求追踪 | 每个响应都有 `requestId`，日志和审计可关联。 |
| 鉴权 | 登录外接口默认校验 access token；回调接口走 provider 签名或 state 校验。 |
| 权限 | 所有项目、资产、分享、审计、连接器连接都按 user/org/project/scope 校验。 |
| 幂等 | 登录外写接口、支付、项目创建、资产上传、用量记账支持 `Idempotency-Key`。 |
| 条件缓存 | 动态配置支持 `ETag`、`Last-Modified`、`version` 和 `304 Not Modified`。 |
| 设备路由 | 下发任务前检查设备注册和在线状态；离线时返回 `DEVICE_OFFLINE` 或进入队列策略。 |
| 凭证安全 | refresh token 哈希存储；第三方 token 通过凭证引用管理。 |
| 审计 | 公共连接器、项目协作、计费、安全相关动作进入审计或日志。 |
| 限流 | 登录、刷新、回调、搜索、上传、支付相关接口需要频控。 |

## 9. 依赖和阶段架构

```text
P0 Core/Auth
  -> Plan/Account
  -> Device
  -> Model Entitlement
  -> P1 Catalog/Marketplace/Connector Directory
  -> P2 OAuth/Knowledge/Project/Asset/Share/Audit
  -> P3 Assistant/Automation/Billing Runtime/Feedback/Memory
```

关键依赖：

- 登录后功能依赖 `AUTH-01` 和 `AUTH-02`。
- 设备下发依赖 `DEV-01` 和 `DEV-02`。
- 套餐和权益限制依赖 `BILL-01`。
- Credits 余额、扣费和用量依赖 `BILL-02`。
- 第三方授权依赖 `CONN-02` 或 `KS-02`。
- 项目资产、项目任务、项目自动化依赖 `PROJ-01` 和 `PROJ-02`。

## 10. 安全边界

| 风险面 | 架构约束 |
| --- | --- |
| Electron 泄露远程 token | Electron 不保存远程 token，不直接调用 AgentCloud。 |
| 第三方 token 泄露 | AgentCloud 只暴露凭证引用或授权状态，不返回明文 token。 |
| 重复支付或扣费 | 支付回调和用量记账必须幂等。 |
| 越权访问项目资产 | 项目、成员、角色和资源 owner 必须参与权限判断。 |
| 伪造回调 | Webhook 必须验签、校验 state，并做事件 ID 去重。 |
| 离线设备任务丢失 | 下发前检查设备状态，离线返回或进入明确队列策略。 |
| 运营配置污染 | 下架、禁用、版本号和缓存失效由云端控制。 |

## 11. 测试和验收策略

| 类型 | 覆盖 |
| --- | --- |
| 合约测试 | 通用响应、错误码、分页、鉴权、幂等、条件缓存。 |
| 权限测试 | 账号、组织、项目、成员、角色、资源 owner、连接器 scope。 |
| Webhook 测试 | 验签、重复事件、非法事件、异步处理、失败重试。 |
| 设备联调 | 登录、刷新、注册、心跳、目录拉取、任务下发、离线处理。 |
| 计费测试 | 套餐展示、余额、用量、订单、支付回调、重复回调。 |
| 资产测试 | 上传、配额、下载、删除、分享链接过期和取消分享。 |
| 审计测试 | 项目动作、连接器动作、计费和安全事件可查询。 |

## 12. 后续阶段设计入口

以下设计不阻塞 P0，但进入对应阶段前必须按文档执行：

| 事项 | 阶段 | 文档 |
| --- | --- | --- |
| Webhook 和 Worker 队列 | P1 | `webhook-queue-design.md` |
| 第三方 Provider 集成 | P1 起 | `provider-integration-design.md` |
| 对象存储和分享文件 | P2 | `object-storage-design.md` |
| 计费和支付闭环 | P3 | `billing-payment-design.md` |
| 助理消息下发 | P3 | `assistant-dispatch-design.md` |

仍未进入当前迭代的内容包括分库分表、运营后台高级权限、复杂财务后台和生产级 CDN 策略。
