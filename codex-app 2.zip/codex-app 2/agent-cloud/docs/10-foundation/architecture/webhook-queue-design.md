# Webhook 和 Worker 队列设计

整理日期：2026-06-23

适用阶段：P1 起

## 1. 定位

本文收口 AgentCloud Webhook 快速返回、验签、事件去重、后台处理和重试策略。P1 首版不引入额外队列基础设施，优先复用 PostgreSQL `webhook_events` 表和 worker 轮询；后续吞吐量不足时再替换为专用队列。

## 2. 处理流程

```text
第三方平台 -> Webhook Endpoint
  -> 验签 / state 校验
  -> event_id 去重
  -> webhook_events 落库
  -> 快速返回 2xx
  -> Worker 轮询 pending 事件
  -> 业务处理 / 重试 / 标记失败
```

## 3. 状态模型

| 状态 | 含义 |
| --- | --- |
| `received` | 已接收并落库。 |
| `processing` | Worker 正在处理。 |
| `succeeded` | 处理成功。 |
| `retrying` | 处理失败，等待重试。 |
| `failed` | 超过最大重试或不可恢复错误。 |
| `ignored` | 重复事件或无需处理事件。 |

## 4. 幂等和去重

- `provider + event_id` 必须唯一。
- 相同事件重复到达时返回成功，但不重复执行业务动作。
- 支付、OAuth、助理消息必须在各自业务表内再次做幂等保护。

## 5. 重试规则

- Worker 使用指数退避，最小 30 秒，最大 30 分钟。
- 默认最多重试 10 次。
- 验签失败、state 不匹配、格式非法不重试。
- provider 暂时性错误可重试。

## 6. Worker 边界

- P1 Worker 只处理 Webhook 基础事件和连接器 OAuth 后续状态。
- P3 支付、助理和自动化可复用同一 worker 模型，但不得成为 P1 依赖。
- Webhook handler 不执行重任务。

## 7. 升级条件

只有出现以下情况才引入专用队列：

- PostgreSQL 轮询造成明显数据库压力。
- Webhook 峰值导致处理延迟超过业务 SLA。
- 需要跨服务分布式消费和严格并发控制。
