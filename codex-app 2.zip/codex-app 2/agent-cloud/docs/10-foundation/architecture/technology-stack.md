# AgentCloud 基础技术栈选型

整理日期：2026-06-23

状态：P0 开发前冻结

## 1. 选型结论

AgentCloud P0 及后续阶段统一采用以下基础技术栈：

```text
Go + Gin
PostgreSQL + GORM + goose
Redis + go-redis
JWT access token
Opaque refresh token
bcrypt password hashing
config.yaml + env secret override
slog structured logging
```

## 2. 固定技术栈

| 类别 | 选型 | 约束 |
| --- | --- | --- |
| 服务端语言 | Go | 后端服务统一使用 Go。 |
| Web 框架 | Gin | HTTP 路由、中间件和请求处理统一使用 Gin。 |
| 数据库 | PostgreSQL | 业务持久化统一使用 PostgreSQL。 |
| ORM | GORM | 业务数据访问统一使用 GORM。 |
| 数据库迁移 | goose | 数据库 schema 变更统一通过 goose migration 管理。 |
| 缓存 | Redis | 缓存、短期状态、限流或幂等辅助存储优先使用 Redis。 |
| Redis 客户端 | go-redis | Go 服务访问 Redis 统一使用 go-redis。 |
| Access Token | JWT | 短期访问令牌使用 JWT。 |
| Refresh Token | Opaque refresh token | 刷新令牌使用服务端可撤销、可轮换的 opaque token。 |
| 密码哈希 | bcrypt | 用户密码哈希统一使用 bcrypt。 |
| 配置管理 | `config.yaml` | 非敏感基础配置从 `config.yaml` 加载。 |
| 敏感配置 | 环境变量覆盖 secret | 密钥、密码、token secret 等敏感值必须通过环境变量覆盖，不写入仓库配置。 |
| 日志 | Go `slog` | 服务日志统一使用 Go 标准库 `slog` 的结构化日志。 |

## 3. 不允许替换的选型

| 不使用 | 原因 |
| --- | --- |
| Echo、Fiber、chi 等替代 Web 框架 | Web 框架已冻结为 Gin。 |
| MySQL、SQLite、MongoDB 等替代主数据库 | 主业务数据库已冻结为 PostgreSQL。 |
| Ent、sqlc、xorm、手写 SQL 作为主数据访问层 | ORM 已冻结为 GORM；个别复杂查询可在 GORM 边界内审慎使用 raw SQL。 |
| GORM `AutoMigrate` 作为正式 schema 管理方式 | 正式 schema 变更必须通过 goose migration。 |
| migrate、Atlas 等替代迁移工具 | 迁移工具已冻结为 goose。 |
| redigo 等替代 Redis 客户端 | Redis 客户端已冻结为 go-redis。 |
| Server-side session access token | Access token 已冻结为 JWT。 |
| JWT refresh token | Refresh token 已冻结为 opaque token。 |
| argon2、scrypt 作为默认密码哈希 | 密码哈希已冻结为 bcrypt。 |
| zap、logrus、zerolog 作为默认日志库 | 日志已冻结为 Go `slog`。 |

## 4. P0 工程落地约束

- P0 工程初始化必须包含 Go module、Gin HTTP server、`config.yaml` 加载、环境变量 secret 覆盖、`slog` 初始化、PostgreSQL 连接、Redis 连接和 goose migration 入口。
- P0 业务表必须由 goose migration 创建，不能依赖 GORM `AutoMigrate` 生成正式 schema。
- GORM model 必须跟 goose migration 保持一致；schema 以 migration 为准。
- 表结构、字段、索引、唯一约束、外键和软删策略统一见 `database-design.md`。
- 数据库创建脚本位于 `../../../db/migrations/`，执行说明见 `../../../db/README.md`。
- JWT access token 必须短期有效，刷新和撤销能力由 opaque refresh token 承担。
- refresh token 必须可撤销、可轮换，并能按设备失效。
- 密码只保存 bcrypt hash，不保存明文、可逆密文或弱 hash。
- `config.yaml` 可以保存非敏感默认值；数据库密码、JWT secret、refresh token secret、Redis 密码等敏感值必须通过环境变量提供或覆盖。
- 日志必须输出结构化字段；不得记录密码、refresh token、JWT 原文或第三方 token 明文。

## 5. 可后置但不改变基础选型的事项

| 事项 | 处理 |
| --- | --- |
| 表结构扩展细节 | 按 `database-design.md` 的阶段边界随 P0-P3 逐步落地。 |
| 对象存储供应商和 CDN | P2 按 `object-storage-design.md` 落地。 |
| 队列系统和 Worker 部署方式 | P1 按 `webhook-queue-design.md` 落地；P3 复用该模型扩展。 |
| 运营后台页面和权限细节 | 后续后台开发阶段再确定。 |
| 离线设备任务队列持久化策略 | P3 按 `assistant-dispatch-design.md` 的短 TTL 重试边界落地。 |
