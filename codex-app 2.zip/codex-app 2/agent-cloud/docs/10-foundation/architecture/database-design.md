# AgentCloud 数据库设计说明书

整理日期：2026-06-23

状态：P0 开发前数据库设计基线

## 1. 定位

本文是 AgentCloud 数据库表结构、字段、关系、索引和迁移边界的唯一收口文档。API 文档只描述接口入参和出参；产品、架构和阶段计划不再保留字段级数据库设计。

关联文档：

- `technology-stack.md`
- `technical-architecture.md`
- `../../20-delivery/iterations/01-agent-cloud-api-service/feature-plan.md`
- `../../30-release/cloud-api-spec.md`

## 2. 基础约定

| 项 | 约定 |
| --- | --- |
| 数据库 | PostgreSQL |
| 访问层 | GORM |
| 迁移工具 | goose |
| 表名 | 复数 snake_case，例如 `users`、`refresh_tokens` |
| 字段名 | snake_case |
| 主键 | `id uuid primary key` |
| 时间字段 | 默认包含 `created_at timestamptz not null`、`updated_at timestamptz not null` |
| 软删字段 | 需要恢复、隐藏或保留审计痕迹的业务资源使用 `deleted_at timestamptz null` |
| JSON 字段 | PostgreSQL `jsonb` |
| 金额 | 金额用 `numeric(12,2)`，积分/点数流水用 `bigint` |
| 状态字段 | 使用 `text not null`，具体枚举由业务层校验 |
| 外键 | 关键归属关系使用外键；跨阶段或外部 provider 引用用普通字段 |
| 唯一约束 | 账号、成员关系、收藏、授权连接、幂等键等必须用唯一约束保证 |

## 3. GORM 与 goose 边界

- goose migration 是 schema 的唯一来源。
- GORM model 必须匹配 goose migration，不得用 GORM `AutoMigrate` 作为正式 schema 管理方式。
- migration 文件负责建表、字段类型、索引、唯一约束、外键和软删字段。
- GORM tag 只用于映射和查询辅助，不承担 schema 事实来源。
- 修改字段、索引或约束时，必须先新增 goose migration，再同步 GORM model。
- P0 初始 migration 只创建 P0 必需表；P1/P2/P3 表随阶段进入时再创建。

## 4. 通用字段模板

大多数业务表使用以下基础字段：

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 主键 | primary key |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | 需要软删的表使用 |

事件、流水、日志类表默认不软删。授权、token、会话类表使用 `revoked_at`、`expires_at` 或状态字段表达生命周期。

## 5. P0 表设计

### 5.1 `users`

阶段：P0

用途：用户账号。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 用户 ID | primary key |
| `account` | `text` | 登录账号 | not null |
| `phone` | `text` | 手机号 | nullable |
| `email` | `text` | 邮箱 | nullable |
| `password_hash` | `text` | bcrypt 密码哈希 | not null |
| `display_name` | `text` | 展示名 | not null |
| `avatar_url` | `text` | 头像 URL | nullable |
| `status` | `text` | 用户状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `ux_users_account` unique (`account`)
- `ux_users_phone` unique (`phone`) where `phone is not null`
- `ux_users_email` unique (`email`) where `email is not null`
- `idx_users_status` (`status`)

关系：

- 1:N `memberships`
- 1:N `devices`
- 1:N `refresh_tokens`

### 5.2 `orgs`

阶段：P0

用途：组织或团队。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 组织 ID | primary key |
| `name` | `text` | 组织名称 | not null |
| `plan_id` | `uuid` | 当前套餐 | nullable, fk `plans.id` |
| `status` | `text` | 组织状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `idx_orgs_plan_id` (`plan_id`)
- `idx_orgs_status` (`status`)

关系：

- 1:N `memberships`
- 1:N `devices`
- N:1 `plans`

### 5.3 `memberships`

阶段：P0

用途：用户与组织的成员关系。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 成员关系 ID | primary key |
| `user_id` | `uuid` | 用户 ID | not null, fk `users.id` |
| `org_id` | `uuid` | 组织 ID | not null, fk `orgs.id` |
| `role` | `text` | 组织角色 | not null |
| `status` | `text` | 成员状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `ux_memberships_user_org` unique (`user_id`, `org_id`) where `deleted_at is null`
- `idx_memberships_org_role` (`org_id`, `role`)

关系：

- N:1 `users`
- N:1 `orgs`

### 5.4 `refresh_tokens`

阶段：P0

用途：opaque refresh token 的服务端记录。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | token 记录 ID | primary key |
| `user_id` | `uuid` | 用户 ID | not null, fk `users.id` |
| `device_id` | `uuid` | 设备 ID | nullable, fk `devices.id` |
| `token_hash` | `text` | refresh token 哈希 | not null |
| `family_id` | `uuid` | token 轮换族 ID | not null |
| `expires_at` | `timestamptz` | 过期时间 | not null |
| `revoked_at` | `timestamptz` | 撤销时间 | nullable |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |

索引和约束：

- `ux_refresh_tokens_hash` unique (`token_hash`)
- `idx_refresh_tokens_user_id` (`user_id`)
- `idx_refresh_tokens_device_id` (`device_id`)
- `idx_refresh_tokens_family_id` (`family_id`)
- `idx_refresh_tokens_expires_at` (`expires_at`)

关系：

- N:1 `users`
- N:1 `devices`

### 5.5 `devices`

阶段：P0

用途：设备端代理服务注册记录。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 设备 ID | primary key |
| `user_id` | `uuid` | 归属用户 | not null, fk `users.id` |
| `org_id` | `uuid` | 当前组织 | not null, fk `orgs.id` |
| `name` | `text` | 设备名称 | not null |
| `platform` | `text` | 设备平台 | not null |
| `app_version` | `text` | 桌面应用版本 | nullable |
| `local_agent_version` | `text` | 设备端代理版本 | nullable |
| `local_endpoint_version` | `text` | 本地端点版本 | nullable |
| `status` | `text` | 在线或解绑状态 | not null |
| `last_seen_at` | `timestamptz` | 最近心跳时间 | nullable |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `idx_devices_user_id` (`user_id`)
- `idx_devices_org_id` (`org_id`)
- `idx_devices_status_last_seen` (`status`, `last_seen_at`)

关系：

- N:1 `users`
- N:1 `orgs`
- 1:N `refresh_tokens`
- 1:N `project_tasks`

### 5.6 `plans`

阶段：P0

用途：套餐展示和权益基础配置。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 套餐 ID | primary key |
| `code` | `text` | 套餐编码 | not null |
| `name` | `text` | 套餐名称 | not null |
| `audience` | `text` | 个人或企业 | not null |
| `price` | `numeric(12,2)` | 展示价格 | not null |
| `currency` | `text` | 币种 | not null |
| `features` | `jsonb` | 功能列表 | not null |
| `limits` | `jsonb` | 限额配置 | not null |
| `version` | `text` | 配置版本 | not null |
| `status` | `text` | 套餐状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `ux_plans_code` unique (`code`)
- `idx_plans_audience_status` (`audience`, `status`)
- `idx_plans_version` (`version`)

关系：

- 1:N `orgs`
- 1:N `model_entitlements`

### 5.7 `model_providers`

阶段：P0

用途：模型供应商预设。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 供应商 ID | primary key |
| `code` | `text` | 供应商编码 | not null |
| `name` | `text` | 供应商名称 | not null |
| `regions` | `jsonb` | 支持区域 | not null |
| `capabilities` | `jsonb` | 能力标签 | not null |
| `version` | `text` | 配置版本 | not null |
| `status` | `text` | 状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `ux_model_providers_code` unique (`code`)
- `idx_model_providers_status` (`status`)

关系：

- 1:N `model_catalog_items`

### 5.8 `model_catalog_items`

阶段：P0

用途：内置模型目录。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 模型目录项 ID | primary key |
| `provider_id` | `uuid` | 供应商 ID | not null, fk `model_providers.id` |
| `model_name` | `text` | 模型名称 | not null |
| `display_name` | `text` | 展示名 | not null |
| `capabilities` | `jsonb` | 模型能力 | not null |
| `regions` | `jsonb` | 可用区域 | not null |
| `plan_rules` | `jsonb` | 套餐可见规则 | not null |
| `version` | `text` | 配置版本 | not null |
| `status` | `text` | 状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `ux_model_catalog_provider_model` unique (`provider_id`, `model_name`) where `deleted_at is null`
- `idx_model_catalog_status_version` (`status`, `version`)

关系：

- N:1 `model_providers`
- 1:N `model_entitlements`

### 5.9 `model_entitlements`

阶段：P0

用途：账号、组织或套餐的模型权益。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 权益 ID | primary key |
| `scope_type` | `text` | 权益范围类型 | not null |
| `scope_id` | `uuid` | 范围对象 ID | not null |
| `plan_id` | `uuid` | 套餐 ID | nullable, fk `plans.id` |
| `model_id` | `uuid` | 模型 ID | not null, fk `model_catalog_items.id` |
| `limits` | `jsonb` | 权益限制 | not null |
| `version` | `text` | 配置版本 | not null |
| `status` | `text` | 状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `ux_model_entitlements_scope_model` unique (`scope_type`, `scope_id`, `model_id`) where `deleted_at is null`
- `idx_model_entitlements_plan_id` (`plan_id`)

关系：

- N:1 `plans`
- N:1 `model_catalog_items`

### 5.10 `idempotency_keys`

阶段：P0

用途：写接口幂等。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 幂等记录 ID | primary key |
| `scope` | `text` | 幂等范围 | not null |
| `key` | `text` | 幂等键 | not null |
| `request_hash` | `text` | 请求摘要 | not null |
| `response_status` | `integer` | 响应状态码 | nullable |
| `response_body` | `jsonb` | 响应摘要 | nullable |
| `expires_at` | `timestamptz` | 过期时间 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |

索引和约束：

- `ux_idempotency_scope_key` unique (`scope`, `key`)
- `idx_idempotency_expires_at` (`expires_at`)

关系：

- 无强外键。

## 6. P1 表设计

### 6.1 `webhook_events`

阶段：P1

用途：第三方回调事件验签、去重和异步处理记录。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 事件 ID | primary key |
| `provider` | `text` | 第三方 provider | not null |
| `event_id` | `text` | provider 事件 ID | not null |
| `event_type` | `text` | 事件类型 | not null |
| `payload` | `jsonb` | 原始事件摘要 | not null |
| `status` | `text` | 处理状态 | not null |
| `processed_at` | `timestamptz` | 处理完成时间 | nullable |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |

索引和约束：

- `ux_webhook_events_provider_event` unique (`provider`, `event_id`)
- `idx_webhook_events_status_created` (`status`, `created_at`)

关系：

- 无强外键。

### 6.2 `expert_categories`

阶段：P1

用途：专家分类。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 分类 ID | primary key |
| `code` | `text` | 分类编码 | not null |
| `name` | `text` | 分类名 | not null |
| `sort_order` | `integer` | 排序 | not null default 0 |
| `version` | `text` | 配置版本 | not null |
| `status` | `text` | 状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `ux_expert_categories_code` unique (`code`)
- `idx_expert_categories_status_sort` (`status`, `sort_order`)

关系：

- 1:N `experts`

### 6.3 `experts`

阶段：P1

用途：运营专家。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 专家 ID | primary key |
| `category_id` | `uuid` | 专家分类 | nullable, fk `expert_categories.id` |
| `name` | `text` | 专家名 | not null |
| `description` | `text` | 描述 | nullable |
| `prompt_snapshot` | `jsonb` | prompt 策略快照 | not null |
| `skill_ids` | `jsonb` | 关联技能 ID 列表 | not null |
| `connector_policy` | `jsonb` | 连接器策略 | not null |
| `version` | `text` | 版本 | not null |
| `status` | `text` | 状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `idx_experts_category_status` (`category_id`, `status`)
- `idx_experts_version` (`version`)

关系：

- N:1 `expert_categories`
- N:M `expert_teams` through `expert_team_members`

### 6.4 `expert_teams`

阶段：P1

用途：专家团。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 专家团 ID | primary key |
| `name` | `text` | 专家团名 | not null |
| `description` | `text` | 描述 | nullable |
| `workflow` | `jsonb` | workflow 定义 | not null |
| `version` | `text` | 版本 | not null |
| `status` | `text` | 状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `idx_expert_teams_status_version` (`status`, `version`)

关系：

- N:M `experts` through `expert_team_members`

### 6.5 `expert_team_members`

阶段：P1

用途：专家团成员。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 成员 ID | primary key |
| `team_id` | `uuid` | 专家团 ID | not null, fk `expert_teams.id` |
| `expert_id` | `uuid` | 专家 ID | not null, fk `experts.id` |
| `role` | `text` | 成员角色 | nullable |
| `sort_order` | `integer` | 排序 | not null default 0 |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |

索引和约束：

- `ux_expert_team_members_team_expert` unique (`team_id`, `expert_id`)
- `idx_expert_team_members_team_sort` (`team_id`, `sort_order`)

关系：

- N:1 `expert_teams`
- N:1 `experts`

### 6.6 `skill_categories`

阶段：P1

用途：技能市场分类。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 分类 ID | primary key |
| `code` | `text` | 分类编码 | not null |
| `name` | `text` | 分类名 | not null |
| `sort_order` | `integer` | 排序 | not null default 0 |
| `version` | `text` | 配置版本 | not null |
| `status` | `text` | 状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `ux_skill_categories_code` unique (`code`)
- `idx_skill_categories_status_sort` (`status`, `sort_order`)

关系：

- 1:N `skills`

### 6.7 `skills`

阶段：P1

用途：市场技能。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 技能 ID | primary key |
| `category_id` | `uuid` | 分类 ID | nullable, fk `skill_categories.id` |
| `name` | `text` | 技能名 | not null |
| `description` | `text` | 描述 | nullable |
| `permissions` | `jsonb` | 权限声明 | not null |
| `risk` | `jsonb` | 风险元数据 | not null |
| `latest_version` | `text` | 最新版本 | not null |
| `status` | `text` | 状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `idx_skills_category_status` (`category_id`, `status`)
- `idx_skills_name` (`name`)

关系：

- N:1 `skill_categories`
- 1:N `skill_versions`

### 6.8 `skill_versions`

阶段：P1

用途：技能安装包版本和下载元数据。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 技能版本 ID | primary key |
| `skill_id` | `uuid` | 技能 ID | not null, fk `skills.id` |
| `version` | `text` | 版本号 | not null |
| `package_key` | `text` | 安装包存储 key | not null |
| `checksum` | `text` | 安装包校验值 | not null |
| `status` | `text` | 状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |

索引和约束：

- `ux_skill_versions_skill_version` unique (`skill_id`, `version`)
- `idx_skill_versions_status` (`status`)

关系：

- N:1 `skills`

### 6.9 `inspiration_categories`

阶段：P1

用途：灵感分类。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 分类 ID | primary key |
| `code` | `text` | 分类编码 | not null |
| `name` | `text` | 分类名 | not null |
| `sort_order` | `integer` | 排序 | not null default 0 |
| `version` | `text` | 配置版本 | not null |
| `status` | `text` | 状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `ux_inspiration_categories_code` unique (`code`)
- `idx_inspiration_categories_status_sort` (`status`, `sort_order`)

关系：

- 1:N `inspirations`

### 6.10 `inspirations`

阶段：P1

用途：灵感案例。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 灵感 ID | primary key |
| `category_id` | `uuid` | 分类 ID | nullable, fk `inspiration_categories.id` |
| `title` | `text` | 标题 | not null |
| `description` | `text` | 描述 | nullable |
| `prompt_template` | `jsonb` | prompt 模板 | not null |
| `skill_ids` | `jsonb` | 技能引用 | not null |
| `expert_ids` | `jsonb` | 专家引用 | not null |
| `featured` | `boolean` | 是否精选 | not null default false |
| `status` | `text` | 状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `idx_inspirations_category_status` (`category_id`, `status`)
- `idx_inspirations_featured` (`featured`)

关系：

- N:1 `inspiration_categories`
- 1:N `inspiration_favorites`

### 6.11 `inspiration_favorites`

阶段：P1

用途：用户收藏灵感。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 收藏 ID | primary key |
| `user_id` | `uuid` | 用户 ID | not null, fk `users.id` |
| `inspiration_id` | `uuid` | 灵感 ID | not null, fk `inspirations.id` |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |

索引和约束：

- `ux_inspiration_favorites_user_inspiration` unique (`user_id`, `inspiration_id`)
- `idx_inspiration_favorites_user_id` (`user_id`)

关系：

- N:1 `users`
- N:1 `inspirations`

### 6.12 `connectors`

阶段：P1

用途：连接器目录。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 连接器 ID | primary key |
| `code` | `text` | 连接器编码 | not null |
| `name` | `text` | 连接器名称 | not null |
| `category` | `text` | 分类 | nullable |
| `auth_methods` | `jsonb` | 授权方式 | not null |
| `scopes` | `jsonb` | scope 配置 | not null |
| `version` | `text` | 配置版本 | not null |
| `status` | `text` | 状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `ux_connectors_code` unique (`code`)
- `idx_connectors_category_status` (`category`, `status`)

关系：

- 1:N `connector_auth_sessions`
- 1:N `connector_connections`

### 6.13 `connector_auth_sessions`

阶段：P1

用途：OAuth 授权会话。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 授权会话 ID | primary key |
| `connector_id` | `uuid` | 连接器 ID | not null, fk `connectors.id` |
| `user_id` | `uuid` | 用户 ID | not null, fk `users.id` |
| `project_id` | `uuid` | 项目 ID | nullable |
| `state_hash` | `text` | OAuth state 哈希 | not null |
| `scopes` | `jsonb` | 请求 scope | not null |
| `status` | `text` | 会话状态 | not null |
| `expires_at` | `timestamptz` | 过期时间 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |

索引和约束：

- `ux_connector_auth_sessions_state_hash` unique (`state_hash`)
- `idx_connector_auth_sessions_user_id` (`user_id`)
- `idx_connector_auth_sessions_expires_at` (`expires_at`)

关系：

- N:1 `connectors`
- N:1 `users`

### 6.14 `connector_connections`

阶段：P1

用途：连接器授权状态和凭证引用。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 授权连接 ID | primary key |
| `connector_id` | `uuid` | 连接器 ID | not null, fk `connectors.id` |
| `scope_type` | `text` | 授权范围类型 | not null |
| `user_id` | `uuid` | 用户 ID | nullable, fk `users.id` |
| `project_id` | `uuid` | 项目 ID | nullable |
| `token_ref` | `text` | 第三方 token 引用 | not null |
| `scopes` | `jsonb` | 已授权 scope | not null |
| `status` | `text` | 授权状态 | not null |
| `expires_at` | `timestamptz` | provider token 过期时间 | nullable |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `ux_connector_connections_scope` unique (`connector_id`, `scope_type`, `user_id`, `project_id`) where `deleted_at is null`
- `idx_connector_connections_user_id` (`user_id`)
- `idx_connector_connections_project_id` (`project_id`)

关系：

- N:1 `connectors`
- N:1 `users`
- P2 后 `project_id` 可关联 `projects.id`

## 7. P2 表设计

### 7.1 `knowledge_source_bindings`

阶段：P2

用途：云资料库授权绑定。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 绑定 ID | primary key |
| `provider` | `text` | 资料库 provider | not null |
| `user_id` | `uuid` | 用户 ID | not null, fk `users.id` |
| `token_ref` | `text` | token 引用 | not null |
| `status` | `text` | 授权状态 | not null |
| `expires_at` | `timestamptz` | 过期时间 | nullable |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `ux_knowledge_source_bindings_user_provider` unique (`user_id`, `provider`) where `deleted_at is null`
- `idx_knowledge_source_bindings_status` (`status`)

关系：

- N:1 `users`

### 7.2 `projects`

阶段：P2

用途：项目协作主体。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 项目 ID | primary key |
| `org_id` | `uuid` | 组织 ID | not null, fk `orgs.id` |
| `name` | `text` | 项目名称 | not null |
| `instructions` | `text` | 项目说明 | nullable |
| `status` | `text` | 项目状态 | not null |
| `created_by` | `uuid` | 创建人 | not null, fk `users.id` |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `idx_projects_org_status` (`org_id`, `status`)
- `idx_projects_created_by` (`created_by`)

关系：

- N:1 `orgs`
- 1:N `project_members`
- 1:N `project_tasks`
- 1:N `project_assets`

### 7.3 `project_members`

阶段：P2

用途：项目成员和权限。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 项目成员 ID | primary key |
| `project_id` | `uuid` | 项目 ID | not null, fk `projects.id` |
| `user_id` | `uuid` | 用户 ID | not null, fk `users.id` |
| `role` | `text` | 项目角色 | not null |
| `status` | `text` | 成员状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `ux_project_members_project_user` unique (`project_id`, `user_id`) where `deleted_at is null`
- `idx_project_members_user_id` (`user_id`)

关系：

- N:1 `projects`
- N:1 `users`

### 7.4 `project_invites`

阶段：P2

用途：项目邀请。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 邀请 ID | primary key |
| `project_id` | `uuid` | 项目 ID | not null, fk `projects.id` |
| `inviter_id` | `uuid` | 邀请人 | not null, fk `users.id` |
| `invitee_account` | `text` | 被邀请账号 | nullable |
| `role` | `text` | 邀请角色 | not null |
| `token_hash` | `text` | 邀请 token 哈希 | not null |
| `status` | `text` | 邀请状态 | not null |
| `expires_at` | `timestamptz` | 过期时间 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |

索引和约束：

- `ux_project_invites_token_hash` unique (`token_hash`)
- `idx_project_invites_project_status` (`project_id`, `status`)

关系：

- N:1 `projects`
- N:1 `users`

### 7.5 `project_join_requests`

阶段：P2

用途：项目加入申请和审批。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 申请 ID | primary key |
| `project_id` | `uuid` | 项目 ID | not null, fk `projects.id` |
| `user_id` | `uuid` | 申请人 | not null, fk `users.id` |
| `status` | `text` | 审批状态 | not null |
| `reviewer_id` | `uuid` | 审批人 | nullable, fk `users.id` |
| `reviewed_at` | `timestamptz` | 审批时间 | nullable |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |

索引和约束：

- `ux_project_join_requests_open` unique (`project_id`, `user_id`, `status`)
- `idx_project_join_requests_project_status` (`project_id`, `status`)

关系：

- N:1 `projects`
- N:1 `users`

### 7.6 `project_tasks`

阶段：P2

用途：项目任务摘要和设备下发状态。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 项目任务 ID | primary key |
| `project_id` | `uuid` | 项目 ID | not null, fk `projects.id` |
| `local_task_id` | `text` | 设备端本地任务 ID | nullable |
| `device_id` | `uuid` | 目标设备 | nullable, fk `devices.id` |
| `creator_id` | `uuid` | 创建人 | not null, fk `users.id` |
| `status` | `text` | 任务状态 | not null |
| `summary` | `jsonb` | 任务摘要 | nullable |
| `dispatch` | `jsonb` | 下发状态 | nullable |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `idx_project_tasks_project_status` (`project_id`, `status`)
- `idx_project_tasks_device_id` (`device_id`)
- `idx_project_tasks_local_task_id` (`local_task_id`)

关系：

- N:1 `projects`
- N:1 `devices`
- N:1 `users`

### 7.7 `project_templates`

阶段：P2

用途：项目模板。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 模板 ID | primary key |
| `name` | `text` | 模板名称 | not null |
| `description` | `text` | 描述 | nullable |
| `instructions` | `text` | 默认项目说明 | nullable |
| `metadata` | `jsonb` | 模板元数据 | nullable |
| `version` | `text` | 配置版本 | not null |
| `status` | `text` | 状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `idx_project_templates_status_version` (`status`, `version`)

关系：

- 无强外键。

### 7.8 `project_activities`

阶段：P2

用途：项目活动流。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 活动 ID | primary key |
| `project_id` | `uuid` | 项目 ID | not null, fk `projects.id` |
| `actor_id` | `uuid` | 操作人 | nullable, fk `users.id` |
| `activity_type` | `text` | 活动类型 | not null |
| `resource_type` | `text` | 资源类型 | nullable |
| `resource_id` | `uuid` | 资源 ID | nullable |
| `metadata` | `jsonb` | 附加信息 | nullable |
| `created_at` | `timestamptz` | 创建时间 | not null |

索引和约束：

- `idx_project_activities_project_created` (`project_id`, `created_at`)
- `idx_project_activities_actor_created` (`actor_id`, `created_at`)

关系：

- N:1 `projects`
- N:1 `users`

### 7.9 `task_collaborators`

阶段：P2

用途：项目任务协作者。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 协作者 ID | primary key |
| `task_id` | `uuid` | 任务 ID | not null, fk `project_tasks.id` |
| `user_id` | `uuid` | 用户 ID | not null, fk `users.id` |
| `role` | `text` | 协作角色 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |

索引和约束：

- `ux_task_collaborators_task_user` unique (`task_id`, `user_id`)
- `idx_task_collaborators_user_id` (`user_id`)

关系：

- N:1 `project_tasks`
- N:1 `users`

### 7.10 `task_handoffs`

阶段：P2

用途：任务流转。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | handoff ID | primary key |
| `task_id` | `uuid` | 任务 ID | not null, fk `project_tasks.id` |
| `from_user_id` | `uuid` | 发起人 | not null, fk `users.id` |
| `to_user_id` | `uuid` | 接收人 | not null, fk `users.id` |
| `target_project_id` | `uuid` | 目标项目 | nullable, fk `projects.id` |
| `status` | `text` | 流转状态 | not null |
| `accepted_at` | `timestamptz` | 接收时间 | nullable |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |

索引和约束：

- `idx_task_handoffs_task_id` (`task_id`)
- `idx_task_handoffs_to_user_status` (`to_user_id`, `status`)

关系：

- N:1 `project_tasks`
- N:1 `users`
- N:1 `projects`

### 7.11 `project_assets`

阶段：P2

用途：项目资产元数据。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 资产 ID | primary key |
| `project_id` | `uuid` | 项目 ID | not null, fk `projects.id` |
| `name` | `text` | 资产名称 | not null |
| `file_type` | `text` | 文件类型 | not null |
| `storage_key` | `text` | 对象存储 key | not null |
| `size_bytes` | `bigint` | 文件大小 | not null |
| `owner_id` | `uuid` | 上传人 | not null, fk `users.id` |
| `status` | `text` | 资产状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `idx_project_assets_project_id` (`project_id`)
- `idx_project_assets_owner_id` (`owner_id`)
- `idx_project_assets_storage_key` (`storage_key`)

关系：

- N:1 `projects`
- N:1 `users`

### 7.12 `shared_files`

阶段：P2

用途：公网分享文件。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 分享 ID | primary key |
| `owner_id` | `uuid` | 所有人 | not null, fk `users.id` |
| `asset_id` | `uuid` | 项目资产 | nullable, fk `project_assets.id` |
| `storage_key` | `text` | 对象存储 key | not null |
| `url` | `text` | 分享 URL | not null |
| `access_scope` | `text` | 访问范围 | not null |
| `expires_at` | `timestamptz` | 过期时间 | nullable |
| `status` | `text` | 分享状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `idx_shared_files_owner_id` (`owner_id`)
- `idx_shared_files_asset_id` (`asset_id`)
- `idx_shared_files_expires_at` (`expires_at`)

关系：

- N:1 `users`
- N:1 `project_assets`

### 7.13 `audit_logs`

阶段：P2

用途：协作、连接器、计费和安全审计。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 审计 ID | primary key |
| `org_id` | `uuid` | 组织 ID | nullable, fk `orgs.id` |
| `project_id` | `uuid` | 项目 ID | nullable, fk `projects.id` |
| `actor_id` | `uuid` | 操作人 | nullable, fk `users.id` |
| `action` | `text` | 动作 | not null |
| `resource_type` | `text` | 资源类型 | not null |
| `resource_id` | `uuid` | 资源 ID | nullable |
| `result` | `text` | 操作结果 | not null |
| `metadata` | `jsonb` | 附加信息 | nullable |
| `created_at` | `timestamptz` | 创建时间 | not null |

索引和约束：

- `idx_audit_logs_org_created` (`org_id`, `created_at`)
- `idx_audit_logs_project_created` (`project_id`, `created_at`)
- `idx_audit_logs_actor_created` (`actor_id`, `created_at`)

关系：

- N:1 `orgs`
- N:1 `projects`
- N:1 `users`

## 8. P3 表设计

### 8.1 `assistant_integrations`

阶段：P3

用途：助理平台接入。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 接入 ID | primary key |
| `platform` | `text` | 平台 | not null |
| `org_id` | `uuid` | 组织 ID | not null, fk `orgs.id` |
| `device_id` | `uuid` | 默认设备 | nullable, fk `devices.id` |
| `credential_ref` | `text` | 平台凭据引用 | not null |
| `webhook_url` | `text` | 回调地址 | not null |
| `status` | `text` | 状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `ux_assistant_integrations_org_platform` unique (`org_id`, `platform`) where `deleted_at is null`
- `idx_assistant_integrations_device_id` (`device_id`)

关系：

- N:1 `orgs`
- N:1 `devices`

### 8.2 `assistant_dispatches`

阶段：P3

用途：助理消息下发和结果回传状态。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 下发 ID | primary key |
| `integration_id` | `uuid` | 助理接入 ID | not null, fk `assistant_integrations.id` |
| `device_id` | `uuid` | 目标设备 | nullable, fk `devices.id` |
| `platform` | `text` | 平台 | not null |
| `message` | `jsonb` | 归一化消息 | not null |
| `status` | `text` | 下发状态 | not null |
| `reply` | `jsonb` | 回传结果 | nullable |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |

索引和约束：

- `idx_assistant_dispatches_integration_created` (`integration_id`, `created_at`)
- `idx_assistant_dispatches_device_status` (`device_id`, `status`)

关系：

- N:1 `assistant_integrations`
- N:1 `devices`

### 8.3 `automation_templates`

阶段：P3

用途：自动化模板。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 模板 ID | primary key |
| `scene` | `text` | 场景 | not null |
| `name` | `text` | 模板名 | not null |
| `prompt_template` | `jsonb` | prompt 模板 | not null |
| `schedule_preset` | `jsonb` | 调度预设 | not null |
| `version` | `text` | 配置版本 | not null |
| `status` | `text` | 状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `idx_automation_templates_scene_status` (`scene`, `status`)
- `idx_automation_templates_version` (`version`)

关系：

- 1:N `project_automations`

### 8.4 `project_automations`

阶段：P3

用途：项目级自动化配置。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 自动化 ID | primary key |
| `project_id` | `uuid` | 项目 ID | not null, fk `projects.id` |
| `template_id` | `uuid` | 模板 ID | nullable, fk `automation_templates.id` |
| `device_id` | `uuid` | 目标设备 | nullable, fk `devices.id` |
| `name` | `text` | 自动化名称 | not null |
| `prompt` | `text` | 任务提示 | not null |
| `schedule` | `jsonb` | 调度配置 | not null |
| `connector_ids` | `jsonb` | 连接器引用 | nullable |
| `status` | `text` | 状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `idx_project_automations_project_status` (`project_id`, `status`)
- `idx_project_automations_device_id` (`device_id`)

关系：

- N:1 `projects`
- N:1 `automation_templates`
- N:1 `devices`

### 8.5 `credit_ledgers`

阶段：P3

用途：积分余额和用量流水。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 流水 ID | primary key |
| `user_id` | `uuid` | 用户 ID | nullable, fk `users.id` |
| `org_id` | `uuid` | 组织 ID | nullable, fk `orgs.id` |
| `amount` | `bigint` | 积分变化值 | not null |
| `reason` | `text` | 变动原因 | not null |
| `task_id` | `uuid` | 关联任务 | nullable |
| `idempotency_key` | `text` | 记账幂等键 | not null |
| `metadata` | `jsonb` | 附加信息 | nullable |
| `created_at` | `timestamptz` | 创建时间 | not null |

索引和约束：

- `ux_credit_ledgers_idempotency_key` unique (`idempotency_key`)
- `idx_credit_ledgers_user_created` (`user_id`, `created_at`)
- `idx_credit_ledgers_org_created` (`org_id`, `created_at`)

关系：

- N:1 `users`
- N:1 `orgs`

### 8.6 `orders`

阶段：P3

用途：套餐购买订单。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 订单 ID | primary key |
| `user_id` | `uuid` | 用户 ID | not null, fk `users.id` |
| `org_id` | `uuid` | 组织 ID | nullable, fk `orgs.id` |
| `plan_id` | `uuid` | 套餐 ID | not null, fk `plans.id` |
| `provider` | `text` | 支付 provider | not null |
| `provider_order_id` | `text` | provider 订单 ID | nullable |
| `amount` | `numeric(12,2)` | 金额 | not null |
| `currency` | `text` | 币种 | not null |
| `status` | `text` | 订单状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |

索引和约束：

- `ux_orders_provider_order` unique (`provider`, `provider_order_id`) where `provider_order_id is not null`
- `idx_orders_user_created` (`user_id`, `created_at`)
- `idx_orders_status` (`status`)

关系：

- N:1 `users`
- N:1 `orgs`
- N:1 `plans`

### 8.7 `invoices`

阶段：P3

用途：发票入口。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 发票 ID | primary key |
| `order_id` | `uuid` | 订单 ID | not null, fk `orders.id` |
| `external_url` | `text` | 外部发票入口 | nullable |
| `status` | `text` | 发票状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |

索引和约束：

- `idx_invoices_order_id` (`order_id`)
- `idx_invoices_status` (`status`)

关系：

- N:1 `orders`

### 8.8 `memory_settings`

阶段：P3

用途：云记忆开关和作用范围。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 设置 ID | primary key |
| `scope_type` | `text` | 设置范围类型 | not null |
| `scope_id` | `uuid` | 范围对象 ID | not null |
| `enabled` | `boolean` | 是否启用 | not null default false |
| `settings` | `jsonb` | 详细设置 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |

索引和约束：

- `ux_memory_settings_scope` unique (`scope_type`, `scope_id`)

关系：

- 无强外键。

### 8.9 `memories`

阶段：P3

用途：云记忆。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 记忆 ID | primary key |
| `user_id` | `uuid` | 用户 ID | not null, fk `users.id` |
| `org_id` | `uuid` | 组织 ID | nullable, fk `orgs.id` |
| `content` | `text` | 记忆内容 | not null |
| `metadata` | `jsonb` | 附加信息 | nullable |
| `status` | `text` | 状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |
| `deleted_at` | `timestamptz` | 软删除时间 | nullable |

索引和约束：

- `idx_memories_user_created` (`user_id`, `created_at`)
- `idx_memories_org_id` (`org_id`)

关系：

- N:1 `users`
- N:1 `orgs`

### 8.10 `feedback`

阶段：P3

用途：用户反馈。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 反馈 ID | primary key |
| `user_id` | `uuid` | 用户 ID | not null, fk `users.id` |
| `content` | `text` | 反馈内容 | not null |
| `status` | `text` | 状态 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |
| `updated_at` | `timestamptz` | 更新时间 | not null |

索引和约束：

- `idx_feedback_user_created` (`user_id`, `created_at`)
- `idx_feedback_status` (`status`)

关系：

- N:1 `users`
- 1:N `feedback_attachments`

### 8.11 `feedback_attachments`

阶段：P3

用途：反馈附件。

| 字段 | 类型 | 含义 | 约束 |
| --- | --- | --- | --- |
| `id` | `uuid` | 附件 ID | primary key |
| `feedback_id` | `uuid` | 反馈 ID | not null, fk `feedback.id` |
| `storage_key` | `text` | 对象存储 key | not null |
| `file_name` | `text` | 文件名 | not null |
| `file_size` | `bigint` | 文件大小 | not null |
| `content_type` | `text` | 内容类型 | not null |
| `created_at` | `timestamptz` | 创建时间 | not null |

索引和约束：

- `idx_feedback_attachments_feedback_id` (`feedback_id`)

关系：

- N:1 `feedback`

## 9. 关系总览

| 关系 | 说明 |
| --- | --- |
| `users` -> `memberships` -> `orgs` | 用户通过成员关系进入组织。 |
| `orgs.plan_id` -> `plans.id` | 组织绑定当前套餐。 |
| `users` -> `devices` | 用户注册多个设备。 |
| `devices` -> `project_tasks` | 项目任务可下发到指定设备。 |
| `plans` -> `model_entitlements` -> `model_catalog_items` | 套餐和模型权益关系。 |
| `connectors` -> `connector_auth_sessions` / `connector_connections` | 连接器目录到授权会话和授权连接。 |
| `projects` -> `project_members` / `project_tasks` / `project_assets` | 项目协作核心关系。 |
| `projects` -> `project_activities` | 项目关键操作形成活动流。 |
| `project_tasks` -> `task_collaborators` / `task_handoffs` | 任务协作者和流转关系。 |
| `project_assets` -> `shared_files` | 项目资产可生成公网分享。 |
| `assistant_integrations` -> `assistant_dispatches` | 助理平台消息下发和回传状态。 |
| `orders` -> `invoices` | 订单对应发票入口。 |
| `feedback` -> `feedback_attachments` | 反馈对应附件。 |

## 10. 阶段对应关系

| 阶段 | 表 |
| --- | --- |
| P0 | `users`, `orgs`, `memberships`, `refresh_tokens`, `devices`, `plans`, `model_providers`, `model_catalog_items`, `model_entitlements`, `idempotency_keys` |
| P1 | `webhook_events`, `expert_categories`, `experts`, `expert_teams`, `expert_team_members`, `skill_categories`, `skills`, `skill_versions`, `inspiration_categories`, `inspirations`, `inspiration_favorites`, `connectors`, `connector_auth_sessions`, `connector_connections` |
| P2 | `knowledge_source_bindings`, `projects`, `project_members`, `project_invites`, `project_join_requests`, `project_tasks`, `project_templates`, `project_activities`, `task_collaborators`, `task_handoffs`, `project_assets`, `shared_files`, `audit_logs` |
| P3 | `assistant_integrations`, `assistant_dispatches`, `automation_templates`, `project_automations`, `credit_ledgers`, `orders`, `invoices`, `memory_settings`, `memories`, `feedback`, `feedback_attachments` |

## 11. migration 拆分建议

实际数据库创建脚本位于 `../../../db/migrations/`，执行说明见 `../../../db/README.md`。

| 阶段 | migration 建议 |
| --- | --- |
| P0 | `../../../db/migrations/00001_p0_core_identity_device_model.sql` |
| P1 | `../../../db/migrations/00010_p1_marketplace_connector_webhook.sql` |
| P2 | `../../../db/migrations/00020_p2_collaboration_asset_audit.sql` |
| P3 | `../../../db/migrations/00030_p3_assistant_billing_feedback.sql` |

编号用于 goose `up-to` 阶段执行：P0 到 `1`，P1 到 `10`，P2 到 `20`，P3 到 `30`。
