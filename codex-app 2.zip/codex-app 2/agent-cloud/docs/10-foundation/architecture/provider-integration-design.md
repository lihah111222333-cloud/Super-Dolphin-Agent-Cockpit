# 第三方 Provider 集成设计

整理日期：2026-06-23

适用阶段：P1 起

## 1. 定位

本文收口连接器、云资料库、支付和助理平台的 provider 集成边界。AgentCloud 保存授权状态和凭证引用，不向设备端或 Electron 返回第三方 token 明文。

## 2. Provider 分类

| 类型 | 阶段 | 示例能力 |
| --- | --- | --- |
| Connector provider | P1 | OAuth、授权状态、连通测试。 |
| Knowledge provider | P2 | 空间列表、文件搜索、引用载荷、产物回写。 |
| Payment provider | P3 | 支付会话、支付回调、发票入口。 |
| Assistant provider | P3 | 消息回调、消息发送、附件回传。 |

## 3. OAuth 规则

- 授权会话必须包含 `state`、过期时间和发起用户。
- 回调必须校验 `state`。
- token 保存为凭证引用，业务表只保存 `credential_ref`。
- 解除绑定必须撤销或失效本地凭证引用。

## 4. 错误映射

| Provider 错误 | AgentCloud 错误码 |
| --- | --- |
| 未授权或授权过期 | `CONNECTOR_AUTH_REQUIRED` |
| 权限不足 | `FORBIDDEN` |
| 资源不存在 | `NOT_FOUND` |
| 限流 | `RATE_LIMITED` |
| provider 不可用 | `PROVIDER_ERROR` |

## 5. 安全约束

- 日志不记录第三方 token、authorization code、refresh token。
- provider 原始响应只保存必要摘要。
- 所有外部回调必须验签或校验 state。
- provider 调用必须有超时和错误映射。

## 6. 阶段边界

- P1 只实现连接器目录、OAuth 和授权状态。
- P2 实现云资料库搜索、引用和回写。
- P3 实现支付和助理平台 provider。
