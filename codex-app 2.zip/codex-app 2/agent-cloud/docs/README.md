# agent-cloud docs 入口

本目录按“入口 -> 基础事实 -> 交付推进 -> 发布材料 -> 归档”的生命周期组织。开发人员先读 `00-start/`，再按自己的任务进入对应目录。

## 先看这里

| 问题 | 文档 |
| --- | --- |
| AI 从 0 进入项目先读什么？ | `00-start/ai-project-context.md` |
| 当前项目做到哪一步？ | `00-start/current-status.md` |
| 新开发者应该按什么顺序读？ | `00-start/reading-guide.md` |
| 文档应该放在哪里？ | `00-start/doc-governance.md` |
| 本地和飞书云盘如何对应？ | `00-start/feishu-drive-mapping.md` |

## 推荐阅读顺序

```text
1. 00-start/ai-project-context.md
2. 00-start/current-status.md
3. 00-start/reading-guide.md
4. 10-foundation/product/agent-cloud-product-spec.md
5. 10-foundation/architecture/technical-architecture.md
6. 10-foundation/architecture/technology-stack.md
7. 10-foundation/architecture/database-design.md
8. 20-delivery/execution/execution-spec.md
9. 20-delivery/execution/engineering-bootstrap-spec.md
10. 20-delivery/execution/local-dev-runbook.md
11. 20-delivery/iterations/01-agent-cloud-api-service/master-plan.md
12. 20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/goal.md
13. 20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/task-plan.md
14. 20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/api-contract.md
15. 20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/acceptance-checklist.md
16. 30-release/cloud-api-spec.md
```

## 按诉求定位

| 我要做什么 | 看哪里 |
| --- | --- |
| AI 从 0 加载项目上下文 | `00-start/ai-project-context.md` |
| 判断当前阶段和下一步门禁 | `00-start/current-status.md` |
| 快速接手项目 | `00-start/reading-guide.md` |
| 确认 AgentCloud 产品范围和非目标 | `10-foundation/product/agent-cloud-product-spec.md` |
| 理解云端 API 服务架构和模块边界 | `10-foundation/architecture/technical-architecture.md` |
| 查看业务架构图和技术架构图 | `10-foundation/architecture/agent-cloud-architecture-diagrams.drawio` |
| 确认基础技术栈和禁止替换项 | `10-foundation/architecture/technology-stack.md` |
| 确认数据库表结构、索引和迁移边界 | `10-foundation/architecture/database-design.md` |
| 执行数据库创建脚本 | `../db/README.md` |
| 开始 P0-P3 阶段开发 | `20-delivery/iterations/01-agent-cloud-api-service/master-plan.md` |
| 查功能 ID 和排期清单 | `20-delivery/iterations/01-agent-cloud-api-service/feature-plan.md` |
| 查 P0 阶段目标、边界和验收要点 | `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/goal.md` |
| 查 P0 任务拆分 | `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/task-plan.md` |
| 查 P0 API 合约细则 | `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/api-contract.md` |
| 查 P0 验收清单 | `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/acceptance-checklist.md` |
| 查工程启动和配置规则 | `20-delivery/execution/engineering-bootstrap-spec.md` |
| 查本地开发启动步骤 | `20-delivery/execution/local-dev-runbook.md` |
| 查 seed 数据执行规则 | `20-delivery/execution/seed-data-spec.md` |
| 查开发执行、测试和阶段推进约束 | `20-delivery/execution/execution-spec.md` |
| 查开发团队规范 | `20-delivery/execution/team-development-standards.md` |
| 查云端 REST API 规格 | `30-release/cloud-api-spec.md` |
| 查发布就绪检查 | `30-release/release-readiness-checklist.md` |
| 查 Webhook / Worker 设计 | `10-foundation/architecture/webhook-queue-design.md` |
| 查对象存储设计 | `10-foundation/architecture/object-storage-design.md` |
| 查第三方 Provider 集成设计 | `10-foundation/architecture/provider-integration-design.md` |
| 查计费支付设计 | `10-foundation/architecture/billing-payment-design.md` |
| 查助理消息下发设计 | `10-foundation/architecture/assistant-dispatch-design.md` |
| 查历史材料 | `99-archive/` |

## 事实源优先级

| 事实类型 | 以哪个文档为准 |
| --- | --- |
| 产品范围和非目标 | `10-foundation/product/agent-cloud-product-spec.md` |
| 技术架构和层级边界 | `10-foundation/architecture/technical-architecture.md` |
| 架构图源文件 | `10-foundation/architecture/agent-cloud-architecture-diagrams.drawio` |
| 基础技术栈 | `10-foundation/architecture/technology-stack.md` |
| 数据库表、字段、索引和 migration 边界 | `10-foundation/architecture/database-design.md` |
| 阶段治理和门禁 | `20-delivery/iterations/01-agent-cloud-api-service/master-plan.md` |
| 功能 ID、排期和依赖 | `20-delivery/iterations/01-agent-cloud-api-service/feature-plan.md` |
| P0 阶段目标、边界和验收要点 | `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/goal.md` |
| P0 任务拆分 | `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/task-plan.md` |
| P0 API 合约细则 | `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/api-contract.md` |
| P0 验收证据清单 | `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/acceptance-checklist.md` |
| 本地开发和 seed 执行 | `20-delivery/execution/local-dev-runbook.md`、`20-delivery/execution/seed-data-spec.md` |
| REST API 发布总览 | `30-release/cloud-api-spec.md` |
| 发布就绪检查 | `30-release/release-readiness-checklist.md` |

## 阶段文档

| 阶段 | 文档 |
| --- | --- |
| 总规划 | `20-delivery/iterations/01-agent-cloud-api-service/master-plan.md` |
| P0 | `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/goal.md`、`20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/task-plan.md`、`20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/api-contract.md`、`20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/acceptance-checklist.md` |
| P1 | `20-delivery/iterations/01-agent-cloud-api-service/p1-marketplace-connector-webhook/goal.md` |
| P2 | `20-delivery/iterations/01-agent-cloud-api-service/p2-collaboration-asset-audit/goal.md` |
| P3 | `20-delivery/iterations/01-agent-cloud-api-service/p3-platform-billing-feedback/goal.md` |

## 一级目录

| 目录 | 放置内容 |
| --- | --- |
| `00-start/` | 当前状态、阅读路径、文档治理、飞书映射。 |
| `10-foundation/` | 长期有效的产品、架构、协议事实。 |
| `20-delivery/` | 开发执行规格、迭代计划、阶段目标、验收材料。 |
| `30-release/` | API reference、compatibility、changelog、release note。 |
| `99-archive/` | 已过期但需要追溯的历史文档。 |

## 责任边界速记

| 层级 | 责任 |
| --- | --- |
| Electron | 桌面 UI 和用户交互，不保存远程 `accessToken` 或 `refreshToken`，不直接调用 AgentCloud。 |
| 设备端代理服务 | AgentCloud 的主要调用方，负责保存远程 token、注册设备、代理云端能力和执行本地 Agent 能力。 |
| AgentCloud | 云端远程 API 服务，负责账号、设备、运营配置、协作、第三方回调、计费、分享、反馈和跨设备同步。 |
| 第三方平台 | 通过 OAuth、助理消息、支付等公网回调接入 AgentCloud。 |
| 云后台管理端 | 管理模型、专家、技能、灵感、连接器、套餐和模板等运营配置。 |
| 云端 Worker | 处理 Webhook 异步任务、消息派发、回调重试、计费记账和索引维护。 |

## 维护规则

- 新文件先按 `00-start/doc-governance.md` 的放置规则落位，不在 `docs/` 根目录平铺。
- 文档正文过长时拆到对应生命周期目录，`README.md` 只保留导航。
- 飞书云盘目录或文件 token 变化后，同步更新 `00-start/feishu-drive-mapping.md`。
