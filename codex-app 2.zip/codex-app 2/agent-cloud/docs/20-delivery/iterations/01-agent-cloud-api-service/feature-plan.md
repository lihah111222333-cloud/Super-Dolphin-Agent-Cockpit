# 云后端远程 API 服务功能清单与排期拆分

整理日期：2026-06-23

依据文件：`../../../30-release/cloud-api-spec.md`

定位：本文是云后端远程 API 服务的进度管理清单，用于后续工作安排、任务拆分、排期和验收。本文按产品功能域拆分，颗粒度控制在“一个后端工作包可以独立开发和验收”的级别。数据库表、字段、索引和约束统一见 `../../../10-foundation/architecture/database-design.md`。

## 0. 阶段定义

| 阶段 | 目标 | 进入下一阶段条件 |
| --- | --- | --- |
| P0 | 云后端可登录、可识别账号和设备、可返回基础动态配置 | 设备端可完成登录、刷新 token、注册设备、拉取账号/模型/套餐 |
| P1 | 运营配置和市场类能力可用 | 模型、专家、技能、灵感、连接器目录可缓存刷新 |
| P2 | 协作、授权、资产和审计闭环 | 项目协作、OAuth、云资料库、分享、审计可用 |
| P3 | 平台网关、自动化、计费和反馈完善 | 助理网关、项目自动化、计费闭环、反馈、云记忆可用 |

## 1. 主要依赖顺序

```text
P0 通用协议/鉴权
  -> 套餐展示
  -> 账号上下文
  -> 设备注册/心跳
  -> 模型目录/权益
  -> P1 专家/技能/灵感/连接器目录
  -> P2 OAuth/云资料库/项目协作/资产/分享/审计
  -> P3 助理网关/项目自动化/计费闭环/反馈/云记忆
```

约束：

- 所有需要登录的功能必须依赖 `AUTH-01` 和 `AUTH-02`。
- 所有按设备下发任务的功能必须依赖 `DEV-01` 和 `DEV-02`。
- 所有按套餐、权益限制的功能必须依赖 `BILL-01`；Credits 余额、扣费和用量功能必须依赖 `BILL-02`。
- 所有第三方授权能力必须依赖 `CONN-02` 或 `KS-02` 的 OAuth 会话能力。
- 项目资产、项目任务、项目自动化、项目级自定义连接器必须依赖 `PROJ-01` 项目基础和 `PROJ-02` 成员权限。

## 2. P0 基础能力

### 2.1 通用 API 平台

| ID | 功能项 | 功能说明 | 涉及 API | 实现要点 | 依赖 | 阶段 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| CORE-01 | 通用响应和错误码 | 统一 `data/error/requestId` 响应、分页、错误码 | 所有 API | 中间件生成 `requestId`；统一错误映射；分页统一 `cursor/limit` | 无 | P0 | 任意接口成功/失败响应格式一致；错误码覆盖鉴权、权限、校验、限流 |
| CORE-02 | 鉴权中间件 | 校验 `Authorization: Bearer <accessToken>` | 除登录/回调外所有 API | access token 解析、过期判断、用户上下文注入 | AUTH-01 | P0 | 未登录返回 `UNAUTHORIZED`；有效 token 可进入业务处理 |
| CORE-03 | 幂等机制 | 写接口支持 `Idempotency-Key` | 登录外写接口、支付、项目创建、资产上传 | 记录幂等请求并重复返回同结果 | CORE-01 | P0 | 同一 key 重放不会重复创建资源 |
| CORE-04 | 条件缓存响应 | 动态配置支持 `ETag` / `Last-Modified` / `version` | 模型、专家、技能、灵感、连接器、模板、套餐 | 为运营数据生成版本；支持 `304 Not Modified` | CORE-01 | P0 | 数据未变化时返回 304；变化后返回新版本 |

### 2.2 账号、登录、token

| ID | 功能项 | 功能说明 | 涉及 API | 实现要点 | 依赖 | 阶段 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| AUTH-01 | 账号登录 | 账号密码或手机号验证码登录，返回远程 token | `POST /auth/login` | 校验账号；生成短期 access token 和可轮换 refresh token | CORE-01 | P0 | 登录成功返回 `accessToken/refreshToken/user`；错误密码不可登录 |
| AUTH-02 | token 刷新 | access token 过期后刷新 | `POST /auth/refresh` | refresh token 服务端保存；支持轮换和撤销 | AUTH-01 | P0 | 旧 access 过期后可刷新；撤销 token 后刷新失败 |
| AUTH-03 | 退出登录 | 撤销 refresh token 和设备会话 | `POST /auth/logout` | 支持按设备或 refresh token 撤销 | AUTH-01 | P0 | 退出后原 refresh token 不可再刷新 |
| BILL-01 | 套餐展示 | 返回套餐和价格配置 | `GET /plans` | 运营版本化；短缓存 TTL | CORE-04 | P0 | 返回个人/企业套餐；价格变化有新版本 |
| AUTH-04 | 当前账号上下文 | 返回用户、组织、套餐、角色 | `GET /account/me` | 聚合账号、组织、成员和套餐上下文 | AUTH-01, BILL-01 | P0 | 返回当前用户所属组织、角色、套餐；无权限返回 403 |

### 2.3 设备

| ID | 功能项 | 功能说明 | 涉及 API | 实现要点 | 依赖 | 阶段 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| DEV-01 | 设备注册 | 注册设备端代理服务，生成 `deviceId` | `POST /devices/register` | 绑定用户和组织；保存设备基础信息 | AUTH-01 | P0 | 同账号可注册多设备；返回稳定 `deviceId` |
| DEV-02 | 设备心跳 | 更新设备在线状态和版本 | `PATCH /devices/{deviceId}/heartbeat` | 更新设备在线状态和本地端点能力 | DEV-01 | P0 | 心跳后设备状态为在线；超时设备可判定离线 |
| DEV-03 | 设备列表和解绑 | 查询、解绑账号下设备 | `GET /devices`, `DELETE /devices/{deviceId}` | 权限校验；解绑后阻止下发任务 | DEV-01 | P0 | 只能查看/解绑自己的设备；解绑设备不再可用 |

### 2.4 模型和权益

| ID | 功能项 | 功能说明 | 涉及 API | 实现要点 | 依赖 | 阶段 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| MODEL-01 | 内置模型目录 | 返回动态模型清单 | `GET /models/built-in` | 支持地区、版本、套餐过滤；返回 `version` | CORE-04, AUTH-01 | P0 | 不同套餐可见模型不同；支持 304 |
| MODEL-02 | 模型供应商预设 | 返回供应商、base 能力、区域 | `GET /models/providers` | 运营配置化；不要硬编码到设备端 | CORE-04 | P0 | 返回供应商列表和能力标签 |
| MODEL-03 | 模型权益 | 返回当前账号可用模型和限制 | `GET /models/entitlements` | 合并套餐、组织和灰度权限 | AUTH-04, BILL-01 | P0 | 权益变化后接口结果同步变化 |

## 3. P1 运营配置和市场能力

### 3.1 Webhook 基础设施

| ID | 功能项 | 功能说明 | 涉及 API | 实现要点 | 依赖 | 阶段 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| WEBHOOK-01 | 回调基础设施 | 第三方回调验签、去重、队列化 | OAuth/助理/支付回调 | 原始事件记录、签名验证、幂等 eventId | CORE-03 | P1 | 重复事件不重复处理；非法签名拒绝 |

### 3.2 专家中心

| ID | 功能项 | 功能说明 | 涉及 API | 实现要点 | 依赖 | 阶段 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| EXP-01 | 专家分类 | 返回专家中心分类 | `GET /experts/categories` | 运营配置；支持版本缓存 | CORE-04 | P1 | 分类可新增/禁用；客户端可 304 |
| EXP-02 | 专家列表和搜索 | 按分类、关键词分页查询专家 | `GET /experts` | 支持 `category/q/cursor`；过滤禁用专家 | EXP-01 | P1 | 可分页；下架专家不再返回 |
| EXP-03 | 专家详情快照 | 返回专家 prompt 策略、技能和连接器策略 | `GET /experts/{expertId}` | 详情带 `version`，供调用方固化快照 | EXP-02, SKILL-01, CONN-01 | P1 | 详情包含 prompt、skillIds、connectorPolicy |
| EXP-04 | 专家团列表和详情 | 返回专家团成员和 workflow | `GET /expert-teams`, `GET /expert-teams/{teamId}` | 专家团引用专家版本；支持下架 | EXP-03 | P1 | 专家团详情可完整还原成员和流程 |

### 3.3 技能市场

| ID | 功能项 | 功能说明 | 涉及 API | 实现要点 | 依赖 | 阶段 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| SKILL-01 | 技能市场列表 | 技能搜索、分类、分页 | `GET /skills/marketplace` | 返回技能摘要、版本、状态、风险等级 | CORE-04, AUTH-01 | P1 | 可分页搜索；禁用技能不返回或标记不可用 |
| SKILL-02 | 技能详情 | 返回版本、权限、风险元数据 | `GET /skills/{skillId}` | 权限声明、风险报告、版本列表 | SKILL-01 | P1 | 详情足够调用方做安装前确认 |
| SKILL-03 | 安装包下载信息 | 返回临时下载地址和 checksum | `POST /skills/{skillId}/install-package` | 鉴权、权益校验、短期签名 URL | SKILL-02, BILL-01 | P1 | URL 过期失效；checksum 与包一致 |
| SKILL-04 | 智能找技能 | 根据任务描述返回技能匹配 | `POST /skills/find` | 可先用关键词/向量检索；不必首版上复杂推荐 | SKILL-01 | P1 | 输入任务描述返回相关技能和理由 |
| SKILL-05 | 生成技能草稿载荷 | 返回可由调用方保存的技能草稿 | `POST /skills/generate` | 生成 manifest 草稿；不在云端保存私有草稿 | SKILL-02 | P1 | 返回草稿结构；不会创建市场技能 |

### 3.4 灵感场景和案例

| ID | 功能项 | 功能说明 | 涉及 API | 实现要点 | 依赖 | 阶段 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| INSP-01 | 灵感分类 | 返回运营场景分类 | `GET /inspirations/categories` | 版本缓存；支持精选入口 | CORE-04 | P1 | 分类可运营更新；支持 304 |
| INSP-02 | 灵感列表 | 搜索、分类、精选案例 | `GET /inspirations` | 支持 `q/category/featured/cursor` | INSP-01 | P1 | 可分页；精选过滤有效 |
| INSP-03 | 灵感详情 | 返回 prompt 模板、技能和专家引用 | `GET /inspirations/{inspirationId}` | 详情应可生成任务草稿 | INSP-02, EXP-03, SKILL-02 | P1 | 详情包含 promptTemplate 和引用资源 |
| INSP-04 | 收藏灵感 | 收藏/取消收藏案例 | `POST/DELETE /inspirations/{id}/favorite` | 用户维度收藏幂等 | AUTH-01, INSP-02 | P1 | 重复收藏幂等；取消后列表状态变化 |
| INSP-05 | 制作同款载荷 | 生成任务草稿载荷 | `POST /inspirations/{id}/clone` | 合并 overrides；不执行任务 | INSP-03 | P1 | 返回可下发设备端的 `taskDraftPayload` |

### 3.5 连接器目录

| ID | 功能项 | 功能说明 | 涉及 API | 实现要点 | 依赖 | 阶段 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| CONN-01 | 连接器目录和详情 | 返回支持的连接器、授权方式、scope | `GET /connectors/catalog`, `GET /connectors/{id}` | 运营配置；支持版本缓存 | CORE-04 | P1 | 新增连接器无需发版；详情包含 authMethods/scopes |
| CONN-02 | OAuth 授权会话 | 发起 OAuth 并查询授权状态 | `POST /connectors/{id}/auth/start`, `GET /connectors/auth-sessions/{sessionId}` | 管理授权会话、防 CSRF 和过期策略 | AUTH-01, CONN-01 | P1 | 能生成 authUrl；session 过期后不可用 |
| CONN-03 | OAuth 回调 | 处理第三方 OAuth 回调 | `POST /connectors/{id}/auth/callback` | 验 state、换 token 并保存凭证引用 | CONN-02, WEBHOOK-01 | P1 | 回调成功后 connection 变为 connected |
| CONN-04 | 授权连接列表 | 查询个人/项目授权状态 | `GET /connector-connections` | 按 user/project/scope 过滤 | CONN-03 | P1 | 只返回当前用户有权查看的授权 |
| CONN-05 | 连接器连通测试 | 测试已授权连接器是否可用 | `POST /connectors/{id}/test` | 使用凭证引用发起最小可用性检查；不返回 token 明文 | CONN-03 | P1 | 未授权返回 `CONNECTOR_AUTH_REQUIRED`；可用连接返回 ok |

## 4. P2 协作、授权、资产和审计

### 4.1 云资料库

| ID | 功能项 | 功能说明 | 涉及 API | 实现要点 | 依赖 | 阶段 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| KS-01 | 资料库来源 | 返回已接入资料库 provider | `GET /knowledge-sources` | 配置 provider 能力、图标、授权状态 | AUTH-01 | P2 | 返回 provider 列表和绑定状态 |
| KS-02 | 资料库授权 | 发起/解除资料库授权 | `POST /knowledge-sources/{provider}/auth/start`, `DELETE /knowledge-sources/{provider}/binding` | OAuth 授权和凭证引用安全存储 | AUTH-01, WEBHOOK-01 | P2 | 授权后可查 spaces；解除后无法搜索 |
| KS-03 | 空间和文件搜索 | 查询空间、搜索文件、看文件详情 | `GET /knowledge-sources/{provider}/spaces`, `/files`, `/files/{fileId}` | provider 适配、分页、错误映射 | KS-02 | P2 | 可按关键词搜索；provider 错误映射为 `PROVIDER_ERROR` |
| KS-04 | 引用载荷生成 | 生成设备端可保存的引用载荷 | `POST /knowledge-sources/{provider}/files/{fileId}/references` | 生成可注入任务上下文的引用载荷 | KS-03, DEV-01 | P2 | 返回的载荷足够设备端注入任务上下文 |
| KS-05 | 产物回写 | 把产物保存到云资料库 | `POST /artifacts/{artifactId}/upload-to-cloud` | 通过 deviceId 定位产物来源；调用 provider 创建文件 | KS-02, SHARE-01 | P2 | 回写成功返回 externalFile；无授权返回 `CONNECTOR_AUTH_REQUIRED` |

### 4.2 项目协作

| ID | 功能项 | 功能说明 | 涉及 API | 实现要点 | 依赖 | 阶段 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| PROJ-01 | 项目 CRUD | 创建、查询、更新、删除/退出项目 | `GET/POST/PATCH/DELETE /projects` | 项目归属组织；基础状态管理 | AUTH-04 | P2 | 只有成员可查看；创建者默认 owner/admin |
| PROJ-02 | 项目成员和权限 | 成员列表、邀请、申请、审批 | `/projects/{id}/members`, `/invites`, `/project-invites/{id}/apply`, `/project-join-requests/{id}/approve|reject` | 角色权限、邀请过期和审批流程 | PROJ-01 | P2 | 非管理员不能审批；邀请链接过期失效 |
| PROJ-03 | 项目模板和动态 | 模板列表、项目活动流 | `GET /project-templates`, `GET /projects/{id}/activity` | 模板运营化；活动写入关键操作 | PROJ-01, CORE-04 | P2 | 创建/成员/资产/任务操作生成活动 |
| PROJ-04 | 项目任务摘要 | 创建项目任务、列表、同步摘要 | `POST /projects/{id}/tasks`, `GET /projects/{id}/tasks`, `PATCH /projects/{id}/tasks/{taskId}` | 云端不执行任务，只保存摘要和 dispatch 状态 | PROJ-01, DEV-02 | P2 | 离线设备返回 `DEVICE_OFFLINE`；摘要可更新 |
| PROJ-05 | 协作者和任务流转 | 分享任务、创建 handoff、接收流转 | `POST /tasks/{id}/collaborators`, `/tasks/{id}/handoffs`, `/handoffs/{id}/accept` | 权限校验、状态流转、通知事件 | PROJ-02, PROJ-04 | P2 | 被指派成员可接收；无权限不可访问 |

### 4.3 项目资产和分享

| ID | 功能项 | 功能说明 | 涉及 API | 实现要点 | 依赖 | 阶段 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ASSET-01 | 项目资产列表和上传 | 上传、查询项目资产 | `GET/POST /projects/{id}/assets` | 对象存储、配额和资产元数据管理 | PROJ-01, BILL-01 | P2 | 超配额拒绝；上传后列表可见 |
| ASSET-02 | 项目资产详情和删除 | 查看预览元数据、删除资产 | `GET/DELETE /projects/{id}/assets/{assetId}` | 权限和删除策略 | ASSET-01 | P2 | 无权限不可下载/删除；删除后列表不显示 |
| ASSET-03 | 项目资产配额 | 查询项目资产用量 | `GET /projects/{id}/assets/quota` | 聚合对象存储大小和套餐限制 | ASSET-01, BILL-01 | P2 | 返回 usedBytes/limitBytes 准确 |
| SHARE-01 | 公网分享 | 上传并生成分享链接 | `POST /artifacts/{artifactId}/share` | 存储文件、生成可过期 URL、访问范围 | AUTH-01, DEV-01 | P2 | 链接可访问；过期后不可访问 |
| SHARE-02 | 分享文件管理 | 列表、复制链接、下载、取消分享 | `GET /data/shared-files`, `POST /data/shared-files/{id}/copy-link`, `GET /data/shared-files/{id}/download`, `DELETE /data/shared-files/{id}` | owner 权限、链接刷新、取消访问 | SHARE-01 | P2 | 取消后原链接失效；只可管理自己的分享 |

### 4.4 审计

| ID | 功能项 | 功能说明 | 涉及 API | 实现要点 | 依赖 | 阶段 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| AUDIT-01 | 运行时动作审计同步 | 接收设备端上报的项目/公共连接器审计 | `POST /audit/runtime-actions` | 保存可查询的审计事实 | AUTH-01, PROJ-01 | P2 | 上报后能按项目查询；无项目权限不可写 |
| AUDIT-02 | 连接器审计查询 | 查询公共授权连接器审计日志 | `GET /projects/{id}/connector-audit-logs` | 按项目权限过滤和分页 | AUDIT-01, CONN-04 | P2 | 管理员可查；普通成员按策略限制 |
| AUDIT-03 | 授权连接审计查询 | 查询单个授权连接的审计日志 | `GET /connector-connections/{connectionId}/audit-logs` | 按 connection owner、project 和 scope 权限过滤 | AUDIT-01, CONN-04 | P2 | 只能查询自己或有项目权限的连接审计 |

### 4.5 项目级连接器扩展

| ID | 功能项 | 功能说明 | 涉及 API | 实现要点 | 依赖 | 阶段 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| CONN-06 | 项目级自定义连接器 | 创建、修改、删除项目级自定义连接器 | `POST /connectors/custom`, `PATCH /connectors/custom/{connectorId}`, `DELETE /connectors/custom/{connectorId}` | 绑定项目权限；配置变更写审计；不向 Electron 暴露任意 invoke | PROJ-01, PROJ-02, CONN-01 | P2 | 非项目管理员不可修改；删除后项目不可继续使用该连接器 |

## 5. P3 平台网关、自动化、计费闭环

### 5.1 助理与远程任务

| ID | 功能项 | 功能说明 | 涉及 API | 实现要点 | 依赖 | 阶段 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| ASST-01 | 助理平台接入 | 平台状态、注册、解绑 | `GET /assistant/integrations`, `POST /assistant/integrations/{platform}/register`, `DELETE /assistant/integrations/{platform}` | 平台凭据保存、webhookUrl 生成 | AUTH-04, DEV-01 | P3 | 注册后返回 webhookUrl；解绑后不再接收消息 |
| ASST-02 | 助理消息回调 | 接收第三方平台消息 | `POST /assistant/callbacks/{platform}` | 验签、去重、消息归一化、快速返回 | ASST-01, WEBHOOK-01 | P3 | 重复回调只处理一次；非法签名拒绝 |
| ASST-03 | 设备下发 | 将助理消息下发到目标设备 | `POST /assistant/dispatch` | 设备在线判断、dispatchId、重试队列 | ASST-02, DEV-02 | P3 | 在线设备可收到任务；离线返回或排队 |
| ASST-04 | 结果回传 | 设备端执行结果回传平台 | `POST /assistant/replies` | 平台发送适配、附件处理、失败重试 | ASST-03 | P3 | 回传成功后平台收到回复；失败有重试记录 |

### 5.2 自动化

| ID | 功能项 | 功能说明 | 涉及 API | 实现要点 | 依赖 | 阶段 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| AUTO-01 | 自动化模板 | 返回可运营更新的模板 | `GET /automation-templates` | scene 过滤、版本缓存 | CORE-04 | P3 | 模板更新后 version 变化；支持 304 |
| AUTO-02 | 项目自动化 CRUD | 项目级自动化列表、创建、编辑、删除 | `GET/POST/PATCH/DELETE /projects/{id}/automations` | schedule 配置、目标设备、权限 | PROJ-01, DEV-01 | P3 | 项目管理员可配置；普通成员受限 |
| AUTO-03 | 项目自动化触发 | 到点选择设备并下发项目任务 | 项目自动化内部 Worker，复用 `POST /projects/{id}/tasks` | 调度器、幂等触发、失败重试 | AUTO-02, PROJ-04 | P3 | 同一计划同一时间不会重复触发 |

### 5.3 计费、积分、订单、发票

| ID | 功能项 | 功能说明 | 涉及 API | 实现要点 | 依赖 | 阶段 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BILL-02 | 积分余额和用量 | 查询余额、套餐包、使用流水 | `GET /credits/balance`, `GET /credits/usage` | 余额聚合、分页、时间过滤 | AUTH-04, BILL-01 | P3 | 余额和流水一致；时间筛选有效 |
| BILL-03 | 用量记账 | 记录模型 token、Credits 消耗 | `POST /usage/ledger` | 服务端内部接口；幂等扣费；防重复记账 | BILL-02, CORE-03 | P3 | 同一 idempotency key 不重复扣费 |
| BILL-04 | 订单和购买 | 套餐包购买、订单列表 | `POST /checkout/packages`, `GET /orders` | 支付会话、订单状态、支付回调 | BILL-01, WEBHOOK-01 | P3 | 支付成功后订单状态更新并增加权益 |
| BILL-05 | 发票 | 查询发票和外部控制台链接 | `GET /invoices` | 对接支付/财务系统 | BILL-04 | P3 | 已支付订单可查询发票入口 |

### 5.4 云记忆、反馈、Webhook

| ID | 功能项 | 功能说明 | 涉及 API | 实现要点 | 依赖 | 阶段 | 验收标准 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| MEM-01 | 云记忆设置 | 开关云记忆和作用范围 | `GET/PATCH /memory/settings` | 默认关闭；按账号/组织保存 | AUTH-01 | P3 | 开关后 CRUD 行为按设置生效 |
| MEM-02 | 云记忆 CRUD 和检索 | 保存、编辑、删除、导入、搜索记忆 | `/memories`, `/memories/import`, `/memories/search` | 权限隔离；可先用普通全文检索 | MEM-01 | P3 | 只能访问自己的记忆；搜索能返回相关结果 |
| FB-01 | 反馈提交 | 提交反馈和脱敏日志 bundle | `POST /feedback` | 附件引用、状态流转 | AUTH-01 | P3 | 提交后生成 feedbackId；后台可查看 |
| FB-02 | 反馈附件 | 上传反馈附件 | `POST /feedback/{id}/attachments` | 文件大小限制、类型限制 | FB-01 | P3 | 超限拒绝；上传后附件关联反馈 |
| WEBHOOK-02 | 支付回调 | 支付成功/失败回调处理 | `POST /payments/callbacks/{provider}` | 验签、订单状态更新、权益发放 | BILL-04, WEBHOOK-01 | P3 | 支付成功后订单和权益一致 |

## 6. 排期使用建议

| 任务字段 | 建议填写 |
| --- | --- |
| 功能 ID | 使用本文 ID，例如 `AUTH-01` |
| 所属阶段 | P0 / P1 / P2 / P3 |
| 状态 | 未开始 / 开发中 / 联调中 / 已验收 / 暂缓 |
| 负责人 | 后端、平台、支付、第三方集成等 |
| 前置依赖 | 填本文依赖列中的 ID |
| 验收证据 | 接口测试、联调记录、回调日志、数据库记录、对象存储文件等 |

## 7. 最小可交付路线

1. 先做 `CORE-01`、`AUTH-01`、`AUTH-02`、`BILL-01`、`AUTH-04`。
2. 再做 `DEV-01`、`DEV-02`、`MODEL-01`、`MODEL-02`、`MODEL-03`，让设备端能进入主流程。
3. 再做 P1 运营配置：专家、技能、灵感、连接器目录。
4. 连接器 OAuth 和云资料库进入 P2，避免在账号和目录未稳定前做第三方授权。
5. 项目协作先做 `PROJ-01`、`PROJ-02`，再做任务摘要、资产、分享、审计和项目级自定义连接器。
6. 助理、自动化、支付闭环、云记忆放 P3，等设备、项目和权限模型稳定后再做。
