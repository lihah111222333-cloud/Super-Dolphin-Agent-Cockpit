# AgentCloud API Service P0-P3 总阶段规划

整理日期：2026-06-23

状态：当前有效总阶段规划

迭代目录：`docs/20-delivery/iterations/01-agent-cloud-api-service/`

上游依据：

- `../../../00-start/current-status.md`
- `../../../10-foundation/product/agent-cloud-product-spec.md`
- `../../../10-foundation/architecture/technical-architecture.md`
- `../../../10-foundation/architecture/technology-stack.md`
- `../../../10-foundation/architecture/database-design.md`
- `../../execution/execution-spec.md`
- `feature-plan.md`
- `../../../30-release/cloud-api-spec.md`
- `../../../../db/README.md`
- `../../execution/local-dev-runbook.md`
- `../../execution/seed-data-spec.md`

## 1. 规划目标

本文定义 AgentCloud API Service 从 P0 到 P3 的顺序开发阶段。它是本迭代的阶段治理文件，不替代 `feature-plan.md` 的功能清单，也不替代 API、数据库或架构说明。

本文各阶段“阶段内容”只列功能 ID 范围。真实功能项、涉及 API、依赖和验收标准以 `feature-plan.md` 对应阶段章节为准；阶段目标、边界和门禁以各阶段目录下的 `goal.md` 为准。

目标：

- 明确 P0 -> P1 -> P2 -> P3 的严格推进顺序。
- 明确每个阶段的目标、内容、边界、责任、依赖、交付物和验收方式。
- 防止后续阶段倒置为前置阶段依赖。
- 为后续拆分阶段任务提供统一边界。

## 2. 总体推进原则

- 阶段必须严格顺序推进，不做并行阶段假设。
- 当前阶段只能依赖已完成阶段的 API、表结构、配置和测试能力。
- 未进入当前阶段的接口不得用空实现、假实现或不可验证 stub 占位。
- 数据库按阶段执行 goose migration：P0 到 `1`，P1 到 `10`，P2 到 `20`，P3 到 `30`。
- API 合约、数据库表和功能 ID 发生变化时，必须同步更新对应事实源。
- AgentCloud 只做云端 API 服务，不直接服务 Electron，不执行本地 Agent 任务。

## 3. 总阶段视图

```text
P0 Core / Auth / Device / Model / Plan
  -> P1 Marketplace / Connector / Webhook
  -> P2 Collaboration / Asset / Audit
  -> P3 Platform / Billing / Feedback
```

| 阶段 | 阶段目标 | 最小可验证产物 | 数据库门禁 |
| --- | --- | --- | --- |
| P0 | 基础身份、设备、模型和套餐能力可用。 | 设备端可登录、刷新 token、注册设备、心跳、拉取账号/模型/套餐。 | `goose up-to 1` |
| P1 | 运营配置、市场目录、连接器和 Webhook 基础设施可用。 | 专家、技能、灵感、连接器目录可分页查询、版本缓存、授权状态可验证。 | `goose up-to 10` |
| P2 | 项目协作、资料库、资产、分享和审计闭环。 | 项目成员权限、任务摘要、资产分享、云资料库引用和审计可按权限验证。 | `goose up-to 20` |
| P3 | 助理网关、自动化、计费、反馈和云记忆完善。 | 助理下发回传、自动化触发、支付记账、反馈附件和云记忆可验证。 | `goose up-to 30` |

## 4. P0 基础能力

### 4.1 阶段目标

让设备端代理服务可以完成远程账号登录、refresh token 刷新、设备注册和心跳，并拉取账号上下文、模型目录、模型权益和套餐展示。

### 4.2 阶段内容

- `CORE-01` 到 `CORE-04`
- `AUTH-01` 到 `AUTH-04`
- `DEV-01` 到 `DEV-03`
- `MODEL-01` 到 `MODEL-03`
- `BILL-01`

真实阶段内容来源：

- 功能明细：`feature-plan.md` 的“2. P0 基础能力”
- 阶段目标和门禁：`p0-core-identity-device-model/goal.md`
- 任务拆分：`p0-core-identity-device-model/task-plan.md`
- P0 API 合约细则：`p0-core-identity-device-model/api-contract.md`
- P0 验收清单：`p0-core-identity-device-model/acceptance-checklist.md`

### 4.3 范围边界

允许：

- Go module、Gin server、配置加载、日志、PostgreSQL、Redis 和 goose 入口。
- P0 migration 和 P0 GORM model。
- P0 接口测试、鉴权测试、幂等测试、条件缓存测试。

禁止：

- 专家、技能、灵感、连接器目录。
- 项目协作、OAuth、云资料库、资产、分享、审计。
- 助理、自动化、支付闭环、反馈、云记忆。

### 4.4 责任归属

- 后端服务：P0 API、业务服务、数据库访问、测试。
- 数据库：P0 migration 和 seed 数据。
- 设备端联调：登录、刷新、设备注册、心跳和目录拉取。

### 4.5 前置依赖

- `technology-stack.md` 已冻结。
- `database-design.md` 和 P0 migration 已存在。
- `p0-core-identity-device-model/goal.md` 已明确 P0 目标和边界。
- `p0-core-identity-device-model/task-plan.md` 已明确 P0 任务拆分。
- `p0-core-identity-device-model/api-contract.md` 已明确 P0 API 合约细则。
- `p0-core-identity-device-model/acceptance-checklist.md` 已明确 P0 验收证据清单。

### 4.6 交付物

- 可启动的 AgentCloud Go HTTP 服务。
- P0 migration 可执行。
- P0 API 可通过接口和鉴权测试。
- P0 seed 数据可支持本地验收。
- P0 task-plan、api-contract 和 acceptance-checklist 对应内容完成。
- `p0-core-identity-device-model/goal.md` 中的验收方式全部通过。

### 4.7 验收方式

- 执行 `go test ./...`。
- 执行 P0 migration：`goose -dir db/migrations postgres "$DATABASE_URL" up-to 1`。
- 设备端或 HTTP 客户端完成登录、刷新、注册、心跳、账号、模型、套餐主流程。
- 验证 P0 未依赖 P1/P2/P3 表、接口或 worker。

## 5. P1 运营配置和市场能力

### 5.1 阶段目标

让专家、技能、灵感、连接器目录和 Webhook 基础设施可运营、可缓存、可验签、可去重。

### 5.2 阶段内容

- `WEBHOOK-01`
- `EXP-01` 到 `EXP-04`
- `SKILL-01` 到 `SKILL-05`
- `INSP-01` 到 `INSP-05`
- `CONN-01` 到 `CONN-05`

真实阶段内容来源：

- 功能明细：`feature-plan.md` 的“3. P1 运营配置和市场能力”
- 阶段目标和门禁：`p1-marketplace-connector-webhook/goal.md`
- Webhook / Worker 前置设计：`../../../10-foundation/architecture/webhook-queue-design.md`
- Provider 集成设计：`../../../10-foundation/architecture/provider-integration-design.md`

### 5.3 范围边界

允许：

- 运营配置目录、版本缓存、禁用/下架状态。
- 连接器 OAuth 会话、回调、授权状态和连通测试。
- Webhook 验签、去重、快速返回和后台处理入口。

禁止：

- 项目协作和项目级自定义连接器。
- 云资料库搜索、引用和产物回写。
- 支付闭环和助理平台完整消息流。

### 5.4 责任归属

- 后端服务：目录类 API、连接器授权、Webhook runtime。
- 平台集成：OAuth provider 参数、签名验证和回调格式。
- 测试：目录缓存、OAuth state、Webhook 去重和 token 不外泄。

### 5.5 前置依赖

- P0 已通过验收。
- `webhook-queue-design.md` 已确认 P1 Webhook 和 worker 策略。
- P1 migration 可执行到 `10`。

### 5.6 交付物

- P1 API 可用。
- Webhook 事件可记录、去重和异步处理。
- 连接器授权不返回第三方 token 明文。

### 5.7 验收方式

- 目录类接口支持分页、搜索、状态过滤、版本缓存和 304。
- OAuth session 具备 state、过期和状态查询。
- 重复 Webhook 不重复处理，非法签名拒绝。
- P1 不依赖 P2/P3 功能。

## 6. P2 协作、授权、资产和审计

### 6.1 阶段目标

形成项目协作、云资料库、项目资产、分享和审计闭环。

### 6.2 阶段内容

- `KS-01` 到 `KS-05`
- `PROJ-01` 到 `PROJ-05`
- `ASSET-01` 到 `ASSET-03`
- `SHARE-01` 到 `SHARE-02`
- `AUDIT-01` 到 `AUDIT-03`
- `CONN-06`

真实阶段内容来源：

- 功能明细：`feature-plan.md` 的“4. P2 协作、授权、资产和审计”
- 阶段目标和门禁：`p2-collaboration-asset-audit/goal.md`
- 对象存储设计：`../../../10-foundation/architecture/object-storage-design.md`
- Provider 集成设计：`../../../10-foundation/architecture/provider-integration-design.md`

### 6.3 范围边界

允许：

- 项目、成员、邀请、申请、审批、任务摘要。
- 云资料库授权、搜索、引用和产物回写。
- 项目资产、分享链接、连接器审计和运行时动作审计。
- 项目级自定义连接器配置。

禁止：

- 保存完整本地 Agent 执行轨迹。
- 把设备端文件树、diff、预览搬到云端。
- 绕过项目成员权限访问资产、任务或审计。

### 6.4 责任归属

- 后端服务：项目协作、资料库、资产、分享、审计。
- 存储集成：对象存储、签名 URL、配额统计。
- Provider 集成：资料库 OAuth、搜索和错误映射。

### 6.5 前置依赖

- P1 已通过验收。
- `object-storage-design.md` 和 `provider-integration-design.md` 已确认。
- P2 migration 可执行到 `20`。

### 6.6 交付物

- P2 API 可用。
- 项目权限和资源 owner 校验完整。
- 对象存储上传、分享和删除行为可验证。
- 审计记录可按权限查询。

### 6.7 验收方式

- 非成员无法访问项目、资产、任务和审计。
- 离线设备创建项目任务返回明确状态。
- 分享链接可过期、复制、下载和取消。
- 云资料库 provider 错误统一映射为 `PROVIDER_ERROR`。

## 7. P3 平台、计费、反馈和云记忆

### 7.1 阶段目标

完善助理平台网关、项目自动化、计费闭环、反馈和云记忆同步。

### 7.2 阶段内容

- `ASST-01` 到 `ASST-04`
- `AUTO-01` 到 `AUTO-03`
- `BILL-02` 到 `BILL-05`
- `MEM-01` 到 `MEM-02`
- `FB-01` 到 `FB-02`
- `WEBHOOK-02`

真实阶段内容来源：

- 功能明细：`feature-plan.md` 的“5. P3 平台网关、自动化、计费闭环”
- 阶段目标和门禁：`p3-platform-billing-feedback/goal.md`
- 计费支付设计：`../../../10-foundation/architecture/billing-payment-design.md`
- 助理消息下发设计：`../../../10-foundation/architecture/assistant-dispatch-design.md`

### 7.3 范围边界

允许：

- 助理平台接入、消息回调、设备下发和结果回传。
- 项目自动化配置和幂等触发。
- 积分、用量、订单、支付回调、发票入口。
- 反馈、附件、云记忆设置和 CRUD。

禁止：

- 支付和用量记账跳过幂等。
- 助理回调阻塞重任务。
- 云记忆突破账号、组织或项目权限边界。

### 7.4 责任归属

- 后端服务：助理、自动化、计费、反馈、记忆。
- 支付集成：订单、回调、权益发放、发票入口。
- Worker：异步下发、重试、记账和状态同步。

### 7.5 前置依赖

- P2 已通过验收。
- `billing-payment-design.md` 和 `assistant-dispatch-design.md` 已确认。
- P3 migration 可执行到 `30`。

### 7.6 交付物

- P3 API 可用。
- 助理消息可下发和回传。
- 支付回调和用量记账具备幂等闭环。
- 反馈和云记忆按权限隔离。

### 7.7 验收方式

- 重复支付回调不重复发放权益。
- 同一自动化计划同一触发时间不重复执行。
- 云记忆默认关闭，开启后只访问授权范围。
- 助理平台非法签名拒绝，重复消息去重。

## 8. 后续阶段计划拆分规则

- 只有当前阶段 `goal.md` 通过确认后，才拆该阶段任务计划。
- 任务必须绑定 `feature-plan.md` 中的功能 ID。
- 每个任务必须有开发产物、测试方式和验收证据。
- 不创建跨阶段任务；跨阶段依赖只允许指向已完成阶段。
- API、数据库、seed 和测试变更必须在同一阶段内闭环。

## 9. 总结

本迭代从 P0 开始推进。P0 是唯一当前可直接开发阶段；P1/P2/P3 只能在前置阶段验收后进入。`feature-plan.md` 保留为功能清单，本文负责阶段治理，阶段目录下的 `goal.md` 负责进入阶段前的目标和门禁。
