# P1 运营配置和市场能力阶段目标

整理日期：2026-06-23

阶段目录：`p1-marketplace-connector-webhook/`

上级规划：`../master-plan.md`

## 1. 计划目标

完成专家、技能、灵感、连接器目录和 Webhook 基础设施，让运营配置可查询、可缓存、可下架，并让第三方回调具备验签和去重入口。

## 2. 阶段内容

- `WEBHOOK-01`
- `EXP-01` 到 `EXP-04`
- `SKILL-01` 到 `SKILL-05`
- `INSP-01` 到 `INSP-05`
- `CONN-01` 到 `CONN-05`

## 3. 范围边界

允许：

- 目录类 API、分页、搜索、状态过滤、版本缓存和 304。
- 连接器 OAuth session、回调、授权状态和连通测试。
- Webhook 原始事件记录、签名校验、事件去重和 worker 处理入口。

禁止：

- 项目协作、项目级自定义连接器和资料库搜索。
- 资产、分享、审计闭环。
- 助理、自动化、支付和云记忆。

## 4. 责任归属

| 责任 | 内容 |
| --- | --- |
| 后端服务 | P1 API、Webhook runtime、连接器授权。 |
| 平台集成 | OAuth provider 参数、回调签名和错误映射。 |
| 运营配置 | 专家、技能、灵感、连接器数据维护。 |
| 测试 | 目录缓存、OAuth state、Webhook 去重和 token 不外泄。 |

## 5. 前置依赖

- P0 已通过验收。
- `../../../../10-foundation/architecture/webhook-queue-design.md`
- P1 migration 可执行到 `10`。

## 6. 交付物

- P1 API 可用。
- Webhook 验签、去重、快速返回和后台处理可验证。
- 第三方 token 不明文返回。

## 7. 验收方式

- 目录禁用/下架后不继续正常返回。
- 目录数据未变化时支持 304。
- OAuth session 过期后不可用。
- 重复 Webhook 只处理一次。

## 8. 下一阶段门禁

进入 P2 前必须满足：

- P1 功能 ID 全部完成并有测试证据。
- P1 未提前依赖项目、资产、分享或计费闭环。
- `object-storage-design.md` 和 `provider-integration-design.md` 已确认。
