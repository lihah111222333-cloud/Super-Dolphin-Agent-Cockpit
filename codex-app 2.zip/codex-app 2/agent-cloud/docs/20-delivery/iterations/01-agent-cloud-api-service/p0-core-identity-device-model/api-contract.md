# P0 API 合约细则

整理日期：2026-06-24

阶段目录：`p0-core-identity-device-model/`

上级规划：`../master-plan.md`

事实源：

- `../../../../30-release/cloud-api-spec.md`
- `../feature-plan.md`
- `goal.md`

## 1. 通用约定

API 前缀：`/api/v1`

成功响应：

```json
{
  "data": {},
  "error": null,
  "requestId": "req_xxx"
}
```

错误响应：

```json
{
  "data": null,
  "error": {
    "code": "VALIDATION_FAILED",
    "message": "invalid request",
    "details": {}
  },
  "requestId": "req_xxx"
}
```

通用规则：

- 登录和 refresh 外，接口默认校验 `Authorization: Bearer <accessToken>`。
- 设备相关接口校验 `X-Device-Id` 或路径中的 `deviceId` 是否属于当前用户。
- 写接口支持 `Idempotency-Key`；重复请求返回第一次结果。
- 目录类 GET 支持 `ETag`、`Last-Modified` 和 `If-None-Match`。
- 时间字段使用 ISO 8601。

## 2. P0 接口清单

| 功能 ID | 方法 | 路径 | 鉴权 | 幂等 | 条件缓存 |
| --- | --- | --- | --- | --- | --- |
| AUTH-01 | POST | `/auth/login` | 否 | 否 | 否 |
| AUTH-02 | POST | `/auth/refresh` | 否 | 否 | 否 |
| AUTH-03 | POST | `/auth/logout` | 是 | 是 | 否 |
| AUTH-04 | GET | `/account/me` | 是 | 否 | 否 |
| DEV-01 | POST | `/devices/register` | 是 | 是 | 否 |
| DEV-02 | PATCH | `/devices/{deviceId}/heartbeat` | 是 | 否 | 否 |
| DEV-03 | GET | `/devices` | 是 | 否 | 否 |
| DEV-03 | DELETE | `/devices/{deviceId}` | 是 | 是 | 否 |
| BILL-01 | GET | `/plans` | 否 | 否 | 是 |
| MODEL-01 | GET | `/models/built-in` | 是 | 否 | 是 |
| MODEL-02 | GET | `/models/providers` | 否 | 否 | 是 |
| MODEL-03 | GET | `/models/entitlements` | 是 | 否 | 是 |

## 3. Auth API

### 3.1 `POST /auth/login`

请求：

```json
{
  "account": "demo@example.com",
  "password": "password"
}
```

响应 `data`：

```json
{
  "accessToken": "jwt",
  "refreshToken": "opaque",
  "user": {
    "id": "uuid",
    "account": "demo@example.com",
    "displayName": "Demo User"
  }
}
```

校验：

- `account` 和 `password` 必填。
- 密码错误返回 `UNAUTHORIZED`，不暴露账号是否存在。

### 3.2 `POST /auth/refresh`

请求：

```json
{
  "refreshToken": "opaque"
}
```

响应 `data`：

```json
{
  "accessToken": "jwt",
  "refreshToken": "new_opaque"
}
```

校验：

- refresh token 必须存在、未过期、未撤销。
- refresh 成功后旧 refresh token 不可再次使用。
- 失败返回 `TOKEN_REFRESH_FAILED`。

### 3.3 `POST /auth/logout`

请求：

```json
{
  "refreshToken": "opaque",
  "deviceId": "uuid"
}
```

响应 `data`：

```json
{
  "ok": true
}
```

校验：

- `refreshToken` 或 `deviceId` 至少提供一个。
- 只能撤销当前用户自己的 token 或设备会话。

### 3.4 `GET /account/me`

响应 `data`：

```json
{
  "user": { "id": "uuid", "account": "demo@example.com", "displayName": "Demo User" },
  "org": { "id": "uuid", "name": "Demo Org" },
  "plan": { "id": "uuid", "code": "free", "name": "Free" },
  "roles": ["owner"]
}
```

## 4. Device API

### 4.1 `POST /devices/register`

请求：

```json
{
  "deviceName": "MacBook Pro",
  "platform": "darwin",
  "appVersion": "0.1.0",
  "localAgentVersion": "0.1.0"
}
```

响应 `data`：

```json
{
  "deviceId": "uuid"
}
```

校验：

- `deviceName`、`platform` 必填。
- 同一用户可注册多设备。
- 带同一 `Idempotency-Key` 重放不得重复创建设备。

### 4.2 `PATCH /devices/{deviceId}/heartbeat`

请求：

```json
{
  "status": "online",
  "localEndpointVersion": "0.1.0"
}
```

响应 `data`：

```json
{
  "serverTime": "2026-06-24T00:00:00Z"
}
```

校验：

- `deviceId` 必须属于当前用户。
- 已解绑设备返回 `FORBIDDEN` 或 `NOT_FOUND`。

### 4.3 `GET /devices`

响应 `data`：

```json
{
  "devices": []
}
```

### 4.4 `DELETE /devices/{deviceId}`

响应 `data`：

```json
{
  "deleted": true
}
```

## 5. Plan And Model API

### 5.1 `GET /plans`

响应 `data`：

```json
{
  "plans": [],
  "version": "v1",
  "updatedAt": "2026-06-24T00:00:00Z"
}
```

### 5.2 `GET /models/providers`

查询参数：`region`, `plan`

响应 `data`：

```json
{
  "providers": [],
  "version": "v1"
}
```

### 5.3 `GET /models/built-in`

查询参数：`appVersion`, `orgId`

响应 `data`：

```json
{
  "models": [],
  "version": "v1"
}
```

### 5.4 `GET /models/entitlements`

响应 `data`：

```json
{
  "modelIds": [],
  "limits": {},
  "version": "v1"
}
```

## 6. P0 错误码要求

| code | 必须覆盖场景 |
| --- | --- |
| `UNAUTHORIZED` | access token 缺失、过期、签名错误、登录失败。 |
| `TOKEN_REFRESH_FAILED` | refresh token 缺失、过期、撤销、重放。 |
| `FORBIDDEN` | 访问不属于当前用户的设备或组织资源。 |
| `NOT_FOUND` | 资源不存在或已删除。 |
| `VALIDATION_FAILED` | 请求体或查询参数不合法。 |
| `CONFLICT` | 幂等冲突或重复资源冲突。 |
| `RATE_LIMITED` | 登录、refresh 或写接口频控。 |
| `INTERNAL_ERROR` | 未预期服务端错误。 |

## 7. P0 合约完成定义

- 本文列出的接口均有 handler、service、repository 或等价实现。
- 成功和失败响应均符合 envelope。
- 受保护接口无 token 返回 `UNAUTHORIZED`。
- 条件缓存接口在数据未变化时返回 `304 Not Modified`。
- 写接口幂等行为可测。
