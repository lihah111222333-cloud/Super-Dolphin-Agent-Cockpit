# P0 验收清单

整理日期：2026-06-24

阶段目录：`p0-core-identity-device-model/`

上级规划：`../master-plan.md`

## 1. 使用规则

P0 进入 P1 前，本文所有必选项必须有证据。证据可以是自动化测试输出、HTTP 调用记录、migration/seed 命令输出或联调记录。

## 2. 工程和数据库

| 状态 | 验收项 | 证据 |
| --- | --- | --- |
| [ ] | `go test ./...` 通过。 | 测试输出。 |
| [ ] | `goose -dir db/migrations postgres "$DATABASE_URL" up-to 1` 通过。 | goose 输出。 |
| [ ] | P0 seed 可重复执行且不重复创建核心数据。 | seed 输出或数据库记录。 |
| [ ] | `/healthz` 返回 200。 | HTTP 输出。 |
| [ ] | 服务启动日志使用 `slog` 结构化输出。 | 日志片段。 |

## 3. Core API

| 状态 | 功能 ID | 验收项 | 证据 |
| --- | --- | --- | --- |
| [ ] | CORE-01 | 成功响应符合 `data/error/requestId` envelope。 | HTTP 输出。 |
| [ ] | CORE-01 | 失败响应符合 `data/error/requestId` envelope。 | HTTP 输出。 |
| [ ] | CORE-02 | 受保护接口无 token 返回 `UNAUTHORIZED`。 | HTTP 输出。 |
| [ ] | CORE-03 | 同一 `Idempotency-Key` 重放不重复创建资源。 | 测试或 HTTP 输出。 |
| [ ] | CORE-04 | 条件请求数据未变化时返回 `304 Not Modified`。 | HTTP 输出。 |

## 4. Auth

| 状态 | 功能 ID | 验收项 | 证据 |
| --- | --- | --- | --- |
| [ ] | AUTH-01 | 正确账号密码可登录并返回 access token、refresh token、user。 | HTTP 输出。 |
| [ ] | AUTH-01 | 错误密码不可登录，且不暴露账号是否存在。 | HTTP 输出。 |
| [ ] | AUTH-02 | access token 过期后可用 refresh token 刷新。 | 测试或 HTTP 输出。 |
| [ ] | AUTH-02 | refresh 成功后旧 refresh token 不可再次刷新。 | 测试或 HTTP 输出。 |
| [ ] | AUTH-03 | logout 后 refresh token 不可继续使用。 | HTTP 输出。 |
| [ ] | AUTH-04 | `/account/me` 返回 user、org、plan、roles。 | HTTP 输出。 |

## 5. Device

| 状态 | 功能 ID | 验收项 | 证据 |
| --- | --- | --- | --- |
| [ ] | DEV-01 | 登录用户可注册设备并得到 `deviceId`。 | HTTP 输出。 |
| [ ] | DEV-01 | 同一幂等 key 注册设备不重复创建。 | 测试或数据库记录。 |
| [ ] | DEV-02 | 设备心跳后 `last_seen_at` 更新。 | HTTP 输出或数据库记录。 |
| [ ] | DEV-02 | 不能心跳其他用户设备。 | HTTP 输出。 |
| [ ] | DEV-03 | 用户只能列出自己的设备。 | HTTP 输出。 |
| [ ] | DEV-03 | 解绑设备后该设备不可继续心跳。 | HTTP 输出。 |

## 6. Plan And Model

| 状态 | 功能 ID | 验收项 | 证据 |
| --- | --- | --- | --- |
| [ ] | BILL-01 | `/plans` 返回套餐和 version。 | HTTP 输出。 |
| [ ] | BILL-01 | `/plans` 支持 304。 | HTTP 输出。 |
| [ ] | MODEL-01 | `/models/built-in` 返回当前账号可见模型。 | HTTP 输出。 |
| [ ] | MODEL-02 | `/models/providers` 返回供应商和能力标签。 | HTTP 输出。 |
| [ ] | MODEL-03 | `/models/entitlements` 返回可用模型和 limits。 | HTTP 输出。 |
| [ ] | MODEL-01~03 | 模型或权益变化后 version 可变化。 | 测试或数据库记录。 |

## 7. P0 边界

| 状态 | 验收项 | 证据 |
| --- | --- | --- |
| [ ] | P0 未创建 P1/P2/P3 handler 或假实现。 | 文件检查。 |
| [ ] | P0 未依赖专家、技能、灵感、连接器目录。 | 代码或任务检查。 |
| [ ] | P0 未实现项目、资料库、资产、分享、审计。 | 代码或任务检查。 |
| [ ] | P0 未实现助理、自动化、计费闭环、反馈、云记忆。 | 代码或任务检查。 |

## 8. 进入 P1 结论

| 项 | 结论 |
| --- | --- |
| P0 是否允许进入 P1 | 未确认 |
| 验收负责人 | 待填写 |
| 验收日期 | 待填写 |
| 遗留问题 | 待填写 |
