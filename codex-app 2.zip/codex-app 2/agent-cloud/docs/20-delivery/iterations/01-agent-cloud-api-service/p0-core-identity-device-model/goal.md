# P0 基础能力阶段目标

整理日期：2026-06-23

阶段目录：`p0-core-identity-device-model/`

上级规划：`../master-plan.md`

## 1. 计划目标

完成 AgentCloud P0 基础能力，使设备端代理服务可以登录、刷新 token、注册设备、上报心跳，并拉取账号、模型和套餐基础信息。

## 2. 阶段内容

- `CORE-01` 通用响应和错误码
- `CORE-02` 鉴权中间件
- `CORE-03` 幂等机制
- `CORE-04` 条件缓存响应
- `AUTH-01` 账号登录
- `AUTH-02` token 刷新
- `AUTH-03` 退出登录
- `AUTH-04` 当前账号上下文
- `DEV-01` 设备注册
- `DEV-02` 设备心跳
- `DEV-03` 设备列表和解绑
- `MODEL-01` 内置模型目录
- `MODEL-02` 模型供应商预设
- `MODEL-03` 模型权益
- `BILL-01` 套餐展示

## 3. 范围边界

允许：

- Go 工程骨架、Gin HTTP server、配置加载、日志、数据库、Redis、goose 入口。
- P0 表、GORM model、repository、service、handler 和测试。
- P0 seed 数据。

禁止：

- P1 专家、技能、灵感、连接器目录。
- P2 项目、资料库、资产、分享、审计。
- P3 助理、自动化、计费闭环、反馈、云记忆。

## 4. 责任归属

| 责任 | 内容 |
| --- | --- |
| 后端服务 | P0 HTTP API、业务逻辑、鉴权、幂等、缓存。 |
| 数据库 | P0 migration、GORM model、seed 数据。 |
| 测试 | 接口行为、鉴权、refresh token、设备、缓存和幂等。 |
| 联调 | 设备端代理服务登录、刷新、注册、心跳和目录拉取。 |

## 5. 前置依赖

- `../../../../10-foundation/architecture/technology-stack.md`
- `../../../../10-foundation/architecture/database-design.md`
- `../../../../../db/migrations/00001_p0_core_identity_device_model.sql`
- `../../../execution/engineering-bootstrap-spec.md`
- `../../../execution/local-dev-runbook.md`
- `../../../execution/seed-data-spec.md`
- `task-plan.md`
- `api-contract.md`
- `acceptance-checklist.md`

## 6. 交付物

- 可运行的 Go API 服务。
- P0 migration 可执行到 `1`。
- P0 seed 数据可创建测试账号、组织、套餐和模型。
- P0 API 符合 `../../../../30-release/cloud-api-spec.md` 和 `api-contract.md` 的通用 envelope、鉴权、设备头、幂等、分页和条件缓存约定。
- P0 验收证据可证明登录、刷新、设备、模型和套餐主链路可用。

## 7. 验收方式

- `go test ./...` 通过。
- `goose -dir db/migrations postgres "$DATABASE_URL" up-to 1` 通过。
- 登录、刷新、退出、账号上下文、设备、模型、套餐接口可通过 HTTP 验证。
- 受保护接口无 token 返回 `UNAUTHORIZED`。
- 条件缓存数据未变化时返回 `304 Not Modified`。
- 同一 `Idempotency-Key` 不重复创建写入资源。
- 成功和失败响应均包含 `requestId`。
- refresh token 轮换后旧 token 不可再次刷新。
- 解绑设备后该设备不可继续心跳。

## 8. 后续细化规则

P0 已补充任务拆分、接口细则和验收清单：

- `task-plan.md`
- `api-contract.md`
- `acceptance-checklist.md`

后续进入 P0 开发时，必须继续以 `../feature-plan.md`、`../../../../30-release/cloud-api-spec.md`、`../../../../10-foundation/architecture/database-design.md`、本文和上述三个 P0 文件为事实源。新增更细的任务或验收记录不得扩大 P0 范围。

## 9. 下一阶段门禁

进入 P1 前必须满足：

- P0 功能 ID 全部完成并有测试证据。
- `acceptance-checklist.md` 全部必选项有证据。
- P0 未引入 P1/P2/P3 表、接口或 worker 依赖。
- `00-start/current-status.md` 已更新为 P1 准备状态。
