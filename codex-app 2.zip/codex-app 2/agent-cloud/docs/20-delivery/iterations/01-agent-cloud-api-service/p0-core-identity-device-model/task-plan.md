# P0 基础能力任务计划

整理日期：2026-06-24

阶段目录：`p0-core-identity-device-model/`

上级规划：`../master-plan.md`

事实源：

- `goal.md`
- `../feature-plan.md`
- `../../../execution/engineering-bootstrap-spec.md`
- `../../../execution/local-dev-runbook.md`
- `../../../execution/seed-data-spec.md`
- `../../../../10-foundation/architecture/database-design.md`
- `../../../../30-release/cloud-api-spec.md`

## 1. 定位

本文把 P0 功能 ID 拆成可开发、可测试、可验收的最小任务组。本文不新增功能范围；接口细则以 `api-contract.md` 为准，验收证据以 `acceptance-checklist.md` 为准。

## 2. 推进顺序

```text
T00 工程骨架
  -> T01 数据库和 seed
  -> T02 Core API 横切能力
  -> T03 Auth 和 refresh token
  -> T04 设备注册和心跳
  -> T05 套餐、模型和权益
  -> T06 P0 联调和验收
```

## 3. 任务组

| 任务组 | 覆盖功能 ID | 目标 | 主要交付物 | 验收证据 |
| --- | --- | --- | --- | --- |
| T00 工程骨架 | P0 工程前置 | 建立可启动 Go API 服务。 | `cmd/agent-cloud`、config、Gin router、slog、PostgreSQL、Redis 初始化。 | `/healthz` 返回 200；配置加载测试通过。 |
| T01 数据库和 seed | P0 数据前置 | 创建 P0 schema 和本地验收数据。 | goose `up-to 1`、P0 GORM model、幂等 seed。 | migration 成功；seed 可重复执行。 |
| T02 Core API 横切能力 | `CORE-01` ~ `CORE-04` | 固定响应 envelope、错误码、分页、幂等、条件缓存。 | requestId middleware、错误映射、idempotency service、cache header 支持。 | envelope、幂等、304 测试通过。 |
| T03 Auth 和 refresh token | `AUTH-01` ~ `AUTH-04` | 完成登录、刷新、退出和账号上下文。 | 登录、refresh token 轮换、logout、account me。 | 登录/刷新/撤销/无 token 测试通过。 |
| T04 设备注册和心跳 | `DEV-01` ~ `DEV-03` | 完成设备注册、心跳、列表和解绑。 | device register、heartbeat、list、delete。 | 设备归属、解绑、心跳测试通过。 |
| T05 套餐、模型和权益 | `BILL-01`, `MODEL-01` ~ `MODEL-03` | 返回套餐、模型 provider、模型目录和权益。 | plans、model providers、built-in models、entitlements。 | 目录数据、套餐过滤、304 测试通过。 |
| T06 P0 联调和验收 | 全部 P0 | 串起设备端主流程并归档证据。 | HTTP 验收记录、测试结果、P0 check list。 | `acceptance-checklist.md` 全部通过。 |

## 4. 依赖门禁

| 任务组 | 前置依赖 | 不允许依赖 |
| --- | --- | --- |
| T00 | 技术栈已冻结。 | P1/P2/P3 handler、worker。 |
| T01 | P0 migration 存在。 | GORM `AutoMigrate` 生成正式 schema。 |
| T02 | T00、T01。 | 具体业务接口绕过统一 envelope。 |
| T03 | T02。 | 设备上下文作为登录前提。 |
| T04 | T03。 | P2 项目或 P3 助理下发。 |
| T05 | T02、T03、T01 seed。 | P1 市场目录或 P3 计费闭环。 |
| T06 | T00 ~ T05。 | 临时手工改库作为验收证据。 |

## 5. 开发规则

- 每个任务组完成时必须有最小测试或 HTTP 验收证据。
- P0 不创建 P1/P2/P3 空包、空 handler 或假实现。
- `idempotency_keys`、`refresh_tokens`、`devices` 等安全路径必须有失败场景测试。
- API、migration、seed 和测试变更必须在 P0 内闭环。

## 6. 完成定义

P0 完成必须同时满足：

- `go test ./...` 通过。
- `goose -dir db/migrations postgres "$DATABASE_URL" up-to 1` 通过。
- P0 seed 可重复执行。
- `api-contract.md` 中 P0 接口均实现。
- `acceptance-checklist.md` 全部勾选。
