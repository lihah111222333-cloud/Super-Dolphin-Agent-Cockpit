# agent-cloud 开发执行规格

整理日期：2026-06-23

状态：当前有效开发执行规格

## 1. 规格定位

本文用于约束 AgentCloud 从 P0 到 P3 的开发推进方式。它不替代产品说明书、技术架构说明书、功能清单或 API 规格，而是规定阶段顺序、依赖门禁、验收方式和禁止越界事项。

关联文档：

- `../../10-foundation/product/agent-cloud-product-spec.md`
- `../../10-foundation/architecture/technical-architecture.md`
- `../../10-foundation/architecture/technology-stack.md`
- `../../10-foundation/architecture/database-design.md`
- `engineering-bootstrap-spec.md`
- `local-dev-runbook.md`
- `seed-data-spec.md`
- `../iterations/01-agent-cloud-api-service/master-plan.md`
- `../iterations/01-agent-cloud-api-service/feature-plan.md`
- `../../30-release/cloud-api-spec.md`
- `../../30-release/release-readiness-checklist.md`

## 2. 基础技术栈约束

P0 开发必须使用 `../../10-foundation/architecture/technology-stack.md` 中冻结的技术栈：

- Go + Gin
- PostgreSQL + GORM + goose
- Redis + go-redis
- JWT access token
- Opaque refresh token
- bcrypt password hashing
- `config.yaml` + env secret override
- Go `slog` structured logging

不得引入替代 Web 框架、数据库、ORM、迁移工具、Redis 客户端、token 方案、密码哈希或日志库。正式数据库 schema 必须通过 goose migration 管理，不得用 GORM `AutoMigrate` 作为正式迁移机制。

数据库表、字段、索引、唯一约束、外键、软删和阶段建表计划以 `../../10-foundation/architecture/database-design.md` 为准。

数据库创建操作使用 `../../../db/migrations/` 下的 goose SQL 脚本；阶段执行命令见 `../../../db/README.md`。

本地启动、P0 seed 和冒烟验证分别见 `local-dev-runbook.md` 和 `seed-data-spec.md`。

## 3. 阶段开放原则

- 阶段必须按 P0 -> P1 -> P2 -> P3 严格顺序推进。
- 当前阶段只能依赖已完成阶段的能力。
- 后续阶段不能成为前置阶段的依赖。
- 阶段内不得偷偷依赖未来 API、未来数据表或未来异步能力。
- 未进入当前阶段的接口不得用空实现、假实现或不可验证 stub 占位。
- 每个功能 ID 必须能独立说明依赖、输入输出、错误场景、验收方式和测试证据。

## 4. 阶段边界

| 阶段 | 核心目标 | 最小可验证产物 |
| --- | --- | --- |
| P0 | 登录、token、账号、设备、模型和套餐基础能力可用。 | 设备端可登录、刷新 token、注册设备、心跳、拉取账号/模型/套餐。 |
| P1 | 运营配置和市场目录可用。 | 专家、技能、灵感、连接器目录可分页查询、版本缓存和下架生效。 |
| P2 | 协作、授权、资产和审计闭环。 | 项目协作、OAuth、云资料库、资产、分享和审计按权限可用。 |
| P3 | 平台网关、自动化、计费和反馈完善。 | 助理网关、项目自动化、计费闭环、反馈和云记忆达到可用状态。 |

## 5. P0 执行范围

允许实现：

- `CORE-01` 到 `CORE-04`
- `AUTH-01` 到 `AUTH-04`
- `DEV-01` 到 `DEV-03`
- `MODEL-01` 到 `MODEL-03`
- `BILL-01`

验收重点：

- 成功和失败响应均符合 `data/error/requestId` envelope。
- 登录外受保护接口校验 access token。
- refresh token 可轮换、可撤销。
- 设备注册后可通过 `X-Device-Id` 建立设备上下文。
- 动态配置类接口支持版本字段和条件缓存。
- 写接口具备幂等行为。

禁止事项：

- 不实现专家、技能、灵感、连接器目录。
- 不实现项目协作、OAuth、云资料库、资产、分享、审计。
- 不实现助理、自动化、支付闭环、云记忆。
- 不引入 Electron 直连 AgentCloud 的接口形态。

## 6. P1 执行范围

前置门禁：P0 已通过验收。

允许实现：

- `WEBHOOK-01`
- `EXP-01` 到 `EXP-04`
- `SKILL-01` 到 `SKILL-05`
- `INSP-01` 到 `INSP-05`
- `CONN-01` 到 `CONN-05`

验收重点：

- 目录类接口支持分页、搜索、状态过滤和版本缓存。
- 禁用或下架资源不会继续被正常返回。
- OAuth 授权会话具备 state 校验、过期和状态查询。
- 第三方 token 不明文返回。
- 连接器连通测试不泄露第三方 token。
- Webhook 具备验签、事件去重和队列化处理入口。

禁止事项：

- 不把用户私有专家或技能草稿保存为云端运营资源。
- 不开放任意连接器 invoke API 给 Electron。
- 不提前实现 P2 项目协作或 P3 计费闭环作为 P1 依赖。

## 7. P2 执行范围

前置门禁：P1 已通过验收。

允许实现：

- `KS-01` 到 `KS-05`
- `PROJ-01` 到 `PROJ-05`
- `ASSET-01` 到 `ASSET-03`
- `SHARE-01` 到 `SHARE-02`
- `AUDIT-01` 到 `AUDIT-03`
- `CONN-06`

验收重点：

- 项目、成员、邀请、审批和任务摘要按权限闭环。
- 云资料库授权、搜索、引用载荷和产物回写按 provider 错误统一映射。
- 项目资产支持上传、列表、详情、删除和配额。
- 分享链接具备过期、复制、下载和取消分享行为。
- 审计记录可按项目和权限查询。
- 项目级自定义连接器只能由有权限的项目成员维护。

禁止事项：

- 不保存完整本地执行轨迹。
- 不把设备文件树、diff 或预览搬到云端。
- 不在未完成权限模型前实现可跨项目访问的资产或审计接口。

## 8. P3 执行范围

前置门禁：P2 已通过验收。

允许实现：

- `ASST-01` 到 `ASST-04`
- `AUTO-01` 到 `AUTO-03`
- `BILL-02` 到 `BILL-05`
- `MEM-01` 到 `MEM-02`
- `FB-01` 到 `FB-02`
- `WEBHOOK-02`

验收重点：

- 助理平台回调可验签、去重、下发设备并回传结果。
- 项目自动化可配置、触发和幂等执行。
- 积分、用量、订单、支付回调和发票形成一致记录。
- 反馈和附件上传可追踪。
- 云记忆默认关闭，按账号或组织隔离。

禁止事项：

- 不在支付和用量记账中跳过幂等。
- 不在助理回调中阻塞执行重任务。
- 不让云记忆突破账号、组织或项目权限边界。

## 9. 测试要求

| 类型 | 最低要求 |
| --- | --- |
| API 合约测试 | 覆盖响应 envelope、错误码、鉴权、分页、幂等、条件缓存。 |
| 权限测试 | 覆盖账号、组织、角色、项目成员、资源 owner、连接器 scope。 |
| 设备联调 | 覆盖登录、刷新、设备注册、心跳、目录拉取和设备离线处理。 |
| Webhook 测试 | 覆盖验签、重复事件、非法事件、快速返回和异步处理。 |
| 计费测试 | 覆盖余额、用量、订单、支付回调、重复回调和权益发放。 |
| 资产测试 | 覆盖上传、配额、下载、删除、分享过期和取消分享。 |
| 审计测试 | 覆盖项目动作、连接器动作、计费和安全事件可查询。 |

## 10. 文档更新要求

- 阶段状态变化后更新 `../../00-start/current-status.md`。
- API 规格变化后更新 `../../30-release/cloud-api-spec.md`。
- 发布门禁变化后更新 `../../30-release/release-readiness-checklist.md`。
- 阶段规划变化后更新 `../iterations/01-agent-cloud-api-service/master-plan.md` 和对应阶段 `goal.md`。
- 功能 ID、依赖、验收方式变化后更新 `../iterations/01-agent-cloud-api-service/feature-plan.md`。
- 产品范围或非目标变化后更新 `../../10-foundation/product/agent-cloud-product-spec.md`。
- 架构边界、模块、数据流或安全策略变化后更新 `../../10-foundation/architecture/technical-architecture.md`。
- 表结构、字段、索引、唯一约束、外键或软删策略变化后更新 `../../10-foundation/architecture/database-design.md`。
