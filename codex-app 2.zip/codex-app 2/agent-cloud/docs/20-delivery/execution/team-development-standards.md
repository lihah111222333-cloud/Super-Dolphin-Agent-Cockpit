# AgentCloud 开发团队规范

## 1. 适用范围

本文约束 `agent-cloud` 的日常开发、评审、测试、文档和发布协作。

AgentCloud 是云端远程 API 服务，服务对象是设备端代理服务、第三方回调、云后台和 Worker。不得把 Electron 直连、设备端本地执行、文件树、diff、预览、自定义模型 Key 或本地 Agent runtime 放进云端。

## 2. 开发顺序

- 严格按 P0 -> P1 -> P2 -> P3 推进。
- 开始阶段开发前，先读 `docs/00-start/current-status.md`、当前阶段 `goal.md`、`task-plan.md`、`api-contract.md` 和 `acceptance-checklist.md`。
- 后续阶段不能成为前置阶段的编译、测试或验收依赖。
- 未进入当前阶段的接口不得用空实现、假实现或不可验证 stub 占位。
- 功能 ID、API 合约和验收证据必须能互相追踪。

## 3. 代码规范

- 技术栈以 `docs/10-foundation/architecture/technology-stack.md` 为准。
- 数据库 schema 以 `docs/10-foundation/architecture/database-design.md` 和 goose migration 为准，不用 GORM `AutoMigrate` 作为正式迁移。
- API 响应统一使用 `data/error/requestId` envelope。
- 写接口必须处理幂等；回调、支付、计费和队列消费必须防重复。
- 第三方 token、refresh token、密钥和支付敏感字段不得明文返回或进入日志。
- 日志使用 `slog`，保留 request id、账号/设备/项目上下文和错误码，不记录敏感 header/body。

## 4. 测试规范

- 每个阶段必须留下最小可运行验证。
- P0 至少覆盖登录、刷新 token、设备注册、心跳、账号/模型/套餐拉取。
- API 测试必须覆盖 envelope、错误码、鉴权、分页、幂等和条件缓存。
- 权限测试必须覆盖账号、组织、角色、项目成员、资源 owner 和连接器 scope。
- Webhook 测试必须覆盖验签、重复事件、非法事件、快速返回和异步处理。
- 计费测试必须覆盖订单、支付回调、重复回调、用量和权益发放。

## 5. 文档规范

- 产品范围以 `docs/10-foundation/product/agent-cloud-product-spec.md` 为准。
- 技术架构以 `docs/10-foundation/architecture/technical-architecture.md` 为准。
- API 规格以 `docs/30-release/cloud-api-spec.md` 和阶段 `api-contract.md` 为准。
- 开发顺序和门禁以 `docs/20-delivery/execution/execution-spec.md` 为准。
- 新增文档按 `docs/00-start/doc-governance.md` 放置，不在 `docs/` 根目录平铺。

## 6. 评审规范

变更进入评审前必须说明：

- 影响哪个阶段和哪些功能 ID。
- 是否修改 API 合约、数据库 schema、错误码或权限模型。
- 是否引入未来阶段依赖。
- 运行了哪些验证命令。
- 是否需要更新 README、API 规格、acceptance checklist、release checklist 或飞书映射。

评审优先检查：

- 是否让 Electron 绕过设备端代理服务直连云端。
- 是否把本地 Agent 执行事实搬进云端。
- 是否泄露 token、密钥、文件内容或支付敏感信息。
- 是否缺少幂等、权限或最小验证。

## 7. 发布规范

- 发布前必须通过当前阶段 acceptance checklist。
- 发布 API 变更必须更新 `docs/30-release/cloud-api-spec.md`。
- P3 前不得回填改变 P0-P2 已冻结边界。
- 发布后新增能力进入新迭代规划，不直接修改已完成阶段的验收口径。
