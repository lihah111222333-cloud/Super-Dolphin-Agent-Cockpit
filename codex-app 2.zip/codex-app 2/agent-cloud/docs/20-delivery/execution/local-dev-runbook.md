# AgentCloud 本地开发运行手册

整理日期：2026-06-24

状态：P0 开发前有效

## 1. 定位

本文说明开发人员如何在本地启动 AgentCloud API 服务并完成 P0 验证。本文是执行手册，不替代产品、架构、数据库或阶段规划文档。

相关文件：

- `engineering-bootstrap-spec.md`
- `seed-data-spec.md`
- `../iterations/01-agent-cloud-api-service/p0-core-identity-device-model/task-plan.md`
- `../iterations/01-agent-cloud-api-service/p0-core-identity-device-model/api-contract.md`
- `../iterations/01-agent-cloud-api-service/p0-core-identity-device-model/acceptance-checklist.md`
- `../../../db/README.md`

## 2. 前置条件

| 项 | 要求 |
| --- | --- |
| Go | 使用项目实际 `go.mod` 指定版本。 |
| PostgreSQL | 本地可连接，已创建 `agent_cloud` 数据库。 |
| Redis | 本地可连接；若关闭 Redis，必须在配置中显式关闭相关能力。 |
| goose | 可执行 migration。 |
| 配置文件 | `config/config.yaml` 存在且只保存非敏感默认值。 |

## 3. 环境变量

从 `agent-cloud/` 目录启动前，至少设置：

```bash
export DATABASE_URL='postgres://agent_cloud:password@localhost:5432/agent_cloud?sslmode=disable'
export AGENT_CLOUD_DATABASE_URL="$DATABASE_URL"
export AGENT_CLOUD_REDIS_ADDR='127.0.0.1:6379'
export AGENT_CLOUD_JWT_SECRET='local-dev-jwt-secret'
export AGENT_CLOUD_REFRESH_TOKEN_PEPPER='local-dev-refresh-pepper'
export AGENT_CLOUD_BCRYPT_COST='10'
```

本地默认值只用于开发，不得复制到生产环境。

## 4. 初始化数据库

从 `agent-cloud/` 目录执行：

```bash
goose -dir db/migrations postgres "$DATABASE_URL" up-to 1
```

查看状态：

```bash
goose -dir db/migrations postgres "$DATABASE_URL" status
```

## 5. 导入 P0 seed

目标命令：

```bash
go run ./cmd/agent-cloud seed p0
```

在 seed 命令尚未实现前，P0 的 T01 任务不得视为完成。seed 规则以 `seed-data-spec.md` 为准。

## 6. 启动服务

```bash
go run ./cmd/agent-cloud
```

最低启动检查：

```bash
curl -i http://127.0.0.1:8080/healthz
```

预期：

- HTTP 状态码为 `200`。
- 服务输出结构化 `slog` 日志。
- 数据库连接成功。
- Redis 连接状态明确，不允许静默失败。

## 7. P0 接口冒烟

登录：

```bash
curl -sS -X POST http://127.0.0.1:8080/api/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"account":"demo@example.com","password":"local-dev-password"}'
```

拉取套餐：

```bash
curl -i http://127.0.0.1:8080/api/v1/plans
```

后续接口按 `../iterations/01-agent-cloud-api-service/p0-core-identity-device-model/api-contract.md` 执行，并将结果记录到 `../iterations/01-agent-cloud-api-service/p0-core-identity-device-model/acceptance-checklist.md`。

## 8. 测试命令

从 `agent-cloud/` 目录执行：

```bash
go test ./...
```

P0 完成前，至少覆盖：

- 配置加载。
- HTTP envelope。
- 登录和 refresh token 轮换。
- 设备注册幂等。
- 设备归属权限。
- 目录类接口 304。

## 9. 常见失败处理

| 现象 | 处理 |
| --- | --- |
| migration 连接失败 | 检查 `DATABASE_URL` 和数据库是否已创建。 |
| seed 重复插入 | 修复 seed 幂等逻辑，不手工删库作为长期方案。 |
| `/healthz` 非 200 | 检查配置加载、数据库和 Redis 初始化日志。 |
| 受保护接口返回 401 | 重新登录，确认 `Authorization: Bearer <token>`。 |
| 目录接口无法返回 304 | 检查 ETag 或 Last-Modified 生成逻辑。 |

## 10. 退出和清理

本地开发可按需回滚最近一次 migration：

```bash
goose -dir db/migrations postgres "$DATABASE_URL" down
```

生产或共享环境不得用 `down` 代替数据恢复方案。
