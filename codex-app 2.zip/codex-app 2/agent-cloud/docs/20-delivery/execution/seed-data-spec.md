# AgentCloud Seed 数据执行规格

整理日期：2026-06-24

状态：P0 开发前有效

## 1. 定位

本文规定 AgentCloud 本地开发、接口验收和阶段联调所需 seed 数据的范围、执行时机和约束。本文不定义生产初始化数据，不替代数据库表结构设计。

相关文件：

- `../../10-foundation/architecture/database-design.md`
- `engineering-bootstrap-spec.md`
- `local-dev-runbook.md`
- `../../../db/README.md`
- `../../../db/seed/README.md`

## 2. 使用场景

| 场景 | 是否使用 seed | 说明 |
| --- | --- | --- |
| 本地开发 | 是 | 用于登录、设备注册、套餐和模型接口验证。 |
| 本地接口验收 | 是 | 用于完成 P0 验收清单。 |
| 自动化测试 | 可使用 | 优先使用测试 fixture；需要端到端验收时可复用 seed 规则。 |
| 预发布环境 | 谨慎使用 | 只能导入非敏感、可审计的运营基础数据。 |
| 生产环境 | 默认不使用 | 生产初始化数据必须单独走发布和变更审批。 |

## 3. 执行顺序

P0 开发和验收时，必须按以下顺序执行：

```text
创建 PostgreSQL 数据库
  -> 执行 P0 migration
  -> 执行 P0 seed
  -> 启动 AgentCloud API 服务
  -> 执行接口验收
```

从 `agent-cloud/` 目录执行 P0 migration：

```bash
goose -dir db/migrations postgres "$DATABASE_URL" up-to 1
```

P0 seed 目标命令：

```bash
go run ./cmd/agent-cloud seed p0
```

说明：在工程代码尚未实现前，上述 seed 命令是 P0 开发需要落地的目标命令；不得用手工改库作为最终验收方式。

## 4. P0 最小 seed 数据集

| 数据域 | 最小数据 | 用途 |
| --- | --- | --- |
| 用户 | `demo@example.com` 本地测试用户。 | 登录、账号上下文、refresh token。 |
| 组织 | `Demo Org` 默认组织。 | membership、套餐归属。 |
| 组织成员 | demo 用户为 `owner`。 | `/account/me` 返回角色。 |
| 套餐 | `free`、`pro`。 | `/plans` 和权益展示。 |
| 模型供应商 | 至少 1 个启用 provider。 | `/models/providers`。 |
| 模型目录 | 至少 2 个启用模型。 | `/models/built-in`。 |
| 模型权益 | `free` 和 `pro` 至少各 1 组权益。 | `/models/entitlements`。 |

P0 本地 seed 默认登录密码目标为 `local-dev-password`。本地测试密码只允许用于本地开发文档或本地 `.env`，不得写入生产配置。密码入库必须使用 bcrypt hash，不允许明文落库。

## 5. 幂等规则

- seed 必须可重复执行。
- 用户按账号去重。
- 组织按稳定 slug 或名称去重。
- 套餐按 `code` 去重。
- 模型供应商按 `provider_code` 去重。
- 模型目录按 `model_id` 或稳定 code 去重。
- 模型权益按组织、套餐、模型和权益维度去重。
- seed 更新已有基础数据时，必须只更新非用户私有字段。

## 6. 边界约束

- seed 不得通过 GORM `AutoMigrate` 创建 schema。
- seed 不得绕过 migration 直接创建表或索引。
- seed 不得写入真实第三方 token、真实支付凭证或生产密钥。
- seed 不得提前创建 P1/P2/P3 数据作为 P0 验收前提。
- seed 不得依赖外部公网服务。

## 7. 验收要求

P0 seed 完成后必须能支持：

- `POST /auth/login` 使用 demo 用户登录。
- `GET /account/me` 返回 user、org、plan、roles。
- `GET /plans` 返回套餐和 version。
- `GET /models/providers` 返回启用 provider。
- `GET /models/built-in` 返回当前账号可见模型。
- `GET /models/entitlements` 返回当前账号模型权益。
- 重复执行 seed 不重复创建核心数据。

验收证据记录到 `../iterations/01-agent-cloud-api-service/p0-core-identity-device-model/acceptance-checklist.md`。
