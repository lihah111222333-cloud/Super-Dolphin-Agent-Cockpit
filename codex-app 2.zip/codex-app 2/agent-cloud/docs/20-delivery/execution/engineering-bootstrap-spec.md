# AgentCloud 工程启动规格

整理日期：2026-06-23

状态：P0 开发前有效

## 1. 定位

本文规定 AgentCloud 从文档进入 Go 工程开发时的最小工程骨架、配置、启动、seed 和验证要求。它不新增产品能力，只把 `technology-stack.md` 中的 P0 工程落地约束具体化。

## 2. 工程目录建议

P0 首版使用以下最小目录：

```text
agent-cloud/
  cmd/agent-cloud/
    main.go
  config/
    config.yaml
  internal/
    app/
    config/
    http/
    middleware/
    domain/
    storage/
  db/
    migrations/
    seed/
  docs/
```

约束：

- `cmd/agent-cloud/main.go` 只负责加载配置、初始化依赖、启动 HTTP server。
- `internal/http` 放 Gin router、handler 和中间件。
- `internal/domain` 放业务服务和领域类型。
- `internal/storage` 放 GORM model、repository、PostgreSQL 和 Redis 初始化。
- 不为未来阶段提前创建空 package。

## 3. 配置规则

`config/config.yaml` 只保存非敏感默认值：

```yaml
server:
  addr: ":8080"
database:
  url: ""
redis:
  addr: "127.0.0.1:6379"
auth:
  access_token_ttl_seconds: 900
  refresh_token_ttl_seconds: 2592000
log:
  level: "info"
```

敏感值必须通过环境变量覆盖：

| 环境变量 | 用途 |
| --- | --- |
| `AGENT_CLOUD_DATABASE_URL` | PostgreSQL 连接串。 |
| `AGENT_CLOUD_REDIS_ADDR` | Redis 地址。 |
| `AGENT_CLOUD_REDIS_PASSWORD` | Redis 密码。 |
| `AGENT_CLOUD_JWT_SECRET` | access token 签名密钥。 |
| `AGENT_CLOUD_REFRESH_TOKEN_PEPPER` | refresh token hash pepper。 |
| `AGENT_CLOUD_BCRYPT_COST` | bcrypt cost；本地可较低，生产按安全要求配置。 |

## 4. 启动命令

从 `agent-cloud/` 执行：

```bash
go run ./cmd/agent-cloud
```

最低启动验收：

- 输出结构化 `slog` 日志。
- `/healthz` 返回 `200`。
- 数据库连接成功。
- Redis 连接成功；若本地未启用 Redis，必须在配置中显式关闭依赖 Redis 的功能，不能静默失败。

## 5. Migration 和 seed

Migration：

```bash
goose -dir db/migrations postgres "$DATABASE_URL" up-to 1
```

Migration 执行说明见 `../../../db/README.md`。

P0 seed 数据必须覆盖：

| 数据 | 用途 |
| --- | --- |
| 测试用户 | 登录和账号上下文。 |
| 默认组织 | membership 和 plan 归属。 |
| 默认套餐 | `/plans` 和权益。 |
| 模型 provider | `/models/providers`。 |
| 模型目录 | `/models/built-in`。 |
| 模型权益 | `/models/entitlements`。 |

seed 规则：

- seed 必须幂等，可重复执行。
- 测试密码只用于本地开发，不写入生产配置。
- seed 不通过 GORM `AutoMigrate` 创建 schema。
- seed 执行规则见 `seed-data-spec.md`。
- seed 目录说明见 `../../../db/seed/README.md`。
- 本地启动和冒烟流程见 `local-dev-runbook.md`。

## 6. P0 最小测试

- 配置加载测试。
- HTTP envelope 测试。
- 登录和 refresh token 轮换测试。
- 设备注册幂等测试。
- 设备归属权限测试。
- 目录类接口 304 测试。

## 7. 不做事项

- 不引入约定外 Web 框架、ORM、迁移工具、日志库或 token 方案。
- 不提前创建 P1/P2/P3 空 handler。
- 不添加生产部署、CI、监控或复杂容器编排；这些等首个可运行服务稳定后再补。
