# agent-cloud 飞书云盘路径映射

| 项目 | 内容 |
| --- | --- |
| 本地项目目录 | `/Users/ai/Devlop/codex-app/agent-cloud/` |
| 本地 docs 目录 | `/Users/ai/Devlop/codex-app/agent-cloud/docs/` |
| 云盘父目录 | `/CodexApp/` |
| 云盘父目录 token | 未记录 |
| 云盘项目目录 | `/CodexApp/agent-cloud/` |
| 云盘项目目录 token | 未记录 |
| 云盘项目目录 URL | 未记录 |
| 本地到云盘同步命令 | 未记录 |
| 精确一致性校验命令 | 未记录 |
| 映射更新日期 | 2026-06-23 |
| 说明 | 本文件仅记录本地路径与云盘目标路径的语义映射；当前未记录可校验的飞书 token。 |

## 目录映射

| 本地路径 | 云盘路径 | folder token |
| --- | --- | --- |
| `agent-cloud/` | `/CodexApp/agent-cloud/` | 未记录 |
| `agent-cloud/docs/` | `/CodexApp/agent-cloud/docs/` | 未记录 |
| `agent-cloud/docs/00-start/` | `/CodexApp/agent-cloud/docs/00-start/` | 未记录 |
| `agent-cloud/docs/10-foundation/` | `/CodexApp/agent-cloud/docs/10-foundation/` | 未记录 |
| `agent-cloud/docs/20-delivery/` | `/CodexApp/agent-cloud/docs/20-delivery/` | 未记录 |
| `agent-cloud/docs/30-release/` | `/CodexApp/agent-cloud/docs/30-release/` | 未记录 |
| `agent-cloud/docs/99-archive/` | `/CodexApp/agent-cloud/docs/99-archive/` | 未记录 |

## 关键文件映射

| 本地文件 | 云盘路径 | file token |
| --- | --- | --- |
| `agent-cloud/docs/README.md` | `/CodexApp/agent-cloud/docs/README.md` | 未记录 |
| `agent-cloud/docs/00-start/ai-project-context.md` | `/CodexApp/agent-cloud/docs/00-start/ai-project-context.md` | 未记录 |
| `agent-cloud/docs/00-start/current-status.md` | `/CodexApp/agent-cloud/docs/00-start/current-status.md` | 未记录 |
| `agent-cloud/docs/00-start/reading-guide.md` | `/CodexApp/agent-cloud/docs/00-start/reading-guide.md` | 未记录 |
| `agent-cloud/docs/00-start/doc-governance.md` | `/CodexApp/agent-cloud/docs/00-start/doc-governance.md` | 未记录 |
| `agent-cloud/docs/10-foundation/product/agent-cloud-product-spec.md` | `/CodexApp/agent-cloud/docs/10-foundation/product/agent-cloud-product-spec.md` | 未记录 |
| `agent-cloud/docs/10-foundation/architecture/technical-architecture.md` | `/CodexApp/agent-cloud/docs/10-foundation/architecture/technical-architecture.md` | 未记录 |
| `agent-cloud/docs/10-foundation/architecture/technology-stack.md` | `/CodexApp/agent-cloud/docs/10-foundation/architecture/technology-stack.md` | 未记录 |
| `agent-cloud/docs/10-foundation/architecture/database-design.md` | `/CodexApp/agent-cloud/docs/10-foundation/architecture/database-design.md` | 未记录 |
| `agent-cloud/docs/20-delivery/execution/execution-spec.md` | `/CodexApp/agent-cloud/docs/20-delivery/execution/execution-spec.md` | 未记录 |
| `agent-cloud/docs/20-delivery/iterations/01-agent-cloud-api-service/feature-plan.md` | `/CodexApp/agent-cloud/docs/20-delivery/iterations/01-agent-cloud-api-service/feature-plan.md` | 未记录 |
| `agent-cloud/docs/30-release/cloud-api-spec.md` | `/CodexApp/agent-cloud/docs/30-release/cloud-api-spec.md` | 未记录 |

## 后续维护规则

- 新增文档先按 `docs/README.md` 和 `docs/00-start/doc-governance.md` 的放置规则落位。
- 若本地发生删除、重命名或目录迁移，同步飞书后必须更新本文件。
- 本映射只覆盖 `agent-cloud/` 到 `/CodexApp/agent-cloud/`，不记录 AgentHost、Electron、codexapp-go 或其他项目目录。
