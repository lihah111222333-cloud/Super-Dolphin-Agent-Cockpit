# agent-cloud docs 目录治理规则

## 目标

`docs/` 按文档生命周期管理，而不是按临时主题堆放。目标是后续文件数量增长后，仍能快速判断：

- 新文档应该放在哪里。
- 哪些文档是当前有效事实。
- 哪些文档只属于某次迭代。
- 哪些文档只是同步、映射、治理元数据。

## 一级目录职责

| 目录 | 职责 | 不放什么 |
| --- | --- | --- |
| `00-start/` | AI 启动上下文、当前状态、阅读路径、文档治理、云盘映射。 | 产品、架构、API 正文。 |
| `10-foundation/` | 长期有效的产品、架构、协议和边界事实。 | 临时迭代计划、发布 changelog。 |
| `20-delivery/` | 开发执行规格、迭代计划、阶段目标、验收材料。 | 长期稳定产品或架构正文。 |
| `30-release/` | API reference、compatibility、changelog、release note。 | 未冻结的阶段草案。 |
| `99-archive/` | 过期但需追溯的旧文档。 | 当前有效文档。 |

## 二级目录职责

| 目录 | 职责 |
| --- | --- |
| `10-foundation/product/` | AgentCloud 产品定位、目标、范围、非目标和阶段验收。 |
| `10-foundation/architecture/` | AgentCloud 技术架构、基础技术栈、数据库设计、模块边界、数据流、安全、测试策略和长期有效的阶段前置设计。 |
| `10-foundation/protocol/` | 长期有效的协议事实、schema、接口约定或外部协议快照。 |
| `20-delivery/execution/` | 开发推进规则、阶段门禁、测试要求、工程启动和实施约束。 |
| `20-delivery/iterations/<迭代>/` | 单次迭代的总阶段规划、功能清单、阶段目标、API 合约和验收证据。 |
| `../../db/migrations/` | goose 数据库创建和迁移脚本。 |
| `../../db/seed/` | 本地开发和阶段验收 seed 实现或说明。 |

## 命名规则

- 文件名使用英文 kebab-case，例如 `feature-plan.md`、`execution-spec.md`、`cloud-api-spec.md`。
- 中文放在标题和正文，不放文件名。
- 迭代目录使用序号和主题：`01-agent-cloud-api-service/`。
- 迭代总阶段规划统一命名为 `master-plan.md`。
- 阶段目标统一放在 `<stage-slug>/goal.md`。
- 当前有效技术架构统一命名为 `technical-architecture.md`。
- 每个大型目录后续可补 `README.md` 作为局部索引。

## 渐进式加载规则

- 根 `README.md` 只放导航、推荐阅读顺序和目录职责。
- `00-start/ai-project-context.md` 面向 AI 从 0 启动，稳定描述项目边界和禁止越界事项。
- `00-start/current-status.md` 只描述当前阶段、当前入口和当前允许/禁止事项。
- 迭代细节不进入根 `README.md`，只保留迭代入口链接。
- 云盘映射不进入业务文档，统一放 `00-start/feishu-drive-mapping.md`。

## 新增文档判定

| 问题 | 放置位置 |
| --- | --- |
| 这是入口、当前状态、阅读路径或治理信息吗？ | `00-start/` |
| 这是长期有效的产品事实吗？ | `10-foundation/product/` |
| 这是长期有效的工程设计吗？ | `10-foundation/architecture/` |
| 这是长期有效的协议或 API 约定事实吗？ | `10-foundation/protocol/` 或 `30-release/` |
| 这是开发或测试执行约束吗？ | `20-delivery/execution/` |
| 这是某次迭代的产物吗？ | `20-delivery/iterations/<迭代>/` |
| 这是发布后给使用者看的材料吗？ | `30-release/` |
| 这是过期但不能删除的材料吗？ | `99-archive/` |

## 飞书同步规则

- 本地 `agent-cloud/` 对应飞书云盘 `/CodexApp/agent-cloud/`。
- 云盘 folder token、file token 或路径变化后，更新 `00-start/feishu-drive-mapping.md`。
- 只有执行过真实同步和一致性校验后，才能在映射文档中记录“已同步”结论。
