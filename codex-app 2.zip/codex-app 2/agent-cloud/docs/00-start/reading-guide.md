# agent-cloud 阅读路径

## 新开发者 15 分钟路径

1. `00-start/ai-project-context.md`
2. `00-start/current-status.md`
3. `10-foundation/product/agent-cloud-product-spec.md`
4. `10-foundation/architecture/technical-architecture.md`
5. `10-foundation/architecture/technology-stack.md`
6. `10-foundation/architecture/database-design.md`
7. `20-delivery/execution/execution-spec.md`
8. `20-delivery/execution/engineering-bootstrap-spec.md`
9. `20-delivery/execution/local-dev-runbook.md`
10. `20-delivery/iterations/01-agent-cloud-api-service/master-plan.md`
11. `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/goal.md`
12. `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/task-plan.md`
13. `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/api-contract.md`
14. `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/acceptance-checklist.md`

目标：确认 AgentCloud 只做云端远程 API 服务，不做 Electron UI、不做本地 Agent 执行、不保存设备端私有执行数据。

## 阶段开发路径

1. `00-start/ai-project-context.md`
2. `00-start/current-status.md`
3. `10-foundation/architecture/technology-stack.md`
4. `10-foundation/architecture/database-design.md`
5. `20-delivery/execution/execution-spec.md`
6. `20-delivery/execution/engineering-bootstrap-spec.md`
7. `20-delivery/execution/local-dev-runbook.md`
8. `20-delivery/iterations/01-agent-cloud-api-service/master-plan.md`
9. 当前阶段 `goal.md`
10. 当前阶段 `task-plan.md`
11. 当前阶段 `api-contract.md`
12. 当前阶段 `acceptance-checklist.md`
13. 当前阶段涉及的 API 总览和功能清单。

目标：按 P0 -> P1 -> P2 -> P3 严格顺序推进，不让后续阶段成为前置阶段依赖。

## 数据库创建路径

1. `10-foundation/architecture/database-design.md`
2. `../../db/README.md`
3. `../../db/migrations/`
4. `20-delivery/execution/seed-data-spec.md`
5. `../../db/seed/README.md`

目标：先确认表设计和阶段边界，再按当前阶段执行对应 goose `up-to` 命令和 seed 命令。

## API 开发路径

1. 当前阶段 `api-contract.md`
2. `30-release/cloud-api-spec.md`
3. 当前阶段 `goal.md`
4. `10-foundation/architecture/technical-architecture.md`
5. `10-foundation/architecture/technology-stack.md`
6. `10-foundation/architecture/database-design.md`
7. `20-delivery/execution/execution-spec.md`
8. `20-delivery/iterations/01-agent-cloud-api-service/feature-plan.md`

目标：先遵守统一 `/api/v1`、鉴权、设备头、响应 envelope、错误码、幂等、分页和缓存约定，再实现具体业务接口。

## 协作和安全路径

1. `10-foundation/product/agent-cloud-product-spec.md`
2. `10-foundation/architecture/technical-architecture.md`
3. `30-release/cloud-api-spec.md`
4. `20-delivery/iterations/01-agent-cloud-api-service/master-plan.md`
5. `20-delivery/iterations/01-agent-cloud-api-service/feature-plan.md`

目标：确认账号、组织、项目、成员、设备、连接器授权、第三方 token、审计和计费的责任边界。

## 文档维护路径

1. `docs/README.md`
2. `00-start/doc-governance.md`
3. `00-start/current-status.md`
4. `00-start/feishu-drive-mapping.md`

目标：新增文档先落到正确生命周期目录，避免恢复旧的平铺结构。
