# agent-cloud 当前开发入口

| 项目 | 当前值 |
| --- | --- |
| 当前状态 | 产品、架构、基础技术栈、数据库、API 规格、P0-P3 总阶段规划、各阶段 `goal.md`、P0 任务计划、P0 API 合约、P0 验收清单、本地开发手册和 seed 执行规格已整理；代码实现状态未在本文档集中记录。 |
| 当前开发阶段 | P0 基础能力可以进入开发。 |
| 当前阶段入口 | `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/goal.md` |
| P0 任务计划 | `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/task-plan.md` |
| P0 API 合约 | `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/api-contract.md` |
| P0 验收清单 | `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/acceptance-checklist.md` |
| 总阶段规划 | `20-delivery/iterations/01-agent-cloud-api-service/master-plan.md` |
| 功能清单 | `20-delivery/iterations/01-agent-cloud-api-service/feature-plan.md` |
| 开发执行规格 | `20-delivery/execution/execution-spec.md` |
| 工程启动规格 | `20-delivery/execution/engineering-bootstrap-spec.md` |
| 本地开发运行手册 | `20-delivery/execution/local-dev-runbook.md` |
| Seed 数据执行规格 | `20-delivery/execution/seed-data-spec.md` |
| 产品说明书 | `10-foundation/product/agent-cloud-product-spec.md` |
| 技术架构说明书 | `10-foundation/architecture/technical-architecture.md` |
| 基础技术栈选型 | `10-foundation/architecture/technology-stack.md` |
| 数据库设计说明书 | `10-foundation/architecture/database-design.md` |
| 数据库创建脚本 | `../../db/README.md` |
| Seed 目录说明 | `../../db/seed/README.md` |
| 云端 API 规格 | `30-release/cloud-api-spec.md` |
| 发布就绪检查清单 | `30-release/release-readiness-checklist.md` |
| AI 启动上下文 | `00-start/ai-project-context.md` |
| 更新时间 | 2026-06-24 |

## 当前阶段目标

P0 的目标是让设备端代理服务可以完成登录、刷新 token、注册设备、上报心跳，并拉取账号、模型和套餐基础信息。

## 当前阶段允许做什么

- 实现通用响应、错误码、分页、请求 ID、幂等和条件缓存。
- 实现登录、token 刷新、退出登录和当前账号上下文。
- 实现设备注册、设备心跳、设备列表和解绑。
- 实现内置模型目录、模型供应商预设和模型权益。
- 实现套餐展示和版本化缓存。
- 建立 P0 对应的接口测试、鉴权测试、幂等测试和条件缓存测试。
- 按 `20-delivery/execution/engineering-bootstrap-spec.md` 建立最小 Go 工程和配置。
- 按 `20-delivery/execution/local-dev-runbook.md` 启动本地服务并完成冒烟验证。
- 按 `20-delivery/execution/seed-data-spec.md` 实现并执行 P0 seed。
- 按 P0 时机执行 `../../db/README.md` 中的 goose `up-to 1`。

## 当前阶段禁止做什么

- 不实现 P1 专家、技能、灵感、连接器目录。
- 不实现 P2 项目协作、OAuth、云资料库、资产、分享和审计。
- 不实现 P3 助理网关、自动化、计费闭环、反馈和云记忆。
- 不让 Electron 直接调用 AgentCloud。
- 不把本地 Agent 执行、设备文件树、diff 或预览放进云端。
- 不返回第三方 token 明文。
- 不引入 `10-foundation/architecture/technology-stack.md` 之外的基础技术栈。

## 本阶段必读文档

1. `00-start/ai-project-context.md`
2. `20-delivery/execution/execution-spec.md`
3. `20-delivery/execution/engineering-bootstrap-spec.md`
4. `20-delivery/execution/local-dev-runbook.md`
5. `20-delivery/execution/seed-data-spec.md`
6. `10-foundation/architecture/technology-stack.md`
7. `10-foundation/architecture/database-design.md`
8. `10-foundation/product/agent-cloud-product-spec.md`
9. `10-foundation/architecture/technical-architecture.md`
10. `20-delivery/iterations/01-agent-cloud-api-service/master-plan.md`
11. `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/goal.md`
12. `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/task-plan.md`
13. `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/api-contract.md`
14. `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/acceptance-checklist.md`
15. `30-release/cloud-api-spec.md`

## 进入 P1 门禁

- `CORE-01` 到 `CORE-04` 完成并可测试。
- `AUTH-01` 到 `AUTH-04` 完成并可测试。
- `DEV-01` 到 `DEV-03` 完成并可测试。
- `MODEL-01` 到 `MODEL-03` 完成并可测试。
- `BILL-01` 完成并支持版本化缓存。
- 设备端代理服务可完成登录、刷新 token、注册设备、上报心跳、拉取账号/模型/套餐。
- `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/goal.md` 中的验收方式全部通过。
- `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/acceptance-checklist.md` 全部必选项有证据。
- P0 未引入 P1/P2/P3 的功能依赖。
