# agent-cloud AI 项目上下文

## 一句话定义

`agent-cloud` 是桌面 Agent 体系的云端远程 API 服务。

## 项目目标

- 提供账号、组织、角色、token 和设备身份能力。
- 提供模型、专家、技能、灵感、连接器、自动化模板和套餐等运营动态配置。
- 提供项目协作、云资料库、资产、分享、审计、反馈和跨设备同步能力。
- 承接 OAuth、助理消息、支付等第三方公网回调。
- 为设备端代理服务提供稳定的 HTTPS `/api/v1` REST API。

## 明确非目标

- 不直接服务 Electron Renderer。
- 不让 Electron 保存远程 `accessToken` 或 `refreshToken`。
- 不执行本地 Agent 任务。
- 不访问用户设备文件系统。
- 不提供设备端文件树、文件内容、diff 或预览。
- 不保存用户设备端私有专家、技能草稿或自定义模型 API Key。
- 不提供任意连接器 invoke API 给 Electron。
- 不把本地 Agent runtime、Codex app-server、AgentRuntime 或 `codexapp-go` 的职责写进云端。

## 架构位置

```text
Electron 薄前端
  -> 设备端代理服务
  -> AgentCloud /api/v1
  -> 第三方平台 / 云后台 / 云端 Worker
```

AgentCloud 的主要调用方是设备端代理服务，不是 Electron Renderer。第三方平台通过公网回调进入 AgentCloud，云后台和 Worker 负责运营配置和异步处理。

## 技术边界

| 项目 | 内容 |
| --- | --- |
| API 前缀 | `/api/v1` |
| 传输 | HTTPS |
| 鉴权 | `Authorization: Bearer <accessToken>` |
| 设备识别 | `X-Device-Id` |
| 响应格式 | `data/error/requestId` envelope |
| 写接口 | 支持 `Idempotency-Key` |
| 分页 | `cursor`, `limit` |
| 缓存 | `ETag`、`Last-Modified`、业务 `version` |
| 异步处理 | Webhook 快速返回，重活进入 Queue / Worker |

## 基础技术栈

| 类别 | 选型 |
| --- | --- |
| 服务端 | Go + Gin |
| 数据库 | PostgreSQL + GORM + goose |
| 缓存 | Redis + go-redis |
| Token | JWT access token + opaque refresh token |
| 密码哈希 | bcrypt |
| 配置 | `config.yaml` + 环境变量覆盖 secret |
| 日志 | Go `slog` 结构化日志 |

## AI 启动必读

1. `00-start/current-status.md`
2. `20-delivery/execution/execution-spec.md`
3. `20-delivery/execution/engineering-bootstrap-spec.md`
4. `20-delivery/execution/local-dev-runbook.md`
5. `20-delivery/execution/seed-data-spec.md`
6. `10-foundation/architecture/technology-stack.md`
7. `10-foundation/architecture/database-design.md`
8. `10-foundation/product/agent-cloud-product-spec.md`
9. `10-foundation/architecture/technical-architecture.md`
10. `20-delivery/iterations/01-agent-cloud-api-service/master-plan.md`
11. `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/goal.md`
12. `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/task-plan.md`
13. `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/api-contract.md`
14. `20-delivery/iterations/01-agent-cloud-api-service/p0-core-identity-device-model/acceptance-checklist.md`
15. `30-release/cloud-api-spec.md`

## 常见误解禁止

- 不要把 AgentCloud 写成本地 Agent runtime。
- 不要让 Electron 直接调用 AgentCloud 或保存远程 token。
- 不要把设备端文件、shell、diff、预览、权限确认放进云端。
- 不要在 P0 开发中提前依赖 P1/P2/P3 能力。
- 不要让后续阶段成为前置阶段依赖。
- 不要引入约定外的 Web 框架、数据库、ORM、迁移工具、Redis 客户端、token 方案或日志库。
- 不要把第三方 token 明文返回给设备端或 Electron。
