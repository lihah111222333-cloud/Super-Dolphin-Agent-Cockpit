# 桌面 Agent 云后端远程 API 服务开发文档

整理日期：2026-06-22

定位：本文是 AgentCloud 云端 REST API 的发布规格和接口总览。产品边界以 `../10-foundation/product/agent-cloud-product-spec.md` 为准，技术架构以 `../10-foundation/architecture/technical-architecture.md` 为准，数据库设计以 `../10-foundation/architecture/database-design.md` 为准，阶段执行以 `../20-delivery/execution/execution-spec.md` 和 `../20-delivery/iterations/01-agent-cloud-api-service/master-plan.md` 为准。

核心链路：

```text
Electron 薄前端 -> 设备端代理服务 -> 云后端远程 API
```

云后端不直接服务 Electron Renderer。Electron 不保存远程 access token / refresh token，不直接请求远程 API。所有远程能力由设备端代理服务调用。

## 0. API 覆盖结论

本文覆盖 AgentCloud 对外 API 范围，但不替代产品、架构、数据库和阶段执行文档：

| 范围 | 本文是否覆盖 |
| --- | --- |
| 账号、登录、token、设备 | 覆盖 |
| 模型列表、专家中心、技能市场、灵感、连接器目录、自动化模板、套餐价格 | 覆盖 |
| 项目协作、项目资产、分享、审计 | 覆盖 |
| 连接器 OAuth、云资料库授权、助理网关 | 覆盖 |
| 计费、积分、订单、发票、反馈 | 覆盖 |
| 设备端任务执行、文件树、产物预览、设备端技能执行 | 不覆盖；云端只定义设备交互边界 |

## 1. 边界原则

### 1.1 云后端职责

云后端负责需要账号、协作、运营配置、第三方公网回调、计费和跨设备同步的能力：

- 用户登录、token 刷新、账号资料、组织和角色。
- 设备注册、设备心跳、设备状态。
- 模型列表、模型供应商、模型权益。
- 专家中心、专家分类、专家团。
- 技能市场、技能包下载、技能风险元数据。
- 灵感场景、案例、精选、收藏。
- 连接器目录、OAuth 发起、OAuth 回调、授权状态。
- 云资料库授权、搜索、引用、回写。
- 项目、成员、邀请、审批、项目任务摘要、项目资产。
- 助理平台接入、消息回调、设备下发、结果回传。
- 自动化模板、项目自动化配置。
- 套餐、积分、订单、发票、用量记账。
- 分享文件、反馈、日志附件上传。

### 1.2 云后端不做

| 不做 | 原因 |
| --- | --- |
| 不直接执行本地 Agent 任务 | 文件系统、shell、预览、权限确认属于设备端职责 |
| 不保存用户设备端私有专家 | 云端只管理运营专家；私有专家由设备端自行保存 |
| 不保存用户设备端技能草稿 | 云端只管理市场技能；草稿和设备端上传包由设备端自行保存 |
| 不提供 Electron 专用接口 | 云端 API 面向设备端代理服务和第三方回调 |
| 不保存 Electron session | 云端只识别远程 access token、refresh token、deviceId |
| 不提供 `/task-modes`、`/permission-modes` 这类固定枚举 | 前端常量或调用方共享 schema 即可 |

### 1.3 调用方

| 调用方 | 用途 |
| --- | --- |
| 设备端代理服务 | 主要调用方，代理云端所有远程能力 |
| 第三方平台回调 | OAuth、助理消息、支付回调 |
| 云后台管理端 | 运营模型、专家、技能、灵感、套餐等 |
| 云端定时任务/Worker | 账单、索引、回调重试、消息派发 |

## 2. 通用 API 约定

### 2.1 基础约定

| 项 | 约定 |
| --- | --- |
| API 前缀 | `/api/v1` |
| 传输 | HTTPS |
| 鉴权 | `Authorization: Bearer <accessToken>` |
| 设备头 | `X-Device-Id: dev_xxx` |
| 幂等 | 写接口支持 `Idempotency-Key` |
| 分页 | `cursor`, `limit` |
| 时间 | ISO 8601 |
| 版本缓存 | 优先 `ETag`，其次 `Last-Modified`，再次业务 `version` |

### 2.2 通用响应

```json
{
  "data": {},
  "error": null,
  "requestId": "req_xxx"
}
```

错误响应：

```json
{
  "data": null,
  "error": {
    "code": "UNAUTHORIZED",
    "message": "access token expired",
    "details": {}
  },
  "requestId": "req_xxx"
}
```

### 2.3 通用错误码

| code | 场景 |
| --- | --- |
| `UNAUTHORIZED` | access token 缺失或失效 |
| `TOKEN_REFRESH_FAILED` | refresh token 失效或被撤销 |
| `FORBIDDEN` | 无账号、组织、项目或资源权限 |
| `NOT_FOUND` | 资源不存在 |
| `VALIDATION_FAILED` | 入参错误 |
| `CONFLICT` | 幂等冲突、重复资源、版本冲突 |
| `RATE_LIMITED` | 频控 |
| `PLAN_REQUIRED` | 套餐或权益不足 |
| `DEVICE_OFFLINE` | 目标本地设备离线 |
| `CONNECTOR_AUTH_REQUIRED` | 连接器未授权或授权过期 |
| `PROVIDER_ERROR` | 第三方服务失败 |
| `INTERNAL_ERROR` | 服务端错误 |

### 2.4 缓存响应约定

模型列表、专家中心、技能市场、灵感、连接器目录、自动化模板、套餐价格等动态数据必须返回缓存辅助字段，便于设备端做本地缓存和增量刷新。

建议响应头：

| Header | 用途 |
| --- | --- |
| `ETag` | 调用方下次用 `If-None-Match` 增量刷新 |
| `Last-Modified` | 调用方下次用 `If-Modified-Since` |
| `Cache-Control: max-age=...` | 建议客户端缓存 TTL |

建议响应体补充：

```json
{
  "items": [],
  "version": "v20260622_01",
  "updatedAt": "2026-06-22T08:00:00Z"
}
```

服务端收到条件请求且数据未变化时返回 `304 Not Modified`。

## 3. 云端核心数据对象

本节只描述 API 涉及的核心业务对象。数据库表、字段、索引、唯一约束、外键、软删和阶段建表计划统一见 `../10-foundation/architecture/database-design.md`。

| 数据域 | 核心对象 |
| --- | --- |
| 身份和组织 | 用户、组织、成员关系、refresh token |
| 设备 | 设备注册、心跳、解绑和在线状态 |
| 套餐和模型 | 套餐、模型供应商、模型目录、模型权益 |
| 运营配置 | 专家、专家团、技能、灵感、连接器、自动化模板 |
| 授权和回调 | 连接器授权、云资料库授权、Webhook 事件 |
| 项目协作 | 项目、成员、邀请、任务摘要、协作者、handoff |
| 资产和分享 | 项目资产、分享文件 |
| 计费和反馈 | 积分流水、订单、发票、反馈 |
| 审计 | 项目、连接器、计费和安全相关审计 |

## 4. 登录、token、账号、设备

### 实现逻辑

1. 设备端代理服务调用云端登录接口。
2. 云端校验账号后返回短期 `accessToken`、可轮换 `refreshToken` 和 `user`。
3. 设备端代理服务自行保存远程 token，并自行管理本机 UI 会话。
4. 设备端代理服务调用云端 API 时使用 `accessToken`。
5. `accessToken` 过期后，设备端代理服务用 `refreshToken` 刷新。
6. 云端 refresh token 必须可撤销、可轮换、可按设备失效。

暂不实现扫码登录。

### API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `POST` | `/auth/login` | `account`, `password` 或 `phone`, `code` | `accessToken`, `refreshToken`, `user` | 登录 |
| `POST` | `/auth/refresh` | `refreshToken` | `accessToken`, `refreshToken?` | 刷新 token |
| `POST` | `/auth/logout` | `refreshToken`, `deviceId` | `ok=true` | 退出并撤销 token |
| `GET` | `/account/me` | - | `user`, `org`, `plan`, `roles` | 当前账号上下文 |
| `POST` | `/devices/register` | `deviceName`, `platform`, `appVersion`, `localAgentVersion` | `deviceId`, `deviceToken?` | 注册本地设备 |
| `PATCH` | `/devices/{deviceId}/heartbeat` | `status`, `localEndpointVersion` | `serverTime` | 设备心跳 |
| `GET` | `/devices` | - | `devices[]` | 设备列表 |
| `DELETE` | `/devices/{deviceId}` | - | `deleted=true` | 解绑设备 |

## 5. 模型目录和权益

### 实现逻辑

模型列表不能硬编码到设备端或 Electron。云端按版本、地区、套餐、灰度和组织权限返回模型清单。调用方可缓存结果，但权限判断前应强制刷新或使用极短 TTL。

### API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/models/built-in` | `appVersion`, `orgId` | `models[]`, `version` | 动态内置模型清单 |
| `GET` | `/models/providers` | `region`, `plan` | `providers[]`, `version` | 供应商预设 |
| `GET` | `/models/entitlements` | - | `modelIds[]`, `limits`, `version` | 当前账号可用模型和限制 |

## 6. 专家中心与专家团

### 实现逻辑

云端只管理运营专家和专家团。用户在设备端创建的私有专家不上云。云端专家返回 prompt 策略快照、技能引用和连接器策略，供调用方创建任务时固化快照。

### API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/experts/categories` | - | `categories[]`, `version` | 专家分类 |
| `GET` | `/experts` | `category`, `q`, `cursor` | `experts[]`, `nextCursor`, `version` | 专家中心 |
| `GET` | `/experts/{expertId}` | - | `expert`, `version` | 专家详情和 prompt 策略快照 |
| `GET` | `/expert-teams` | `category`, `q` | `teams[]`, `version` | 专家团列表 |
| `GET` | `/expert-teams/{teamId}` | - | `team`, `members`, `workflow`, `version` | 专家团详情 |

## 7. 技能市场

### 实现逻辑

云端提供技能市场、版本、风险元数据和安装包下载信息。调用方负责下载、验签、解包、扫描和安装。云端不执行设备端技能。

用户本地创建的技能草稿不上云，除非未来单独设计“发布到市场”流程。

### API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/skills/marketplace` | `q`, `category`, `cursor` | `skills[]`, `nextCursor`, `version` | 技能市场 |
| `GET` | `/skills/{skillId}` | - | `skill`, `versions`, `permissions`, `risk`, `version` | 市场技能详情 |
| `POST` | `/skills/{skillId}/install-package` | `version` | `downloadUrl`, `checksum`, `expiresAt` | 获取安装包下载信息 |
| `POST` | `/skills/find` | `taskDescription` | `matches[]` | 根据需求查找技能 |
| `POST` | `/skills/generate` | `taskDescription`, `constraints` | `skillDraft` | 生成技能草稿载荷，调用方保存 |

## 8. 连接器

### 实现逻辑

云端负责连接器目录、OAuth、授权状态、项目级公共连接器和审计。调用方可缓存授权状态，并在 Agent 工具层受控调用连接器。

云端不提供给 Electron 的任意连接器 invoke API。连接器真实调用必须由设备端代理服务或受控云端 provider gateway 发起，并写审计。

### API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/connectors/catalog` | `q`, `category` | `connectors[]`, `version` | 连接器目录 |
| `GET` | `/connectors/{connectorId}` | - | `connector`, `authMethods`, `scopes`, `version` | 连接器详情 |
| `GET` | `/connector-connections` | `scope=personal/project`, `projectId` | `connections[]` | 授权状态 |
| `POST` | `/connectors/{connectorId}/auth/start` | `scope`, `projectId`, `redirectUri` | `authUrl`, `sessionId` | 发起 OAuth |
| `GET` | `/connectors/auth-sessions/{sessionId}` | - | `status`, `connection` | 查询授权状态 |
| `POST` | `/connectors/{connectorId}/auth/callback` | 第三方回调参数 | `ok=true` | OAuth 回调 |
| `POST` | `/connectors/{connectorId}/test` | `connectionId` | `ok`, `error` | 云端连通测试 |
| `GET` | `/connector-connections/{connectionId}/audit-logs` | `cursor`, `limit` | `logs[]`, `nextCursor` | 审计日志 |
| `POST` | `/connectors/custom` | `name`, `mcpConfig`, `scope`, `projectId` | `connector` | 项目级自定义连接器 |
| `PATCH` | `/connectors/custom/{connectorId}` | `name`, `mcpConfig` | `connector` | 修改项目级连接器 |
| `DELETE` | `/connectors/custom/{connectorId}` | - | `deleted=true` | 删除项目级连接器 |

## 9. 云资料库

### 实现逻辑

云端负责腾讯文档、ima、乐享等云资料库授权、搜索、引用载荷生成和产物回写。调用方只保存引用快照，执行任务时按需向云端拉取摘要或内容。

第三方 token 不返回给调用方明文，云端通过凭证引用或内部凭证管理调用 provider。

### API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/knowledge-sources` | - | `sources[]` | 已接入资料库 |
| `POST` | `/knowledge-sources/{provider}/auth/start` | `redirectUri` | `authUrl`, `sessionId` | 发起授权 |
| `DELETE` | `/knowledge-sources/{provider}/binding` | - | `deleted=true` | 解除绑定 |
| `GET` | `/knowledge-sources/{provider}/spaces` | `cursor` | `spaces[]`, `nextCursor` | 空间/知识库列表 |
| `GET` | `/knowledge-sources/{provider}/files` | `q`, `owner`, `spaceId`, `fileType`, `cursor` | `files[]`, `nextCursor` | 搜索文件 |
| `GET` | `/knowledge-sources/{provider}/files/{fileId}` | - | `file`, `preview` | 文件详情 |
| `POST` | `/knowledge-sources/{provider}/files/{fileId}/references` | `taskId`, `deviceId` | `contextRefPayload` | 生成本地引用载荷 |
| `POST` | `/artifacts/{artifactId}/upload-to-cloud` | `provider`, `targetFolderId`, `title`, `deviceId` | `externalFile` | 产物回写 |

## 10. 项目与团队协作

### 实现逻辑

项目协作是云端能力。云端保存项目、成员、邀请、审批、项目资产、项目任务摘要和协作动态。具体 Agent 执行仍发生在本地设备；云端只下发任务或接收摘要。

### API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/projects` | `q`, `cursor` | `projects[]`, `nextCursor` | 我的项目 |
| `POST` | `/projects` | `name`, `instructions`, `connectorIds`, `skillIds`, `expertIds`, `templateId` | `project` | 创建项目 |
| `GET` | `/projects/{projectId}` | - | `project` | 项目详情 |
| `PATCH` | `/projects/{projectId}` | `name`, `instructions` | `project` | 更新项目 |
| `DELETE` | `/projects/{projectId}` | - | `deleted=true` | 删除/退出 |
| `GET` | `/project-templates` | `scene` | `templates[]`, `version` | 项目模板 |
| `GET` | `/projects/{projectId}/activity` | `type`, `cursor` | `activities[]`, `nextCursor` | 项目动态 |
| `GET` | `/projects/{projectId}/members` | `role` | `members[]` | 成员 |
| `POST` | `/projects/{projectId}/invites` | `role` | `inviteUrl`, `inviteId` | 邀请 |
| `POST` | `/project-invites/{inviteId}/apply` | `remark` | `requestId` | 申请加入 |
| `POST` | `/project-join-requests/{requestId}/approve` | `role` | `member` | 审批通过 |
| `POST` | `/project-join-requests/{requestId}/reject` | `reason` | `rejected=true` | 拒绝 |
| `POST` | `/projects/{projectId}/tasks` | `prompt`, `deviceId`, `metadata` | `projectTask`, `dispatch` | 创建项目任务并下发设备 |
| `GET` | `/projects/{projectId}/tasks` | `q`, `status`, `cursor` | `tasks[]`, `nextCursor` | 项目任务列表 |
| `PATCH` | `/projects/{projectId}/tasks/{taskId}` | `status`, `summary`, `localTaskId` | `projectTask` | 同步任务摘要 |
| `POST` | `/tasks/{taskId}/collaborators` | `memberIds`, `role` | `collaborators[]` | 分享任务 |
| `POST` | `/tasks/{taskId}/handoffs` | `assigneeId`, `title`, `description`, `status`, `dueAt`, `attachments` | `handoff` | 任务流转 |
| `POST` | `/handoffs/{handoffId}/accept` | `targetProjectId` | `task` | 接收流转 |

### 项目资产 API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/projects/{projectId}/assets` | `q`, `fileType`, `cursor` | `assets[]`, `nextCursor` | 资产列表 |
| `POST` | `/projects/{projectId}/assets` | `file`, `tags` | `asset` | 上传资产 |
| `GET` | `/projects/{projectId}/assets/{assetId}` | - | `asset`, `preview` | 资产详情 |
| `DELETE` | `/projects/{projectId}/assets/{assetId}` | - | `deleted=true` | 删除资产 |
| `GET` | `/projects/{projectId}/assets/quota` | - | `usedBytes`, `limitBytes` | 配额 |
| `POST` | `/artifacts/{artifactId}/save-to-project-assets` | `projectId`, `folderId`, `deviceId` | `asset` | 保存产物为项目资产 |

## 11. 助理与远程任务

### 实现逻辑

云端负责平台接入、回调验签、消息归一化、设备路由、消息下发和结果回传。设备端代理服务负责实际执行。

暂不实现扫码绑定类业务。

### API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/assistant/integrations` | - | `integrations[]` | 平台状态 |
| `POST` | `/assistant/integrations/{platform}/register` | 平台凭据、`mode`, `deviceId` | `integration`, `webhookUrl` | 平台注册 |
| `DELETE` | `/assistant/integrations/{platform}` | - | `deleted=true` | 解绑 |
| `POST` | `/assistant/callbacks/{platform}` | 第三方消息体 | `ok=true` | 消息/卡片/事件回调 |
| `POST` | `/assistant/dispatch` | `deviceId`, `platform`, `message` | `dispatchId` | 云端下发本地设备 |
| `POST` | `/assistant/replies` | `platform`, `remoteConversationId`, `content`, `attachments` | `sent=true` | 本地执行结果回传平台 |

## 12. 自动化模板和项目自动化

### 实现逻辑

个人设备端自动化由设备端自行调度。云端负责可运营更新的模板，以及项目级自动化配置。项目自动化触发时，云端选择目标设备并下发任务。

### API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/automation-templates` | `scene` | `templates[]`, `version` | 动态模板 |
| `GET` | `/projects/{projectId}/automations` | `status`, `cursor` | `automations[]`, `nextCursor` | 项目自动化 |
| `POST` | `/projects/{projectId}/automations` | `name`, `prompt`, `schedule`, `deviceId`, `connectorIds` | `automation` | 创建项目自动化 |
| `PATCH` | `/projects/{projectId}/automations/{automationId}` | 可选字段、`status` | `automation` | 编辑/启停 |
| `DELETE` | `/projects/{projectId}/automations/{automationId}` | - | `deleted=true` | 删除 |

## 13. 灵感场景和案例

### 实现逻辑

灵感是运营内容，云端负责分类、精选、搜索、收藏和“制作同款”的草稿载荷生成。调用方拿到草稿载荷后创建任务草稿。

### API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/inspirations/categories` | - | `categories[]`, `version` | 动态场景 |
| `GET` | `/inspirations` | `q`, `category`, `featured`, `cursor` | `items[]`, `nextCursor`, `version` | 案例列表 |
| `GET` | `/inspirations/{inspirationId}` | - | `inspiration`, `promptTemplate`, `skillIds`, `expertIds` | 案例详情 |
| `POST` | `/inspirations/{inspirationId}/favorite` | - | `favorited=true` | 收藏 |
| `DELETE` | `/inspirations/{inspirationId}/favorite` | - | `favorited=false` | 取消收藏 |
| `POST` | `/inspirations/{inspirationId}/clone` | `mode=draft`, `deviceId`, `overrides` | `taskDraftPayload` | 生成本地草稿载荷 |

## 14. 云记忆同步

### 实现逻辑

记忆可以只存在设备端。如果需要跨设备个性化，云端提供同名 CRUD 和检索接口。调用方决定是否开启云同步，并自行处理失败重试。

### API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/memory/settings` | - | `enabled`, `scope` | 云端记忆设置 |
| `PATCH` | `/memory/settings` | `enabled`, `scope` | `settings` | 更新 |
| `GET` | `/memories` | `q`, `cursor` | `memories[]`, `nextCursor` | 云端记忆 |
| `POST` | `/memories` | `content`, `tags` | `memory` | 新增 |
| `PATCH` | `/memories/{memoryId}` | `content`, `tags`, `enabled` | `memory` | 编辑 |
| `DELETE` | `/memories/{memoryId}` | - | `deleted=true` | 删除 |
| `POST` | `/memories/import` | `content`, `source` | `imported[]` | 导入 |
| `GET` | `/memories/search` | `q`, `limit` | `memories[]` | 检索 |

## 15. 分享、数据管理、反馈

### 实现逻辑

云端负责公网分享、下载、取消分享、反馈提交和日志附件。日志由调用方先脱敏打包，云端只接收脱敏后的 bundle。

### API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `POST` | `/artifacts/{artifactId}/share` | `expiresAt`, `accessScope`, `deviceId` | `shareId`, `url` | 上传并生成公网分享 |
| `GET` | `/data/shared-files` | `cursor` | `files[]`, `nextCursor` | 我分享的文件 |
| `POST` | `/data/shared-files/{shareId}/copy-link` | - | `url` | 复制/刷新分享链接 |
| `GET` | `/data/shared-files/{shareId}/download` | - | 文件流或 URL | 下载 |
| `DELETE` | `/data/shared-files/{shareId}` | - | `deleted=true` | 取消分享 |
| `POST` | `/feedback` | `content`, `uploadLogs`, `attachmentIds`, `logBundleId` | `feedbackId` | 提交反馈 |
| `POST` | `/feedback/{feedbackId}/attachments` | `file` | `attachment` | 附件上传 |

## 16. 套餐、积分、订单、发票、用量

### 实现逻辑

套餐价格、积分规则、模型权益和最终扣费都以云端为准。调用方可缓存套餐展示，但购买、扣费、权限判断前必须请求云端或使用极短 TTL。

### API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `GET` | `/plans` | `audience=personal/enterprise` | `plans[]`, `version` | 套餐和价格 |
| `GET` | `/credits/balance` | - | `balance`, `packages[]` | 余额 |
| `GET` | `/credits/usage` | `dateFrom`, `dateTo`, `cursor` | `usage[]`, `nextCursor` | 用量 |
| `POST` | `/usage/ledger` | `taskId`, `runId`, `modelTokens`, `credits`, `source` | `ledgerId` | 服务端内部记账 |
| `GET` | `/orders` | `cursor` | `orders[]`, `nextCursor` | 订单 |
| `GET` | `/invoices` | `cursor` | `invoices[]`, `externalConsoleUrl` | 发票 |
| `POST` | `/checkout/packages` | `packageId`, `quantity` | `checkoutUrl`, `orderId` | 购买 |

## 17. 审计和动作同步

### 实现逻辑

设备端任务执行审计先由设备端自行保存。需要上云的动作由调用方通过远程 token 写入云端。云端只保存协作、公共连接器、计费、安全相关审计，不强制保存所有设备端私有任务明细。

### API

| 方法 | 路径 | 入参 | 返回 | 说明 |
| --- | --- | --- | --- | --- |
| `POST` | `/audit/runtime-actions` | `projectId`, `taskId`, `action`, `result` | `logId` | 项目/公共连接器审计同步 |
| `GET` | `/projects/{projectId}/connector-audit-logs` | `cursor`, `limit` | `logs[]`, `nextCursor` | 公共授权连接器审计 |

## 18. Webhook 和回调

### 实现逻辑

第三方回调只能打到云端。云端完成验签、去重、落库和异步处理，再按设备路由下发给设备端代理服务。

回调接口必须：

- 校验 provider 签名。
- 使用事件 ID 做幂等。
- 快速返回，重活进入队列。
- 记录原始回调摘要和处理结果。

### 回调入口

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| `POST` | `/connectors/{connectorId}/auth/callback` | OAuth 回调 |
| `POST` | `/assistant/callbacks/{platform}` | 助理平台消息回调 |
| `POST` | `/payments/callbacks/{provider}` | 支付回调 |

## 19. 最小落地边界

| 阶段 | 云后端必须有 | 可后置 |
| --- | --- | --- |
| P0 | 登录、refresh token、账号信息、设备注册、模型目录、套餐展示 | 项目协作、助理、连接器 |
| P1 | 技能市场、专家中心、灵感、连接器目录、连接器 OAuth、Webhook 基础设施 | P2 资料库能力、复杂审批、发票 |
| P2 | 云资料库授权、项目、成员、项目任务摘要、项目资产、分享、审计 | 企业高级权限 |
| P3 | 助理网关、项目自动化、计费闭环、反馈、云记忆同步 | 运营后台高级能力 |

## 20. 明确不进入云端的内容

| 内容 | 处理方式 |
| --- | --- |
| 设备端任务完整执行过程 | 设备端自行保存；云端只收项目摘要或审计 |
| 设备端文件树、文件内容、diff、预览 | 设备端自行实现 |
| 用户在设备端创建的私有专家 | 设备端自行保存 |
| 设备端技能草稿、设备端上传技能包 | 设备端自行保存 |
| 自定义模型 API Key | 设备端自行加密保存 |
| Electron 设备端 session token | 设备端代理服务自行签发和校验，云端不定义 |
| 固定 UI 枚举 | 前端常量或共享 schema |
