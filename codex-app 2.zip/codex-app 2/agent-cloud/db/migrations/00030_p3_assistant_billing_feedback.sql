-- +goose Up
CREATE TABLE assistant_integrations (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    platform text NOT NULL,
    org_id uuid NOT NULL REFERENCES orgs(id),
    device_id uuid REFERENCES devices(id),
    credential_ref text NOT NULL,
    webhook_url text NOT NULL,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE UNIQUE INDEX ux_assistant_integrations_org_platform ON assistant_integrations (org_id, platform) WHERE deleted_at IS NULL;
CREATE INDEX idx_assistant_integrations_device_id ON assistant_integrations (device_id);

CREATE TABLE assistant_dispatches (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    integration_id uuid NOT NULL REFERENCES assistant_integrations(id),
    device_id uuid REFERENCES devices(id),
    platform text NOT NULL,
    message jsonb NOT NULL DEFAULT '{}'::jsonb,
    status text NOT NULL,
    reply jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_assistant_dispatches_integration_created ON assistant_dispatches (integration_id, created_at);
CREATE INDEX idx_assistant_dispatches_device_status ON assistant_dispatches (device_id, status);

CREATE TABLE automation_templates (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    scene text NOT NULL,
    name text NOT NULL,
    prompt_template jsonb NOT NULL DEFAULT '{}'::jsonb,
    schedule_preset jsonb NOT NULL DEFAULT '{}'::jsonb,
    version text NOT NULL,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE INDEX idx_automation_templates_scene_status ON automation_templates (scene, status);
CREATE INDEX idx_automation_templates_version ON automation_templates (version);

CREATE TABLE project_automations (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id uuid NOT NULL REFERENCES projects(id),
    template_id uuid REFERENCES automation_templates(id),
    device_id uuid REFERENCES devices(id),
    name text NOT NULL,
    prompt text NOT NULL,
    schedule jsonb NOT NULL DEFAULT '{}'::jsonb,
    connector_ids jsonb,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE INDEX idx_project_automations_project_status ON project_automations (project_id, status);
CREATE INDEX idx_project_automations_device_id ON project_automations (device_id);

CREATE TABLE credit_ledgers (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid REFERENCES users(id),
    org_id uuid REFERENCES orgs(id),
    amount bigint NOT NULL,
    reason text NOT NULL,
    task_id uuid,
    idempotency_key text NOT NULL,
    metadata jsonb,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX ux_credit_ledgers_idempotency_key ON credit_ledgers (idempotency_key);
CREATE INDEX idx_credit_ledgers_user_created ON credit_ledgers (user_id, created_at);
CREATE INDEX idx_credit_ledgers_org_created ON credit_ledgers (org_id, created_at);

CREATE TABLE orders (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES users(id),
    org_id uuid REFERENCES orgs(id),
    plan_id uuid NOT NULL REFERENCES plans(id),
    provider text NOT NULL,
    provider_order_id text,
    amount numeric(12,2) NOT NULL,
    currency text NOT NULL,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX ux_orders_provider_order ON orders (provider, provider_order_id) WHERE provider_order_id IS NOT NULL;
CREATE INDEX idx_orders_user_created ON orders (user_id, created_at);
CREATE INDEX idx_orders_status ON orders (status);

CREATE TABLE invoices (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id uuid NOT NULL REFERENCES orders(id),
    external_url text,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_invoices_order_id ON invoices (order_id);
CREATE INDEX idx_invoices_status ON invoices (status);

CREATE TABLE memory_settings (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    scope_type text NOT NULL,
    scope_id uuid NOT NULL,
    enabled boolean NOT NULL DEFAULT false,
    settings jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX ux_memory_settings_scope ON memory_settings (scope_type, scope_id);

CREATE TABLE memories (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES users(id),
    org_id uuid REFERENCES orgs(id),
    content text NOT NULL,
    metadata jsonb,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE INDEX idx_memories_user_created ON memories (user_id, created_at);
CREATE INDEX idx_memories_org_id ON memories (org_id);

CREATE TABLE feedback (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES users(id),
    content text NOT NULL,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_feedback_user_created ON feedback (user_id, created_at);
CREATE INDEX idx_feedback_status ON feedback (status);

CREATE TABLE feedback_attachments (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    feedback_id uuid NOT NULL REFERENCES feedback(id),
    storage_key text NOT NULL,
    file_name text NOT NULL,
    file_size bigint NOT NULL,
    content_type text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_feedback_attachments_feedback_id ON feedback_attachments (feedback_id);

-- +goose Down
DROP TABLE IF EXISTS feedback_attachments;
DROP TABLE IF EXISTS feedback;
DROP TABLE IF EXISTS memories;
DROP TABLE IF EXISTS memory_settings;
DROP TABLE IF EXISTS invoices;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS credit_ledgers;
DROP TABLE IF EXISTS project_automations;
DROP TABLE IF EXISTS automation_templates;
DROP TABLE IF EXISTS assistant_dispatches;
DROP TABLE IF EXISTS assistant_integrations;
