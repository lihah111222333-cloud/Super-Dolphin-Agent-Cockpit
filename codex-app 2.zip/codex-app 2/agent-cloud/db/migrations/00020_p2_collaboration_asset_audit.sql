-- +goose Up
CREATE TABLE knowledge_source_bindings (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    provider text NOT NULL,
    user_id uuid NOT NULL REFERENCES users(id),
    token_ref text NOT NULL,
    status text NOT NULL,
    expires_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE UNIQUE INDEX ux_knowledge_source_bindings_user_provider ON knowledge_source_bindings (user_id, provider) WHERE deleted_at IS NULL;
CREATE INDEX idx_knowledge_source_bindings_status ON knowledge_source_bindings (status);

CREATE TABLE projects (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id uuid NOT NULL REFERENCES orgs(id),
    name text NOT NULL,
    instructions text,
    status text NOT NULL,
    created_by uuid NOT NULL REFERENCES users(id),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE INDEX idx_projects_org_status ON projects (org_id, status);
CREATE INDEX idx_projects_created_by ON projects (created_by);

CREATE TABLE project_members (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id uuid NOT NULL REFERENCES projects(id),
    user_id uuid NOT NULL REFERENCES users(id),
    role text NOT NULL,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE UNIQUE INDEX ux_project_members_project_user ON project_members (project_id, user_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_project_members_user_id ON project_members (user_id);

CREATE TABLE project_invites (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id uuid NOT NULL REFERENCES projects(id),
    inviter_id uuid NOT NULL REFERENCES users(id),
    invitee_account text,
    role text NOT NULL,
    token_hash text NOT NULL,
    status text NOT NULL,
    expires_at timestamptz NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX ux_project_invites_token_hash ON project_invites (token_hash);
CREATE INDEX idx_project_invites_project_status ON project_invites (project_id, status);

CREATE TABLE project_join_requests (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id uuid NOT NULL REFERENCES projects(id),
    user_id uuid NOT NULL REFERENCES users(id),
    status text NOT NULL,
    reviewer_id uuid REFERENCES users(id),
    reviewed_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX ux_project_join_requests_open ON project_join_requests (project_id, user_id, status);
CREATE INDEX idx_project_join_requests_project_status ON project_join_requests (project_id, status);

CREATE TABLE project_tasks (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id uuid NOT NULL REFERENCES projects(id),
    local_task_id text,
    device_id uuid REFERENCES devices(id),
    creator_id uuid NOT NULL REFERENCES users(id),
    status text NOT NULL,
    summary jsonb,
    dispatch jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE INDEX idx_project_tasks_project_status ON project_tasks (project_id, status);
CREATE INDEX idx_project_tasks_device_id ON project_tasks (device_id);
CREATE INDEX idx_project_tasks_local_task_id ON project_tasks (local_task_id);

CREATE TABLE project_templates (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name text NOT NULL,
    description text,
    instructions text,
    metadata jsonb,
    version text NOT NULL,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE INDEX idx_project_templates_status_version ON project_templates (status, version);

CREATE TABLE project_activities (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id uuid NOT NULL REFERENCES projects(id),
    actor_id uuid REFERENCES users(id),
    activity_type text NOT NULL,
    resource_type text,
    resource_id uuid,
    metadata jsonb,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_project_activities_project_created ON project_activities (project_id, created_at);
CREATE INDEX idx_project_activities_actor_created ON project_activities (actor_id, created_at);

CREATE TABLE task_collaborators (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id uuid NOT NULL REFERENCES project_tasks(id),
    user_id uuid NOT NULL REFERENCES users(id),
    role text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX ux_task_collaborators_task_user ON task_collaborators (task_id, user_id);
CREATE INDEX idx_task_collaborators_user_id ON task_collaborators (user_id);

CREATE TABLE task_handoffs (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id uuid NOT NULL REFERENCES project_tasks(id),
    from_user_id uuid NOT NULL REFERENCES users(id),
    to_user_id uuid NOT NULL REFERENCES users(id),
    target_project_id uuid REFERENCES projects(id),
    status text NOT NULL,
    accepted_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_task_handoffs_task_id ON task_handoffs (task_id);
CREATE INDEX idx_task_handoffs_to_user_status ON task_handoffs (to_user_id, status);

CREATE TABLE project_assets (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id uuid NOT NULL REFERENCES projects(id),
    name text NOT NULL,
    file_type text NOT NULL,
    storage_key text NOT NULL,
    size_bytes bigint NOT NULL,
    owner_id uuid NOT NULL REFERENCES users(id),
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE INDEX idx_project_assets_project_id ON project_assets (project_id);
CREATE INDEX idx_project_assets_owner_id ON project_assets (owner_id);
CREATE INDEX idx_project_assets_storage_key ON project_assets (storage_key);

CREATE TABLE shared_files (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id uuid NOT NULL REFERENCES users(id),
    asset_id uuid REFERENCES project_assets(id),
    storage_key text NOT NULL,
    url text NOT NULL,
    access_scope text NOT NULL,
    expires_at timestamptz,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE INDEX idx_shared_files_owner_id ON shared_files (owner_id);
CREATE INDEX idx_shared_files_asset_id ON shared_files (asset_id);
CREATE INDEX idx_shared_files_expires_at ON shared_files (expires_at);

CREATE TABLE audit_logs (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id uuid REFERENCES orgs(id),
    project_id uuid REFERENCES projects(id),
    actor_id uuid REFERENCES users(id),
    action text NOT NULL,
    resource_type text NOT NULL,
    resource_id uuid,
    result text NOT NULL,
    metadata jsonb,
    created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_audit_logs_org_created ON audit_logs (org_id, created_at);
CREATE INDEX idx_audit_logs_project_created ON audit_logs (project_id, created_at);
CREATE INDEX idx_audit_logs_actor_created ON audit_logs (actor_id, created_at);

-- +goose Down
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS shared_files;
DROP TABLE IF EXISTS project_assets;
DROP TABLE IF EXISTS task_handoffs;
DROP TABLE IF EXISTS task_collaborators;
DROP TABLE IF EXISTS project_activities;
DROP TABLE IF EXISTS project_templates;
DROP TABLE IF EXISTS project_tasks;
DROP TABLE IF EXISTS project_join_requests;
DROP TABLE IF EXISTS project_invites;
DROP TABLE IF EXISTS project_members;
DROP TABLE IF EXISTS projects;
DROP TABLE IF EXISTS knowledge_source_bindings;
