-- +goose Up
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE users (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    account text NOT NULL,
    phone text,
    email text,
    password_hash text NOT NULL,
    display_name text NOT NULL,
    avatar_url text,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE UNIQUE INDEX ux_users_account ON users (account);
CREATE UNIQUE INDEX ux_users_phone ON users (phone) WHERE phone IS NOT NULL;
CREATE UNIQUE INDEX ux_users_email ON users (email) WHERE email IS NOT NULL;
CREATE INDEX idx_users_status ON users (status);

CREATE TABLE plans (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    code text NOT NULL,
    name text NOT NULL,
    audience text NOT NULL,
    price numeric(12,2) NOT NULL,
    currency text NOT NULL,
    features jsonb NOT NULL DEFAULT '{}'::jsonb,
    limits jsonb NOT NULL DEFAULT '{}'::jsonb,
    version text NOT NULL,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE UNIQUE INDEX ux_plans_code ON plans (code);
CREATE INDEX idx_plans_audience_status ON plans (audience, status);
CREATE INDEX idx_plans_version ON plans (version);

CREATE TABLE orgs (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name text NOT NULL,
    plan_id uuid REFERENCES plans(id),
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE INDEX idx_orgs_plan_id ON orgs (plan_id);
CREATE INDEX idx_orgs_status ON orgs (status);

CREATE TABLE memberships (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES users(id),
    org_id uuid NOT NULL REFERENCES orgs(id),
    role text NOT NULL,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE UNIQUE INDEX ux_memberships_user_org ON memberships (user_id, org_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_memberships_org_role ON memberships (org_id, role);

CREATE TABLE devices (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES users(id),
    org_id uuid NOT NULL REFERENCES orgs(id),
    name text NOT NULL,
    platform text NOT NULL,
    app_version text,
    local_agent_version text,
    local_endpoint_version text,
    status text NOT NULL,
    last_seen_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE INDEX idx_devices_user_id ON devices (user_id);
CREATE INDEX idx_devices_org_id ON devices (org_id);
CREATE INDEX idx_devices_status_last_seen ON devices (status, last_seen_at);

CREATE TABLE refresh_tokens (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES users(id),
    device_id uuid REFERENCES devices(id),
    token_hash text NOT NULL,
    family_id uuid NOT NULL,
    expires_at timestamptz NOT NULL,
    revoked_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX ux_refresh_tokens_hash ON refresh_tokens (token_hash);
CREATE INDEX idx_refresh_tokens_user_id ON refresh_tokens (user_id);
CREATE INDEX idx_refresh_tokens_device_id ON refresh_tokens (device_id);
CREATE INDEX idx_refresh_tokens_family_id ON refresh_tokens (family_id);
CREATE INDEX idx_refresh_tokens_expires_at ON refresh_tokens (expires_at);

CREATE TABLE model_providers (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    code text NOT NULL,
    name text NOT NULL,
    regions jsonb NOT NULL DEFAULT '[]'::jsonb,
    capabilities jsonb NOT NULL DEFAULT '[]'::jsonb,
    version text NOT NULL,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE UNIQUE INDEX ux_model_providers_code ON model_providers (code);
CREATE INDEX idx_model_providers_status ON model_providers (status);

CREATE TABLE model_catalog_items (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    provider_id uuid NOT NULL REFERENCES model_providers(id),
    model_name text NOT NULL,
    display_name text NOT NULL,
    capabilities jsonb NOT NULL DEFAULT '[]'::jsonb,
    regions jsonb NOT NULL DEFAULT '[]'::jsonb,
    plan_rules jsonb NOT NULL DEFAULT '{}'::jsonb,
    version text NOT NULL,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE UNIQUE INDEX ux_model_catalog_provider_model ON model_catalog_items (provider_id, model_name) WHERE deleted_at IS NULL;
CREATE INDEX idx_model_catalog_status_version ON model_catalog_items (status, version);

CREATE TABLE model_entitlements (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    scope_type text NOT NULL,
    scope_id uuid NOT NULL,
    plan_id uuid REFERENCES plans(id),
    model_id uuid NOT NULL REFERENCES model_catalog_items(id),
    limits jsonb NOT NULL DEFAULT '{}'::jsonb,
    version text NOT NULL,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE UNIQUE INDEX ux_model_entitlements_scope_model ON model_entitlements (scope_type, scope_id, model_id) WHERE deleted_at IS NULL;
CREATE INDEX idx_model_entitlements_plan_id ON model_entitlements (plan_id);

CREATE TABLE idempotency_keys (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    scope text NOT NULL,
    key text NOT NULL,
    request_hash text NOT NULL,
    response_status integer,
    response_body jsonb,
    expires_at timestamptz NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX ux_idempotency_scope_key ON idempotency_keys (scope, key);
CREATE INDEX idx_idempotency_expires_at ON idempotency_keys (expires_at);

-- +goose Down
DROP TABLE IF EXISTS idempotency_keys;
DROP TABLE IF EXISTS model_entitlements;
DROP TABLE IF EXISTS model_catalog_items;
DROP TABLE IF EXISTS model_providers;
DROP TABLE IF EXISTS refresh_tokens;
DROP TABLE IF EXISTS devices;
DROP TABLE IF EXISTS memberships;
DROP TABLE IF EXISTS orgs;
DROP TABLE IF EXISTS plans;
DROP TABLE IF EXISTS users;
