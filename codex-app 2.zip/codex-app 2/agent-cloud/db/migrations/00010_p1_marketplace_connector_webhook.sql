-- +goose Up
CREATE TABLE webhook_events (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    provider text NOT NULL,
    event_id text NOT NULL,
    event_type text NOT NULL,
    payload jsonb NOT NULL DEFAULT '{}'::jsonb,
    status text NOT NULL,
    processed_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX ux_webhook_events_provider_event ON webhook_events (provider, event_id);
CREATE INDEX idx_webhook_events_status_created ON webhook_events (status, created_at);

CREATE TABLE expert_categories (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    code text NOT NULL,
    name text NOT NULL,
    sort_order integer NOT NULL DEFAULT 0,
    version text NOT NULL,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE UNIQUE INDEX ux_expert_categories_code ON expert_categories (code);
CREATE INDEX idx_expert_categories_status_sort ON expert_categories (status, sort_order);

CREATE TABLE experts (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    category_id uuid REFERENCES expert_categories(id),
    name text NOT NULL,
    description text,
    prompt_snapshot jsonb NOT NULL DEFAULT '{}'::jsonb,
    skill_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
    connector_policy jsonb NOT NULL DEFAULT '{}'::jsonb,
    version text NOT NULL,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE INDEX idx_experts_category_status ON experts (category_id, status);
CREATE INDEX idx_experts_version ON experts (version);

CREATE TABLE expert_teams (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    name text NOT NULL,
    description text,
    workflow jsonb NOT NULL DEFAULT '{}'::jsonb,
    version text NOT NULL,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE INDEX idx_expert_teams_status_version ON expert_teams (status, version);

CREATE TABLE expert_team_members (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    team_id uuid NOT NULL REFERENCES expert_teams(id),
    expert_id uuid NOT NULL REFERENCES experts(id),
    role text,
    sort_order integer NOT NULL DEFAULT 0,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX ux_expert_team_members_team_expert ON expert_team_members (team_id, expert_id);
CREATE INDEX idx_expert_team_members_team_sort ON expert_team_members (team_id, sort_order);

CREATE TABLE skill_categories (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    code text NOT NULL,
    name text NOT NULL,
    sort_order integer NOT NULL DEFAULT 0,
    version text NOT NULL,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE UNIQUE INDEX ux_skill_categories_code ON skill_categories (code);
CREATE INDEX idx_skill_categories_status_sort ON skill_categories (status, sort_order);

CREATE TABLE skills (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    category_id uuid REFERENCES skill_categories(id),
    name text NOT NULL,
    description text,
    permissions jsonb NOT NULL DEFAULT '{}'::jsonb,
    risk jsonb NOT NULL DEFAULT '{}'::jsonb,
    latest_version text NOT NULL,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE INDEX idx_skills_category_status ON skills (category_id, status);
CREATE INDEX idx_skills_name ON skills (name);

CREATE TABLE skill_versions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    skill_id uuid NOT NULL REFERENCES skills(id),
    version text NOT NULL,
    package_key text NOT NULL,
    checksum text NOT NULL,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX ux_skill_versions_skill_version ON skill_versions (skill_id, version);
CREATE INDEX idx_skill_versions_status ON skill_versions (status);

CREATE TABLE inspiration_categories (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    code text NOT NULL,
    name text NOT NULL,
    sort_order integer NOT NULL DEFAULT 0,
    version text NOT NULL,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE UNIQUE INDEX ux_inspiration_categories_code ON inspiration_categories (code);
CREATE INDEX idx_inspiration_categories_status_sort ON inspiration_categories (status, sort_order);

CREATE TABLE inspirations (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    category_id uuid REFERENCES inspiration_categories(id),
    title text NOT NULL,
    description text,
    prompt_template jsonb NOT NULL DEFAULT '{}'::jsonb,
    skill_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
    expert_ids jsonb NOT NULL DEFAULT '[]'::jsonb,
    featured boolean NOT NULL DEFAULT false,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE INDEX idx_inspirations_category_status ON inspirations (category_id, status);
CREATE INDEX idx_inspirations_featured ON inspirations (featured);

CREATE TABLE inspiration_favorites (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL REFERENCES users(id),
    inspiration_id uuid NOT NULL REFERENCES inspirations(id),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX ux_inspiration_favorites_user_inspiration ON inspiration_favorites (user_id, inspiration_id);
CREATE INDEX idx_inspiration_favorites_user_id ON inspiration_favorites (user_id);

CREATE TABLE connectors (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    code text NOT NULL,
    name text NOT NULL,
    category text,
    auth_methods jsonb NOT NULL DEFAULT '[]'::jsonb,
    scopes jsonb NOT NULL DEFAULT '[]'::jsonb,
    version text NOT NULL,
    status text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE UNIQUE INDEX ux_connectors_code ON connectors (code);
CREATE INDEX idx_connectors_category_status ON connectors (category, status);

CREATE TABLE connector_auth_sessions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    connector_id uuid NOT NULL REFERENCES connectors(id),
    user_id uuid NOT NULL REFERENCES users(id),
    project_id uuid,
    state_hash text NOT NULL,
    scopes jsonb NOT NULL DEFAULT '[]'::jsonb,
    status text NOT NULL,
    expires_at timestamptz NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX ux_connector_auth_sessions_state_hash ON connector_auth_sessions (state_hash);
CREATE INDEX idx_connector_auth_sessions_user_id ON connector_auth_sessions (user_id);
CREATE INDEX idx_connector_auth_sessions_expires_at ON connector_auth_sessions (expires_at);

CREATE TABLE connector_connections (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    connector_id uuid NOT NULL REFERENCES connectors(id),
    scope_type text NOT NULL,
    user_id uuid REFERENCES users(id),
    project_id uuid,
    token_ref text NOT NULL,
    scopes jsonb NOT NULL DEFAULT '[]'::jsonb,
    status text NOT NULL,
    expires_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    deleted_at timestamptz
);

CREATE UNIQUE INDEX ux_connector_connections_scope ON connector_connections (
    connector_id,
    scope_type,
    COALESCE(user_id, '00000000-0000-0000-0000-000000000000'::uuid),
    COALESCE(project_id, '00000000-0000-0000-0000-000000000000'::uuid)
) WHERE deleted_at IS NULL;
CREATE INDEX idx_connector_connections_user_id ON connector_connections (user_id);
CREATE INDEX idx_connector_connections_project_id ON connector_connections (project_id);

-- +goose Down
DROP TABLE IF EXISTS connector_connections;
DROP TABLE IF EXISTS connector_auth_sessions;
DROP TABLE IF EXISTS connectors;
DROP TABLE IF EXISTS inspiration_favorites;
DROP TABLE IF EXISTS inspirations;
DROP TABLE IF EXISTS inspiration_categories;
DROP TABLE IF EXISTS skill_versions;
DROP TABLE IF EXISTS skills;
DROP TABLE IF EXISTS skill_categories;
DROP TABLE IF EXISTS expert_team_members;
DROP TABLE IF EXISTS expert_teams;
DROP TABLE IF EXISTS experts;
DROP TABLE IF EXISTS expert_categories;
DROP TABLE IF EXISTS webhook_events;
