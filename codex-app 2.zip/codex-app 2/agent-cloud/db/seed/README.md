# AgentCloud Seed 数据

本目录用于保存 AgentCloud 本地开发和阶段验收所需的 seed 实现或说明。

执行规则以 `../../docs/20-delivery/execution/seed-data-spec.md` 为准。

## P0 目标命令

从 `agent-cloud/` 目录执行：

```bash
go run ./cmd/agent-cloud seed p0
```

在工程实现前，该命令是 P0 T01 的目标交付物。P0 seed 必须幂等，可重复执行，且不得通过 GORM `AutoMigrate` 创建 schema。

## P0 最小数据

| 数据 | 用途 |
| --- | --- |
| demo 用户 | 登录和账号上下文。 |
| 默认组织 | membership 和套餐归属。 |
| 默认套餐 | `/plans` 和权益展示。 |
| 模型 provider | `/models/providers`。 |
| 模型目录 | `/models/built-in`。 |
| 模型权益 | `/models/entitlements`。 |

生产初始化数据不放在本目录执行，必须单独走发布和变更审批。
