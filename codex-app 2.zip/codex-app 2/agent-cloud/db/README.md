# AgentCloud 数据库脚本

本目录保存 AgentCloud 的 goose PostgreSQL migrations。表结构来源见 `../docs/10-foundation/architecture/database-design.md`。

## 前置条件

- PostgreSQL 已创建目标数据库。
- 本机已安装 goose。
- `DATABASE_URL` 指向目标库，例如：

```bash
export DATABASE_URL='postgres://agent_cloud:password@localhost:5432/agent_cloud?sslmode=disable'
```

## 按阶段创建数据库结构

从 `agent-cloud/` 目录执行：

```bash
goose -dir db/migrations postgres "$DATABASE_URL" up-to 1
```

| 阶段 | 命令 |
| --- | --- |
| P0 | `goose -dir db/migrations postgres "$DATABASE_URL" up-to 1` |
| P1 | `goose -dir db/migrations postgres "$DATABASE_URL" up-to 10` |
| P2 | `goose -dir db/migrations postgres "$DATABASE_URL" up-to 20` |
| P3 | `goose -dir db/migrations postgres "$DATABASE_URL" up-to 30` |

从仓库根目录执行时，把 `-dir` 改成：

```bash
goose -dir agent-cloud/db/migrations postgres "$DATABASE_URL" up-to 1
```

## 查看状态

```bash
goose -dir db/migrations postgres "$DATABASE_URL" status
```

## Seed 数据

P0 本地开发和验收 seed 规则见：

- `../docs/20-delivery/execution/seed-data-spec.md`
- `seed/README.md`

目标命令：

```bash
go run ./cmd/agent-cloud seed p0
```

## 回滚

只在本地开发或明确可回滚环境使用：

```bash
goose -dir db/migrations postgres "$DATABASE_URL" down
```

生产环境回滚必须先评估数据影响，不直接依赖 `down` 作为无损恢复方案。
