# AGENTS.md

本文件是 Codex 和其他编码代理在 `agent-cloud` 仓库中工作的项目指令。

本文件只作为路由索引和约束清单，不重复承载大段规格正文。使用时先从 `docs/README.md` 渐进加载项目文档，再按任务读取最相关的事实源文档。

## 1. 必读启动上下文

修改代码或文档前，先读：

1. `docs/README.md`
2. `docs/00-start/ai-project-context.md`
3. `docs/00-start/current-status.md`
4. `docs/00-start/reading-guide.md`

以 `docs/00-start/current-status.md` 作为当前阶段门禁。如果该文件发生变化，按更新后的阶段和入口文档执行。

任何代码变更前，还必须阅读 `docs/20-delivery/execution/team-development-standards.md`。

## 2. 项目边界

`agent-cloud` 是桌面 Agent 体系的云端远程 API 服务。

主链路：

```text
Electron 薄前端
  -> 设备端代理服务
  -> AgentCloud /api/v1
  -> 第三方平台 / 云后台 / 云端 Worker
```

硬性边界：

- 不让 Electron 直接调用 AgentCloud。
- 不让 Electron 保存远程 `accessToken` 或 `refreshToken`。
- 不在 AgentCloud 中执行本地 Agent 任务。
- 不从 AgentCloud 访问用户设备文件系统。
- 不把设备文件树、文件内容、shell、diff、预览或权限确认放进 AgentCloud。
- 不在 AgentCloud 保存设备端私有专家、技能草稿或自定义模型 API Key。
- 不向 Electron 暴露任意连接器 invoke API。
- 不把本地 Agent runtime、Codex app-server、AgentRuntime 或 `codexapp-go` 的职责混入 AgentCloud。
- 不以明文返回第三方 token、refresh token、密钥或支付敏感数据。

## 3. 冻结技术栈

项目技术栈由 `docs/10-foundation/architecture/technology-stack.md` 冻结：

```text
Go + Gin
PostgreSQL + GORM + goose
Redis + go-redis
JWT access token
Opaque refresh token
bcrypt password hashing
config.yaml + environment variable secret overrides
Go slog structured logging
```

规则：

- 不用 Echo、Fiber、chi 或其他 Web 框架替换 Gin。
- 不用 MySQL、SQLite、MongoDB 或其他主数据库替换 PostgreSQL。
- 不用 Ent、sqlc、xorm 或手写 SQL 作为主数据访问层替换 GORM。
- 不使用 GORM `AutoMigrate` 管理正式 schema，正式 schema 必须使用 goose migration。
- 不替换 goose、go-redis、JWT access token、opaque refresh token、bcrypt 或 `slog`。
- 除非任务明确要求且标准库或项目现有能力不能满足，否则不要新增生产依赖。

## 4. 阶段和进度来源

不要在本文件硬编码当前开发阶段、阶段功能清单或阶段验收状态。

阶段和进度只以这些文件为准：

- 当前阶段、当前入口和下一阶段门禁：`docs/00-start/current-status.md`
- 总阶段顺序和阶段治理：`docs/20-delivery/iterations/01-agent-cloud-api-service/master-plan.md`
- 功能 ID、排期和依赖：`docs/20-delivery/iterations/01-agent-cloud-api-service/feature-plan.md`
- 当前阶段目标：当前阶段目录下的 `goal.md`
- 当前阶段任务拆分：当前阶段目录下的 `task-plan.md`
- 当前阶段 API 合约：当前阶段目录下的 `api-contract.md`
- 当前阶段验收证据：当前阶段目录下的 `acceptance-checklist.md`

实现前必须先确认当前阶段目录，再读取该阶段的目标、任务、API 合约和验收清单。

阶段规则：

- 严格按 `master-plan.md` 中定义的阶段顺序推进。
- 当前阶段只能依赖已完成阶段。
- 后续阶段不能成为当前阶段的编译、测试或验收依赖。
- 未进入当前阶段的接口不得使用空 handler、假实现、占位 package 或不可验证 stub。

## 5. 渐进式加载索引

只读取能覆盖当前任务的最小文档集合。

目录索引：

| 目录 | 何时加载 |
| --- | --- |
| `docs/00-start/` | 启动会话、确认当前阶段、阅读顺序或文档治理时。 |
| `docs/10-foundation/product/` | 确认产品范围、非目标和 AgentCloud 责任边界时。 |
| `docs/10-foundation/architecture/` | 确认架构、冻结技术栈、数据库设计、模块边界和 provider 设计时。 |
| `docs/20-delivery/execution/` | 实现代码、测试、工程启动、本地运行、seed 数据或团队流程时。 |
| `docs/20-delivery/iterations/` | 处理阶段、功能 ID、任务计划、API 合约或验收证据时。 |
| `docs/30-release/` | 修改已发布 API 行为或检查发布就绪状态时。 |
| `db/` | 修改 goose migration、seed 数据或数据库执行说明时。 |

任务索引：

| 任务 | 先读这些 |
| --- | --- |
| 从 0 理解项目 | `docs/README.md`、`docs/00-start/ai-project-context.md`、`docs/00-start/current-status.md`、`docs/00-start/reading-guide.md` |
| 开始或继续当前阶段开发 | `docs/00-start/current-status.md`、`docs/20-delivery/execution/execution-spec.md`、`docs/20-delivery/execution/team-development-standards.md`、`docs/20-delivery/execution/engineering-bootstrap-spec.md`、`docs/20-delivery/execution/local-dev-runbook.md`、`docs/20-delivery/execution/seed-data-spec.md`、当前阶段目录下的 `goal.md`、`task-plan.md`、`api-contract.md`、`acceptance-checklist.md` |
| 修改 API 行为 | 当前阶段的 `api-contract.md`、`docs/30-release/cloud-api-spec.md`、`docs/20-delivery/iterations/01-agent-cloud-api-service/feature-plan.md` |
| 修改数据库 schema 或 model | `docs/10-foundation/architecture/database-design.md`、`db/README.md`、相关 `db/migrations/*.sql`、`docs/20-delivery/execution/seed-data-spec.md` |
| 处理 auth、token、device 或权限 | 当前阶段的 `api-contract.md`、`docs/10-foundation/architecture/database-design.md`、`docs/10-foundation/architecture/technical-architecture.md` |
| 处理配置或服务启动 | `docs/20-delivery/execution/engineering-bootstrap-spec.md`、`docs/20-delivery/execution/local-dev-runbook.md`、`docs/10-foundation/architecture/technology-stack.md` |
| 新增或移动文档 | `docs/README.md`、`docs/00-start/doc-governance.md`、`docs/00-start/feishu-drive-mapping.md` |
| 检查发布就绪 | `docs/30-release/release-readiness-checklist.md` |

事实源优先级：

- 产品范围和非目标：`docs/10-foundation/product/agent-cloud-product-spec.md`
- 架构和模块边界：`docs/10-foundation/architecture/technical-architecture.md`
- 技术栈选型：`docs/10-foundation/architecture/technology-stack.md`
- 数据库 schema 和 migration 边界：`docs/10-foundation/architecture/database-design.md`
- 开发规范：`docs/20-delivery/execution/team-development-standards.md`
- 阶段治理：`docs/20-delivery/iterations/01-agent-cloud-api-service/master-plan.md`
- 功能 ID 和依赖：`docs/20-delivery/iterations/01-agent-cloud-api-service/feature-plan.md`
- REST API 总览：`docs/30-release/cloud-api-spec.md`

## 6. 实现规则

- 保持变更最小，并能追溯到请求对应的功能 ID 或阶段任务。
- 代码、测试、评审说明、文档更新和发布门禁遵守 `docs/20-delivery/execution/team-development-standards.md`。
- 工程结构遵守 `docs/20-delivery/execution/engineering-bootstrap-spec.md`。
- `cmd/agent-cloud/main.go` 只负责加载配置、初始化依赖并启动 HTTP server。
- Gin route、handler 和 middleware 放在 `internal/http` 与 `internal/middleware`。
- 业务 service 和领域类型放在 `internal/domain`。
- GORM model、repository、PostgreSQL 和 Redis 初始化放在 `internal/storage`。
- 不创建未来阶段的空 package。
- API 响应必须使用 `data/error/requestId` envelope。
- 受保护 API 必须校验 `Authorization: Bearer <accessToken>`。
- 设备 API 必须校验 `X-Device-Id` 或路径中的 `deviceId` 是否属于当前用户。
- 合约要求幂等的登录外写接口必须处理 `Idempotency-Key`。
- 合约要求缓存的动态目录 API 必须支持 `ETag`、`Last-Modified`、业务 `version` 和 `304 Not Modified`。
- secret 必须来自环境变量，不写入提交的配置文件。
- 日志必须使用结构化 `slog`，并且不得包含密码、JWT、refresh token、第三方 token、secret 或敏感请求体。

## 7. 数据库规则

- Goose migration 文件是正式 schema 来源。
- GORM model 必须与 goose migration 保持一致。
- 阶段 migration 执行方式以 `db/README.md` 为准。
- 执行当前阶段 schema 前，先确认 `docs/00-start/current-status.md` 和 `db/README.md` 中的阶段版本。
- 示例命令格式：

```bash
goose -dir db/migrations postgres "$DATABASE_URL" up-to <stage-version>
```

- 阶段 seed 命令以 `docs/20-delivery/execution/seed-data-spec.md` 和 `db/seed/README.md` 为准。
- Seed 必须幂等，且不得通过 GORM `AutoMigrate` 创建 schema。
- 不得把手工改库作为最终验收证据。

## 8. 验证规则

代码变更后，运行最小相关检查。常用检查包括：

```bash
go test ./...
goose -dir db/migrations postgres "$DATABASE_URL" up-to <stage-version>
go run ./cmd/agent-cloud seed <stage>
go run ./cmd/agent-cloud
curl -i http://127.0.0.1:8080/healthz
```

具体 migration 版本、seed 命令和验收 API 以当前阶段文档为准。同时根据当前阶段 `api-contract.md` 验证受影响的 HTTP API。

如果因为工程骨架、数据库、Redis 或凭据缺失导致命令无法运行，必须在最终回复中明确说明，并说明已替代验证了什么。

## 9. 文档规则

- `docs/README.md` 只保留导航。
- 新文档放入 `docs/00-start/doc-governance.md` 定义的生命周期目录。
- 不在 `docs/` 根目录直接新增长正文文档。
- 当前阶段或门禁变化时，更新 `docs/00-start/current-status.md`。
- API 行为变化时，更新 `docs/30-release/cloud-api-spec.md`。
- 产生验收证据时，更新当前阶段 acceptance checklist。
- 只有真实同步或 token/path 变化后，才更新 `docs/00-start/feishu-drive-mapping.md`。

## 10. 最终回复要求

完成任务时，说明：

- 改了什么。
- 影响哪个功能 ID、阶段或文档事实源。
- 哪些检查已通过。
- 哪些检查没有运行，以及原因。
- 剩余假设或风险。

除非用户明确要求，否则不要提交 commit。
