# codexapp-go AI Guide

这是 AI 进入 `codexapp-go/` 的最小入口。完整导航看 `docs/README.md`，不要在这里重复维护长目录说明。

## 项目边界

`codexapp-go` 是 Codex app-server JSON-RPC 的纯 Go client SDK。

链路是：

```text
Electron -> AgentHost -> AgentRuntime -> CodexRuntime Adapter -> codexapp-go -> Codex app-server
```

只做：类型安全 JSON-RPC client、事件订阅、server request 处理、协议能力封装。

不做：Electron UI、AgentHost 编排、REST/SSE、任务暂停/阶段控制、用户确认流程、app-server 安装/启动/守护。

## 先读什么

从 0 进入项目，只读这 3 个文件：

1. `docs/00-start/ai-project-context.md`
2. `docs/00-start/current-status.md`
3. `docs/00-start/reading-guide.md`

然后按任务需要再读：

- 产品边界：`docs/10-foundation/product/codexapp-go-product-spec.md`
- 技术架构：`docs/10-foundation/architecture/technical-architecture.md`
- JSON-RPC 协议：`docs/10-foundation/protocol/app-server/json-rpc-manual.md`
- 开发执行：`docs/20-delivery/execution/execution-spec.md`
- 阶段计划：`docs/20-delivery/iterations/01-codexapp-go-m0-m6/master-plan.md`

## 改 docs 的规则

- `docs/README.md` 只做短导航，不放长说明。
- 稳定项目上下文改 `docs/00-start/ai-project-context.md`。
- 当前阶段和门禁改 `docs/00-start/current-status.md`。
- 阅读路径改 `docs/00-start/reading-guide.md`。
- 放置规则改 `docs/00-start/doc-governance.md`。
- 飞书路径或 token 改 `docs/00-start/feishu-drive-mapping.md`。
- 不新增 `docs/` 一级目录；放置位置按 `doc-governance.md`。

只有内容有独立生命周期、会撑爆现有文件、或需要长期追溯时才新增文档。临时讨论和小补充优先改现有文件。

## 飞书同步

本地 `codexapp-go/` 对应飞书 `/CodexApp/codexapp-go/`，folder token：

```text
VEYZf71oolZjecdBuTvcxfIMnmb
```

修改或新增本项目文档后，同步整个目录：

```bash
lark-cli drive +push --as user --local-dir codexapp-go --folder-token VEYZf71oolZjecdBuTvcxfIMnmb --if-exists smart --json
lark-cli drive +status --as user --local-dir codexapp-go --folder-token VEYZf71oolZjecdBuTvcxfIMnmb --json
```

完成标准：`new_local`、`new_remote`、`modified` 都为空。

发生删除、重命名或目录迁移时，先确认用户明确要求，再考虑 `--delete-remote --yes`，并更新 `docs/00-start/feishu-drive-mapping.md`。
