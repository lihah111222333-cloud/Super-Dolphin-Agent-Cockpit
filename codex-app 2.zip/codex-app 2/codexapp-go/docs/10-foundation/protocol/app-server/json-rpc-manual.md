# Codex app-server JSON-RPC 接口手册

本文基于同目录的官方文档快照 `official-doc-snapshot.md`，并用本机
`codex-cli 0.137.0` 生成的 app-server TypeScript/JSON Schema 做接口覆盖校验。

生成当前版本 schema 的命令：

```bash
codex app-server generate-ts --out ./schemas
codex app-server generate-json-schema --out ./schemas
```

说明：

- app-server 使用 JSON-RPC 2.0 形态，但线上消息省略 `"jsonrpc":"2.0"` 字段。
- 请求必须带 `id`，响应用同一个 `id` 返回 `result` 或 `error`。
- 通知没有 `id`，只包含 `method` 和可选 `params`。
- 客户端连接后必须先发送 `initialize` 请求，再发送 `initialized` 通知。
- 实验接口或实验字段需要在 `initialize.params.capabilities.experimentalApi` 中显式启用。
- 精确字段全集以目标版本生成的 schema 为准；本文列关键字段、用途、返回和使用方式。

## 1. 传输与通用消息

### 传输

| 传输 | 启动方式 | 使用方式 |
| --- | --- | --- |
| stdio | `codex app-server` 或 `--listen stdio://` | JSONL，每行一条 JSON-RPC 消息。 |
| WebSocket | `--listen ws://127.0.0.1:4500` | 每个 WebSocket text frame 一条消息；实验、不建议裸露到远端。 |
| Unix socket | `--listen unix://` 或 `unix://PATH` | 通过 HTTP Upgrade 建 WebSocket。 |
| off | `--listen off` | 不暴露本地传输。 |

WebSocket 健康检查：

- `GET /readyz`：监听器可接收连接后返回 `200 OK`。
- `GET /healthz`：没有 `Origin` 头时返回 `200 OK`；带 `Origin` 返回 `403`。
- WebSocket 认证可用 capability token 或 signed bearer token。远程暴露前必须配置认证。

### 消息格式

请求：

```json
{ "method": "thread/start", "id": 10, "params": { "model": "gpt-5.4" } }
```

响应：

```json
{ "id": 10, "result": { "thread": { "id": "thr_123" } } }
```

错误：

```json
{ "id": 10, "error": { "code": 123, "message": "Something went wrong" } }
```

通知：

```json
{ "method": "turn/started", "params": { "turn": { "id": "turn_456" } } }
```

## 2. 最小调用流程

```json
{ "method": "initialize", "id": 0, "params": {
  "clientInfo": { "name": "my_client", "title": "My Client", "version": "0.1.0" },
  "capabilities": { "experimentalApi": true }
} }
{ "id": 0, "result": { "userAgent": "...", "platformFamily": "...", "platformOs": "..." } }
{ "method": "initialized", "params": {} }
{ "method": "thread/start", "id": 1, "params": { "cwd": "/Users/me/project" } }
{ "id": 1, "result": { "thread": { "id": "thr_123" } } }
{ "method": "turn/start", "id": 2, "params": {
  "threadId": "thr_123",
  "input": [{ "type": "text", "text": "Summarize this repo." }]
} }
```

客户端随后持续读取 `thread/*`、`turn/*`、`item/*` 等通知，直到收到
`turn/completed`。

## 3. 客户端请求接口

方向：客户端发送请求，app-server 返回响应。

### 3.1 初始化

| 方法 | 关键参数 | 返回 | 使用方法 |
| --- | --- | --- | --- |
| `initialize` | `clientInfo.name/title/version`；可选 `capabilities.experimentalApi`、`optOutNotificationMethods` | `userAgent`、`platformFamily`、`platformOs` | 每条连接只调用一次；所有其他请求之前必须调用。重复调用返回 already initialized。 |

### 3.2 Thread 生命周期与元数据

| 方法 | 关键参数 | 返回/事件 | 使用方法 |
| --- | --- | --- | --- |
| `thread/start` | `model`、`cwd`、`approvalPolicy`、`sandbox`/`sandboxPolicy`、`personality`、`serviceName`、实验 `dynamicTools` | `thread`；通知 `thread/started` | 创建新会话，并自动订阅该 thread 的 turn/item 事件。 |
| `thread/resume` | `threadId`；可传与 start 类似的覆盖配置 | `thread` | 恢复已有 thread，后续 `turn/start` 追加到同一历史。恢复本身不更新 `updatedAt`。 |
| `thread/fork` | `threadId` | 新 `thread`；通知 `thread/started` | 复制存储历史并生成新 thread id；这是上下文分支，不是 Git worktree。 |
| `thread/read` | `threadId`、`includeTurns` | `thread`，可含 `turns` 和 runtime `status` | 只读会话，不加载到内存，不订阅事件。 |
| `thread/list` | `cursor`、`limit`、`sortKey`、`sortDirection`、`modelProviders`、`sourceKinds`、`archived`、`cwd`、`searchTerm`、实验 `parentThreadId` | `{ data, nextCursor }` | 渲染历史列表；默认列非归档 interactive 来源。 |
| `thread/loaded/list` | 可空参数 | `{ data: [threadId] }` | 查看当前进程内存中已加载的 thread。 |
| `thread/unsubscribe` | `threadId` | `{ status }`；可能后续 `thread/closed` | 取消当前连接订阅；最后一个订阅者离开后，空闲期满会卸载 thread。 |
| `thread/archive` | `threadId` | `{}`；通知 `thread/archived` | 把持久化 rollout 移到归档目录，并尝试归档派生子 thread。 |
| `thread/unarchive` | `threadId` | `thread`；通知 `thread/unarchived` | 将归档 thread 恢复到 active sessions。 |
| `thread/name/set` | `threadId`、`name` | `{}` 或更新结果；通知 `thread/name/updated` | 设置用户可见标题。 |
| `thread/goal/set` | `threadId`、`objective`、`status`、可选 `tokenBudget` | `goal`；通知 `thread/goal/updated` | 设置或更新 `/goal` 对应的持久目标。新 objective 会重置使用统计。 |
| `thread/goal/get` | `threadId` | `goal` 或空值 | 读取当前 goal。 |
| `thread/goal/clear` | `threadId` | `{}`；通知 `thread/goal/cleared` | 清除 goal。 |
| `thread/metadata/update` | `threadId`、`gitInfo` | 更新后的 `thread` | 不恢复 thread 的情况下更新存储元数据；显式 `null` 清除字段。 |
| `thread/compact/start` | `threadId` | `{}`；进度通过 `turn/*`、`item/*` | 手动触发上下文压缩；请求立即返回。 |
| `thread/shellCommand` | `threadId`、`command` | `{}`；输出走标准 turn/item 事件 | 执行用户发起的 shell 命令；官方文档明确它在 sandbox 外运行，客户端应只给显式用户操作暴露。 |
| `thread/rollback` | `threadId`、`numTurns` | 更新后的 `thread` | 从内存上下文删除最近 N 个 turn，并写入 rollback marker。 |
| `thread/inject_items` | `threadId`、Responses API `items` | `{}` | 直接把原始 Responses API item 注入模型可见历史，不启动用户 turn。 |
| `thread/approveGuardianDeniedAction` | `threadId`、序列化 `GuardianAssessmentEvent` | 审批结果 | 当前 schema 暴露的 Guardian denied action 继续执行审批接口；通常由安全/自动审批 UI 驱动。 |

官方文档还列出下列 thread 请求，但本机 `codex-cli 0.137.0` 生成的
`ClientRequest` 顶层联合类型未暴露；使用前应以目标版本 schema 确认：

| 方法 | 详情/用法 |
| --- | --- |
| `thread/delete` | 永久删除 active 或 archived thread 及其 spawned descendants；成功后通知 `thread/deleted`。 |
| `thread/turns/list` | 分页读取某个 thread 的 turn 历史；`itemsView` 可选 `notLoaded`、`summary`、`full`。 |
| `thread/turns/items/list` | 官方文档标记为预留；当前实现返回 unsupported。 |
| `thread/backgroundTerminals/clean` | 实验接口；停止 thread 关联的所有后台终端。 |
| `thread/backgroundTerminals/list` | 实验接口；分页列出后台终端，返回 app-server `processId`。 |
| `thread/backgroundTerminals/terminate` | 实验接口；按 `processId` 终止一个后台终端。 |

### 3.3 Turn 与 Review

| 方法 | 关键参数 | 返回/事件 | 使用方法 |
| --- | --- | --- | --- |
| `turn/start` | `threadId`、`input`；可覆盖 `cwd`、`model`、`effort`、`personality`、`approvalPolicy`、`sandboxPolicy`、`summary`、`outputSchema`、`collaborationMode` | `turn`；随后 `turn/started`、`item/*`、`turn/completed` | 启动一次用户请求。`input` 支持 `text`、`image`、`localImage`、`skill`、`mention`。 |
| `turn/steer` | `threadId`、`expectedTurnId`、`input` | `{ turnId }` | 给正在运行的 turn 追加用户输入；不能覆盖模型、cwd、sandbox 等 turn 配置。 |
| `turn/interrupt` | `threadId`、`turnId` | `{}`；最终 `turn/completed.status = "interrupted"` | 请求取消正在运行的 turn。 |
| `review/start` | `threadId`、`target`、可选 `delivery` | `turn`、`reviewThreadId` | 启动 Codex reviewer。`delivery: "inline"` 复用当前 thread；`"detached"` 会 fork 新 review thread。 |

常见 `turn/start.input`：

```json
[
  { "type": "text", "text": "$skill-creator Add a new skill." },
  { "type": "skill", "name": "skill-creator", "path": "/Users/me/.codex/skills/skill-creator/SKILL.md" },
  { "type": "mention", "name": "Demo App", "path": "app://demo-app" }
]
```

### 3.4 模型、功能、权限配置

| 方法 | 关键参数 | 返回 | 使用方法 |
| --- | --- | --- | --- |
| `model/list` | `cursor`、`limit`、`includeHidden` | `{ data, nextCursor }` | 渲染模型选择器；模型项含 reasoning effort、输入模态、是否默认等。 |
| `modelProvider/capabilities/read` | model/provider 组合 | provider 能力边界 | 实验接口；读取模型提供方能力限制。 |
| `experimentalFeature/list` | `cursor`、`limit` | feature flag 列表 | 展示实验功能及生命周期阶段。 |
| `experimentalFeature/enablement/set` | feature key 到启用状态的 patch | 更新结果 | 修改内存运行时 feature enablement，例如 apps/plugins。 |
| `permissionProfile/list` | `cursor`、`limit`、可选 `cwd` | 权限 profile 列表 | 当前 schema 暴露；用于列出可选 sandbox/approval 权限预设。 |
| `configRequirements/read` | 无参数 | `{ requirements }` 或 `null` | 读取 `requirements.toml`/MDM 管理约束，如允许的 approval、sandbox、网络要求。 |

官方文档还列出 `collaborationMode/list`；本机当前 schema 未暴露该客户端请求。

### 3.5 命令与进程

| 方法 | 关键参数 | 返回/事件 | 使用方法 |
| --- | --- | --- | --- |
| `command/exec` | `command` argv、`cwd`、`sandboxPolicy`、`timeoutMs`、可选 `tty`、`streamStdoutStderr` | 非流式返回 `exitCode/stdout/stderr`；流式时通知 `command/exec/outputDelta` | 在 server sandbox 下执行单个命令，不创建 thread/turn。 |
| `command/exec/write` | `processId`、`deltaBase64` 或 `closeStdin` | 写入状态 | 给 PTY/流式 `command/exec` 会话写 stdin 或关闭 stdin。 |
| `command/exec/resize` | `processId`、`cols`、`rows` | `{}` | 调整 PTY 尺寸。 |
| `command/exec/terminate` | `processId` | `{}` | 终止运行中的 `command/exec` 会话。 |

官方文档描述了实验 `process/*` 显式进程控制 API，但本机当前
`ClientRequest` 未暴露这些请求；通知类型仍存在：

| 方法 | 详情/用法 |
| --- | --- |
| `process/spawn` | 文档版实验接口；用 `processHandle` 启动 sandbox 外进程。 |
| `process/writeStdin` | 向 `processHandle` 写 stdin 或关闭 stdin。 |
| `process/resizePty` | 调整 process PTY。 |
| `process/kill` | 终止 process。 |
| `process/outputDelta` | 服务端通知进程 stdout/stderr base64 delta。 |
| `process/exited` | 服务端通知进程退出码。 |

### 3.6 文件系统

v2 文件系统 API 都使用绝对路径。写入内容使用 base64。

| 方法 | 关键参数 | 返回/事件 | 使用方法 |
| --- | --- | --- | --- |
| `fs/readFile` | `path` | 文件内容 | 读取 host 文件。 |
| `fs/writeFile` | `path`、`dataBase64` | 写入结果 | 写 host 文件。 |
| `fs/createDirectory` | `path`、可选 `recursive` | 创建结果 | 创建目录；默认递归。 |
| `fs/getMetadata` | `path` | 文件/目录元数据 | 查询路径类型、大小、时间等元数据。 |
| `fs/readDirectory` | `path` | 直接子项列表 | 列目录。 |
| `fs/remove` | `path`、可选 `recursive`、`force` | 删除结果 | 删除文件或目录树；默认递归且忽略缺失。 |
| `fs/copy` | `sourcePath`、`destinationPath`、目录复制时 `recursive` | 复制结果 | 复制文件或目录。 |
| `fs/watch` | `watchId`、`path` | `{ path }`；后续 `fs/changed` | 监听文件或目录变更。 |
| `fs/unwatch` | `watchId` | `{}` | 取消监听。 |

示例：

```json
{ "method": "fs/watch", "id": 54, "params": {
  "watchId": "watch-1",
  "path": "/Users/me/project/.git/HEAD"
} }
{ "method": "fs/changed", "params": {
  "watchId": "watch-1",
  "changedPaths": ["/Users/me/project/.git/HEAD"]
} }
```

### 3.7 Skills、Hooks、Apps、Plugins、Marketplace

| 方法 | 关键参数 | 返回/事件 | 使用方法 |
| --- | --- | --- | --- |
| `skills/list` | `cwds`、`forceReload`、`perCwdExtraUserRoots` | `{ data }` | 列出 cwd 作用域内可用 skills；收到 `skills/changed` 后应重新拉取。 |
| `skills/extraRoots/set` | `extraRoots` | 更新结果 | 当前 schema 暴露；为 skills 扫描设置额外根目录。 |
| `skills/config/write` | `path`、`enabled` | 更新结果 | 按 skill 文件路径启用/禁用 skill。 |
| `hooks/list` | `cwds` | hooks 列表 | 当前 schema 暴露；列出配置 hooks 及运行摘要/元数据。 |
| `app/list` | `cursor`、`limit`、可选 `threadId`、`forceRefetch` | `{ data, nextCursor }`；后续可有 `app/list/updated` | 列出 connectors/apps；`threadId` 会使用该 thread 的 feature gating 快照。 |
| `marketplace/add` | marketplace 名称/来源 | 添加结果 | 添加远程 plugin marketplace 并持久化。 |
| `marketplace/remove` | `marketplaceName` | 移除结果 | 当前 schema 暴露；删除 marketplace 配置。 |
| `marketplace/upgrade` | 可选 marketplace 名称 | 升级结果 | 刷新指定 Git marketplace；省略则刷新全部 Git marketplace。 |
| `plugin/list` | marketplace/cwd 过滤参数 | plugin marketplace 与安装状态 | 列出本地、Git、remote plugin 及 install/auth policy 元数据。 |
| `plugin/installed` | `cwds`、`installSuggestionPluginNames` | 已安装/建议 plugin | 当前 schema 暴露；供提及/安装入口查询。 |
| `plugin/read` | `marketplacePath` 或 `remoteMarketplaceName` + `pluginName` | plugin 详情 | 读取一个 plugin，包含 skills、apps、MCP server 名称、shareUrl 等。 |
| `plugin/skill/read` | plugin 与 skill 标识 | skill 内容/元数据 | 当前 schema 暴露；读取 plugin 内 skill。 |
| `plugin/install` | marketplace/plugin 标识 | 安装结果 | 安装 plugin。 |
| `plugin/uninstall` | plugin 标识 | 卸载结果 | 卸载已安装 plugin。 |
| `plugin/share/save` | `pluginPath`、可选 `remotePluginId`、`discoverability`、`shareTargets` | share 结果 | 当前 schema 暴露；保存/发布 plugin share。 |
| `plugin/share/updateTargets` | `remotePluginId`、`discoverability`、`shareTargets` | 更新结果 | 更新 remote plugin share 目标。 |
| `plugin/share/list` | 空对象 | share 列表 | 列出当前用户的 plugin shares。 |
| `plugin/share/checkout` | `remotePluginId` | checkout 结果 | 拉取/检出一个 remote shared plugin。 |
| `plugin/share/delete` | `remotePluginId` | 删除结果 | 删除 remote plugin share。 |

### 3.8 MCP server 与工具调用

| 方法 | 关键参数 | 返回/事件 | 使用方法 |
| --- | --- | --- | --- |
| `mcpServer/oauth/login` | MCP server 名称 | 授权 URL；最终 `mcpServer/oauthLogin/completed` | 为配置的 MCP server 启动 OAuth。 |
| `config/mcpServer/reload` | 无参数 | refresh 结果 | 从磁盘重载 MCP server 配置，并给已加载 thread 排队刷新。 |
| `mcpServerStatus/list` | `cursor`、`limit`、`detail` | server/tool/resource/auth 状态 | 分页读取 MCP servers；`detail: "toolsAndAuthOnly"` 可省资源。 |
| `mcpServer/resource/read` | server 名称、resource URI | resource 内容 | 通过已初始化 MCP server 读取单个 resource。 |
| `mcpServer/tool/call` | `threadId`、server、tool、arguments | tool 结果；可能有 `item/mcpToolCall/progress` | 在 thread 配置的 MCP server 上调用工具。 |

### 3.9 配置、迁移、反馈、Windows sandbox

| 方法 | 关键参数 | 返回/事件 | 使用方法 |
| --- | --- | --- | --- |
| `config/read` | `includeLayers` | effective config；可含 layers | 读取配置叠加后的生效配置。 |
| `config/value/write` | `keyPath`、`value`、`mergeStrategy` | 写入结果 | 写单个 `config.toml` 配置值。 |
| `config/batchWrite` | `edits[]` | 写入结果 | 原子写入多项配置。 |
| `externalAgentConfig/detect` | `includeHome`、`cwds` | 可迁移 items | 检测 Claude Code 等外部 agent 配置、skills、plugins、sessions。 |
| `externalAgentConfig/import` | `migrationItems`、可选 `source` | `{ importId }`；通知 `externalAgentConfig/import/completed` | 按 detect 返回的明确条目执行迁移。 |
| `feedback/upload` | 分类、原因、日志、conversation id、额外日志文件 | 上传状态 | 提交反馈报告。 |
| `windowsSandbox/setupStart` | `mode: "elevated" \| "unelevated"` | `{ started }`；最终 `windowsSandbox/setupCompleted` | Windows 客户端异步触发 sandbox setup。 |
| `windowsSandbox/readiness` | 无参数 | readiness 状态 | 当前 schema 暴露；读取 Windows sandbox 可用性。 |

官方文档还给出：

| 方法 | 详情/用法 |
| --- | --- |
| `externalAgentConfig/import/readHistories` | 读取已完成 import 历史；当前 schema 顶层未暴露。 |
| `externalAgentConfig/import/progress` | 文档示例中的进度通知；当前 schema 顶层通知只暴露 completed。 |

### 3.10 账号与认证

| 方法 | 关键参数 | 返回/事件 | 使用方法 |
| --- | --- | --- | --- |
| `account/read` | `refreshToken` | `{ account, requiresOpenaiAuth }` | 读取当前认证状态；ChatGPT managed 模式可强制刷新 token。 |
| `account/login/start` | `type`；`apiKey` 或 ChatGPT flow 参数；实验 `chatgptAuthTokens` | 登录启动结果；最终 `account/login/completed`、`account/updated` | 开始 API key、ChatGPT browser/device-code 或外部 token 登录。 |
| `account/login/cancel` | `loginId` | cancel 状态；通知 `account/login/completed` | 取消 pending ChatGPT managed 登录。 |
| `account/logout` | 无参数 | `{}`；通知 `account/updated` | 退出登录。 |
| `account/rateLimits/read` | 无参数 | ChatGPT rate limit 快照 | 获取 ChatGPT rate limits 和 earned reset credits。 |
| `account/sendAddCreditsNudgeEmail` | `creditType: "credits" \| "usage_limit"` | `{ status }` | 请求 ChatGPT 向 workspace owner 发送加 credits/usage limit 提醒。 |

官方文档还列出但当前 schema 未暴露的账号请求：

| 方法 | 详情/用法 |
| --- | --- |
| `account/rateLimitResetCredit/consume` | 用 `idempotencyKey` 消耗一次 earned reset；返回 `reset`、`alreadyRedeemed`、`nothingToReset` 或 `noCredit`。 |
| `account/usage/read` | 读取 ChatGPT token activity summary 和 daily buckets。 |

### 3.11 模糊文件搜索与旧兼容接口

| 方法 | 关键参数 | 返回/事件 | 使用方法 |
| --- | --- | --- | --- |
| `fuzzyFileSearch` | `query`、`roots`、`cancellationToken` | 搜索结果；可伴随 `fuzzyFileSearch/sessionUpdated`、`sessionCompleted` | 当前 schema 暴露；做本地 fuzzy file search。 |
| `getConversationSummary` | `rolloutPath` 或 `conversationId` | conversation summary | 当前 schema 暴露的旧/兼容接口；新客户端优先用 thread 读取接口。 |
| `gitDiffToRemote` | `cwd` | diff 结果 | 当前 schema 暴露的旧/兼容接口；用于读取工作区到 remote 的 diff。 |
| `getAuthStatus` | `includeToken`、`refreshToken` | auth status | 当前 schema 暴露的旧/兼容接口；新客户端优先用 `account/read`。 |

## 4. 客户端通知接口

方向：客户端发送 notification，不带 `id`。

| 方法 | 参数 | 使用方法 |
| --- | --- | --- |
| `initialized` | `{}` 或省略 | `initialize` 成功后立即发送，表示客户端完成握手准备。 |

## 5. 服务端请求接口

方向：app-server 主动向客户端发送请求，带 `id`；客户端必须用同一 `id`
响应。

| 方法 | 关键参数 | 客户端响应 | 使用方法 |
| --- | --- | --- | --- |
| `item/commandExecution/requestApproval` | `threadId`、`turnId`、`itemId`、`command`、`cwd`、`reason`、`availableDecisions`、可选网络/权限上下文 | command approval decision | 命令或网络访问需要用户/宿主审批时触发。响应可接受、会话级接受、拒绝、取消，或带 exec policy amendment 接受。 |
| `item/fileChange/requestApproval` | `threadId`、`turnId`、`itemId`、`reason`、`grantRoot` | file change approval decision | 文件修改需要审批时触发。响应接受、会话级接受、拒绝或取消。 |
| `item/tool/requestUserInput` | `threadId`、`turnId`、问题列表、选项、可选 `autoResolutionMs` | 用户答案 | 工具需要向用户询问 1-3 个短问题时触发；结束后会有 `serverRequest/resolved`。 |
| `mcpServer/elicitation/request` | MCP elicitation schema 与上下文 | elicitation action/values | MCP server 通过 elicitation 向宿主请求结构化输入。 |
| `item/permissions/requestApproval` | requested permission profile/extra permissions | permission decision | 请求额外 filesystem/network 权限时触发。 |
| `item/tool/call` | dynamic tool 名称与 arguments | dynamic tool result content | 实验 dynamic tools 调用；客户端执行工具并回传内容。 |
| `account/chatgptAuthTokens/refresh` | `reason`、`previousAccountId` | 新 `accessToken`、账号 id、plan type | 外部 ChatGPT tokens 模式下，server 遇到授权失败时请求宿主刷新 token。 |
| `attestation/generate` | attestation 生成上下文 | attestation 结果 | 当前 schema 暴露；由宿主生成证明材料。 |
| `applyPatchApproval` | legacy patch approval 参数 | approval response | 旧兼容审批请求；新客户端优先处理 `item/fileChange/requestApproval`。 |
| `execCommandApproval` | legacy exec approval 参数 | approval response | 旧兼容审批请求；新客户端优先处理 `item/commandExecution/requestApproval`。 |

审批请求的通用收尾：

```json
{ "id": 99, "result": { "decision": "accept" } }
{ "method": "serverRequest/resolved", "params": {
  "threadId": "thr_123",
  "requestId": 99
} }
```

具体响应字段名以目标版本 schema 为准。

## 6. 服务端通知接口

方向：app-server 主动通知客户端，不带 `id`。客户端通常只监听与当前 UI
相关的 thread/turn/item 通知；不需要的通知可以在 `initialize` 中通过
`optOutNotificationMethods` 精确禁用。

### 6.1 通用、thread、turn

| 方法 | 触发时机 | 用法 |
| --- | --- | --- |
| `error` | turn 或后台任务失败 | 展示错误；turn 失败后还会收到 `turn/completed.status = "failed"`。 |
| `thread/started` | thread start/resume/fork 或 detached review 建立 | 加入订阅 thread，初始化 UI 状态。 |
| `thread/status/changed` | loaded thread runtime status 改变 | 更新 idle/active/systemError/notLoaded 状态。 |
| `thread/archived` | thread 被归档 | 从 active 列表移除或标记 archived。 |
| `thread/unarchived` | thread 从归档恢复 | 更新历史列表。 |
| `thread/closed` | thread 因无订阅且空闲被卸载 | 清理连接侧状态。 |
| `thread/name/updated` | 标题改变 | 更新标题显示。 |
| `thread/goal/updated` | goal 被设置或更新 | 更新目标面板。 |
| `thread/goal/cleared` | goal 被清除 | 清空目标面板。 |
| `thread/settings/updated` | thread 运行设置改变 | 同步模型、sandbox、approval 等设置显示。 |
| `thread/tokenUsage/updated` | token usage 更新 | 更新用量/预算显示。 |
| `turn/started` | turn 开始 | 创建 turn UI 容器。 |
| `turn/completed` | turn 完成、失败或中断 | 关闭 loading；读取最终 `turn.status` 和 `error`。 |
| `turn/diff/updated` | turn 内文件修改 diff 聚合变化 | 更新 diff 视图；item 仍以 `item/*` 为准。 |
| `turn/plan/updated` | agent 计划更新 | 更新计划面板。 |
| `thread/compacted` | legacy conversation compacted | 官方文档称已废弃；优先用 `contextCompaction` item。 |

官方文档还描述 `thread/deleted`，但当前 schema 顶层通知未暴露；使用前确认目标版本。

### 6.2 Hook、skill、app、MCP、配置

| 方法 | 触发时机 | 用法 |
| --- | --- | --- |
| `hook/started` | hook 开始运行 | 展示 hook 运行状态。 |
| `hook/completed` | hook 完成 | 展示 hook 输出/错误摘要。 |
| `skills/changed` | watched skill 文件变化 | 重新调用 `skills/list`。 |
| `app/list/updated` | accessible apps 或 directory apps 刷新完成 | 更新 apps 列表缓存。 |
| `item/mcpToolCall/progress` | MCP tool call 有进度 | 更新 connector/tool 进度。 |
| `mcpServer/oauthLogin/completed` | MCP OAuth flow 完成 | 更新 MCP auth 状态。 |
| `mcpServer/startupStatus/updated` | loaded thread 的 MCP server startup 状态变化 | 更新 MCP server 状态和错误。 |
| `remoteControl/status/changed` | remote-control 连接状态变化 | 更新远程控制 UI。 |
| `externalAgentConfig/import/completed` | 外部配置导入完成 | 展示 import 结果。 |
| `configWarning` | 配置存在 warning | 展示配置警告。 |

### 6.3 Item 生命周期与 delta

| 方法 | 触发时机 | 用法 |
| --- | --- | --- |
| `item/started` | 新 work item 开始 | 创建 item；常见类型有 `userMessage`、`agentMessage`、`commandExecution`、`fileChange`、`mcpToolCall`、`dynamicToolCall`、`webSearch`、`contextCompaction`。 |
| `item/completed` | work item 完成 | 用最终 item 作为权威状态。 |
| `rawResponseItem/completed` | 原始 Responses API item 完成 | 当前 schema 暴露；用于需要底层 response item 的客户端。 |
| `item/agentMessage/delta` | agent message 文本流式增量 | 按顺序追加到消息文本。 |
| `item/plan/delta` | plan 文本增量 | 可用于打字机效果；最终以 `item/completed` 的 plan 为准。 |
| `item/reasoning/summaryTextDelta` | reasoning summary 文本增量 | 展示可读推理摘要。 |
| `item/reasoning/summaryPartAdded` | 新 reasoning summary 段落边界 | 分段展示 summary。 |
| `item/reasoning/textDelta` | raw reasoning 文本增量 | 仅模型/配置支持时出现。 |
| `item/commandExecution/outputDelta` | turn 内命令 stdout/stderr | 按顺序拼接输出。 |
| `item/commandExecution/terminalInteraction` | 终端交互事件 | 更新 PTY 交互 UI。 |
| `item/fileChange/outputDelta` | legacy apply_patch 输出 | 官方文档称兼容/废弃；新客户端用 fileChange item 和 `turn/diff/updated`。 |
| `item/fileChange/patchUpdated` | patch 内容更新 | 更新文件修改预览。 |
| `item/autoApprovalReview/started` | 自动审批 review 开始 | 展示自动审批检查状态。 |
| `item/autoApprovalReview/completed` | 自动审批 review 完成 | 展示自动审批结果。 |
| `serverRequest/resolved` | 服务端请求被回答或清理 | 清除 pending approval/input UI。 |

### 6.4 command/process、文件、搜索、模型、Windows、账号

| 方法 | 触发时机 | 用法 |
| --- | --- | --- |
| `command/exec/outputDelta` | 流式 `command/exec` 输出 | base64 解码后追加 stdout/stderr。 |
| `process/outputDelta` | 文档版 process API 输出 | 仅在目标版本支持 process 会话时使用。 |
| `process/exited` | process 会话退出 | 更新退出码。 |
| `fs/changed` | `fs/watch` 监听路径变化 | 使 UI 缓存失效或重新读取。 |
| `fuzzyFileSearch/sessionUpdated` | fuzzy file search 当前 query 匹配更新 | 更新搜索建议列表。 |
| `fuzzyFileSearch/sessionCompleted` | fuzzy file search session 完成 | 停止加载状态。 |
| `model/rerouted` | 模型被服务端 reroute | 告知用户实际模型变化。 |
| `model/verification` | 模型验证状态变化 | 更新模型可用性提示。 |
| `warning` | 普通 warning | 展示非致命警告。 |
| `guardianWarning` | Guardian 风险警告 | 展示安全/合规提示。 |
| `deprecationNotice` | API 或能力弃用提示 | 记录并提示升级。 |
| `windows/worldWritableWarning` | Windows world-writable path 警告 | 展示 sandbox/权限风险。 |
| `windowsSandbox/setupCompleted` | Windows sandbox setup 完成 | 更新 setup 成功/失败状态。 |
| `account/login/completed` | login flow 成功或失败 | 更新登录 UI。 |
| `account/updated` | auth mode 改变 | 更新账号状态；`authMode` 可为 `apikey`、`chatgpt`、`chatgptAuthTokens`、`agentIdentity`、`personalAccessToken`、`bedrockApiKey` 或 `null`。 |
| `account/rateLimits/updated` | ChatGPT rate limits 变化 | 更新用量/限额 UI。 |

### 6.5 Realtime 通知

当前 schema 暴露一组 `thread/realtime/*` 通知，官方文档正文未展开。按名称使用：

| 方法 | 用法 |
| --- | --- |
| `thread/realtime/started` | realtime 会话开始。 |
| `thread/realtime/itemAdded` | realtime item 增加。 |
| `thread/realtime/transcript/delta` | transcript 文本增量。 |
| `thread/realtime/transcript/done` | transcript 完成。 |
| `thread/realtime/outputAudio/delta` | 输出音频增量。 |
| `thread/realtime/sdp` | SDP 信息。 |
| `thread/realtime/error` | realtime 错误。 |
| `thread/realtime/closed` | realtime 关闭。 |

## 7. 官方文档与当前 schema 的差异清单

本节只记录本次校验发现的差异，不代表目标版本一定不可用。集成时用目标
`codex` 二进制重新生成 schema。

### 7.1 官方文档列出，但本机 0.137.0 顶层 schema 未暴露

- `thread/delete`
- `thread/turns/list`
- `thread/turns/items/list`
- `thread/backgroundTerminals/clean`
- `thread/backgroundTerminals/list`
- `thread/backgroundTerminals/terminate`
- `process/spawn`
- `process/writeStdin`
- `process/resizePty`
- `process/kill`
- `collaborationMode/list`
- `tool/requestUserInput`
- `account/rateLimitResetCredit/consume`
- `account/usage/read`
- `externalAgentConfig/import/readHistories`
- `externalAgentConfig/import/progress`
- `thread/deleted`

### 7.2 当前 schema 暴露，但官方文档正文未详细展开

- `thread/approveGuardianDeniedAction`
- `skills/extraRoots/set`
- `hooks/list`
- `marketplace/remove`
- `plugin/installed`
- `plugin/skill/read`
- `plugin/share/save`
- `plugin/share/updateTargets`
- `plugin/share/list`
- `plugin/share/checkout`
- `plugin/share/delete`
- `permissionProfile/list`
- `windowsSandbox/readiness`
- `fuzzyFileSearch`
- `getConversationSummary`
- `gitDiffToRemote`
- `getAuthStatus`
- `rawResponseItem/completed`
- `thread/realtime/*`
- `windows/worldWritableWarning`
- `attestation/generate`
- `mcpServer/elicitation/request`
- `item/permissions/requestApproval`

## 8. 集成建议

1. 每次升级 `codex` 后重新生成 `generate-ts` 或 `generate-json-schema`，不要只依赖手写文档。
2. 客户端按连接执行 `initialize` -> `initialized`，并在 `initialize` 中声明实验能力和通知 opt-out。
3. 请求/响应用 `id` 做关联；服务端请求也必须响应，否则审批、工具调用或 token refresh 会卡住。
4. Thread UI 以 `item/completed` 的最终 item 为权威状态，delta 只用于流式展示。
5. 文件、命令、process、shellCommand 都是高风险能力；即使协议允许，也应在产品层做显式用户意图和权限边界。
