# CodexApp 产品说明书

| 项目 | 内容 |
| --- | --- |
| 产品名称 | CodexApp |
| 产品形态 | 本地桌面应用客户端 |
| 文档类型 | 产品说明书 |
| 文档版本 | v0.1 |
| 日期 | 2026-06-22 |
| 当前状态 | 设计定义稿 |
| 主要依赖 | Electron、AgentHost、codexapp-go、Codex app-server |

## 1. 产品定义

CodexApp 是一款面向本地开发与工程协作场景的“超级 Agent”桌面应用客户端。它不是分布式系统，也不是云端 SaaS 控制台，而是在用户本机运行的桌面应用，通过本地宿主/承载层连接 Codex app-server，向用户提供可视化的 agent 会话、任务执行、事件流、审批、工具调用和运行状态管理能力。

CodexApp 的核心 runtime 接入架构分为以下层次：

1. Electron：桌面应用前端壳，负责 UI、桌面交互和用户体验。
2. AgentHost：本地宿主/承载层，对 Electron 暴露 HTTP RESTful API，负责 runtime 控制、事件转发和状态投影。
3. AgentRuntime：AgentHost 内部 runtime 抽象，定义 thread、turn、事件和 pending request 的统一模型。
4. CodexRuntime Adapter：AgentRuntime 的 Codex 实现，通过 `codexapp-go` 接入并适配 Codex app-server。
5. codexapp-go：Codex app-server JSON-RPC 的基础 Go SDK。
6. Codex app-server：agent runtime，负责 Codex thread、turn、事件流、工具调用、审批和底层运行时能力。

另有一个独立的 Go SDK：

- `codexapp-go`：纯 Go client SDK，只封装 Codex app-server JSON-RPC 协议，供 CodexRuntime Adapter 引用。

## 2. 产品目标

### 2.1 核心目标

- 提供一个稳定、清晰、可维护的本地桌面 Agent 客户端。
- 将 Electron UI 与 Codex app-server JSON-RPC 细节隔离。
- 让 AgentHost 成为本地宿主/承载层，负责 runtime 接入、适配、控制、事件转发和本地状态聚合。
- 让 `codexapp-go` 成为 Codex app-server JSON-RPC 的类型安全 Go 封装包。
- 让 Codex app-server 专注于 agent runtime，不承载 CodexApp 的产品业务逻辑。

### 2.2 非目标

- 不做分布式 agent 调度系统。
- 不让 Electron 直接连接 Codex app-server。
- 不让 `codexapp-go` 管理进程、启动程序、维护业务状态或暴露 HTTP API。
- 不在 Codex app-server 内修改或嵌入 CodexApp 专属业务逻辑。
- 不在 MVP 阶段实现团队协作、多租户、远程服务器控制台或云端同步。

## 3. 目标用户

| 用户类型 | 需求 |
| --- | --- |
| 本地开发者 | 在桌面 UI 中创建、恢复、管理 Codex agent 会话。 |
| 高级工程用户 | 查看 turn 事件、工具调用、命令执行、文件修改、审批请求和错误详情。 |
| 产品/研发集成者 | 基于 AgentHost 扩展本地工作流、状态管理和产品能力。 |
| SDK 使用者 | 在 Go 服务中通过 `codexapp-go` 类型安全调用 Codex app-server JSON-RPC。 |

## 4. 总体架构

```mermaid
flowchart TB
  User["用户"]
  Electron["Electron 桌面客户端"]
  AgentHost["AgentHost 本地宿主/承载层"]
  AgentRuntime["AgentRuntime 抽象"]
  CodexAdapter["CodexRuntime Adapter"]
  SDK["codexapp-go SDK"]
  AppServer["Codex app-server"]

  User --> Electron
  Electron -->|"HTTP REST / SSE"| AgentHost
  AgentHost --> AgentRuntime
  AgentRuntime --> CodexAdapter
  CodexAdapter --> SDK
  SDK -->|"JSON-RPC"| AppServer
  AppServer -->|"thread / turn / item events"| SDK
  SDK --> CodexAdapter
  CodexAdapter --> AgentRuntime
  AgentRuntime --> AgentHost
  AgentHost -->|"事件投影 / 状态聚合"| Electron
```

### 4.1 分层原则

| 层级 | 职责 | 不负责 |
| --- | --- | --- |
| Electron | 桌面 UI、交互、会话视图、审批弹窗、设置页、事件展示 | 不直接调用 JSON-RPC；不保存 runtime 权威状态；不启动 agent runtime |
| AgentHost | HTTP API、runtime 控制、事件订阅与转发、状态投影、权限审批转发、错误归一化、本地生命周期协调 | 不实现 Codex agent runtime；不把 JSON-RPC 类型散落到 UI；不直接调用 Codex JSON-RPC |
| AgentRuntime | thread、turn、RuntimeEvent、PendingRequest 的统一抽象 | 不封装 Codex JSON-RPC；不提供 HTTP/SSE；不决定 UI 展示 |
| CodexRuntime Adapter | Codex runtime 接入、适配、控制和事件翻译，引用 `codexapp-go` | 不实现 JSON-RPC transport；不暴露给 Electron；不保存 UI 投影 |
| codexapp-go | JSON-RPC 连接、请求/响应类型、通知订阅、服务端请求响应、错误封装 | 不启动系统程序；不提供 REST API；不做业务编排；不面向 Electron |
| Codex app-server | thread、turn、item、工具调用、审批请求、MCP、文件/命令运行时能力 | 不理解 CodexApp 产品页面；不管理 Electron 状态 |

## 5. 产品范围

### 5.1 MVP 范围

MVP 必须覆盖：

- 本地启动桌面应用。
- 检查 AgentHost 和 Codex app-server 可用性。
- 创建、恢复、查看 Codex thread。
- 启动、追加、打断 turn。
- 实时展示 agent message、plan、reasoning summary、command、file change、MCP tool call 等事件。
- 处理命令执行审批、文件变更审批和用户输入请求。
- 展示账户状态、模型列表、基础配置和错误信息。
- 保留可诊断的本地日志。
- 通过 `codexapp-go` 调用 Codex app-server，不在 AgentHost 中手写零散 JSON-RPC。

### 5.2 后续范围

- 插件与 marketplace 管理。
- Apps/connectors 管理。
- 更完整的 MCP server 管理。
- 历史会话搜索、归档、删除和标签。
- 更精细的权限 profile、sandbox 策略和安全提示。
- 多平台打包：macOS、Windows、Linux。

### 5.3 明确不在当前范围

- 云端账号系统。
- 团队空间、多用户协作、多租户权限。
- 远程 agent worker 集群。
- 自研模型运行时。
- 绕过 Codex app-server 直接调用 Responses API。

## 6. 核心功能说明

### 6.1 桌面首页

用途：作为用户进入 CodexApp 的主工作台。

功能：

- 显示最近 thread 列表。
- 显示当前 Codex runtime 状态。
- 提供新建会话入口。
- 提供设置、账号、日志和诊断入口。

验收标准：

- 用户打开应用后能明确看到 runtime 是否可用。
- 用户能在 2 次点击内创建一个新 agent 会话。
- 当 Codex app-server 不可用时，页面必须给出可执行的错误提示。

### 6.2 Thread 管理

用途：管理 Codex app-server 的 conversation thread。

功能：

- 新建 thread。
- 恢复已有 thread。
- fork thread。
- 读取 thread 详情。
- 列出 thread 历史。
- 归档和恢复归档。
- 设置 thread 名称。
- 设置、读取和清除 thread goal。

数据来源：

- 权威数据来自 Codex app-server。
- AgentHost 可以维护本地缓存或投影，但必须能从 app-server 重新构建。

### 6.3 Turn 执行

用途：让用户向 agent 发起一次任务请求。

功能：

- 发起 `turn/start`。
- 通过 `turn/steer` 追加指令。
- 通过 `turn/interrupt` 中断执行。
- 展示 turn 状态：运行中、完成、失败、中断。
- 展示 turn 错误，包括上游 HTTP 错误、sandbox 错误、用量限制和内部错误。

输入类型：

- 文本。
- 图片 URL。
- 本地图片路径。
- skill 引用。
- app/connector mention。

### 6.4 事件流展示

用途：把 Codex app-server 的 JSON-RPC 通知转换成用户可理解的 UI 状态。

必须展示的事件类型：

- `thread/*`：thread 生命周期和状态变化。
- `turn/*`：turn 开始、完成、diff、plan。
- `item/started`、`item/completed`：工作项生命周期。
- `item/agentMessage/delta`：agent 回复流式文本。
- `item/commandExecution/outputDelta`：命令输出。
- `item/fileChange/patchUpdated` 和 `turn/diff/updated`：文件变更。
- `item/mcpToolCall/progress`：MCP 工具进度。
- `account/*`：账号和 rate limit 状态。
- `serverRequest/resolved`：审批或用户输入请求完成。

AgentHost 责任：

- 订阅 JSON-RPC 通知。
- 转换成前端稳定事件模型。
- 对 Electron 暴露 SSE 事件流。

Electron 责任：

- 消费 SSE。
- 更新 UI。
- 不解析底层 JSON-RPC 联合类型。

### 6.5 审批与用户输入

用途：处理 Codex app-server 主动发起的 server request。

必须支持：

- `item/commandExecution/requestApproval`
- `item/fileChange/requestApproval`
- `item/tool/requestUserInput`
- `item/permissions/requestApproval`
- `mcpServer/elicitation/request`
- `account/chatgptAuthTokens/refresh`

流程：

1. app-server 向 SDK 发送 server request。
2. SDK 将请求交给 CodexRuntime Adapter。
3. CodexRuntime Adapter 映射为 AgentRuntime PendingRequest。
4. AgentHost 建立 pending approval 状态。
5. Electron 展示审批或输入 UI。
6. 用户操作后 Electron 调用 AgentHost REST API。
7. AgentHost 通过 AgentRuntime/CodexRuntime Adapter 调用 SDK 回应 app-server。
8. app-server 发送 `serverRequest/resolved`。
9. AgentHost 清理 pending 状态并通知 Electron。

约束：

- 审批请求必须按 `threadId`、`turnId`、`itemId` 归属。
- 用户未响应前不得静默接受高风险动作。
- Electron 刷新后必须能从 AgentHost 恢复 pending approval 状态。

### 6.6 文件与命令能力

用途：向用户展示 Codex runtime 中的文件变更和命令执行。

边界：

- Codex app-server 执行 runtime 能力。
- AgentHost 转发请求、记录状态、处理审批和安全提示。
- Electron 展示结果。
- `codexapp-go` 只负责协议调用和事件接收。

安全要求：

- 高风险命令和文件修改必须走审批。
- `thread/shellCommand` 属于用户显式命令入口，不应被隐藏触发。
- 文件删除、递归删除、写入敏感路径必须有明确 UI 提示。

### 6.7 账号、模型与配置

功能：

- 读取账号状态。
- 发起登录、取消登录和登出。
- 读取 ChatGPT rate limits。
- 列出模型。
- 读取配置。
- 写入必要的本地配置。
- 读取 admin requirements。

约束：

- Electron 不直接保存 access token。
- 敏感信息由 Codex/app-server 或系统安全存储处理。
- AgentHost 对外只返回 UI 必需字段。

### 6.8 Skill、Plugin、App、MCP 能力

MVP 支持：

- 列出 skills。
- 在 turn 输入中引用 skill。
- 列出 apps/connectors。
- 调用 MCP tool。
- 读取 MCP server 状态。

后续增强：

- plugin install/uninstall。
- marketplace add/upgrade/remove。
- app settings 管理。
- MCP OAuth 完整管理 UI。

## 7. AgentHost 说明

### 7.1 定位

AgentHost 是 CodexApp 的本地宿主/承载层。它对 Electron 提供稳定 HTTP API，内部通过 AgentRuntime 控制 agent runtime，并由 CodexRuntime Adapter 通过 `codexapp-go` 接入并适配 Codex app-server。

### 7.2 主要职责

- 管理本地 HTTP server。
- 管理 Electron 可消费的 REST API。
- 通过 AgentRuntime 调用具体 runtime adapter。
- 由 CodexRuntime Adapter 连接 `codexapp-go`。
- 接入并适配本地 Agent Runtime。
- 控制 runtime thread/turn 生命周期。
- 管理 thread 会话投影。
- 转换 JSON-RPC 通知为前端事件。
- 维护 pending approval 状态。
- 聚合诊断信息。
- 协调 Codex app-server 可用性检查。
- 处理本地配置读写。

### 7.3 不负责

- 不实现 Codex agent 运行时。
- 不直接执行模型推理。
- 不让 UI 依赖 JSON-RPC 原始类型。
- 不把 SDK 的协议类型复制成多套分叉定义。

## 8. codexapp-go SDK 说明

### 8.1 定位

`codexapp-go` 是 Codex app-server JSON-RPC 协议的纯 Go client SDK。它是库，不是应用，不直接运行系统程序。

### 8.2 主要职责

- 建立 app-server transport 连接。
- 执行 `initialize`/`initialized` 握手。
- 管理 JSON-RPC request id。
- 提供类型安全的请求方法。
- 提供通知订阅机制。
- 提供 server request 响应机制。
- 统一 JSON-RPC error 和 protocol error。
- 暴露当前协议版本的 Go 类型。

### 8.3 不负责

- 不启动 Codex app-server 进程。
- 不管理 Electron 生命周期。
- 不提供 HTTP REST API。
- 不做业务编排。
- 不保存产品级会话状态。
- 不直接面向 Electron。

### 8.4 SDK API 形态

建议形态：

```go
client, err := codexapp.Connect(ctx, codexapp.StdioTransport(cmd))
if err != nil {
    return err
}

initResp, err := client.Initialize(ctx, codexapp.InitializeParams{
    ClientInfo: codexapp.ClientInfo{
        Name:    "codexapp_agenthost",
        Title:   "CodexApp AgentHost",
        Version: "0.1.0",
    },
})
```

事件订阅建议：

```go
events := client.Events()
for event := range events {
    // CodexRuntime Adapter 将 SDK event 转为 AgentRuntime 事件。
}
```

说明：以上是产品级 API 形态要求，不是最终代码实现约束。

## 9. Electron 客户端说明

### 9.1 定位

Electron 是 CodexApp 的桌面 UI 层，只和 AgentHost 通信。

### 9.2 页面模块

| 页面 | 功能 |
| --- | --- |
| 首页 | runtime 状态、最近会话、新建入口 |
| 会话页 | thread/turn/item 展示、输入框、事件流、diff、命令输出 |
| 审批中心 | 命令审批、文件审批、权限审批、用户输入请求 |
| 设置页 | 模型、sandbox、approval、MCP、apps、日志 |
| 诊断页 | AgentHost 状态、app-server 状态、最近错误、日志路径 |

### 9.3 UI 约束

- UI 只调用 AgentHost REST API。
- 事件流只消费 AgentHost 的 SSE 或等价单向事件流。
- 不出现 Codex app-server transport 配置细节。
- 审批操作必须明确展示风险、命令、路径和作用域。

## 10. AgentHost 对 Electron 的 REST API 边界

MVP 推荐使用 HTTP REST 加 SSE。REST 负责命令式操作，SSE 负责事件流。

### 10.1 健康与诊断

| 方法 | 路径 | 用途 |
| --- | --- | --- |
| `GET` | `/api/health` | 检查 AgentHost 可用性。 |
| `GET` | `/api/runtime/status` | 返回 Codex app-server 连接状态、版本和初始化状态。 |
| `GET` | `/api/diagnostics` | 返回最近错误、日志位置、runtime 状态摘要。 |

### 10.2 Thread

| 方法 | 路径 | 用途 |
| --- | --- | --- |
| `GET` | `/api/threads` | 列出 thread。 |
| `POST` | `/api/threads` | 创建 thread。 |
| `GET` | `/api/threads/{threadId}` | 读取 thread 详情。 |
| `POST` | `/api/threads/{threadId}/resume` | 恢复 thread。 |
| `POST` | `/api/threads/{threadId}/fork` | fork thread。 |
| `POST` | `/api/threads/{threadId}/archive` | 归档 thread。 |
| `POST` | `/api/threads/{threadId}/unarchive` | 取消归档。 |
| `PUT` | `/api/threads/{threadId}/name` | 设置 thread 名称。 |
| `PUT` | `/api/threads/{threadId}/goal` | 设置 goal。 |
| `GET` | `/api/threads/{threadId}/goal` | 读取 goal。 |
| `DELETE` | `/api/threads/{threadId}/goal` | 清除 goal。 |

### 10.3 Turn

| 方法 | 路径 | 用途 |
| --- | --- | --- |
| `POST` | `/api/threads/{threadId}/turns` | 启动 turn。 |
| `POST` | `/api/threads/{threadId}/turns/{turnId}/steer` | 追加输入。 |
| `POST` | `/api/threads/{threadId}/turns/{turnId}/interrupt` | 中断 turn。 |

### 10.4 事件与审批

| 方法 | 路径 | 用途 |
| --- | --- | --- |
| `GET` | `/api/events` | SSE 全局事件流。 |
| `GET` | `/api/threads/{threadId}/events` | SSE thread 事件流。 |
| `GET` | `/api/approvals` | 列出 pending approval。 |
| `POST` | `/api/approvals/{approvalId}/resolve` | 响应审批或用户输入。 |

### 10.5 配置与账号

| 方法 | 路径 | 用途 |
| --- | --- | --- |
| `GET` | `/api/account` | 读取账号状态。 |
| `POST` | `/api/account/login` | 发起登录。 |
| `POST` | `/api/account/logout` | 登出。 |
| `GET` | `/api/models` | 列出模型。 |
| `GET` | `/api/config` | 读取配置。 |
| `PATCH` | `/api/config` | 写入配置。 |

## 11. 状态模型

### 11.1 核心对象

| 对象 | 来源 | 说明 |
| --- | --- | --- |
| Thread | Codex app-server | 会话容器。 |
| Turn | Codex app-server | 一次用户请求和 agent 执行过程。 |
| Item | Codex app-server | turn 内的消息、命令、文件变更、工具调用等单元。 |
| RuntimeEvent | AgentHost 投影 | 给 Electron 消费的稳定事件。 |
| ApprovalRequest | AgentHost 投影 | 服务端请求的产品态包装。 |
| AccountStatus | Codex app-server | 当前认证和额度状态。 |
| RuntimeStatus | AgentHost | 本地 runtime 健康状态。 |

### 11.2 权威状态原则

- Codex thread、turn、item 的权威状态来自 Codex app-server。
- AgentHost 可以缓存和投影，但不得成为 runtime 事实源。
- Electron 只保存 UI 临时状态。
- 审批 pending 状态由 AgentHost 维护，以支持 UI 刷新恢复。

## 12. 错误处理

### 12.1 错误分类

| 类型 | 示例 | 处理 |
| --- | --- | --- |
| 连接错误 | app-server 不可用、transport 断开 | AgentHost 标记 runtime unavailable，Electron 展示重连/诊断。 |
| 协议错误 | JSON-RPC error、未知 method | SDK 归一化错误，AgentHost 记录日志。 |
| 运行时错误 | turn failed、sandbox error、usage limit | Electron 在会话页展示具体原因。 |
| 审批错误 | approval 超时、请求已清理 | Electron 清理弹窗并展示状态。 |
| 配置错误 | config invalid、requirements 冲突 | 设置页展示可修复项。 |

### 12.2 用户可见要求

- 所有失败必须有可读错误文案。
- 高风险能力失败不得吞掉原始原因。
- 诊断页必须能看到最近错误和发生时间。

## 13. 安全与权限

要求：

- AgentHost 默认只监听本机地址。
- Electron 不直接持有 Codex access token。
- 文件写入、删除、命令执行、网络授权必须有明确审批边界。
- app-server WebSocket 不应在未认证情况下暴露到非 loopback 网络。
- 日志不得记录 access token、API key 或完整 bearer token。
- 用户确认前不得自动接受 destructive 操作。

## 14. 性能与可靠性

### 14.1 性能目标

| 指标 | 目标 |
| --- | --- |
| 应用启动到首页可见 | 3 秒内，冷启动可放宽 |
| 创建 thread 响应 | 1 秒内返回或显示 loading |
| 事件流延迟 | 本地环境下 200ms 级别 |
| 大量命令输出 | UI 不阻塞，输出可增量渲染 |

### 14.2 可靠性要求

- AgentHost 崩溃后重启应能重新读取 thread 历史。
- Electron 刷新后应能恢复当前 thread 和 pending approval。
- app-server 断连后应显示状态，并支持重连或重启引导。
- SDK 必须正确处理 request id、响应匹配、通知分发和 server request。

## 15. 日志与可观测性

必须记录：

- AgentHost 启动和关闭。
- app-server 连接状态。
- initialize 成功/失败。
- thread/turn 关键生命周期。
- 审批请求创建和解决。
- JSON-RPC 错误。
- 用户可见错误。

不记录：

- access token。
- API key。
- 敏感文件内容。
- 未经脱敏的完整命令输出历史，除非用户明确开启诊断日志。

## 16. 打包与运行

### 16.1 桌面应用包

Electron 包含：

- 前端资源。
- AgentHost 二进制。
- 本地配置模板。
- 必要的启动脚本或 launcher。

### 16.2 Codex app-server 可用性

Codex app-server 可以由本地 Codex 安装提供。产品必须在启动时检查：

- `codex` 是否存在。
- `codex app-server --help` 是否可用。
- 目标 transport 是否可连接。
- 当前版本是否满足最小协议要求。

进程启动和守护策略属于 AgentHost/桌面启动链路，不属于 `codexapp-go` SDK。

## 17. 验收标准

### 17.1 产品级验收

- Electron 能通过 AgentHost 创建 thread 并启动 turn。
- 用户能看到 agent 流式回复。
- 用户能看到命令、文件、工具调用等 item 状态。
- 审批请求能从 app-server 到 UI，再由 UI 回到 app-server 完整闭环。
- runtime 不可用时 UI 给出明确诊断。
- Electron 没有直接 JSON-RPC 调用。
- AgentHost 调用 app-server 必须经过 AgentRuntime、CodexRuntime Adapter 和 `codexapp-go`。
- `codexapp-go` 不包含进程启动、HTTP server 或 Electron 相关代码。

### 17.2 SDK 级验收

- 支持 initialize/initialized。
- 支持客户端请求、服务端通知、服务端请求三类 JSON-RPC 消息。
- 支持 request id 并发匹配。
- 支持 context cancellation。
- 支持错误封装。
- 支持事件订阅。
- 支持 server request 响应。
- 覆盖当前目标版本 Codex app-server schema 中的主要方法。

## 18. 版本路线

### v0.1 MVP

- Electron 基础会话 UI。
- AgentHost HTTP API。
- codexapp-go 基础 JSON-RPC client。
- thread/start、thread/resume、turn/start、turn/steer、turn/interrupt。
- 核心事件展示。
- 命令和文件审批。
- 基础账号、模型、配置读取。

### v0.2 Beta

- thread 历史增强。
- skill/app/MCP 管理增强。
- plugin/marketplace 基础管理。
- 诊断页增强。
- 更完整的错误恢复。

### v1.0

- 稳定桌面打包。
- 完整权限与审批体验。
- 完整会话历史体验。
- 跨平台基础支持。
- SDK API 稳定化。

## 19. 未决问题

| 问题 | 影响 |
| --- | --- |
| Codex app-server 由 AgentHost 启动、连接 daemon，还是要求用户预装并由系统管理 | 影响打包、启动、错误恢复 |
| MVP 事件流使用 SSE 还是 WebSocket | SSE 更简单；WebSocket 适合未来双向低延迟 |
| Windows sandbox 能力是否进入 MVP | 影响 Windows 首版范围 |
| plugin/marketplace 是否进入首版 UI | 影响设置页复杂度 |
| `codexapp-go` 是否完全由 schema 生成类型 | 影响 SDK 维护成本和协议漂移风险 |

## 20. 最终边界声明

CodexApp 是本地桌面产品。Electron 负责用户体验，AgentHost 负责本地宿主/承载、runtime 控制、事件转发和状态投影，AgentRuntime 负责统一 runtime 抽象，CodexRuntime Adapter 负责 Codex 接入和适配，`codexapp-go` 负责 Codex app-server JSON-RPC 协议封装，Codex app-server 负责 agent runtime。

任何新功能必须先判断归属层级。不能把 UI 逻辑放进 SDK，不能把协议细节泄漏给 Electron，不能把产品业务塞进 Codex app-server。
