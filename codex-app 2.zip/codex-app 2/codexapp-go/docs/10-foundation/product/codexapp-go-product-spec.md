# codexapp-go 产品说明书

| 项目 | 内容 |
| --- | --- |
| 产品名称 | codexapp-go |
| 产品形态 | Go client SDK / library |
| 文档类型 | 产品说明书 |
| 文档版本 | v0.1 |
| 日期 | 2026-06-22 |
| 当前状态 | 产品定义稿 |
| 主要使用方 | AgentHost 内的 CodexRuntime Adapter |
| 上游依赖 | Codex app-server JSON-RPC 协议 |
| 下游消费者 | CodexApp 的 CodexRuntime Adapter，不直接面向 Electron |
| 参考文档 | `docs/10-foundation/protocol/app-server/official-doc-snapshot.md`、`docs/10-foundation/protocol/app-server/json-rpc-manual.md`、`../../agent-host/docs/agent-runtime-product-spec.md` |

## 1. 产品定义

`codexapp-go` 是一个纯 Go client SDK，用于封装 Codex app-server 的 JSON-RPC 接口。它的唯一职责是让 AgentHost 内的 CodexRuntime Adapter 能以类型安全、可维护、可测试的方式调用 Codex app-server，并订阅 app-server 发出的通知和 server request。具体开发顺序、M2+ facade 分期和首版 API 签名以 `docs/20-delivery/execution/execution-spec.md` 为准。

本文中的 `AgentHost` 指“超级 Agent”桌面应用中的本地宿主/承载层。`AgentRuntime` 是 AgentHost 内部的 runtime 抽象，`CodexRuntime Adapter` 是该抽象的 Codex 实现，也是 `codexapp-go` 的直接调用方。

`codexapp-go` 不是桌面应用，不是 AgentHost 服务，不是 AgentRuntime，也不是 Electron 可直接调用的 API 层。它作为 CodexRuntime Adapter 引用的第三方包或内部基础库存在。

在当前“超级 Agent”桌面应用架构中，`codexapp-go` 位于 CodexRuntime Adapter 与 Codex app-server 之间：

```mermaid
flowchart TB
  Electron["Electron 桌面客户端"]
  AgentHost["AgentHost 本地宿主/承载层"]
  AgentRuntime["AgentRuntime 抽象"]
  CodexAdapter["CodexRuntime Adapter"]
  SDK["codexapp-go SDK"]
  AppServer["Codex app-server"]

  Electron -->|"HTTP REST / SSE"| AgentHost
  AgentHost --> AgentRuntime
  AgentRuntime --> CodexAdapter
  CodexAdapter -->|"Go API"| SDK
  SDK -->|"JSON-RPC"| AppServer
  AppServer -->|"responses / notifications / server requests"| SDK
  SDK -->|"typed events / typed responses"| CodexAdapter
  CodexAdapter -->|"RuntimeEvent / PendingRequest"| AgentRuntime
  AgentRuntime --> AgentHost
```

## 2. 产品定位

### 2.1 一句话定位

`codexapp-go` 是 Codex app-server JSON-RPC 协议的类型安全 Go SDK。

### 2.2 核心价值

- 屏蔽 JSON-RPC 连接、请求 id、响应匹配、通知分发等底层细节。
- 为 CodexRuntime Adapter 提供稳定的 Go API。
- 用生成类型覆盖 app-server 协议面，降低手写协议漂移风险。
- 用真实 app-server 契约测试校验运行行为，而不仅依赖静态类型。
- 把 Codex app-server 的事件流、审批请求、工具调用请求以 typed SDK 消息暴露给 CodexRuntime Adapter。

### 2.3 产品边界

| 维度 | 是什么 | 不是什么 |
| --- | --- | --- |
| 产品形态 | Go SDK / library | 独立进程、桌面应用、HTTP 服务 |
| 使用者 | CodexRuntime Adapter | Electron、最终用户、远程第三方客户端 |
| 协议职责 | JSON-RPC client、类型、事件订阅、server request 回复 | REST API、SSE API、业务状态投影 |
| 运行职责 | 管理已有 transport 上的 JSON-RPC 通信 | 启动系统程序、管理 app-server 进程生命周期 |
| 业务职责 | 暴露 app-server 原生能力的 Go 封装 | 定义 CodexApp 产品业务、任务编排、UI 状态 |

## 3. 背景与问题

CodexApp 的本地 runtime 接入链路分为以下层次：

1. Electron：负责用户界面和桌面端体验。
2. AgentHost：本地宿主/承载层，负责 runtime 接入、适配、控制、事件转发，对 Electron 提供 HTTP RESTful API，并消费 Codex runtime 能力。
3. AgentRuntime：AgentHost 内部 runtime 抽象，定义 thread、turn、事件和 pending request 的统一模型。
4. CodexRuntime Adapter：AgentRuntime 的 Codex 实现，使用 `codexapp-go` 翻译 Codex app-server 能力。
5. codexapp-go：Codex app-server JSON-RPC 的基础 Go SDK。
6. Codex app-server：负责 thread、turn、事件流、工具调用、审批、MCP 等 agent runtime 能力。

如果 CodexRuntime Adapter 或 AgentHost 直接散落手写 JSON-RPC 调用，会产生以下问题：

- method 名称、字段、响应类型容易漂移。
- request id、并发响应匹配、超时、取消、server request 回复逻辑重复出现。
- 通知和事件分发缺少统一入口。
- app-server 版本升级时难以判断影响范围。
- AgentHost runtime 接入代码会混入大量底层协议细节。

`codexapp-go` 的存在就是为了解决这些协议接入问题，把 Codex app-server 的 JSON-RPC 能力封装成一个基础、稳定、可复用的 Go SDK。

## 4. 产品目标

### 4.1 核心目标

- 提供 Codex app-server JSON-RPC 的完整 Go 封装。
- 支持 request/response、notification、server request 三类 JSON-RPC 消息。
- 提供类型安全的参数、响应、通知和错误模型。
- 支持 app-server 初始化握手：`initialize` -> `initialized`。
- 支持事件订阅和分发，让 CodexRuntime Adapter 能稳定消费 `thread/*`、`turn/*`、`item/*`、`account/*` 等通知。
- 支持服务端主动请求的处理和回复，例如审批、用户输入、动态工具调用和 token refresh。
- 支持 app-server 协议版本升级时的类型再生成、差异检测和契约测试。

### 4.2 质量目标

- 正确性优先于封装厚度。
- 协议覆盖优先于手写便利 API。
- 错误必须可诊断，不吞掉 JSON-RPC error、transport error 或 protocol mismatch。
- 并发请求必须准确匹配响应。
- 通知分发不能阻塞底层 reader。
- server request 必须能被 CodexRuntime Adapter 接管，并由 AgentHost 产品层决策后按 id 回复。

### 4.3 非目标

- 不开发 Electron UI。
- 不提供 HTTP RESTful API。
- 不提供 SSE/WebSocket 给 Electron。
- 不实现业务编排、任务状态机、会话投影或审批策略。
- 不直接启动、安装、升级或守护 Codex app-server 进程。
- 不封装 OpenAI Responses API。
- 不替代 Codex app-server 的 runtime 能力。
- 不把 CodexApp 的产品概念强加到 SDK 类型里。
- 不做分布式、多租户、远程集群或云端控制面。

## 5. 目标用户与使用场景

### 5.1 目标用户

| 用户 | 需求 |
| --- | --- |
| CodexRuntime Adapter 开发者 | 在 Go 代码中稳定调用 app-server，并把结果转换为 AgentRuntime 事件和 pending request。 |
| AgentHost 开发者 | 通过 AgentRuntime 消费统一 runtime 能力，不直接处理 Codex JSON-RPC。 |
| CodexApp 平台维护者 | 能跟随 app-server 版本升级，确认协议覆盖和兼容性。 |
| 测试与发布维护者 | 能通过契约测试确认 SDK 与当前 app-server 行为一致。 |

### 5.2 典型使用场景

| 场景 | SDK 职责 | CodexRuntime Adapter / AgentHost 职责 |
| --- | --- | --- |
| 创建 thread | 调用 `thread/start`，返回 typed thread | Adapter 映射为 AgentRuntime thread；AgentHost 决定 UI 会话投影 |
| 启动 turn | 调用 `turn/start`，返回 initial turn | Adapter 映射为 AgentRuntime turn；AgentHost 维护前端任务状态 |
| 订阅事件 | 读取并分发 notifications | Adapter 转换为 RuntimeEvent；AgentHost 转换为 SSE |
| 处理审批 | 接收 server request，暴露 pending request，按 request id 回复 | Adapter 映射为 AgentRuntime PendingRequest；AgentHost 等待 Electron 操作 |
| 读取模型 | 调用 `model/list` | Adapter 映射为 capability 或模型列表；AgentHost 决定 UI 展示 |
| 读取账号 | 调用 `account/read` | Adapter 交给 AgentHost 过滤敏感字段 |
| MCP 工具调用 | 调用 `mcpServer/tool/call` 或消费 tool 事件 | Adapter 转换工具事件；AgentHost 决定是否暴露给具体产品功能 |

## 6. 功能范围

### 6.1 MVP 必须支持

#### 6.1.1 连接与会话

- 支持通过已建立的 transport 连接 app-server。
- 支持 stdio JSONL transport。
- 支持 WebSocket transport。
- 支持 Unix socket over WebSocket transport。
- 支持 context cancellation。
- 支持连接关闭和 reader loop 退出。
- 支持 `initialize` 请求和 `initialized` 通知。

说明：SDK 可以提供 transport 接口和默认实现，但不负责启动外部 `codex app-server` 进程。

#### 6.1.2 JSON-RPC 基础能力

- 自动生成 request id。
- 支持调用带 `id` 的 client request。
- 支持发送不带 `id` 的 client notification。
- 支持响应 app-server 发来的 server request。
- 支持并发请求的响应匹配。
- 支持请求级超时和取消。
- 支持 JSON-RPC error 解析。
- 支持未知 notification 的保底分发。

#### 6.1.3 类型安全协议覆盖

必须覆盖以下类型：

- client request params。
- client request response。
- client notification params。
- server notification params。
- server request params。
- server request response。
- JSON-RPC error。
- app-server 常用 domain 类型：Thread、Turn、ThreadItem、Account、Model、MCP status、Skill、Plugin、Config、Filesystem 等。

类型来源应优先使用 `codex app-server generate-ts` / `generate-json-schema` 产物生成 Go 类型。手写类型只能用于 transport、client runtime、错误包装和少量薄 facade。

#### 6.1.4 核心请求分组

SDK 必须至少提供下列能力分组。MVP 对所有分组的最低要求是 generated low-level 覆盖；手写 facade 按 `docs/20-delivery/execution/execution-spec.md` 分阶段交付。

| 分组 | 覆盖能力 |
| --- | --- |
| `Client` | 初始化、关闭、低层 request/notify、server request response。 |
| `Threads` | start、resume、fork、read、list、archive、unarchive、name、goal、rollback、compact、inject items。 |
| `Turns` | start、steer、interrupt。 |
| `Review` | review/start。 |
| `Models` | model/list、provider capabilities。 |
| `Account` | account/read、login、logout、rate limits、nudge email。 |
| `Config` | config/read、value write、batch write、requirements read、MCP reload。 |
| `Skills` | skills/list、skills/config/write、extra roots。 |
| `Apps` | app/list。 |
| `Plugins` | marketplace、plugin list/read/install/uninstall/share。 |
| `MCP` | status list、OAuth login、resource read、tool call。 |
| `Commands` | command/exec、write、resize、terminate。 |
| `Filesystem` | read、write、mkdir、metadata、readdir、remove、copy、watch、unwatch。 |
| `WindowsSandbox` | setupStart、readiness。 |
| `Feedback` | feedback/upload。 |

分组 API 是薄封装，不应引入新的业务模型。低频、实验或变化快的分组可以先只有 low-level 能力，不强制在首版全部手写 facade。

#### 6.1.5 通知订阅

SDK 必须支持订阅和消费 app-server notifications：

- `thread/*`
- `turn/*`
- `item/*`
- `account/*`
- `mcpServer/*`
- `skills/*`
- `app/*`
- `fs/*`
- `command/exec/*`
- `model/*`
- `warning`、`guardianWarning`、`deprecationNotice`、`configWarning`
- `thread/realtime/*`

SDK 应提供两层消费方式：

1. 原始 typed notification stream。
2. 按 method 或 Go 类型分发的 handler/subscribe 机制。

#### 6.1.6 Server request 处理

SDK 必须支持 app-server 主动发起的 server request：

| Server request | SDK 责任 |
| --- | --- |
| `item/commandExecution/requestApproval` | 解码请求，交给 CodexRuntime Adapter，按 id 回复决策。 |
| `item/fileChange/requestApproval` | 解码请求，交给 CodexRuntime Adapter，按 id 回复决策。 |
| `item/tool/requestUserInput` | 解码问题与选项，交给 CodexRuntime Adapter，按 id 回复答案。 |
| `mcpServer/elicitation/request` | 解码 elicitation schema，交给 CodexRuntime Adapter，按 id 回复。 |
| `item/permissions/requestApproval` | 解码权限请求，交给 CodexRuntime Adapter，按 id 回复。 |
| `item/tool/call` | 解码 dynamic tool 调用，交给 CodexRuntime Adapter，按 id 回复结果。 |
| `account/chatgptAuthTokens/refresh` | 解码刷新请求，交给 CodexRuntime Adapter，按 id 回复新 token。 |
| `attestation/generate` | 解码 attestation 请求，交给 CodexRuntime Adapter，按 id 回复。 |
| legacy approval requests | 兼容处理，但标记为 legacy。 |

SDK 不决定是否批准。审批策略属于 AgentHost 和 Electron 产品层。

### 6.2 后续增强

- 自动生成 Go 类型和 method facade 的代码生成器。
- 针对目标 app-server 版本的兼容性矩阵。
- record/replay 测试工具。
- request/notification tracing hook。
- 可选的高层 helper，例如 `RunTurnAndWait`。
- 可选的 schema diff 报告工具。

### 6.3 明确排除

- Electron 组件。
- AgentHost REST API。
- SSE 网关。
- 本地数据库。
- 任务编排状态机。
- app-server 进程守护。
- 自动下载或安装 Codex。
- 远程认证服务。

## 7. SDK 对外 API 要求

### 7.1 包结构

建议包结构：

```text
codexapp-go/
  client.go          # Client lifecycle and request dispatch
  jsonrpc.go         # JSON-RPC envelope and error model
  events.go          # Notification and server request dispatch
  protocol/          # Public generated protocol types and schema snapshots
  transport/         # Transport interface and built-in transports
  internal/runtime/  # Dispatcher, pending requests, event fanout
  threads.go         # Thin facade
  turns.go
  account.go
  models.go
  mcp.go
  config.go
  filesystem.go
```

产品要求不是固定文件名，而是要求职责清晰：公开 `protocol` 生成包、transport、client runtime、薄 facade 必须分开。

`protocol` 包是 SDK 的公开 API，生成代码和 schema snapshot 随 SDK 一起提交。CodexRuntime Adapter 不需要自行运行 codegen 才能使用 SDK。

### 7.2 Client 生命周期

SDK 应提供一个中心 client 对象：

```go
type Client struct {
    // internal fields
}
```

Client 最终必须支持；各阶段开放顺序以 `docs/20-delivery/execution/execution-spec.md` 为准：

- 建立连接。
- 执行初始化。
- 发送请求。
- 发送通知。
- 接收响应。
- 接收通知。
- 接收 server request。
- 关闭连接。

### 7.3 Transport 抽象

Transport 最小职责：

- 写出一条 JSON-RPC message。
- 读取一条 JSON-RPC message。
- 关闭底层连接。

内置 transport：

| Transport | 要求 |
| --- | --- |
| stdio JSONL | 读写 newline-delimited JSON。 |
| WebSocket | 一帧一条 JSON-RPC message。 |
| Unix socket WebSocket | 通过 Unix socket 建 WebSocket。 |

SDK 不负责启动 `codex app-server` 进程；如果调用方传入一个已经运行的 stdio 连接，SDK 可以使用该连接。

### 7.4 Request API

SDK 应提供两类 request API：

1. 通用低层 API：

```go
Request(ctx, method, params, resultPtr)
Notify(ctx, method, params)
Respond(ctx, id, result, rpcErr)
```

2. 类型安全高层 API：

```go
client.Threads().Start(ctx, params)
client.Turns().Start(ctx, params)
client.Models().List(ctx, params)
client.Account().Read(ctx, params)
```

低层 API 用于覆盖新增、实验或低频 method；高层 API 只手写覆盖 CodexRuntime Adapter 高频、稳定、语义清晰的常用 method。SDK 不要求每个 app-server method 都有手写 facade。

### 7.5 Event API

SDK 应提供 event stream：

```go
events := client.Events()
for event := range events {
    // CodexRuntime Adapter 转换为 AgentRuntime 事件。
}
```

SDK 同时应提供高频 delta stream：

```go
deltas := client.Deltas()
for delta := range deltas {
    // CodexRuntime Adapter 转换为 AgentRuntime delta 事件。
}
```

Event 必须包含：

- method。
- typed payload。
- raw payload。
- threadId/turnId/itemId 等可提取索引字段。
- 接收时间。
- 如果无法解码，包含 raw message 和 decode error。

### 7.6 Server request API

SDK 应提供 pending server request stream：

```go
requests := client.ServerRequests()
for req := range requests {
    // CodexRuntime Adapter 映射为 AgentRuntime PendingRequest，然后调用 req.Respond(...)
}
```

Server request 必须包含：

- request id。
- method。
- typed params。
- raw params。
- reply 方法。
- context。

同一个 request id 只能回复一次。重复回复必须返回 SDK 错误。

SDK 永远不自动 approve、decline、cancel 或回复审批类 server request；审批策略属于 AgentHost 和 Electron。

## 8. 协议覆盖要求

### 8.1 当前主参考

当前 SDK 设计以以下本地文档作为产品参考：

- `docs/10-foundation/protocol/app-server/official-doc-snapshot.md`
- `docs/10-foundation/protocol/app-server/json-rpc-manual.md`

精确字段以目标版本 `codex app-server generate-ts` 或 `generate-json-schema` 输出为准。

### 8.2 必须覆盖的消息方向

| 方向 | JSON-RPC 类型 | SDK 必须支持 |
| --- | --- | --- |
| Client -> Server | request | 是 |
| Client -> Server | notification | 是 |
| Server -> Client | response | 是 |
| Server -> Client | notification | 是 |
| Server -> Client | request | 是 |
| Client -> Server | response to server request | 是 |

### 8.3 版本差异策略

app-server 的官方文档和本机 schema 可能存在差异。SDK 必须采用以下策略：

- 以目标 app-server 版本生成的 schema 为最终类型依据。
- 文档提到但 schema 未暴露的接口，不进入默认 typed facade。
- schema 暴露但文档未展开的接口，可以进入 generated low-level 类型，是否提供 facade 由产品范围决定。
- 每次升级 app-server 版本必须生成差异报告。
- 版本差异必须体现在 changelog 和兼容性说明中。
- 删除 method、method 改名、字段从 optional 变 required、字段类型不兼容变化必须阻断发布，除非进入 major 版本并提供迁移说明。
- 新增 method、新增 optional 字段、新增 notification 可以作为 warning 进入发布流程。

## 9. 责任边界

### 9.1 SDK 与 AgentRuntime/CodexRuntime Adapter

| 能力 | codexapp-go | AgentRuntime / CodexRuntime Adapter |
| --- | --- | --- |
| JSON-RPC encode/decode | 负责 | 不重复实现 |
| request id 管理 | 负责 | 不直接管理 |
| 通知读取 | 负责 | Adapter 消费并转换为 RuntimeEvent |
| server request 回复 | 提供机制 | Adapter 映射 PendingRequest；AgentHost 决定业务动作 |
| thread/turn 业务状态 | 不负责 | AgentRuntime 定义统一模型；AgentHost 负责投影和缓存 |
| Electron REST API | 不负责 | AgentHost 负责 |
| SSE 事件流 | 不负责 | AgentHost 负责 |
| 审批策略 | 不负责 | AgentHost 负责 |
| app-server 进程生命周期 | 不负责 | 可由 AgentHost、Adapter 或外部 supervisor 负责 |

### 9.2 SDK 与 Electron

Electron 不直接引用 `codexapp-go`。所有 UI 操作必须经过 AgentHost 的 HTTP RESTful API 或 SSE 事件流。

### 9.3 SDK 与 Codex app-server

`codexapp-go` 不修改 app-server 行为，不 fork app-server 协议，不创建私有协议。它只忠实封装 app-server 当前 JSON-RPC 协议。

## 10. 数据与类型模型

### 10.1 核心类型

| 类型 | 来源 | 用途 |
| --- | --- | --- |
| `Thread` | generated | Codex conversation thread。 |
| `Turn` | generated | 单次用户请求和 agent 执行过程。 |
| `ThreadItem` | generated | message、command、file change、tool call 等工作项。 |
| `ClientRequest` | generated | 客户端可发起请求集合。 |
| `ServerNotification` | generated | app-server 通知集合。 |
| `ServerRequest` | generated | app-server 主动请求集合。 |
| `JSONRPCError` | SDK + generated | JSON-RPC 错误。 |
| `Event` | SDK hand-written | SDK 对通知的统一包装。 |
| `PendingRequest` | SDK hand-written | SDK 对 server request 的统一包装。 |

### 10.2 Raw 与 Typed 并存

SDK 必须同时保留 typed payload 和 raw payload：

- typed payload 用于正常业务开发。
- raw payload 用于诊断、未知字段兼容、版本升级排查。
- raw payload 不应泄漏敏感 token 到默认日志。

## 11. 错误处理

### 11.1 错误分类

| 错误类型 | 示例 | SDK 行为 |
| --- | --- | --- |
| TransportError | 连接断开、读写失败 | 返回错误，关闭事件流，通知 AgentHost。 |
| JSONRPCError | app-server 返回 `error` | 保留 code、message、data。 |
| TimeoutError | 请求超时 | 取消 pending request，返回 context error 包装。 |
| DecodeError | payload 无法解码 | 保留 raw message，发送 decode error event。 |
| ProtocolError | 重复 id、未知 response、重复 reply | 返回 SDK protocol error。 |
| ClosedError | client 已关闭后调用 | 立即返回错误。 |

### 11.2 错误要求

- 错误必须可 `errors.Is` / `errors.As`。
- JSON-RPC error 不得被转换成普通字符串丢失 code。
- transport 关闭必须唤醒所有 pending requests。
- server request decode 失败仍应暴露 raw message，便于 AgentHost 做兼容处理。

## 12. 并发与流控

### 12.1 并发要求

- 支持多个 goroutine 并发调用 request。
- request id 必须全局唯一且单调或不可碰撞。
- pending map 必须线程安全。
- writer 必须串行写消息。
- reader loop 必须独立运行。
- notification dispatch 不能阻塞 reader loop。

### 12.2 流控要求

- Event channel 必须有有限缓冲。
- 缓冲满时策略必须明确：阻塞、丢弃低优先级事件或返回 backpressure error。
- 默认策略应优先正确性：不静默丢弃事件。
- 大量 command output delta 不得无限占用内存。

## 13. 安全要求

- SDK 默认不记录完整 API key、access token、bearer token。
- SDK 不自动批准任何 command、file change 或 permission request。
- SDK 不绕过 app-server 的 sandbox/approval 策略。
- SDK 不把危险方法隐藏成无审批 helper。
- Raw message 日志必须支持调用方脱敏。
- WebSocket bearer token 只通过 header/安全配置传递，不建议写入普通日志。

## 14. 可观测性

SDK 应提供可选 hook，不强依赖具体日志库：

- request started。
- response received。
- notification received。
- server request received。
- server request resolved。
- reconnect/close。
- decode error。
- JSON-RPC error。

Hook 数据应包含：

- method。
- request id。
- duration。
- error category。
- threadId/turnId/itemId，如果可提取。

SDK 不决定日志写到哪里；日志存储归 AgentHost。

## 15. 测试与验收

### 15.1 单元测试

必须覆盖：

- JSON-RPC request encode/decode。
- response id 匹配。
- JSON-RPC error 解析。
- notification decode 和分发。
- server request reply 一次性约束。
- context cancellation。
- transport close 唤醒 pending request。

### 15.2 契约测试

必须使用真实 `codex app-server` 或等价协议 fixture 验证：

- `initialize` -> `initialized` 握手。
- `thread/start` 基本调用。
- `turn/start` 基本调用。
- 至少一种 notification 流。
- 至少一种 server request 处理。
- command exec 或安全 mock 场景。

说明：代码生成只能证明字段形状，不能证明 app-server 运行行为。高准确度必须依赖契约测试。

### 15.3 兼容性测试

每次升级 app-server 版本时必须检查：

- generated 类型是否变化。
- method 集合是否新增、删除或改名。
- 必填字段是否变化。
- 通知 payload 是否变化。
- server request response 是否变化。

### 15.4 产品验收标准

MVP 完成标准：

- CodexRuntime Adapter 可以通过 SDK 完成初始化、创建 thread、启动 turn。
- CodexRuntime Adapter 可以通过 SDK 接收 app-server notifications，并映射为 AgentRuntime 事件。
- CodexRuntime Adapter 可以通过 SDK 接收并回复 server requests。
- SDK 类型覆盖当前目标 schema 的 client request、server request、notification。
- SDK 有最小契约测试证明能与目标 app-server 通信。
- SDK 文档明确说明不负责启动 app-server、不面向 Electron、不做业务编排。
- SDK 提供 `Events()`、`Deltas()`、`ServerRequests()` 三类流，避免高频 delta 阻塞审批和关键事件。
- SDK 以 `Close()` 作为打断 transport 阻塞 I/O 的强保证；request context 只取消单次 request。

## 16. 发布与版本策略

### 16.1 版本号

SDK 使用语义化版本：

- patch：bugfix，不改变公共 API。
- minor：新增 method/type/facade，保持兼容。
- major：公共 API 或目标 app-server 协议基线发生不兼容变化。

### 16.2 app-server 协议基线

每个 SDK release 必须声明：

- 目标 Codex CLI/app-server 版本。
- 使用的 schema 生成时间。
- schema hash。
- 已知文档/schema 差异。
- 契约测试覆盖结果。

### 16.3 兼容策略

- SDK 不承诺跨任意 app-server 版本完全兼容。
- SDK 承诺对声明的目标 app-server 版本进行测试。
- 对实验 API 需要明确标记 unstable。

## 17. 文档要求

SDK 仓库或包内必须至少包含：

| 文档 | 内容 |
| --- | --- |
| README | 安装、最小示例、边界说明。 |
| API reference | 分组 API、类型、错误说明。 |
| Development execution spec | M0-M6 顺序、M2+ facade 分期、首版 API、事件分类、测试门禁。 |
| Compatibility | SDK 版本与 app-server 版本对应关系。 |
| Testing | 如何运行单元测试和契约测试。 |
| Changelog | 协议更新、breaking changes、已知差异。 |

## 18. 风险与约束

| 风险 | 影响 | 应对 |
| --- | --- | --- |
| app-server 协议变化快 | SDK 类型漂移 | schema/codegen + diff + 契约测试。 |
| 文档与 schema 不一致 | 手写 facade 出错 | 以目标版本 schema 为准，文档差异单独记录。 |
| 通知流量大 | CodexRuntime Adapter 事件处理阻塞 | reader 与 dispatch 解耦，有限缓冲和背压策略。 |
| server request 未回复 | app-server 执行卡住 | pending request 追踪、超时、重复回复保护。 |
| SDK 过度封装 | CodexRuntime Adapter 难以利用原生能力 | 保持薄 facade，保留 low-level request。 |
| 敏感信息进入日志 | 安全风险 | 默认脱敏，raw 日志由调用方显式开启。 |

## 19. 里程碑建议

| 阶段 | 目标 | 输出 |
| --- | --- | --- |
| M0 | 协议基线确认 | schema 生成、method 覆盖清单、差异说明。 |
| M1 | 最小 client | transport、request/response、initialize、close。 |
| M2 | 核心 typed API | Threads、Turns、Review、Models、Account。 |
| M3 | 事件与 server request | notification stream、approval/user input reply。 |
| M4 | 扩展协议覆盖 | MCP、Config、Commands、Filesystem 基础 facade；Skills、Apps、Plugins、WindowsSandbox、Feedback 先保证 low-level 覆盖。 |
| M5 | 契约测试 | 真实 app-server 初始化、thread、turn、notification、server request 测试。 |
| M6 | 文档与发布 | README、API reference、compatibility、changelog。 |

## 20. 最终边界声明

`codexapp-go` 的最终边界是：作为 Codex app-server JSON-RPC 协议的纯 Go client SDK，为 AgentHost 内的 CodexRuntime Adapter 提供类型安全 API、事件订阅、server request 回复和协议错误处理。

它不直接服务 Electron，不提供 REST API，不做业务编排，不启动系统程序，不替代 Codex app-server。凡是涉及产品状态、用户交互、审批策略、HTTP API、SSE 投影和桌面体验的能力，都属于 AgentHost 或 Electron，不属于 `codexapp-go`。
