# codexapp-go 技术架构说明书

| 项目 | 内容 |
| --- | --- |
| 文档名称 | codexapp-go 技术架构说明书 |
| 文档版本 | v0.1 |
| 日期 | 2026-06-22 |
| 目标产品 | codexapp-go |
| 产品形态 | Go client SDK / library |
| 主要使用方 | AgentHost 内的 CodexRuntime Adapter |
| 上游系统 | Codex app-server |
| 上游协议 | JSON-RPC 2.0 形态，线上省略 `jsonrpc` 字段 |
| 参考文档 | `docs/10-foundation/product/codexapp-go-product-spec.md`、`docs/10-foundation/protocol/app-server/official-doc-snapshot.md`、`docs/10-foundation/protocol/app-server/json-rpc-manual.md`、`../../agent-host/docs/agent-runtime-product-spec.md` |
| 当前状态 | 技术架构定义稿 |

## 1. 架构总述

`codexapp-go` 是 Codex app-server JSON-RPC 协议的纯 Go client SDK。它位于 CodexRuntime Adapter 和 Codex app-server 之间，为 CodexRuntime Adapter 提供类型安全 API、事件订阅、server request 回复、错误归一化和协议版本管理能力。具体开发顺序、M2+ facade 分期和首版 API 签名以 `docs/20-delivery/execution/execution-spec.md` 为准。

本文中的 `AgentHost` 指“超级 Agent”桌面应用中的本地宿主/承载层。`AgentRuntime` 是 AgentHost 内部 runtime 抽象，`CodexRuntime Adapter` 是该抽象的 Codex 实现，也是 `codexapp-go` 的直接调用方。

`codexapp-go` 不直接面向 Electron，不提供 HTTP REST API，不提供 SSE，不做业务编排，不启动系统程序，不维护产品级会话状态。它只负责“把 Codex app-server 的 JSON-RPC 协议稳定地变成 Go 可调用能力”。

```mermaid
flowchart TB
  Electron["Electron 桌面客户端"]
  AgentHost["AgentHost 本地宿主/承载层"]
  AgentRuntime["AgentRuntime 抽象"]
  CodexAdapter["CodexRuntime Adapter"]
  SDK["codexapp-go SDK"]
  AppServer["Codex app-server"]

  Electron -->|"HTTP REST / SSE"| AgentHost
  AgentHost --> AgentRuntime
  AgentRuntime --> CodexAdapter
  CodexAdapter -->|"Go typed API"| SDK
  SDK -->|"JSON-RPC request / notification"| AppServer
  AppServer -->|"response / notification / server request"| SDK
  SDK -->|"typed response / event / pending request"| CodexAdapter
  CodexAdapter -->|"RuntimeEvent / PendingRequest"| AgentRuntime
  AgentRuntime --> AgentHost
```

## 2. 架构目标

### 2.1 核心目标

- 提供 Codex app-server JSON-RPC 全方向通信能力。
- 用生成类型覆盖请求、响应、通知、server request 和 domain 类型。
- 用手写 runtime glue 管理 transport、request id、并发、分发、超时、关闭和错误。
- 为常用 method 提供薄 facade，避免 CodexRuntime Adapter 散落手写 method 字符串。
- 保留低层 request/notify API，覆盖新增或实验接口。
- 支持真实 app-server 契约测试，验证运行行为。

### 2.2 非目标

- 不实现 Electron UI。
- 不实现 AgentHost REST API。
- 不提供 SSE/WebSocket 给前端。
- 不做会话业务编排。
- 不做任务调度状态机。
- 不保存产品级数据库状态。
- 不启动、安装、升级或守护 Codex app-server 进程。
- 不直接调用 OpenAI Responses API。
- 不 fork 或扩展 Codex app-server 私有协议。

## 3. 架构原则

| 原则 | 说明 |
| --- | --- |
| 协议忠实 | SDK 类型和 method 以目标 app-server schema 为准，不凭记忆手写协议。 |
| 生成优先 | 请求、响应、通知和 domain 类型优先由 schema/codegen 生成。 |
| 手写最小 runtime | 只手写 codegen 不适合生成的部分：transport、dispatcher、pending map、错误、facade。 |
| 薄封装 | facade 只做 Go 方法分组，不引入新的业务模型。 |
| Raw 保留 | typed payload 外保留 raw message，便于诊断和版本差异处理。 |
| 不替 AgentHost 决策 | runtime 接入策略、适配策略、控制策略、审批策略、UI 投影都属于 AgentHost/AgentRuntime/CodexRuntime Adapter。 |
| 可测试 | 单元测试覆盖协议机制，契约测试覆盖真实 app-server 行为。 |

## 4. 系统边界

### 4.1 上下游边界

| 边界 | 输入 | 输出 | SDK 责任 |
| --- | --- | --- | --- |
| CodexRuntime Adapter -> SDK | Go 方法调用、context、typed params | typed response、event、error | 提供稳定 Go API。 |
| SDK -> app-server | JSON-RPC request/notification | JSON bytes | 编码、写入、request id 管理。 |
| app-server -> SDK | JSON-RPC response/notification/server request | typed message、raw message | 解码、匹配、分发、错误处理。 |
| SDK -> CodexRuntime Adapter | typed event、pending server request | Go channel/callback | 非阻塞分发、保留 raw。 |

### 4.2 职责边界

| 能力 | codexapp-go | AgentRuntime / CodexRuntime Adapter | AgentHost / Electron |
| --- | --- | --- | --- |
| JSON-RPC 编解码 | 负责 | 不重复实现 | 不接触 |
| transport 读写 | 负责 | Adapter 提供连接配置 | 不接触 |
| request id 管理 | 负责 | 不直接管理 | 不接触 |
| app-server 初始化握手 | 提供 API | Adapter 调用并映射 runtime 状态 | 只看 AgentHost 状态 |
| notification 读取 | 负责 | Adapter 转为 RuntimeEvent | AgentHost 投影，Electron 消费 SSE |
| server request 回复 | 提供机制 | Adapter 映射 PendingRequest；AgentHost 决策 | 用户交互 |
| thread/turn 业务投影 | 不负责 | AgentRuntime 定义统一模型 | AgentHost 投影，Electron 展示 |
| HTTP REST/SSE | 不负责 | 不负责 | AgentHost 负责，Electron 调用/订阅 |
| app-server 进程生命周期 | 不负责 | Adapter 可接收连接配置 | AgentHost 或外部 supervisor 负责 |

## 5. 总体技术架构

```mermaid
flowchart LR
  subgraph AgentHost["AgentHost"]
    HostAPI["HTTP REST / SSE / 状态投影"]
    AgentRuntime["AgentRuntime"]
    CodexAdapter["CodexRuntime Adapter"]
  end

  subgraph SDK["codexapp-go"]
    Facade["Thin Facades"]
    Client["Client Core"]
    Dispatcher["Dispatcher"]
    Pending["Pending Requests"]
    EventBus["Event Bus"]
    Transport["Transport"]
    Generated["Generated Protocol Types"]
    ErrorModel["Error Model"]
  end

  AppServer["Codex app-server"]

  HostAPI --> AgentRuntime
  AgentRuntime --> CodexAdapter
  CodexAdapter --> Facade
  Facade --> Client
  Client --> Pending
  Client --> Transport
  Transport --> AppServer
  AppServer --> Transport
  Transport --> Dispatcher
  Dispatcher --> Pending
  Dispatcher --> EventBus
  Dispatcher --> ErrorModel
  EventBus --> CodexAdapter
  Generated --> Facade
  Generated --> Dispatcher
```

### 5.1 架构层次

| 层 | 模块 | 职责 |
| --- | --- | --- |
| Public API | Thin Facades | `Threads`、`Turns`、`Models`、`Account` 等分组方法。 |
| Runtime Core | Client Core | 生命周期、初始化、request/notify/respond、关闭。 |
| Protocol Runtime | Dispatcher / Pending | 响应匹配、通知分发、server request 分发。 |
| Transport | stdio/ws/unix | 消息读写，不理解业务 method。 |
| Types | Generated Protocol Types | app-server schema 对应 Go 类型。 |
| Diagnostics | Error Model / Hooks | 错误分类、trace hook、raw message。 |

## 6. 模块架构

### 6.1 建议目录结构

```text
codexapp-go/
  client.go
  options.go
  jsonrpc.go
  protocol/
    types.go
    methods.go
    notifications.go
    server_requests.go
    schema/
      codex_app_server_protocol.schemas.json
      codex_app_server_protocol.v2.schemas.json
  transport/
    transport.go
    stdio.go
    websocket.go
    unixsocket.go
  internal/runtime/
    dispatcher.go
    pending.go
    events.go
    deltas.go
    server_request.go
  errors.go
  hooks.go
  threads.go
  turns.go
  review.go
  models.go
  account.go
  config.go
  skills.go
  apps.go
  plugins.go
  mcp.go
  commands.go
  filesystem.go
  windows_sandbox.go
  feedback.go
```

说明：这是架构推荐结构，不是必须逐字采用的文件清单。关键要求是 `protocol`、transport、client runtime、dispatcher、facade 必须分层。

`protocol` 是公开包，承载由目标 app-server schema 生成的类型、method 常量、decode registry 和 schema snapshot。生成代码提交到仓库，调用方不需要在安装 SDK 后自行运行 codegen。所有生成文件必须带 `Code generated; DO NOT EDIT.` 标记。

`internal/runtime` 是 SDK 私有运行时，不对 CodexRuntime Adapter 暴露。它承载 pending map、dispatcher、event fanout、delta fanout、server request bus 等实现细节。

### 6.2 模块职责

| 模块 | 职责 | 不负责 |
| --- | --- | --- |
| `Client` | SDK 生命周期、初始化、请求发送、通知发送、关闭 | 业务状态、HTTP API |
| `Transport` | JSON-RPC message 的读写和关闭 | method 语义、响应匹配 |
| `Dispatcher` | 识别 response、notification、server request | Adapter 业务处理 |
| `Pending` | request id 到 response channel 的映射 | 通知存储 |
| `EventBus` | 将 notification 分发给 CodexRuntime Adapter | UI 展示 |
| `ServerRequestBus` | 将 server request 暴露给 CodexRuntime Adapter，并支持一次性回复 | 审批决策 |
| `Protocol` | 公开生成包，提供协议类型、method 常量、decode registry、schema snapshot | runtime 并发逻辑 |
| `Facades` | 常用 method 的薄 Go API | 重新定义业务模型 |
| `ErrorModel` | 错误分类、包装、`errors.Is/As` | 用户文案 |
| `Hooks` | 可观测性回调 | 日志存储和采样策略 |

## 7. 核心接口架构

### 7.1 Client

Client 是 SDK 的唯一运行时入口。

```go
type Client struct {
    // request id generator
    // transport
    // pending request registry
    // event bus
    // server request bus
    // lifecycle context
}
```

Client 最终对外能力；各阶段开放顺序以 `docs/20-delivery/execution/execution-spec.md` 为准：

- `Initialize(ctx, params)`
- `Initialized(ctx)`
- `Request(ctx, method, params, resultPtr)`
- `Notify(ctx, method, params)`
- `Respond(ctx, id, result, rpcErr)`
- `Events()`
- `Deltas()`
- `ServerRequests()`
- `Close()`

### 7.2 Transport

Transport 是 SDK 与 app-server 的 I/O 抽象。

```go
type Transport interface {
    ReadMessage() (json.RawMessage, error)
    WriteMessage(msg json.RawMessage) error
    Close() error
}
```

设计要求：

- transport 不解析 method。
- transport 不管理 request id。
- transport 必须支持 `Close()` 后唤醒阻塞读写。
- writer 侧必须串行化写入。
- reader loop 只负责读消息并交给 dispatcher。
- `context.Context` 控制 SDK request 生命周期，不作为打断底层阻塞读写的强保证。
- `Close()` 是打断 transport 阻塞 I/O 的唯一强保证。

内置 transport：

| Transport | 协议形态 | 说明 |
| --- | --- | --- |
| stdio | JSONL | 默认用于本地 `codex app-server` stdio 连接。 |
| WebSocket | text frame | 每帧一条 JSON-RPC message。 |
| Unix socket WebSocket | HTTP Upgrade over Unix socket | 连接 app-server control socket。 |

### 7.3 JSON-RPC Envelope

SDK 内部统一使用 envelope 表示消息。

```go
type RequestEnvelope struct {
    ID     RequestID
    Method string
    Params json.RawMessage
}

type ResponseEnvelope struct {
    ID     RequestID
    Result json.RawMessage
    Error  *JSONRPCError
}

type NotificationEnvelope struct {
    Method string
    Params json.RawMessage
}
```

约束：

- 发给 app-server 的消息省略 `jsonrpc` 字段。
- request 必须有 `id`。
- notification 不得有 `id`。
- response 必须匹配已存在 pending request。
- 未匹配 response 是 protocol error。

## 8. 协议类型与代码生成架构

### 8.1 输入来源

类型生成以目标版本 app-server schema 为准：

```bash
codex app-server generate-ts --out ./schemas/ts
codex app-server generate-json-schema --out ./schemas/json
```

SDK 不应以人工维护的 Markdown 表格作为最终类型来源。Markdown 文档用于理解和差异说明，schema 用于生成。

### 8.1.1 生成包策略

- 生成 Go 类型进入公开包 `protocol`。
- 生成代码提交到仓库。
- schema snapshot 和 schema hash 随生成代码一起提交。
- `protocol` 包是 SDK 公共 API 的一部分，CodexRuntime Adapter 可以直接引用其中的 params、result、notification 和 domain 类型。
- 初期不拆分多个 generated 子包，避免 Go import 和循环依赖复杂化；只有当真实编译时间、文件体积或可读性成为问题时再拆。

### 8.2 生成内容

| 生成物 | 内容 |
| --- | --- |
| method 常量 | 所有 client request、client notification、server request、server notification method。 |
| params 类型 | 每个请求/通知/server request 的参数类型。 |
| result 类型 | 每个请求和 server request response 的返回类型。 |
| union 类型 | `ClientRequest`、`ServerNotification`、`ServerRequest` 等联合类型。 |
| domain 类型 | Thread、Turn、ThreadItem、Account、Model、MCP、Config、Filesystem 等。 |
| decode registry | method -> payload decoder 映射。 |

生成内容必须覆盖 low-level 能力，即使某个 method 没有手写 facade，也可以通过 `Request` / `Notify` 搭配 `protocol` 类型调用。

### 8.3 手写内容

只手写以下内容：

- transport。
- client lifecycle。
- request id generator。
- pending request registry。
- dispatcher。
- event bus。
- server request bus。
- error model。
- trace hooks。
- thin facades。

### 8.4 版本差异处理

```mermaid
flowchart LR
  AppServerVersion["目标 codex app-server 版本"]
  Generate["生成 schema/types"]
  Diff["与上一版本 diff"]
  Codegen["生成 Go 类型"]
  Tests["单元测试 + 契约测试"]
  Release["发布 SDK 版本"]

  AppServerVersion --> Generate --> Diff --> Codegen --> Tests --> Release
```

要求：

- 每次升级目标 app-server 版本必须重新生成 schema。
- method 新增、删除、改名必须进入差异报告。
- 字段 required/optional 变化必须进入差异报告。
- 文档存在但 schema 未暴露的接口，不进入默认 typed facade。
- schema 暴露但文档未展开的接口，至少保留 low-level 访问能力。

### 8.5 Schema diff 门禁

发布前必须执行 schema diff，并按以下规则处理：

| 变化 | 处理 |
| --- | --- |
| 删除 method | 阻断发布，除非进入 major 版本并更新兼容说明。 |
| method 改名 | 阻断发布，除非进入 major 版本并提供迁移说明。 |
| 字段从 optional 变 required | 阻断发布，除非调用方迁移完成。 |
| 字段类型不兼容变化 | 阻断发布。 |
| 新增 method | warning，可发布。 |
| 新增 optional 字段 | warning，可发布。 |
| 新增 notification | warning，并确认 decode registry 覆盖。 |

schema diff 结果必须写入 release notes 或 compatibility 文档。

## 9. 运行时流程

### 9.1 初始化流程

```mermaid
sequenceDiagram
  participant AgentHost
  participant AgentRuntime
  participant CodexAdapter as CodexRuntime Adapter
  participant SDK
  participant AppServer

  AgentHost->>AgentRuntime: initialize runtime
  AgentRuntime->>CodexAdapter: initialize Codex runtime
  CodexAdapter->>SDK: NewClient(transport)
  SDK->>SDK: start reader loop
  CodexAdapter->>SDK: Initialize(ctx, params)
  SDK->>AppServer: request initialize(id=1)
  AppServer-->>SDK: response initialize(id=1)
  SDK-->>CodexAdapter: InitializeResponse
  CodexAdapter-->>AgentRuntime: runtime ready metadata
  AgentRuntime-->>AgentHost: runtime status ready
  CodexAdapter->>SDK: Initialized(ctx)
  SDK->>AppServer: notification initialized
```

关键要求：

- `initialize` 必须是连接上的第一个业务请求。
- `initialized` 是 notification，没有 response。
- 初始化失败后 client 仍可关闭，但不能继续发送普通业务请求。
- `capabilities.experimentalApi` 和 `optOutNotificationMethods` 由 AgentHost/CodexRuntime Adapter 决定，SDK 只传递。

### 9.2 普通请求流程

```mermaid
sequenceDiagram
  participant AgentHost
  participant AgentRuntime
  participant CodexAdapter as CodexRuntime Adapter
  participant SDK
  participant AppServer

  AgentHost->>AgentRuntime: StartThread(req)
  AgentRuntime->>CodexAdapter: StartThread(req)
  CodexAdapter->>SDK: Threads().Start(ctx, params)
  SDK->>SDK: allocate request id
  SDK->>SDK: register pending
  SDK->>AppServer: JSON-RPC request
  AppServer-->>SDK: JSON-RPC response
  SDK->>SDK: match pending by id
  SDK-->>CodexAdapter: typed result or error
  CodexAdapter-->>AgentRuntime: ThreadRef or runtime error
  AgentRuntime-->>AgentHost: ThreadRef or runtime error
```

失败处理：

- context cancel：移除 pending，返回 context error。
- transport close：唤醒所有 pending，返回 transport closed error。
- JSON-RPC error：返回 `*JSONRPCError` 包装。
- decode failure：返回 decode error，并保留 raw response。

### 9.3 通知流程

```mermaid
sequenceDiagram
  participant AppServer
  participant SDK
  participant CodexAdapter as CodexRuntime Adapter
  participant AgentRuntime
  participant AgentHost

  AppServer-->>SDK: notification turn/started
  SDK->>SDK: decode by method
  SDK->>SDK: build Event{method, typed, raw}
  SDK-->>CodexAdapter: event stream
  CodexAdapter-->>AgentRuntime: RuntimeEvent
  AgentRuntime-->>AgentHost: RuntimeEvent
```

要求：

- reader loop 不能被 CodexRuntime Adapter event handler 阻塞。
- event 必须保留 method、typed payload、raw payload、receivedAt。
- 未知 method 必须作为 unknown event 暴露，不直接丢弃。
- decode 失败必须作为 decode error event 暴露。

### 9.4 Server request 流程

```mermaid
sequenceDiagram
  participant AppServer
  participant SDK
  participant CodexAdapter as CodexRuntime Adapter
  participant AgentRuntime
  participant AgentHost
  participant Electron

  AppServer-->>SDK: request item/fileChange/requestApproval(id=99)
  SDK->>SDK: decode and register pending server request
  SDK-->>CodexAdapter: PendingRequest(id=99)
  CodexAdapter-->>AgentRuntime: Runtime PendingRequest
  AgentRuntime-->>AgentHost: Runtime PendingRequest
  AgentHost-->>Electron: expose approval via REST/SSE
  Electron-->>AgentHost: user decision
  AgentHost->>AgentRuntime: Respond(requestID, decision)
  AgentRuntime->>CodexAdapter: Respond(requestID, decision)
  CodexAdapter->>SDK: PendingRequest.Respond(ctx, decision, nil)
  SDK->>AppServer: response id=99
  AppServer-->>SDK: notification serverRequest/resolved
  SDK-->>CodexAdapter: event serverRequest/resolved
  CodexAdapter-->>AgentRuntime: RuntimeEvent serverRequest/resolved
  AgentRuntime-->>AgentHost: RuntimeEvent serverRequest/resolved
```

约束：

- 同一个 server request id 只能回复一次。
- SDK 不决定审批结果。
- server request 超时策略由 AgentHost 产品层决定；CodexRuntime Adapter 负责翻译，SDK 只提供机制。
- 如果 client 关闭，所有未回复 server request 必须标记为 closed。

## 10. 并发架构

### 10.1 Goroutine 模型

```text
Client
  readerLoop        # 单独 goroutine，持续 ReadMessage
  writerLoop        # 可选，串行写出消息
  dispatcher        # 可与 readerLoop 同 goroutine，但不得阻塞
  event fanout      # 将普通 notification 分发到订阅者
  delta fanout      # 将高频 delta notification 分发到订阅者
  serverReq fanout  # 将 server request 分发给 CodexRuntime Adapter
```

### 10.2 并发规则

| 对象 | 并发策略 |
| --- | --- |
| request id generator | atomic 或 mutex，保证唯一。 |
| pending map | mutex 保护。 |
| transport write | 单 writer 或 mutex 串行。 |
| event channel | 有限缓冲，承载普通事件。 |
| delta channel | 有限缓冲，承载高频 delta。 |
| server request channel | 有限缓冲，优先级高于 delta。 |
| server request reply | `sync.Once` 或状态机保证一次性。 |
| Close | 幂等，可重复调用。 |

### 10.3 背压策略

默认策略：不静默丢事件。

要求：

- SDK 对外暴露三类流：`Events()`、`Deltas()`、`ServerRequests()`。
- `ServerRequests()` 承载审批、用户输入、动态工具调用等必须处理的请求，不允许被高频 delta 阻塞。
- `Events()` 承载普通 notification，例如 thread、turn、account、MCP、warning、completed 等。
- `Deltas()` 承载高频增量 notification，例如 agent text delta、command output delta、reasoning delta、file patch delta。
- 三类 channel 都必须有有限容量。
- 默认不静默丢弃 critical events 或 server requests。
- delta buffer 策略必须显式配置；默认可以阻塞或返回 backpressure error，但不能无日志丢弃。
- SDK 不做 UI 级合并；事件聚合属于 AgentHost。

默认建议：

| 流 | 默认策略 |
| --- | --- |
| `ServerRequests()` | 不丢弃；buffer 满时阻塞并触发 backpressure hook。 |
| `Events()` | 不丢弃；buffer 满时阻塞并触发 backpressure hook。 |
| `Deltas()` | 不默认丢弃；允许 CodexRuntime Adapter 配置更大 buffer 或自定义 backpressure 策略。 |

## 10.4 生命周期与取消语义

`context.Context` 和 `Close()` 的职责必须分开：

- request context 只控制单次 request 的等待、超时和 pending 清理。
- request context 超时不关闭 client，不关闭 transport，不停止 reader loop。
- `Client.Close()` 关闭整个 SDK client。
- `Client.Close()` 必须调用 transport `Close()`，并唤醒阻塞的 reader、writer、pending requests 和未回复 server requests。
- transport `Close()` 是打断底层阻塞 I/O 的唯一强保证。
- SDK 不负责 kill 或重启 app-server 进程。

server request 生命周期：

- 收到 server request 后生成 `PendingRequest`。
- `PendingRequest.Respond` 只能成功一次。
- client close 后，未回复 `PendingRequest` 进入 closed 状态。
- SDK 永远不自动 approve、decline、cancel 或回复审批类 server request。
- server request timeout 策略属于 AgentHost；CodexRuntime Adapter 负责翻译，SDK 只提供 context、状态和一次性回复机制。

## 11. 错误架构

### 11.1 错误分类

| 错误 | 场景 | 处理 |
| --- | --- | --- |
| `TransportError` | 连接断开、读写失败 | 关闭 client，唤醒 pending。 |
| `JSONRPCError` | app-server 返回 `error` | 保留 code、message、data。 |
| `DecodeError` | JSON 或 typed payload 解码失败 | 返回 raw message 和目标类型。 |
| `ProtocolError` | response id 未匹配、重复 reply、非法 envelope | 标记 SDK bug 或协议不兼容。 |
| `TimeoutError` | context deadline exceeded | 取消 pending。 |
| `ClosedError` | client 已关闭后调用 | 立即返回。 |

### 11.2 错误类型要求

- 支持 `errors.Is`。
- 支持 `errors.As`。
- JSON-RPC error 的 code 不得丢失。
- raw message 默认不进入普通错误字符串，避免泄漏敏感信息。
- 诊断模式可由 AgentHost 显式开启 raw dump，并负责脱敏和存储。

## 12. 安全架构

### 12.1 安全边界

`codexapp-go` 是本地协议 SDK，但它会经过 app-server 暴露高风险能力，例如命令执行、文件读写、权限审批、MCP 工具调用。因此 SDK 必须保持中立和透明，不自动放大权限。

### 12.2 安全要求

- 不自动批准任何 approval request。
- 不隐藏 destructive 方法。
- 不默认记录 API key、access token、bearer token。
- 不把 raw JSON 默认写入日志。
- WebSocket token 只通过 transport 配置传递。
- server request 必须交给 AgentHost 决策。
- `thread/shellCommand`、`command/exec`、`fs/remove` 等高风险 method 不提供“无提示快捷 helper”。

### 12.3 敏感字段处理

SDK hook 中默认脱敏：

- `apiKey`
- `accessToken`
- `Authorization`
- `bearer`
- `ws-token`
- `chatgptAuthTokens`

脱敏策略应可由 AgentHost 覆盖，但默认必须保守。

## 13. 可观测性架构

### 13.1 Trace Hook

SDK 提供可选 hook：

```go
type Hooks struct {
    OnRequestStart      func(RequestTrace)
    OnResponse          func(ResponseTrace)
    OnNotification      func(NotificationTrace)
    OnServerRequest     func(ServerRequestTrace)
    OnServerRequestDone func(ServerRequestTrace)
    OnBackpressure      func(BackpressureTrace)
    OnError             func(ErrorTrace)
    OnClose             func(CloseTrace)
}
```

### 13.2 Trace 字段

| 字段 | 说明 |
| --- | --- |
| `method` | JSON-RPC method。 |
| `requestID` | request/response 关联 id。 |
| `duration` | 请求耗时。 |
| `errorKind` | 错误分类。 |
| `threadId` | 可从 payload 提取时填充。 |
| `turnId` | 可从 payload 提取时填充。 |
| `itemId` | 可从 payload 提取时填充。 |
| `rawSize` | raw payload 大小，不含原文。 |

SDK 不决定日志落盘位置，不做日志轮转。日志策略属于 AgentHost。

## 14. Public Facade 架构

### 14.1 Facade 规则

facade 是薄封装：

- 方法名映射到 app-server method。
- 参数和返回使用 generated 类型。
- 不改变 app-server 语义。
- 不吞错误。
- 不自动重试非幂等请求。
- 不新增业务状态。
- 不要求每个 app-server method 都有手写 facade。

### 14.2 分组

| Facade | 代表 method |
| --- | --- |
| `Threads` | `thread/start`、`thread/resume`、`thread/fork`、`thread/read`、`thread/list`、`thread/archive`、`thread/unarchive`、`thread/goal/*`、`thread/rollback` |
| `Turns` | `turn/start`、`turn/steer`、`turn/interrupt` |
| `Review` | `review/start` |
| `Models` | `model/list`、`modelProvider/capabilities/read` |
| `Account` | `account/read`、`account/login/start`、`account/logout`、`account/rateLimits/read` |
| `Config` | `config/read`、`config/value/write`、`config/batchWrite`、`configRequirements/read` |
| `Skills` | `skills/list`、`skills/config/write`、`skills/extraRoots/set` |
| `Apps` | `app/list` |
| `Plugins` | `marketplace/*`、`plugin/*` |
| `MCP` | `mcpServerStatus/list`、`mcpServer/resource/read`、`mcpServer/tool/call`、`mcpServer/oauth/login` |
| `Commands` | `command/exec`、`command/exec/write`、`command/exec/resize`、`command/exec/terminate` |
| `Filesystem` | `fs/readFile`、`fs/writeFile`、`fs/createDirectory`、`fs/getMetadata`、`fs/readDirectory`、`fs/remove`、`fs/copy`、`fs/watch`、`fs/unwatch` |
| `WindowsSandbox` | `windowsSandbox/setupStart`、`windowsSandbox/readiness` |
| `Feedback` | `feedback/upload` |

### 14.2.1 Facade 覆盖策略

SDK API 分三层：

| 层级 | 形态 | 用途 |
| --- | --- | --- |
| Level 0 | `Request`、`Notify`、`Respond` | 覆盖所有 method，包括实验接口和版本差异。 |
| Level 1 | `protocol` method 常量、params/result 类型、decode helper | 提供生成级类型安全能力。 |
| Level 2 | 手写 facade | 只覆盖 CodexRuntime Adapter 高频、稳定、语义清晰的路径。 |

手写 facade 最终默认覆盖范围按 `docs/20-delivery/execution/execution-spec.md` 分阶段交付：

- `Threads`
- `Turns`
- `Review`
- `Models`
- `Account`
- `MCP` 基础状态和 tool call
- `Config` 基础读写
- `Commands`
- `Filesystem` 基础能力

低频、变化快或实验接口默认只走 low-level 或 generated helper，例如 plugin share、external import、experimental feature、Windows sandbox 扩展接口。只有当 CodexRuntime Adapter 高频使用且语义稳定时，再增加手写 facade。

### 14.3 Low-level Escape Hatch

必须保留低层接口：

```go
Request(ctx, method, params, resultPtr)
Notify(ctx, method, params)
Respond(ctx, id, result, rpcErr)
```

用途：

- 实验接口。
- schema 已生成但 facade 未覆盖的 method。
- app-server 临时能力验证。
- 兼容不同版本 method 差异。

## 15. 数据流与状态流

### 15.1 Request/Response 数据流

```text
AgentHost request
  -> AgentRuntime request
  -> CodexRuntime Adapter typed params
  -> facade
  -> generated params JSON
  -> JSON-RPC request envelope
  -> transport
  -> app-server
  -> JSON-RPC response envelope
  -> pending match
  -> generated result type
  -> CodexRuntime Adapter typed result
  -> AgentRuntime result
  -> AgentHost response/projection
```

### 15.2 Notification 数据流

```text
app-server notification
  -> transport reader
  -> dispatcher
  -> method registry
  -> typed event + raw event
  -> SDK event stream
  -> CodexRuntime Adapter
  -> AgentRuntime event
  -> AgentHost event projection
  -> Electron SSE
```

### 15.3 Server Request 数据流

```text
app-server server request
  -> transport reader
  -> dispatcher
  -> typed pending request + raw request
  -> SDK server request stream
  -> CodexRuntime Adapter
  -> AgentRuntime PendingRequest
  -> AgentHost pending approval/input state
  -> Electron user action
  -> AgentHost response decision
  -> AgentRuntime response
  -> CodexRuntime Adapter response
  -> SDK response envelope
  -> app-server
```

## 16. 配置架构

### 16.1 SDK Options

SDK client options：

| Option | 说明 |
| --- | --- |
| `ClientInfo` | initialize 使用的客户端标识。 |
| `ExperimentalAPI` | 是否启用实验 API。 |
| `OptOutNotificationMethods` | 初始化时通知过滤。 |
| `RequestTimeout` | 默认请求超时。 |
| `EventBufferSize` | event channel 缓冲。 |
| `DeltaBufferSize` | delta channel 缓冲。 |
| `ServerRequestBufferSize` | server request channel 缓冲。 |
| `BackpressurePolicy` | buffer 满时的阻塞/报错策略。 |
| `Hooks` | trace hooks。 |
| `Logger` | 可选日志接口，默认 no-op。 |

### 16.2 不进入 SDK 的配置

- Electron 端口。
- AgentHost HTTP 路由。
- app-server 进程路径。
- app-server 自动重启策略。
- 产品级默认模型。
- 用户审批策略。
- 会话持久化策略。

这些都属于 AgentHost 或桌面启动链路。

## 17. 测试架构

### 17.1 测试层级

| 测试类型 | 目标 |
| --- | --- |
| 单元测试 | 验证 JSON-RPC envelope、pending map、dispatcher、error model。 |
| Transport 测试 | 验证 stdio/ws/unix transport 的读写和关闭行为。 |
| Codegen 测试 | 验证 method registry 和 generated 类型可编译。 |
| 契约测试 | 使用真实 app-server 验证 initialize、thread、turn、notification、server request。 |
| 兼容性测试 | 比较新旧 schema 差异，确认 facade 覆盖。 |

### 17.2 必测场景

- `initialize` 成功。
- `initialized` notification 发送。
- `thread/start` 请求成功。
- `turn/start` 请求成功并收到 `turn/started` 或相关 item 事件。
- 并发多个 request 能正确匹配 response。
- app-server 返回 JSON-RPC error 时保留 code/message/data。
- unknown notification 不导致 reader loop 退出。
- server request 可回复且只能回复一次。
- transport close 唤醒所有 pending request。
- context timeout 清理 pending request。

### 17.3 契约测试原则

契约测试必须以目标 `codex` 二进制为基线。codegen 只证明字段形状，不证明运行行为。

契约测试产物应记录：

- Codex CLI/app-server 版本。
- schema 生成时间。
- 测试 method。
- 成功/失败结果。
- 已知跳过原因。

## 18. 发布与兼容架构

### 18.1 版本策略

`codexapp-go` 使用语义化版本：

- patch：SDK bugfix，不改变公共 API。
- minor：新增 method、类型、facade，保持兼容。
- major：公共 API 或目标 app-server 协议基线发生不兼容变化。

### 18.2 Release Checklist

- 重新生成目标版本 schema。
- 运行 schema diff。
- 更新 generated Go 类型。
- 运行单元测试。
- 运行契约测试。
- 更新 compatibility 文档。
- 更新 changelog。

### 18.3 兼容性声明

SDK 只承诺对声明的目标 app-server 版本进行测试。不承诺跨任意 Codex 版本完全兼容。实验 API 必须标记 unstable。

## 19. 风险与应对

| 风险 | 影响 | 架构应对 |
| --- | --- | --- |
| app-server 协议变化 | SDK 编译或运行失败 | schema/codegen、diff、契约测试。 |
| 文档与 schema 不一致 | facade 覆盖错误 | 以目标 schema 为准，文档只作说明。 |
| reader loop 被阻塞 | 通知和响应延迟 | dispatcher 与 event handler 解耦。 |
| server request 未回复 | app-server 等待卡住 | pending server request 追踪和一次性回复机制。 |
| 事件流量过大 | 内存增长或延迟 | 有限缓冲、背压策略、Adapter 转换、AgentHost 聚合。 |
| 错误信息丢失 | 难以诊断 | 分类错误、保留 JSON-RPC code 和 raw。 |
| 过度封装 | CodexRuntime Adapter 无法使用原生能力 | 保留 low-level request/notify。 |
| 敏感信息泄漏 | 安全事故 | 默认脱敏，raw dump 显式开启。 |

## 20. 架构验收标准

技术架构完成后，必须满足：

- SDK 只依赖 Codex app-server JSON-RPC，不依赖 Electron、AgentHost HTTP API 或 AgentRuntime。
- SDK 不提供 HTTP REST/SSE。
- SDK 不启动 app-server 进程。
- SDK 能完成 initialize/initialized。
- SDK 能发起 typed request 并匹配 response。
- SDK 能发送 notification。
- SDK 能分发 server notification。
- SDK 能接收并回复 server request。
- SDK 类型覆盖目标 schema 的主要协议面。
- SDK 保留 raw payload 以支持诊断。
- SDK 有明确错误分类和并发模型。
- SDK 有单元测试和真实 app-server 契约测试方案。

## 21. 最终架构结论

`codexapp-go` 的技术架构应采用“生成协议类型 + 手写最小运行时 + 薄 facade”的结构。

生成类型负责协议覆盖，手写运行时负责连接、并发、分发和错误，薄 facade 负责让 CodexRuntime Adapter 以清晰的 Go API 调用 app-server。任何 AgentRuntime 抽象、CodexRuntime Adapter 翻译逻辑、runtime 接入策略、适配策略、控制策略、状态投影、REST/SSE、审批策略和桌面交互都不进入 SDK，全部留在 AgentHost 或 Electron 层。
