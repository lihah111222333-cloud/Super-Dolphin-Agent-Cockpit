# codexapp-go AI 项目上下文

## 一句话定义

`codexapp-go` 是 Codex app-server JSON-RPC 的纯 Go client SDK。

## 项目目标

- 提供类型安全的 JSON-RPC client。
- 提供事件订阅、server request 处理和协议能力封装。
- 服务 AgentHost 内部的 CodexRuntime Adapter。
- 让 CodexRuntime Adapter 避免散落手写 method 字符串、request id、响应匹配和通知分发逻辑。

## 明确非目标

- 不面向 Electron。
- 不提供 HTTP REST 或 SSE。
- 不做 AgentHost 业务编排。
- 不做 AgentRuntime 抽象定义。
- 不启动、安装、升级或守护 Codex app-server。
- 不实现任务阶段控制、暂停策略、用户确认流程。
- 不直接调用 OpenAI Responses API。

## 架构位置

```text
Electron
  -> AgentHost
  -> AgentRuntime
  -> CodexRuntime Adapter
  -> codexapp-go
  -> Codex app-server
```

`codexapp-go` 的直接使用方是 CodexRuntime Adapter，不是 Electron，也不是最终用户。

## 技术边界

| 项目 | 内容 |
| --- | --- |
| 语言 | Go |
| 协议 | Codex app-server JSON-RPC |
| 类型来源 | 目标版本 app-server schema 和人工协议手册 |
| API 策略 | generated protocol + handwritten thin client/facade |
| 测试策略 | 阶段单元测试 + M5 真实 app-server 契约测试 |

## AI 启动必读

1. `00-start/current-status.md`
2. `20-delivery/execution/execution-spec.md`
3. `20-delivery/iterations/01-codexapp-go-m0-m6/master-plan.md`
4. 当前阶段 `goal.md`
5. `10-foundation/protocol/app-server/json-rpc-manual.md`

## 常见误解禁止

- 不要把 `codexapp-go` 写成 AgentHost。
- 不要把高级任务编排放进 SDK。
- 不要让后续阶段成为前置阶段依赖。
- 不要提前暴露未来阶段 public API。
- 不要用空实现、假实现、panic stub 占位未来能力。
- 不要绕过 schema/manual 直接猜 JSON-RPC 字段。
- 不要把 CLI 黑箱治理、任务暂停、阶段确认建模放进 SDK；这些属于 AgentHost/AgentRuntime 层。
