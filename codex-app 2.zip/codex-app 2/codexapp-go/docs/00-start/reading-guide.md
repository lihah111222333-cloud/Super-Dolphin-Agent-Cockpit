# codexapp-go 阅读路径

## 新开发者 15 分钟路径

1. `00-start/ai-project-context.md`
2. `00-start/current-status.md`
3. `10-foundation/product/codexapp-go-product-spec.md`
4. `10-foundation/architecture/technical-architecture.md`
5. `20-delivery/execution/execution-spec.md`
6. `20-delivery/iterations/01-codexapp-go-m0-m6/master-plan.md`

目标：确认 `codexapp-go` 只做 Codex app-server JSON-RPC 的 Go SDK，不做 Electron UI、不做 AgentHost 编排、不启动或守护 app-server。

## 阶段开发路径

1. `00-start/ai-project-context.md`
2. `00-start/current-status.md`
3. `20-delivery/iterations/01-codexapp-go-m0-m6/master-plan.md`
4. 当前阶段 `goal.md`
5. `20-delivery/execution/execution-spec.md`
6. 阶段涉及的基础事实文档。

目标：按 M0 -> M6 严格顺序推进，不让后续阶段成为前置阶段依赖。

## 协议/API 开发路径

1. `10-foundation/protocol/app-server/json-rpc-manual.md`
2. `10-foundation/protocol/app-server/official-doc-snapshot.md`
3. `20-delivery/iterations/01-codexapp-go-m0-m6/m0-protocol-baseline/goal.md`
4. `20-delivery/execution/execution-spec.md`

目标：先固定真实协议事实，再生成 typed protocol 和手写最小 client/facade。

## 文档维护路径

1. `docs/README.md`
2. `00-start/ai-project-context.md`
3. `00-start/current-status.md`
4. `00-start/doc-governance.md`
5. `00-start/feishu-drive-mapping.md`

目标：新增文档先落到正确生命周期目录，避免恢复旧的平铺结构。
