# docs 目录治理规则

## 目标

`docs/` 只保留 5 个一级目录，避免按临时主题持续增加平铺文件夹。开发人员应先从 `00-start/` 判断当前状态和阅读路径，再进入基础事实或交付推进目录。

## 一级目录职责

| 目录 | 职责 | 不放什么 |
| --- | --- | --- |
| `00-start/` | AI 启动上下文、当前状态、阅读路径、文档治理、飞书云盘映射。 | 产品正文、架构正文、阶段实施材料。 |
| `10-foundation/` | 长期有效的产品、架构、协议事实。 | 临时计划、阶段验收记录。 |
| `20-delivery/` | 开发执行、迭代计划、阶段目标、验收材料。 | 长期基础事实、发布 changelog。 |
| `30-release/` | API reference、compatibility、changelog、release note。 | 未冻结的阶段草案。 |
| `99-archive/` | 过期但需追溯的旧文档。 | 当前有效文档。 |

## 二级目录规则

| 类型 | 放置位置 |
| --- | --- |
| AI 启动上下文、当前状态和入口说明 | `00-start/` |
| 产品说明 | `10-foundation/product/` |
| 技术架构 | `10-foundation/architecture/` |
| app-server 协议事实 | `10-foundation/protocol/` |
| 开发执行和测试规则 | `20-delivery/execution/` |
| 迭代计划、阶段目标、验收材料 | `20-delivery/iterations/<迭代>/` |
| 发布后给 SDK 使用者看的材料 | `30-release/` |
| 已废弃但不能删除的历史材料 | `99-archive/` |

## 命名规则

- 文件名使用英文 kebab-case，例如 `master-plan.md`、`goal.md`、`json-rpc-manual.md`。
- 中文放在标题和正文，不放文件名。
- 一级目录使用排序前缀：`00-start`、`10-foundation`、`20-delivery`、`30-release`、`99-archive`。
- 迭代目录使用序号和主题：`01-codexapp-go-m0-m6/`。
- 阶段目录使用稳定前缀和语义：`m0-protocol-baseline/`。

## README 维护规则

- 根 `README.md` 只保留入口导航、阅读顺序、按诉求定位和一级目录说明。
- 详细治理规则放在本文件，不回填到根 `README.md`。
- AI 从 0 进入项目的稳定上下文只更新 `00-start/ai-project-context.md`。
- 当前阶段只更新 `00-start/current-status.md`。
- 阅读路径只更新 `00-start/reading-guide.md`。

## 飞书同步规则

- 本地 `codexapp-go/` 对应飞书云盘 `/CodexApp/codexapp-go/`。
- 同步后必须运行 exact status 校验，确保 `new_local`、`new_remote`、`modified` 为空。
- 云盘 folder token、file token 或路径变化后，更新 `00-start/feishu-drive-mapping.md`。
