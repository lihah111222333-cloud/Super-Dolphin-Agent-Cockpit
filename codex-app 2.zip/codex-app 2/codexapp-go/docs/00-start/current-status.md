# codexapp-go 当前开发入口

| 项目 | 当前值 |
| --- | --- |
| 当前状态 | 文档治理和阶段规划已整理，SDK 代码开发尚未开始。 |
| 当前开发阶段 | M0 协议基线准备完成，下一步进入 M0 开发。 |
| 当前阶段入口 | `20-delivery/iterations/01-codexapp-go-m0-m6/m0-protocol-baseline/goal.md` |
| 总阶段规划 | `20-delivery/iterations/01-codexapp-go-m0-m6/master-plan.md` |
| 开发执行规格 | `20-delivery/execution/execution-spec.md` |
| AI 启动上下文 | `00-start/ai-project-context.md` |
| 最近同步状态 | 2026-06-24 已同步到 `/CodexApp/codexapp-go/`，最终 exact status 无本地/远端/内容差异。 |
| 更新时间 | 2026-06-24 |

## 当前阶段目标

M0 的目标是固定 Codex app-server JSON-RPC 协议事实，产出 schema、schema hash、method 覆盖清单和 schema/manual 差异清单，作为后续 runtime、typed API、事件、server request 和契约测试的唯一协议依据。

## 当前阶段允许做什么

- 确认目标 `codex` 二进制版本。
- 生成 app-server TypeScript schema。
- 生成 app-server JSON Schema。
- 固化 schema snapshot 和 schema hash。
- 产出 method 覆盖清单。
- 产出 schema/manual 差异清单。
- 明确 generated `protocol` 包的初始布局。

## 当前阶段禁止做什么

- 不实现 Client runtime。
- 不实现 stdio/WebSocket transport。
- 不实现 typed facade。
- 不实现 event stream 或 delta stream。
- 不实现 server request reply。
- 不实现 contract test harness。
- 不写未来 public API stub。

## 本阶段必读文档

1. `00-start/ai-project-context.md`
2. `20-delivery/execution/execution-spec.md`
3. `20-delivery/iterations/01-codexapp-go-m0-m6/master-plan.md`
4. `20-delivery/iterations/01-codexapp-go-m0-m6/m0-protocol-baseline/goal.md`
5. `10-foundation/protocol/app-server/json-rpc-manual.md`

## 进入 M1 门禁

- schema snapshot 完成。
- schema hash 可复算。
- generated protocol 可编译。
- method 覆盖清单完成。
- schema/manual 差异清单完成。
- M0 没有引入 runtime、facade、event 或 server request public API。
