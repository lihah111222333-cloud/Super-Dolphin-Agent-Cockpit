# codexapp-go 飞书云盘路径映射

| 项目 | 内容 |
| --- | --- |
| 本地项目目录 | `/Users/ai/Devlop/codex-app/codexapp-go` |
| 云盘父目录 | `/CodexApp/` |
| 云盘父目录 token | `HRDUf6g80lQP4yds94IcIdt2nhn` |
| 云盘项目目录 | `/CodexApp/codexapp-go/` |
| 云盘项目目录 token | `VEYZf71oolZjecdBuTvcxfIMnmb` |
| 云盘项目目录 URL | `https://acn9ha4b3juy.feishu.cn/drive/folder/VEYZf71oolZjecdBuTvcxfIMnmb` |
| 本地到云盘同步命令 | `lark-cli drive +push --as user --local-dir codexapp-go --folder-token VEYZf71oolZjecdBuTvcxfIMnmb --if-exists smart --json` |
| 精确一致性校验命令 | `lark-cli drive +status --as user --local-dir codexapp-go --folder-token VEYZf71oolZjecdBuTvcxfIMnmb --json` |
| 映射更新日期 | 2026-06-24 |
| 说明 | `codexapp-go/` 的相对路径同步到云盘 `/CodexApp/codexapp-go/` 下的同名相对路径。 |

## 目录映射

| 本地路径 | 云盘路径 | folder token |
| --- | --- | --- |
| `codexapp-go/` | `/CodexApp/codexapp-go/` | `VEYZf71oolZjecdBuTvcxfIMnmb` |
| `codexapp-go/docs/` | `/CodexApp/codexapp-go/docs/` | `IRwKfQUmlli3Mjdd3Kkc8c2Znid` |
| `codexapp-go/docs/00-start/` | `/CodexApp/codexapp-go/docs/00-start/` | `O1lSf7tgAl3HzhdoCLicBwqmnfe` |
| `codexapp-go/docs/10-foundation/` | `/CodexApp/codexapp-go/docs/10-foundation/` | `PfeSfLFr9lLWO7d9Emtc6QMHnWh` |
| `codexapp-go/docs/10-foundation/product/` | `/CodexApp/codexapp-go/docs/10-foundation/product/` | `HTdgfqAy5lbVcjd4cdbcFKxsnMh` |
| `codexapp-go/docs/10-foundation/architecture/` | `/CodexApp/codexapp-go/docs/10-foundation/architecture/` | `FKe9fKQbtl1zkyd5zzbcjVyPn9c` |
| `codexapp-go/docs/10-foundation/protocol/` | `/CodexApp/codexapp-go/docs/10-foundation/protocol/` | `EBlGfeg5Hla8SLdXWQMcmKzun3h` |
| `codexapp-go/docs/10-foundation/protocol/app-server/` | `/CodexApp/codexapp-go/docs/10-foundation/protocol/app-server/` | `TzRGf1kN0laXcudau5bcjXDBn9d` |
| `codexapp-go/docs/20-delivery/` | `/CodexApp/codexapp-go/docs/20-delivery/` | `YiI8fZNdwlYtUUdcXjAc2EQKnyg` |
| `codexapp-go/docs/20-delivery/execution/` | `/CodexApp/codexapp-go/docs/20-delivery/execution/` | `R4kFfvjjYlEPeJdlJUGcEPfjncd` |
| `codexapp-go/docs/20-delivery/iterations/` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/` | `AsslfLzHvlfgGYdVpZDcu19Gn3g` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/` | `R2YNfriMullyamdGJ01chinCnzc` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/diagrams/` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/diagrams/` | `T0pbf1Nw4lc0XvdFghKcVXEYnab` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m0-protocol-baseline/` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m0-protocol-baseline/` | `TiO1fq2TwlTriVdr4V0cip1Anab` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m1-minimal-runtime/` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m1-minimal-runtime/` | `XjkcfG1yAlwimYdjWa8cEENsnHc` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m2-core-typed-api/` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m2-core-typed-api/` | `DClufwnzklpoLZdGGUUc1J4mnEh` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m3-events-server-requests/` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m3-events-server-requests/` | `QmV7fgapolqt64dIe6dc1zMAnVf` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m4-extended-protocol-coverage/` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m4-extended-protocol-coverage/` | `VdPQf4U4glRe6ldRnVRcDGEmnQf` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m5-contract-tests/` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m5-contract-tests/` | `P51jfQwGalg5rpdyievcOWGwnWb` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m6-release-documentation/` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m6-release-documentation/` | `FU4FfxcvflENZGdv01KcRTJ4nLh` |
| `codexapp-go/docs/30-release/` | `/CodexApp/codexapp-go/docs/30-release/` | `KHV6fIKE5ltuYUdUQBmcuudrnPg` |
| `codexapp-go/docs/99-archive/` | `/CodexApp/codexapp-go/docs/99-archive/` | `SbEBffOItl5qGtdzqc2cTNYonZe` |

## 文件映射

| 本地路径 | 云盘路径 | file token |
| --- | --- | --- |
| `codexapp-go/AGENT.md` | `/CodexApp/codexapp-go/AGENT.md` | `HqZIbsUyFo4XVMx7DV9cOcRdnuh` |
| `codexapp-go/docs/README.md` | `/CodexApp/codexapp-go/docs/README.md` | `ZSU7bS0GYoEHeOxlUrVcZXGRn1e` |
| `codexapp-go/docs/00-start/ai-project-context.md` | `/CodexApp/codexapp-go/docs/00-start/ai-project-context.md` | `RILVbofBBoYYhExsoQoc56P2n8e` |
| `codexapp-go/docs/00-start/current-status.md` | `/CodexApp/codexapp-go/docs/00-start/current-status.md` | `Xr3hb2jTtoaim5xKwc7cp5wpnxT` |
| `codexapp-go/docs/00-start/doc-governance.md` | `/CodexApp/codexapp-go/docs/00-start/doc-governance.md` | `ZE6abimdyo1G0uxsOzIcl0BvnXf` |
| `codexapp-go/docs/00-start/feishu-drive-mapping.md` | `/CodexApp/codexapp-go/docs/00-start/feishu-drive-mapping.md` | `XXdrbq36doxkd1xgtPNcJNrXn6b` |
| `codexapp-go/docs/00-start/reading-guide.md` | `/CodexApp/codexapp-go/docs/00-start/reading-guide.md` | `OwfSbhVxdoGi8hx3uIKcaOq3nZb` |
| `codexapp-go/docs/10-foundation/product/codexapp-product-spec.md` | `/CodexApp/codexapp-go/docs/10-foundation/product/codexapp-product-spec.md` | `Ce13bdcdRofUKRxcI5AcvfF4nFb` |
| `codexapp-go/docs/10-foundation/product/codexapp-go-product-spec.md` | `/CodexApp/codexapp-go/docs/10-foundation/product/codexapp-go-product-spec.md` | `GvP3bin1XovXlKxtT2lcE5adnbe` |
| `codexapp-go/docs/10-foundation/architecture/technical-architecture.md` | `/CodexApp/codexapp-go/docs/10-foundation/architecture/technical-architecture.md` | `R16dbEPaJoqUcRxik1dcBqeznVd` |
| `codexapp-go/docs/10-foundation/protocol/app-server/json-rpc-manual.md` | `/CodexApp/codexapp-go/docs/10-foundation/protocol/app-server/json-rpc-manual.md` | `TehjbUa5Xoju2TxZphicTFr0ngd` |
| `codexapp-go/docs/10-foundation/protocol/app-server/official-doc-snapshot.md` | `/CodexApp/codexapp-go/docs/10-foundation/protocol/app-server/official-doc-snapshot.md` | `Cyx0b7WbIobnPWxW3uscLozdn1e` |
| `codexapp-go/docs/20-delivery/execution/execution-spec.md` | `/CodexApp/codexapp-go/docs/20-delivery/execution/execution-spec.md` | `HbNBbH9wlobozNxGIo7c8OwTnJb` |
| `codexapp-go/docs/20-delivery/execution/team-development-standards.md` | `/CodexApp/codexapp-go/docs/20-delivery/execution/team-development-standards.md` | `MXcDbC05xo774txCBGic0kvXntq` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/master-plan.md` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/master-plan.md` | `DEGEbgXf1oB0isxoTJ9cw6swnIf` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/diagrams/codexapp-go-architecture.drawio` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/diagrams/codexapp-go-architecture.drawio` | `K19GbyNLdoBMnUxTk4TcEN8wnhe` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/diagrams/codexapp-go-business-architecture.png` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/diagrams/codexapp-go-business-architecture.png` | `FcN4b2Kr9odqytxPLA0cg3qTnYc` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/diagrams/codexapp-go-business-roadmap.png` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/diagrams/codexapp-go-business-roadmap.png` | `Yn8NbLWOPoTqXWxVmxhct2Y8nhf` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/diagrams/codexapp-go-technical-architecture.png` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/diagrams/codexapp-go-technical-architecture.png` | `SDx8bFrXYopgE8xEQXUcCHiDnfh` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m0-protocol-baseline/goal.md` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m0-protocol-baseline/goal.md` | `EFyobZ9Awofclax8OjNc5uYVnYb` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m1-minimal-runtime/goal.md` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m1-minimal-runtime/goal.md` | `H4fXbZfcioMQOJxMHx4cAgaCnMf` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m2-core-typed-api/goal.md` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m2-core-typed-api/goal.md` | `JZmkbCgx2oONC4xHBMxcfXDinWd` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m3-events-server-requests/goal.md` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m3-events-server-requests/goal.md` | `UVQQbZOjIo7zUSxLspCcLVngnuq` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m4-extended-protocol-coverage/goal.md` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m4-extended-protocol-coverage/goal.md` | `Cffqbzgknor6jPxKaGdcSdKtnuK` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m5-contract-tests/goal.md` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m5-contract-tests/goal.md` | `ApY1b7CsBot5IfxtuAOcN0g5nhh` |
| `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m6-release-documentation/goal.md` | `/CodexApp/codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/m6-release-documentation/goal.md` | `IE1sbiTEeo2htPxDVbrcqK19nGc` |

## 最近一次目录重组同步摘要

| 指标 | 数量 |
| --- | ---: |
| 创建远端目录 | 20 |
| 上传或覆盖文件 | 24 |
| 删除旧路径远端文件 | 20 |
| 删除旧空目录 | 8 |
| 失败项 | 0 |


## 后续维护规则

- 新增文档先按 `docs/README.md` 和 `docs/00-start/doc-governance.md` 的放置规则落位。
- 后续常规同步优先使用 `--if-exists smart`，减少无意义覆盖。
- 若本地发生删除、重命名或目录迁移，使用 `--delete-remote --yes` 做文件级镜像，并在执行后更新本文件。
- 本映射只覆盖 `codexapp-go/` 到 `/CodexApp/codexapp-go/`，不记录 AgentHost、Electron 或其他项目目录。
