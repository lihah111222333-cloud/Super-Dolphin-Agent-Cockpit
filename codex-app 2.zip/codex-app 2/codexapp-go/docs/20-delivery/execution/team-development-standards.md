# codexapp-go 开发团队规范

## 1. 适用范围

本文约束 `codexapp-go` 的日常开发、评审、测试、文档和发布协作。

`codexapp-go` 只做 Codex app-server JSON-RPC 的纯 Go SDK。任何开发任务都不得把 Electron UI、AgentHost 编排、REST/SSE、任务暂停控制、用户确认流程、app-server 进程管理放进本 SDK。

## 2. 开发顺序

- 严格按 M0 -> M1 -> M2 -> M3 -> M4 -> M5 -> M6 推进。
- 开始阶段开发前，先读 `docs/00-start/current-status.md` 和当前阶段 `goal.md`。
- 后续阶段不能成为前置阶段的编译、测试或验收依赖。
- public API 只在当前阶段有真实实现、测试和验收场景时开放。
- 禁止提前写空实现、假实现、panic stub 或只返回 `ErrNotImplemented` 的 public API。

## 3. 代码规范

- 优先复用已有结构和 Go 标准库，不为单一实现新增抽象。
- generated 文件必须带 `Code generated; DO NOT EDIT.`，人工代码不得直接修改 generated 输出。
- 手写 facade 必须薄封装 app-server 语义，不做业务状态、不自动改变返回语义。
- context 只控制本次调用生命周期；除非文档明确要求，不因单次请求取消关闭整个 client。
- transport 只管理连接资源，不负责启动、重启或守护 app-server。
- 错误处理必须保留 JSON-RPC method、request id、错误码和可排查上下文。

## 4. 测试规范

- 每个阶段必须留下最小可运行验证。
- 普通单元测试随阶段同步补齐，不能把验证都推迟到 M5。
- M0 至少验证 schema 生成可重复、hash 可复算、generated protocol 可编译。
- M1 至少验证 request/response 匹配、context timeout、Close 唤醒 pending。
- M2 至少验证 facade 调用映射到正确 method 和 generated 类型。
- M3 至少验证 event、delta、server request 分类和背压行为。
- M5 contract test 必须显式开启，默认不污染普通 `go test ./...`。

## 5. 文档规范

- 产品范围以 `docs/10-foundation/product/codexapp-go-product-spec.md` 为准。
- 架构分层以 `docs/10-foundation/architecture/technical-architecture.md` 为准。
- method、字段、通知和 server request 事实以目标版本 generated schema 为准。
- 开发顺序、阶段 API 和测试门禁以 `docs/20-delivery/execution/execution-spec.md` 为准。
- schema 与 Markdown 不一致时，代码以 schema 为准，并补充差异说明。
- 修改或新增 docs 后，按 `docs/00-start/doc-governance.md` 放置，并同步飞书云盘。

## 6. 评审规范

每个变更进入评审前必须说明：

- 影响哪个阶段。
- 修改了哪些 public API 或协议类型。
- 是否引入未来阶段依赖。
- 运行了哪些验证命令。
- 是否需要更新 README、API reference、compatibility、changelog 或飞书映射。

评审优先检查：

- 是否越过当前阶段边界。
- 是否让 AgentHost/AgentRuntime 职责泄漏到 SDK。
- 是否手写了 schema 已能生成的协议事实。
- 是否缺少最小验证。

## 7. 发布规范

- M6 前 public API 允许按阶段新增和小幅调整。
- M6 发布前必须完成 README、API reference、Testing、Compatibility、Changelog。
- 没有 schema hash、target app-server version、contract test result 时不得发布。
- 发布后新增能力进入新迭代规划，不回写改变 M0-M6 阶段边界。
