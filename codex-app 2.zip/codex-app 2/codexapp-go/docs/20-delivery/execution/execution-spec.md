# codexapp-go 开发执行规格

| 项目 | 内容 |
| --- | --- |
| 文档名称 | codexapp-go 开发执行规格 |
| 文档版本 | v0.1 |
| 日期 | 2026-06-22 |
| 适用范围 | M0-M6 开发执行、M2+ typed API 和后续扩展 |
| 上游文档 | `docs/10-foundation/product/codexapp-go-product-spec.md`、`docs/10-foundation/architecture/technical-architecture.md`、`docs/10-foundation/protocol/app-server/json-rpc-manual.md` |

## 1. 目的

本文只解决开发执行问题：先做什么、每阶段交付什么、首版 Go API 如何落地、哪些能力只做 generated low-level 覆盖、哪些能力需要手写 facade。

本文不改变 `codexapp-go` 的产品边界：SDK 仍然只封装 Codex app-server JSON-RPC，不面向 Electron，不提供 REST/SSE，不启动 app-server 进程，不做业务编排。

术语说明：本文中的 `AgentHost` 指“超级 Agent”桌面应用中的本地宿主/承载层。`AgentRuntime` 是 AgentHost 内部 runtime 抽象，`CodexRuntime Adapter` 是该抽象的 Codex 实现，也是 `codexapp-go` 的直接调用方。

## 2. 文档一致性规则

| 事项 | 以谁为准 |
| --- | --- |
| 产品范围和非目标 | `docs/10-foundation/product/codexapp-go-product-spec.md` |
| 架构分层和并发原则 | `docs/10-foundation/architecture/technical-architecture.md` |
| method、字段、通知、server request 事实 | 目标版本 generated schema |
| method 用途和当前人工说明 | `docs/10-foundation/protocol/app-server/json-rpc-manual.md` |
| 开发顺序、M2+ facade 分期、首版 API 签名 | 本文 |

执行规则：

- schema 与 Markdown 不一致时，代码以 schema 为准，Markdown 补差异说明。
- 产品说明与技术架构不一致时，先修文档再开发。
- 手写 facade 不得早于对应 method 的 generated params/result 类型。
- 扩展能力必须先有 low-level 覆盖，再决定是否手写 facade。

## 3. 阶段开放 API 原则

public API 按阶段逐步开放，不在前置阶段暴露未来能力。

规则：

- 一个 public API 只有在当前阶段有真实实现、测试和验收场景时才开放。
- 禁止为了后续阶段提前放空实现、假实现、panic stub 或只返回 `ErrNotImplemented` 的 public API。
- 阶段内可以有未导出的内部结构为后续复用做准备，但不得作为本阶段完成标准。
- generated `protocol` 类型可以在 M0/M1 覆盖完整 schema；手写 `Client` API 和 facade 必须按阶段开放。
- 后续阶段不得成为前置阶段的编译、测试或验收依赖。
- M6 前 public API 允许按阶段新增和小幅调整；M6 发布文档完成后冻结首个稳定 public API。

阶段开放顺序：

| 阶段 | 可新增 public API |
| --- | --- |
| M0 | `protocol` generated 类型、method 常量、decode registry。 |
| M1 | `NewClient`、`Initialize`、`Initialized`、`Request`、`Notify`、`Close`、transport 基础类型。 |
| M2 | M2 facade accessor 和方法。 |
| M3 | `Events`、`Deltas`、`ServerRequests`、`Respond`、`PendingRequest`、event/delta/server request 类型。 |
| M4 | M4 facade accessor 和方法、WebSocket/Unix socket transport 构造能力。 |
| M5 | contract test harness API 仅限测试包或 internal，不扩稳定运行时 API。 |
| M6 | README/API reference/compatibility/changelog 对 public API 做冻结说明。 |

## 4. 里程碑依赖

| 阶段 | 目标 | 前置条件 | 完成标准 |
| --- | --- | --- | --- |
| M0 | 协议基线 | 已确认目标 `codex` 版本 | schema snapshot、schema hash、method 覆盖清单、文档/schema 差异清单。 |
| M1 | 最小 runtime | M0 完成 | stdio transport、JSON-RPC envelope、client request/response、client notification、pending map、initialize/initialized、Close/context 语义可测。 |
| M2 | 核心 typed API | M1 完成 | `Threads`、`Turns`、`Review`、`Models`、`Account` facade；其他 method 可用 low-level 调用。 |
| M3 | 事件与 server request | M2 完成 | `Events()`、`Deltas()`、`ServerRequests()`、`Respond()`、`PendingRequest`、事件分类和背压测试。 |
| M4 | 扩展协议覆盖 | M3 完成 | `MCP`、`Config`、`Commands`、`Filesystem` 基础 facade；`Skills`、`Apps`、`Plugins`、`WindowsSandbox`、`Feedback` 先保证 low-level 覆盖。 |
| M5 | 契约测试 | M4 完成 | 真实 app-server 初始化、thread、turn、notification、server request 契约测试。 |
| M6 | 发布文档 | M5 完成 | README、API reference、Testing、Compatibility、Changelog。 |

说明：单元测试随每个阶段同步写；M5 是真实 app-server 契约测试的集中收口，不是前面阶段跳过测试的理由。

## 5. M0 协议和 codegen 决策

### 5.1 输入

M0 使用目标版本 `codex` 生成协议快照。初始候选版本可参考 `docs/10-foundation/protocol/app-server/json-rpc-manual.md` 记录的 `codex-cli 0.137.0`，但 M0 必须以本机 `codex --version` 的实际输出为准。

```bash
codex --version
codex app-server generate-ts --out ./protocol/schema/ts
codex app-server generate-json-schema --out ./protocol/schema/json
```

必须记录：

- `codex` 版本。
- schema 生成时间。
- schema hash。
- method 总数。
- 文档存在但 schema 未暴露的 method。
- schema 暴露但文档未展开的 method。

### 5.2 输出布局

```text
protocol/
  methods_gen.go
  types_gen.go
  decode_gen.go
  schema/
    ts/
    json/
    schema.hash
```

生成文件必须带 `Code generated; DO NOT EDIT.`。

### 5.3 生成策略

- 只有一个生成入口：`go generate ./protocol`。
- M0 先尝试复用现有 JSON Schema 到 Go 生成能力；如果 union/decode registry 无法满足，再补一个最小本地生成器。
- 生成内容至少包括 `Method` 常量、params/result/domain 类型、notification decoder、server request decoder。
- 首版不拆多个 generated 子包，除非单包无法编译。

## 6. M1 public runtime API

M1 只暴露能在 M1 独立实现和验证的 runtime API：

```go
func NewClient(t transport.Transport, opts ...Option) (*Client, error)

func (c *Client) Initialize(ctx context.Context, params protocol.InitializeParams) (*protocol.InitializeResult, error)
func (c *Client) Initialized(ctx context.Context) error

func (c *Client) Request(ctx context.Context, method protocol.Method, params any, resultPtr any) error
func (c *Client) Notify(ctx context.Context, method protocol.Method, params any) error
func (c *Client) Close() error
```

执行约束：

- 当前协议基线按数字 JSON-RPC id 实现，`protocol.RequestID` 使用数字 id；如果 M0 schema 证明支持字符串 id，再改为 opaque id。
- `Initialize` 不自动发送 `initialized`；调用方必须显式调用 `Initialized`。
- request context 只取消单次等待和 pending 清理，不关闭 client，不关闭 transport。
- `Close` 幂等，必须唤醒 reader、writer、pending requests 和未回复 server requests。
- M1 不公开 `Events()`、`Deltas()`、`ServerRequests()`、`Respond()` 或 `PendingRequest`；这些进入 M3。

## 7. Transport 所有权

| Transport | 阶段 | 构造方式 | Close 行为 |
| --- | --- | --- | --- |
| stdio JSONL | M1 | 调用方传入已建立的 `io.Reader` / `io.Writer`，可选 `io.Closer` | 关闭 transport；只有传入 closer 时才关闭底层资源。 |
| WebSocket | M4 | SDK dial 已运行 app-server 的 ws 地址 | 关闭 websocket 连接，不重启 app-server。 |
| Unix socket WebSocket | M4 | SDK dial 已存在 unix socket 地址 | 关闭 websocket/unix 连接，不删除 socket 文件。 |

SDK 不提供 `StartAppServer`、`KillAppServer`、`RestartAppServer`。这些属于 AgentHost 或外部启动链路。

## 8. M2+ facade 分期

所有 schema 暴露的 client request/notification 在 M1 后都必须能通过 `Request` / `Notify` 加 `protocol` 类型调用；server request reply 能力从 M3 通过 `Respond` 开放。手写 facade 只按下表分期。

| 阶段 | 手写 facade | 说明 |
| --- | --- | --- |
| M2 | `Threads()`、`Turns()`、`Review()`、`Models()`、`Account()` | 支撑 CodexRuntime Adapter 最小 thread/turn 映射。 |
| M3 | 不新增大分组；补齐事件和 server request helper | 先稳定运行时，不扩 facade。 |
| M4 | `MCP()`、`Config()`、`Commands()`、`Filesystem()` 基础能力 | 只覆盖 CodexRuntime Adapter 高频稳定路径。 |
| M4+ | `Skills()`、`Apps()`、`Plugins()`、`WindowsSandbox()`、`Feedback()` | 默认 low-level；只有 CodexRuntime Adapter 高频使用再补 facade。 |

facade 访问方式固定为 accessor：

```go
client.Threads().Start(ctx, params)
client.Turns().Start(ctx, params)
client.Models().List(ctx, params)
client.Account().Read(ctx, params)
```

facade 不自动重试非幂等请求，不新增业务状态，不改变 app-server 返回语义。

### 8.1 M2 facade 方法清单

M2 只实现下列手写 facade。参数和返回类型使用 `protocol` generated 类型；如果 codegen 生成的类型名与表中示例不同，以 generated 名称为准，并同步更新 API reference。

| Facade | Go 方法 | app-server method | 阶段 |
| --- | --- | --- | --- |
| `Threads()` | `Start(ctx, params)` | `thread/start` | M2 |
| `Threads()` | `Resume(ctx, params)` | `thread/resume` | M2 |
| `Threads()` | `Fork(ctx, params)` | `thread/fork` | M2 |
| `Threads()` | `Read(ctx, params)` | `thread/read` | M2 |
| `Threads()` | `List(ctx, params)` | `thread/list` | M2 |
| `Threads()` | `Archive(ctx, params)` | `thread/archive` | M2 |
| `Threads()` | `Unarchive(ctx, params)` | `thread/unarchive` | M2 |
| `Threads()` | `SetName(ctx, params)` | `thread/name/set` | M2 |
| `Threads()` | `SetGoal(ctx, params)` | `thread/goal/set` | M2 |
| `Threads()` | `GetGoal(ctx, params)` | `thread/goal/get` | M2 |
| `Threads()` | `ClearGoal(ctx, params)` | `thread/goal/clear` | M2 |
| `Threads()` | `Rollback(ctx, params)` | `thread/rollback` | M2 |
| `Threads()` | `CompactStart(ctx, params)` | `thread/compact/start` | M2 |
| `Threads()` | `InjectItems(ctx, params)` | `thread/inject_items` | M2 |
| `Turns()` | `Start(ctx, params)` | `turn/start` | M2 |
| `Turns()` | `Steer(ctx, params)` | `turn/steer` | M2 |
| `Turns()` | `Interrupt(ctx, params)` | `turn/interrupt` | M2 |
| `Review()` | `Start(ctx, params)` | `review/start` | M2 |
| `Models()` | `List(ctx, params)` | `model/list` | M2 |
| `Models()` | `ReadProviderCapabilities(ctx, params)` | `modelProvider/capabilities/read` | M2 |
| `Account()` | `Read(ctx, params)` | `account/read` | M2 |
| `Account()` | `LoginStart(ctx, params)` | `account/login/start` | M2 |
| `Account()` | `LoginCancel(ctx, params)` | `account/login/cancel` | M2 |
| `Account()` | `Logout(ctx, params)` | `account/logout` | M2 |
| `Account()` | `ReadRateLimits(ctx, params)` | `account/rateLimits/read` | M2 |
| `Account()` | `SendAddCreditsNudgeEmail(ctx, params)` | `account/sendAddCreditsNudgeEmail` | M2 |

M2 不实现 `thread/delete`、`thread/turns/list`、background terminal、usage、rate-limit credit 等低频或 schema 差异 method；这些先走 low-level。

## 9. M3 事件、server request 与 public API

M3 在 M1 runtime 和 M2 facade 之上，新增事件和 server request public API：

```go
func (c *Client) Events() <-chan Event
func (c *Client) Deltas() <-chan Delta
func (c *Client) ServerRequests() <-chan PendingRequest
func (c *Client) Respond(ctx context.Context, id protocol.RequestID, result any, rpcErr *protocol.JSONRPCError) error
```

M3 才公开 `Event`、`Delta`、`PendingRequest` 和 server request reply 相关错误。M1/M2 不得依赖这些 public 类型完成验收。

### 9.1 事件分类和背压

| 流 | method 规则 | 默认背压 |
| --- | --- | --- |
| `ServerRequests()` | 所有带 `id` 的 app-server server request | 不丢弃；buffer 满时阻塞并触发 hook。 |
| `Deltas()` | method 以 `/delta`、`Delta` 结尾或名称中包含 streaming output，例如 `item/agentMessage/delta`、`item/commandExecution/outputDelta`、`command/exec/outputDelta`、`thread/realtime/*/delta` | 不静默丢弃；默认阻塞并触发 hook。 |
| `Events()` | 其他 notification，包括 `thread/*`、`turn/*`、`item/started`、`item/completed`、`account/*`、`mcpServer/*`、`serverRequest/resolved`、unknown notification、decode error event | 不丢弃；buffer 满时阻塞并触发 hook。 |

执行约束：

- dispatcher 不直接执行 CodexRuntime Adapter 回调。
- unknown notification 进入 `Events()`，保留 raw message。
- decode 失败进入 `Events()`，同时触发 `OnError` hook。
- UI 聚合、delta 合并、SSE 转换都属于 AgentHost。

### 9.2 M3 事件方法清单

| 流 | method |
| --- | --- |
| `Deltas()` | `item/agentMessage/delta` |
| `Deltas()` | `item/plan/delta` |
| `Deltas()` | `item/reasoning/summaryTextDelta` |
| `Deltas()` | `item/reasoning/textDelta` |
| `Deltas()` | `item/commandExecution/outputDelta` |
| `Deltas()` | `item/fileChange/outputDelta` |
| `Deltas()` | `command/exec/outputDelta` |
| `Deltas()` | `process/outputDelta` |
| `Deltas()` | `thread/realtime/transcript/delta` |
| `Deltas()` | `thread/realtime/outputAudio/delta` |
| `Events()` | `thread/*` non-delta notifications |
| `Events()` | `turn/*` non-delta notifications |
| `Events()` | `item/started`、`item/completed`、`item/reasoning/summaryPartAdded`、`item/commandExecution/terminalInteraction`、`item/fileChange/patchUpdated`、`item/autoApprovalReview/*` |
| `Events()` | `account/*` notifications |
| `Events()` | `mcpServer/*` notifications |
| `Events()` | `skills/changed`、`app/list/updated`、`fs/changed` |
| `Events()` | `serverRequest/resolved` |
| `Events()` | `warning`、`guardianWarning`、`deprecationNotice`、`configWarning`、`error` |
| `Events()` | unknown notification 或 decode error event |

新增 notification 默认进入 `Events()`；只有 method 名称或 schema 语义明确是流式增量时才进入 `Deltas()`。

### 9.3 Server request 生命周期

`PendingRequest` 必须包含：

- `ID protocol.RequestID`
- `Method protocol.Method`
- typed params
- raw params
- `Context() context.Context`
- `Respond(ctx, result, rpcErr) error`

规则：

- 同一个 `PendingRequest` 只能成功回复一次。
- client close 后，未回复 request 进入 closed 状态，后续 `Respond` 返回 `ClosedError`。
- decode 失败仍产生 `PendingRequest`，但 typed params 为空，raw params 必须保留。
- SDK 不自动 approve、decline、cancel 或 timeout server request。
- AgentHost 如果要超时，必须通过 AgentRuntime/CodexRuntime Adapter 显式调用 `Respond` 返回业务决定或错误。

### 9.4 M3 server request 方法清单

| method | SDK 行为 | 备注 |
| --- | --- | --- |
| `item/commandExecution/requestApproval` | decode 后进入 `ServerRequests()` | 新 command/network 审批。 |
| `item/fileChange/requestApproval` | decode 后进入 `ServerRequests()` | 新 file change 审批。 |
| `item/tool/requestUserInput` | decode 后进入 `ServerRequests()` | 用户输入请求。 |
| `mcpServer/elicitation/request` | decode 后进入 `ServerRequests()` | MCP structured input。 |
| `item/permissions/requestApproval` | decode 后进入 `ServerRequests()` | 权限请求。 |
| `item/tool/call` | decode 后进入 `ServerRequests()` | dynamic tool call。 |
| `account/chatgptAuthTokens/refresh` | decode 后进入 `ServerRequests()` | token refresh。 |
| `attestation/generate` | decode 后进入 `ServerRequests()` | attestation 生成。 |
| `applyPatchApproval` | decode 后进入 `ServerRequests()`，标记 legacy | 兼容旧 patch 审批。 |
| `execCommandApproval` | decode 后进入 `ServerRequests()`，标记 legacy | 兼容旧 exec 审批。 |

未识别的带 `id` app-server 请求仍进入 `ServerRequests()`，typed params 为空，raw params 保留。

## 10. M4 扩展 facade 清单

M4 只补基础 facade；其他扩展 method 保持 low-level，等 CodexRuntime Adapter 高频使用后再补。

| Facade | Go 方法 | app-server method | 阶段 |
| --- | --- | --- | --- |
| `MCP()` | `ListStatus(ctx, params)` | `mcpServerStatus/list` | M4 |
| `MCP()` | `ReadResource(ctx, params)` | `mcpServer/resource/read` | M4 |
| `MCP()` | `CallTool(ctx, params)` | `mcpServer/tool/call` | M4 |
| `MCP()` | `OAuthLogin(ctx, params)` | `mcpServer/oauth/login` | M4 |
| `Config()` | `Read(ctx, params)` | `config/read` | M4 |
| `Config()` | `WriteValue(ctx, params)` | `config/value/write` | M4 |
| `Config()` | `BatchWrite(ctx, params)` | `config/batchWrite` | M4 |
| `Config()` | `ReadRequirements(ctx, params)` | `configRequirements/read` | M4 |
| `Config()` | `ReloadMCPServers(ctx, params)` | `config/mcpServer/reload` | M4 |
| `Commands()` | `Exec(ctx, params)` | `command/exec` | M4 |
| `Commands()` | `Write(ctx, params)` | `command/exec/write` | M4 |
| `Commands()` | `Resize(ctx, params)` | `command/exec/resize` | M4 |
| `Commands()` | `Terminate(ctx, params)` | `command/exec/terminate` | M4 |
| `Filesystem()` | `ReadFile(ctx, params)` | `fs/readFile` | M4 |
| `Filesystem()` | `WriteFile(ctx, params)` | `fs/writeFile` | M4 |
| `Filesystem()` | `CreateDirectory(ctx, params)` | `fs/createDirectory` | M4 |
| `Filesystem()` | `GetMetadata(ctx, params)` | `fs/getMetadata` | M4 |
| `Filesystem()` | `ReadDirectory(ctx, params)` | `fs/readDirectory` | M4 |
| `Filesystem()` | `Remove(ctx, params)` | `fs/remove` | M4 |
| `Filesystem()` | `Copy(ctx, params)` | `fs/copy` | M4 |
| `Filesystem()` | `Watch(ctx, params)` | `fs/watch` | M4 |
| `Filesystem()` | `Unwatch(ctx, params)` | `fs/unwatch` | M4 |

M4 不手写 `Skills()`、`Apps()`、`Plugins()`、`WindowsSandbox()`、`Feedback()`；这些 method 必须通过 generated low-level 覆盖。

## 11. 测试门禁

| 阶段 | 最小检查 |
| --- | --- |
| M0 | `go generate ./protocol` 可重复运行；generated 代码可编译。 |
| M1 | JSON-RPC encode/decode、response id 匹配、context timeout、Close 唤醒 pending。 |
| M2 | 每个 M2 facade 至少一个 request 构造/调用测试。 |
| M3 | event/delta/server request 分类测试；重复 reply 测试。 |
| M4 | 扩展 facade 测试；low-level 覆盖检查。 |
| M5 | 真实 app-server 契约测试，默认可用 build tag 或环境变量控制。 |
| M6 | compatibility/changelog 包含目标 app-server 版本、schema hash、契约测试结果。 |

契约测试可以由测试 harness 启动 app-server；这不改变 SDK 本身“不启动 app-server”的产品边界。

### 11.1 M5 契约测试执行

契约测试默认不在普通 `go test ./...` 中运行，使用以下任一方式显式开启：

```bash
go test -tags contract ./...
CODEXAPP_GO_CONTRACT=1 go test ./...
```

契约测试 harness 可以启动 `codex app-server` 或连接调用方提供的 app-server 地址。测试结果必须记录：

- `codex --version`。
- schema hash。
- transport 类型。
- 覆盖 method。
- skipped case 及原因。

最小 contract case：

| case | 覆盖 |
| --- | --- |
| `TestContractInitialize` | `initialize` -> `initialized`。 |
| `TestContractThreadStart` | `thread/start` response。 |
| `TestContractTurnStartEvents` | `turn/start`、至少一个 `turn/*` 或 `item/*` notification。 |
| `TestContractServerRequest` | 至少一个 server request 的接收和一次性回复；无法稳定触发时允许使用真实协议 fixture 并标记 skipped reason。 |

## 12. M6 发布文档模板

| 文档 | 最小章节 |
| --- | --- |
| README | 安装、最小连接示例、initialize 示例、thread/turn 示例、边界说明。 |
| API reference | `Client`、`Transport`、M2/M4 facade、`Event`、`Delta`、`PendingRequest`、错误类型。 |
| Testing | 单元测试命令、contract test 开关、需要的本地 `codex` 版本、跳过条件。 |
| Compatibility | SDK version、target app-server version、schema hash、known schema/manual differences、unstable APIs。 |
| Changelog | Added、Changed、Fixed、Breaking、Schema changes、Contract test result。 |

M6 不发布没有 schema hash、target app-server version 或 contract test 结果的版本。

## 13. 暂缓项

以下内容不进入 M0-M3：

- 自动重连。
- app-server 进程管理。
- 多版本 runtime 自动适配。
- record/replay 工具。
- 所有 method 的手写 facade。
- AgentHost REST/SSE 映射。

这些能力只有在 AgentHost/CodexRuntime Adapter 开发中证明需要时再补。
