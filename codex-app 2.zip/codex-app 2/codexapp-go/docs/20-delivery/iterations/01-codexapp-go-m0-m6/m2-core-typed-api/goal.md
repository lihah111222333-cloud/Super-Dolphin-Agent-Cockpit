# M2 核心 Typed API 阶段总目标

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | M2 |
| 阶段名称 | 核心 Typed API |
| 所属迭代 | `20-delivery/iterations/01-codexapp-go-m0-m6` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | 在 M1 low-level request 之上提供核心 outbound typed facade。 |

## 1. 计划目标

在 M1 low-level request 能力之上提供核心 typed facade，使 CodexRuntime Adapter 能以稳定 Go API 调用 thread、turn、review、model、account 相关能力。

M2 的重点是 outbound typed API，不处理 app-server 主动推送的 notification、delta 或 server request。

## 2. 阶段内容

- `Threads()` facade。
- `Turns()` facade。
- `Review()` facade。
- `Models()` facade。
- `Account()` facade。
- 每个 facade 方法只映射 app-server method。
- params/result 使用 generated protocol 类型。
- 保留 low-level escape hatch。

## 3. 范围边界

M2 只做 outbound typed request facade。

M2 不包含：

- event stream。
- delta stream。
- server request。
- `Respond()`。
- MCP facade。
- Config facade。
- Commands facade。
- Filesystem facade。
- Skills facade。
- Apps facade。
- Plugins facade。
- WindowsSandbox facade。
- Feedback facade。
- UI 事件聚合。
- 业务编排状态。

## 4. 责任归属

| 责任方 | 责任 |
| --- | --- |
| codexapp-go | 提供 M2 facade，保证每个 facade 是对 app-server method 的薄封装。 |
| CodexRuntime Adapter | 使用 M2 facade 验证最小 thread/turn 映射。 |
| AgentHost | 不绕过 CodexRuntime Adapter 直接调用 SDK。 |
| Electron | 继续通过 AgentHost REST 接口间接使用能力，不接触 SDK。 |

## 5. 前置依赖

- M1 runtime 已完成。
- M1 `Request` 可用且可测。
- generated params/result 覆盖 M2 method。
- M1 error 和 context 行为已满足 facade 调用需要。

## 6. 交付物

- `Threads()` accessor。
- `Turns()` accessor。
- `Review()` accessor。
- `Models()` accessor。
- `Account()` accessor。
- M2 facade 方法。
- M2 facade 单元测试。
- M2 API reference 草案。

## 7. 验收方式

- 每个 M2 facade 至少有一个 request 构造/调用测试。
- facade 不新增业务状态。
- facade 不吞错误。
- facade 不自动重试非幂等请求。
- low-level `Request` 仍可覆盖未手写 method。
- params/result 使用 generated protocol 类型。
- M2 不依赖 M3 event/server request 类型。

## 8. 进入 M3 门禁

只有在 M2 核心 typed facade 能通过 M1 runtime 验证，并且不引入业务状态或未来阶段依赖后，才能进入 M3。

M3 只能复用 M1 reader/dispatcher 基础和 M0 decode registry，不得要求 M2 facade 承担 inbound stream 职责。
