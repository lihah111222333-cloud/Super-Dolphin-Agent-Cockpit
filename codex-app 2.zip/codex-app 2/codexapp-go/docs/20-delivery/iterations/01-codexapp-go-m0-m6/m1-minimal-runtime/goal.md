# M1 最小 Runtime 阶段总目标

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | M1 |
| 阶段名称 | 最小 Runtime |
| 所属迭代 | `20-delivery/iterations/01-codexapp-go-m0-m6` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | 建立最小可用 JSON-RPC client runtime，支撑后续 typed API 和 inbound stream。 |

## 1. 计划目标

建立最小可用 JSON-RPC client runtime，使 `codexapp-go` 能通过 stdio transport 完成初始化、client request、client notification、响应匹配、关闭和取消。

M1 完成后，SDK 应具备稳定的底层调用能力，但不暴露未来阶段的 typed facade、event stream 或 server request API。

## 2. 阶段内容

- stdio JSONL transport。
- JSON-RPC envelope encode/decode。
- request id 分配。
- pending request map。
- response id 匹配。
- JSON-RPC error 解码。
- `Initialize(ctx, params)`。
- `Initialized(ctx)`。
- `Request(ctx, method, params, resultPtr)`。
- `Notify(ctx, method, params)`。
- `Close()`。
- request context timeout/cancel 清理。

## 3. 范围边界

M1 只开放最小 runtime public API。

M1 不包含：

- `Events()`。
- `Deltas()`。
- `ServerRequests()`。
- `Respond()`。
- `PendingRequest`。
- typed facade。
- WebSocket transport。
- Unix socket WebSocket transport。
- contract test harness。
- app-server 进程启动、守护或重启。
- AgentHost 业务状态。

## 4. 责任归属

| 责任方 | 责任 |
| --- | --- |
| codexapp-go | 实现 runtime、stdio transport、request/response/notification 发送、初始化和关闭。 |
| CodexRuntime Adapter | 可使用 M1 API 做最小连接验证，但不能依赖事件或 server request。 |
| AgentHost | 不直接依赖 M1；只能通过 CodexRuntime Adapter 间接验证。 |
| Electron | 不参与 M1，不能直接消费 SDK。 |

## 5. 前置依赖

- M0 schema snapshot 已完成。
- M0 schema hash 已完成。
- M0 method 常量已生成。
- M0 generated 类型已生成。
- M0 差异清单已确认不会阻断 M1。

## 6. 交付物

- M1 public runtime API。
- stdio transport。
- JSON-RPC envelope 类型。
- JSON-RPC error 类型。
- pending request registry。
- initialize/initialized 调用能力。
- M1 单元测试。

## 7. 验收方式

- JSON-RPC request encode/decode 测试通过。
- client notification encode 测试通过。
- 并发 request response 匹配测试通过。
- JSON-RPC error 保留 code/message/data。
- context timeout 后 pending request 被清理。
- `Close()` 能唤醒 reader、writer 和 pending request。
- M1 不暴露 M3 API。
- M1 不包含 typed facade。

## 8. 进入 M2 门禁

只有在 M1 runtime 可以稳定发送 request/notification、匹配 response、处理错误、关闭资源后，才能进入 M2。

M2 只能基于 M1 的 `Request` 能力构建 thin facade，不得要求 M1 提前提供 event/server request 能力。
