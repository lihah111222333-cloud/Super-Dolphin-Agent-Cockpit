# M3 事件与 Server Request 阶段总目标

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | M3 |
| 阶段名称 | 事件与 Server Request |
| 所属迭代 | `20-delivery/iterations/01-codexapp-go-m0-m6` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | 补齐 app-server 到 SDK 的 inbound 通道。 |

## 1. 计划目标

补齐 app-server 到 SDK 的 inbound 通道，使 SDK 能接收 notification、delta 和 server request，并以三类流暴露给 CodexRuntime Adapter。

M3 完成后，SDK 应能明确区分普通事件、增量事件和需要回复的 server request，并保证 server request 回复只发生一次。

## 2. 阶段内容

- reader loop 到 dispatcher 的 inbound 分发。
- notification decode registry 使用。
- `Events()`。
- `Deltas()`。
- `ServerRequests()`。
- `Event` 类型。
- `Delta` 类型。
- `PendingRequest` 类型。
- `Respond(ctx, id, result, rpcErr)`。
- `PendingRequest.Respond(ctx, result, rpcErr)`。
- server request 一次性回复保护。
- unknown notification 保底分发。
- decode error 保留 raw message。
- event/delta/server request buffer 和背压策略。

## 3. 范围边界

M3 只处理 inbound stream 和 server request reply。

M3 不包含：

- 新增大 facade 分组。
- WebSocket transport。
- Unix socket WebSocket transport。
- MCP facade。
- Config facade。
- Commands facade。
- Filesystem facade。
- contract test harness。
- UI 事件聚合。
- SSE 转换。
- 审批策略。
- 用户输入策略。
- token refresh 业务策略。

## 4. 责任归属

| 责任方 | 责任 |
| --- | --- |
| codexapp-go | 解码、分类、分发 notification/server request，并提供一次性回复机制。 |
| CodexRuntime Adapter | 把 SDK event/server request 映射为 AgentRuntime 事件和 pending request。 |
| AgentHost | 决定审批、用户输入、权限、token refresh 等业务动作。 |
| Electron | 只通过 AgentHost 间接参与用户交互。 |

## 5. 前置依赖

- M2 已完成。
- M1 reader/dispatcher 基础可复用。
- generated notification decoder 可用。
- generated server request decoder 可用。
- M1 close/context 机制能安全终止 inbound 处理。

## 6. 交付物

- `Events()`。
- `Deltas()`。
- `ServerRequests()`。
- `Event` 类型。
- `Delta` 类型。
- `PendingRequest` 类型。
- `Respond()`。
- event/delta/server request 分类表实现。
- 背压 hook 或错误。
- M3 单元测试。

## 7. 验收方式

- 普通 notification 进入 `Events()`。
- delta notification 进入 `Deltas()`。
- server request 进入 `ServerRequests()`。
- unknown notification 不退出 reader loop。
- decode error 保留 raw message。
- `PendingRequest.Respond` 只能成功一次。
- client close 后未回复 server request 进入 closed 状态。
- buffer 满时不静默丢弃事件。
- M3 不新增 M4 facade。

## 8. 进入 M4 门禁

只有在 event、delta、server request 三类 inbound 通道均可验证，并且不会阻塞关键 request 后，才能进入 M4。

M4 只能在 M3 inbound 能力稳定后增加扩展 facade 和 transport，不得把 M3 未完成的分发、背压或回复语义推迟到 M4 兜底。
