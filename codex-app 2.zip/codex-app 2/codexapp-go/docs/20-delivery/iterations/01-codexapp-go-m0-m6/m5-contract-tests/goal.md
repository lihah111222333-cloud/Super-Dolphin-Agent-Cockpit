# M5 契约测试阶段总目标

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | M5 |
| 阶段名称 | 契约测试 |
| 所属迭代 | `20-delivery/iterations/01-codexapp-go-m0-m6` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | 用真实 app-server 验证 M1-M4 的运行行为。 |

## 1. 计划目标

用真实 app-server 验证 M1-M4 的运行行为，证明 generated 类型和 runtime 实现不仅能编译，而且能与目标 app-server 交互。

M5 是验证阶段，不是新增 SDK runtime 能力或补做前序阶段功能的阶段。

## 2. 阶段内容

- contract test harness。
- 显式 contract test 开关。
- 真实 app-server 初始化测试。
- thread/start contract test。
- turn/start notification contract test。
- server request contract 或真实协议 fixture。
- contract test 结果记录。
- skipped case 原因记录。

## 3. 范围边界

M5 只验证运行行为。

M5 不包含：

- 新增稳定 runtime API。
- 新增 facade。
- 修补未完成的 M1-M4 功能作为 M5 交付内容。
- 发布文档冻结。
- 自动下载 app-server。
- app-server 进程守护。
- 端到端产品测试替代 SDK contract test。

## 4. 责任归属

| 责任方 | 责任 |
| --- | --- |
| codexapp-go | 提供 contract tests、显式开关和结果记录格式。 |
| Codex app-server | 作为真实协议基线。 |
| CodexRuntime Adapter | 可参与端到端 smoke，但不作为 SDK contract test 的必需依赖。 |
| AgentHost | 不承担 SDK contract test 的必要前置条件。 |

## 5. 前置依赖

- M4 已完成。
- M1-M4 单元测试通过。
- 目标 app-server 版本已记录。
- schema hash 已记录。
- M1-M4 已知限制已记录。

## 6. 交付物

- contract test harness。
- `go test -tags contract ./...` 支持。
- `CODEXAPP_GO_CONTRACT=1 go test ./...` 支持。
- contract test result 文档或输出。
- skipped case 清单。

## 7. 验收方式

- contract test 默认不污染普通 `go test ./...`。
- 显式开启后能记录 app-server version、schema hash、transport、覆盖 method。
- initialize contract case 可运行。
- thread/start contract case 可运行。
- turn/start event contract case 可运行。
- server request case 可运行或有明确 skipped reason。
- contract failure 能区分 SDK bug、app-server 行为变化、环境缺失。
- M5 不新增稳定 runtime API。

## 8. 进入 M6 门禁

只有在 M5 contract test 能显式运行并留下可复查结果后，才能进入 M6。

M6 只能基于 M0-M5 已完成事实冻结 public API 和发布文档，不得在发布文档阶段重新补设计或补实现。
