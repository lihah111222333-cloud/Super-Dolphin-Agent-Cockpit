# M6 发布文档阶段总目标

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | M6 |
| 阶段名称 | 发布文档 |
| 所属迭代 | `20-delivery/iterations/01-codexapp-go-m0-m6` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | 冻结首个稳定 public API，并完成 SDK 发布文档。 |

## 1. 计划目标

完成首个稳定 SDK 发布文档，冻结经过 M0-M5 验证的 public API，并明确 SDK 与目标 app-server 的兼容边界。

M6 是发布收口阶段，不重新设计 public API，也不新增运行时能力。

## 2. 阶段内容

- README。
- API reference。
- Testing 文档。
- Compatibility 文档。
- Changelog。
- public API freeze 说明。
- unstable API 标记。
- known schema/manual differences。

## 3. 范围边界

M6 是文档和发布收口阶段。

M6 不包含：

- 新增运行时能力。
- 新增 facade。
- 重新设计 public API。
- 重新定义 M0-M5 阶段边界。
- 补写未完成 contract test。
- 改变 SDK 与 AgentHost 的责任边界。

## 4. 责任归属

| 责任方 | 责任 |
| --- | --- |
| codexapp-go | 发布 README、API reference、Testing、Compatibility、Changelog 和 public API freeze 声明。 |
| CodexRuntime Adapter | 校验文档示例能支撑 Adapter 调用。 |
| AgentHost | 消费 compatibility 和 API reference，不直接约束 SDK 内部实现。 |
| Electron | 继续只通过 AgentHost 使用能力，不直接消费 SDK 文档作为集成协议。 |

## 5. 前置依赖

- M5 contract test 已完成。
- schema hash 已记录。
- target app-server version 已记录。
- contract test result 已记录。
- M0-M5 已知限制已整理。
- public API 已经过 M0-M5 验证。

## 6. 交付物

- README。
- API reference。
- Testing。
- Compatibility。
- Changelog。
- public API freeze 声明。

## 7. 验收方式

- README 包含最小连接、initialize、thread/turn 示例。
- API reference 覆盖 `Client`、transport、M2/M4 facade、event/delta/server request、错误类型。
- Testing 文档说明单元测试和 contract test 开关。
- Compatibility 文档声明 SDK version、target app-server version、schema hash。
- Changelog 记录 schema changes 和 contract test result。
- 没有 schema hash、target app-server version 或 contract test result 时不得发布。
- M6 不引入新的 runtime 能力或 facade。

## 8. 迭代完成门禁

只有在 README、API reference、Testing、Compatibility、Changelog 和 public API freeze 声明全部完成后，本次 M0-M6 总迭代才可视为完成。

后续新能力应进入新的迭代规划，不得回写改变本次 M0-M6 的阶段边界。
