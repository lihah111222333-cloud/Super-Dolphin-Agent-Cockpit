# codexapp-go M0-M6 总阶段规划

| 项目 | 内容 |
| --- | --- |
| 文档名称 | codexapp-go M0-M6 总阶段规划 |
| 迭代目录 | `docs/20-delivery/iterations/01-codexapp-go-m0-m6/` |
| 文档类型 | 总阶段拆分方案 |
| 日期 | 2026-06-22 |
| 适用范围 | codexapp-go 从 M0 到 M6 的顺序开发推进 |
| 上游依据 | `codexapp-go-product-spec.md`、`technical-architecture.md`、`execution-spec.md`、`json-rpc-manual.md` |

## 1. 规划目标

本文定义 `codexapp-go` 的总开发阶段拆分，用于后续继续拆解每个阶段的详细开发计划。

本文不是实施任务清单，不列具体文件级任务、函数级任务或排期。每个阶段只定义目标、内容、边界、责任、依赖、交付物和验收方式。

`codexapp-go` 的产品边界保持不变：它是 Codex app-server JSON-RPC 的纯 Go client SDK，只服务 AgentHost 内的 CodexRuntime Adapter，不直接服务 Electron，不提供 REST/SSE，不启动或守护 app-server，不做业务编排。

## 2. 总体推进原则

### 2.1 严格顺序推进

阶段必须按 M0 -> M1 -> M2 -> M3 -> M4 -> M5 -> M6 顺序推进。

不允许：

- 并行假设。
- 后续阶段成为前置阶段的编译依赖。
- 后续阶段成为前置阶段的测试依赖。
- 前置阶段提前暴露后续阶段 public API。
- 为未来阶段写空实现、假实现、panic stub 或只返回 `ErrNotImplemented` 的 public API。

允许：

- 前置阶段保留未导出的内部结构，以便后续复用。
- M0/M1 的 generated protocol 覆盖完整 schema。
- M6 之前 public API 随阶段新增和小幅调整。

### 2.2 阶段门禁

每个阶段必须满足三类门禁才能进入下一阶段：

| 门禁 | 说明 |
| --- | --- |
| 依赖门禁 | 本阶段只能依赖已完成阶段的交付物。 |
| 验证门禁 | 本阶段必须有可运行、可复查的最小验证方式。 |
| 文档门禁 | 本阶段产生的协议事实、API 变化、已知限制必须记录到对应文档。 |

### 2.3 Public API 开放

public API 按阶段开放：

| 阶段 | 可开放 API |
| --- | --- |
| M0 | `protocol` generated 类型、method 常量、decode registry。 |
| M1 | `NewClient`、`Initialize`、`Initialized`、`Request`、`Notify`、`Close`、stdio transport 基础类型。 |
| M2 | 核心 facade accessor 和方法：`Threads()`、`Turns()`、`Review()`、`Models()`、`Account()`。 |
| M3 | `Events()`、`Deltas()`、`ServerRequests()`、`Respond()`、`PendingRequest`、`Event`、`Delta`。 |
| M4 | 扩展 facade 和 transport：`MCP()`、`Config()`、`Commands()`、`Filesystem()`、WebSocket、Unix socket WebSocket。 |
| M5 | contract test harness 只进入测试包或 internal，不新增稳定 runtime API。 |
| M6 | 冻结首个稳定 public API，并以 API reference 和 compatibility 文档声明。 |

## 3. 总阶段视图

| 阶段 | 名称 | 核心目标 | 进入条件 | 退出条件 |
| --- | --- | --- | --- | --- |
| M0 | 协议基线 | 固定目标 app-server 协议事实 | 已有产品/架构/执行规格 | schema、hash、method 覆盖和差异清单完成。 |
| M1 | 最小 runtime | 可发送 request/notification，完成初始化和关闭 | M0 完成 | stdio JSON-RPC runtime 可独立测试。 |
| M2 | 核心 typed API | 用 facade 支撑最小 thread/turn 工作流 | M1 完成 | 核心 facade 可通过 M1 request 能力验证。 |
| M3 | 事件与 server request | 接收 notification/server request 并暴露三类流 | M2 完成 | event/delta/server request 分类和背压可验证。 |
| M4 | 扩展协议覆盖 | 补基础扩展 facade 和额外 transport | M3 完成 | MCP/Config/Commands/Filesystem 基础能力可验证。 |
| M5 | 契约测试 | 用真实 app-server 验证运行行为 | M4 完成 | contract 测试可显式运行并记录结果。 |
| M6 | 发布文档 | 冻结 API 和兼容声明 | M5 完成 | README/API/Testing/Compatibility/Changelog 完成。 |

## 4. M0 协议基线阶段

### 4.1 计划目标

建立 `codexapp-go` 的协议事实基线，使后续所有 runtime、facade、事件和契约测试都以同一份 schema 与 method 清单为依据。

### 4.2 阶段内容

- 确认目标 `codex` 二进制版本。
- 生成 app-server TypeScript schema 和 JSON Schema。
- 固化 schema snapshot 与 schema hash。
- 产出 method 覆盖清单。
- 记录文档存在但 schema 未暴露的 method。
- 记录 schema 暴露但人工文档未展开的 method。
- 明确 generated `protocol` 包的初始布局。

### 4.3 范围边界

M0 只处理协议事实和 generated protocol。

不包含：

- Client runtime。
- transport 实现。
- facade。
- event stream。
- server request reply。
- contract test harness。

### 4.4 责任归属

| 责任方 | 责任 |
| --- | --- |
| codexapp-go | 生成并提交 schema snapshot、hash、method 常量、基础 generated 类型。 |
| CodexRuntime Adapter | 不参与 M0 实现，只作为未来调用方校验 method 覆盖是否够用。 |
| Codex app-server | 提供 schema 生成命令和真实协议事实。 |

### 4.5 前置依赖

- 当前 `codexapp-go` 产品说明、技术架构、开发执行规格已经确认。
- 本机可执行 `codex --version`。
- 可执行 app-server schema 生成命令。

### 4.6 交付物

- `protocol/schema/ts/`
- `protocol/schema/json/`
- `protocol/schema/schema.hash`
- `protocol/methods_gen.go`
- `protocol/types_gen.go`
- `protocol/decode_gen.go`
- method 覆盖清单。
- schema/manual 差异清单。

### 4.7 验收方式

- `go generate ./protocol` 可重复运行。
- generated 代码可编译。
- schema hash 可复算。
- method 覆盖清单能解释所有 client request、client notification、server notification、server request。
- 差异清单能说明文档与 schema 不一致项。

## 5. M1 最小 Runtime 阶段

### 5.1 计划目标

建立最小可用 JSON-RPC client runtime，使 `codexapp-go` 能通过 stdio transport 完成初始化、client request、client notification、响应匹配、关闭和取消。

### 5.2 阶段内容

- stdio JSONL transport。
- JSON-RPC envelope encode/decode。
- request id 分配。
- pending request map。
- response id 匹配。
- JSON-RPC error 解码。
- `Initialize(ctx, params)`。
- `Initialized(ctx)`。
- `Request(ctx, method, params, resultPtr)`。
- `Notify(ctx, method, params)`。
- `Close()`。
- request context timeout/cancel 清理。

### 5.3 范围边界

M1 只开放 M1 public API。

不包含：

- `Events()`。
- `Deltas()`。
- `ServerRequests()`。
- `Respond()`。
- `PendingRequest`。
- typed facade。
- WebSocket/Unix socket transport。
- contract test harness。

### 5.4 责任归属

| 责任方 | 责任 |
| --- | --- |
| codexapp-go | 实现 runtime、stdio transport、request/response/notification 发送、初始化、关闭。 |
| CodexRuntime Adapter | 可用 M1 API 做最小连接验证，但不能依赖事件或 server request。 |
| AgentHost | 不直接依赖 M1；通过 Adapter 间接验证。 |

### 5.5 前置依赖

- M0 schema、method 常量、generated 类型已完成。
- M0 差异清单已确认不会阻断 M1。

### 5.6 交付物

- M1 public runtime API。
- stdio transport。
- JSON-RPC envelope 和 error 类型。
- pending request registry。
- initialize/initialized 调用能力。
- M1 单元测试。

### 5.7 验收方式

- JSON-RPC request encode/decode 测试通过。
- client notification encode 测试通过。
- 并发 request response 匹配测试通过。
- JSON-RPC error 保留 code/message/data。
- context timeout 后 pending 被清理。
- `Close()` 能唤醒 reader、writer 和 pending request。
- M1 不暴露 M3 API。

## 6. M2 核心 Typed API 阶段

### 6.1 计划目标

在 M1 low-level request 能力之上提供核心 typed facade，使 CodexRuntime Adapter 能以稳定 Go API 调用 thread、turn、review、model、account 相关能力。

### 6.2 阶段内容

- `Threads()` facade。
- `Turns()` facade。
- `Review()` facade。
- `Models()` facade。
- `Account()` facade。
- 每个 facade 方法只映射 app-server method。
- params/result 使用 generated protocol 类型。
- 保留 low-level escape hatch。

### 6.3 范围边界

M2 只做 outbound typed request facade。

不包含：

- event stream。
- delta stream。
- server request。
- `Respond()`。
- MCP/Config/Commands/Filesystem facade。
- Skills/Apps/Plugins/WindowsSandbox/Feedback facade。

### 6.4 责任归属

| 责任方 | 责任 |
| --- | --- |
| codexapp-go | 提供 M2 facade，保证每个 facade 是薄封装。 |
| CodexRuntime Adapter | 使用 M2 facade 验证最小 thread/turn 映射。 |
| AgentHost | 不绕过 Adapter 直接调用 SDK。 |

### 6.5 前置依赖

- M1 runtime 完成。
- M1 `Request` 可用且可测。
- generated params/result 覆盖 M2 method。

### 6.6 交付物

- `Threads()`、`Turns()`、`Review()`、`Models()`、`Account()` accessor。
- M2 facade 方法。
- M2 facade 单元测试。
- M2 API reference 草案。

### 6.7 验收方式

- 每个 M2 facade 至少有一个 request 构造/调用测试。
- facade 不新增业务状态。
- facade 不吞错误。
- facade 不自动重试非幂等请求。
- low-level request 仍可覆盖未手写 method。
- M2 不依赖 M3 event/server request 类型。

## 7. M3 事件与 Server Request 阶段

### 7.1 计划目标

补齐 app-server 到 SDK 的 inbound 通道，使 SDK 能接收 notification、delta 和 server request，并以三类流暴露给 CodexRuntime Adapter。

### 7.2 阶段内容

- reader loop 到 dispatcher 的 inbound 分发。
- notification decode registry 使用。
- `Events()`。
- `Deltas()`。
- `ServerRequests()`。
- `Event` 类型。
- `Delta` 类型。
- `PendingRequest` 类型。
- `Respond(ctx, id, result, rpcErr)`。
- `PendingRequest.Respond(ctx, result, rpcErr)`。
- server request 一次性回复保护。
- unknown notification 保底分发。
- decode error 保留 raw message。
- event/delta/server request buffer 和背压策略。

### 7.3 范围边界

M3 只处理 inbound stream 和 server request reply。

不包含：

- 新增大 facade 分组。
- WebSocket/Unix socket transport。
- MCP/Config/Commands/Filesystem facade。
- contract test harness。
- UI 事件聚合。
- SSE 转换。
- 审批策略。

### 7.4 责任归属

| 责任方 | 责任 |
| --- | --- |
| codexapp-go | 解码、分类、分发 notification/server request，并提供一次性回复机制。 |
| CodexRuntime Adapter | 把 SDK event/server request 映射为 AgentRuntime 事件和 pending request。 |
| AgentHost | 决定审批、用户输入、权限、token refresh 等业务动作。 |
| Electron | 只通过 AgentHost 间接参与用户交互。 |

### 7.5 前置依赖

- M2 完成。
- M1 reader/dispatcher 基础可复用。
- generated notification/server request decoder 可用。

### 7.6 交付物

- `Events()`、`Deltas()`、`ServerRequests()`。
- `Event`、`Delta`、`PendingRequest`。
- `Respond()`。
- event/delta/server request 分类表实现。
- 背压 hook 或错误。
- M3 单元测试。

### 7.7 验收方式

- 普通 notification 进入 `Events()`。
- delta notification 进入 `Deltas()`。
- server request 进入 `ServerRequests()`。
- unknown notification 不退出 reader loop。
- decode error 保留 raw message。
- `PendingRequest.Respond` 只能成功一次。
- client close 后未回复 server request 进入 closed 状态。
- buffer 满时不静默丢弃事件。
- M3 不新增 M4 facade。

## 8. M4 扩展协议覆盖阶段

### 8.1 计划目标

在 M3 inbound 能力稳定后，补齐 CodexRuntime Adapter 高频使用的扩展能力 facade 和额外 transport，使 SDK 覆盖更完整的本地 runtime 操作面。

### 8.2 阶段内容

- `MCP()` 基础 facade。
- `Config()` 基础 facade。
- `Commands()` 基础 facade。
- `Filesystem()` 基础 facade。
- WebSocket transport。
- Unix socket WebSocket transport。
- 保证 Skills/Apps/Plugins/WindowsSandbox/Feedback generated low-level 可用。

### 8.3 范围边界

M4 不追求所有 method 手写 facade。

不包含：

- Skills facade。
- Apps facade。
- Plugins facade。
- WindowsSandbox facade。
- Feedback facade。
- 自动重连。
- app-server 进程管理。
- record/replay 工具。

### 8.4 责任归属

| 责任方 | 责任 |
| --- | --- |
| codexapp-go | 提供 M4 基础 facade 和额外 transport。 |
| CodexRuntime Adapter | 使用 M4 facade 验证 MCP/config/command/filesystem 运行映射。 |
| AgentHost | 决定哪些扩展能力暴露给产品功能。 |

### 8.5 前置依赖

- M3 完成。
- event/delta/server request 流不阻塞关键请求。
- low-level coverage 能覆盖所有 schema method。

### 8.6 交付物

- `MCP()`、`Config()`、`Commands()`、`Filesystem()` facade。
- WebSocket transport。
- Unix socket WebSocket transport。
- M4 facade 单元测试。
- low-level coverage 检查。

### 8.7 验收方式

- M4 facade 使用 generated params/result。
- M4 facade 不改变 app-server 语义。
- command/filesystem 高风险能力不绕过 app-server sandbox/approval。
- WebSocket transport 能关闭并唤醒阻塞读写。
- Unix socket WebSocket transport 不删除 socket 文件。
- Skills/Apps/Plugins/WindowsSandbox/Feedback 可通过 low-level 调用。

## 9. M5 契约测试阶段

### 9.1 计划目标

用真实 app-server 验证 M1-M4 的运行行为，证明 generated 类型和 runtime 实现不仅能编译，而且能与目标 app-server 交互。

### 9.2 阶段内容

- contract test harness。
- 显式 contract test 开关。
- 真实 app-server 初始化测试。
- thread/start contract test。
- turn/start notification contract test。
- server request contract 或真实协议 fixture。
- contract test 结果记录。
- skipped case 原因记录。

### 9.3 范围边界

M5 只验证运行行为。

不包含：

- 新增稳定 runtime API。
- 新增 facade。
- 修补未完成的 M1-M4 功能作为 M5 交付内容。
- 发布文档冻结。

### 9.4 责任归属

| 责任方 | 责任 |
| --- | --- |
| codexapp-go | 提供 contract tests 和结果记录格式。 |
| Codex app-server | 作为真实协议基线。 |
| CodexRuntime Adapter | 可参与端到端 smoke，但不作为 SDK contract test 的必需依赖。 |

### 9.5 前置依赖

- M4 完成。
- M1-M4 单元测试通过。
- 目标 app-server 版本和 schema hash 已记录。

### 9.6 交付物

- contract test harness。
- `go test -tags contract ./...` 支持。
- `CODEXAPP_GO_CONTRACT=1 go test ./...` 支持。
- contract test result 文档或输出。
- skipped case 清单。

### 9.7 验收方式

- contract test 默认不污染普通 `go test ./...`。
- 显式开启后能记录 app-server version、schema hash、transport、覆盖 method。
- initialize contract case 可运行。
- thread/start contract case 可运行。
- turn/start event contract case 可运行。
- server request case 可运行或有明确 skipped reason。
- contract failure 能区分 SDK bug、app-server 行为变化、环境缺失。

## 10. M6 发布文档阶段

### 10.1 计划目标

完成首个稳定 SDK 发布文档，冻结经过 M0-M5 验证的 public API，并明确 SDK 与目标 app-server 的兼容边界。

### 10.2 阶段内容

- README。
- API reference。
- Testing 文档。
- Compatibility 文档。
- Changelog。
- public API freeze 说明。
- unstable API 标记。
- known schema/manual differences。

### 10.3 范围边界

M6 是文档和发布收口阶段。

不包含：

- 新增运行时能力。
- 新增 facade。
- 重新设计 public API。
- 重新定义 M0-M5 阶段边界。

### 10.4 责任归属

| 责任方 | 责任 |
| --- | --- |
| codexapp-go | 发布 README、API、Testing、Compatibility、Changelog。 |
| CodexRuntime Adapter | 校验文档示例能支撑 Adapter 调用。 |
| AgentHost | 消费 compatibility 和 API reference，不直接约束 SDK 内部实现。 |

### 10.5 前置依赖

- M5 contract test 完成。
- schema hash、target app-server version、contract test result 已记录。
- M0-M5 已知限制已整理。

### 10.6 交付物

- README。
- API reference。
- Testing。
- Compatibility。
- Changelog。
- public API freeze 声明。

### 10.7 验收方式

- README 包含最小连接、initialize、thread/turn 示例。
- API reference 覆盖 `Client`、transport、M2/M4 facade、event/delta/server request、错误类型。
- Testing 文档说明单元测试和 contract test 开关。
- Compatibility 文档声明 SDK version、target app-server version、schema hash。
- Changelog 记录 schema changes 和 contract test result。
- 没有 schema hash、target app-server version 或 contract test result 时不得发布。

## 11. 后续阶段计划拆分规则

后续拆每个阶段详细计划时，必须遵守本文边界。

每个阶段详细计划必须包含：

- 阶段目标。
- 不做什么。
- 前置依赖。
- 开发项。
- 测试项。
- 文档项。
- 验收命令或验收证据。
- 不允许依赖的未来能力。

详细计划不得：

- 把后续阶段能力提前放进当前阶段验收。
- 把当前阶段未完成能力推给后续阶段兜底。
- 通过假实现满足 public API。
- 把 AgentHost/Electron 业务状态放入 SDK。

## 12. 总结

本次迭代采用严格串行阶段：

```text
M0 Protocol Baseline
  -> M1 Minimal Runtime
  -> M2 Core Typed API
  -> M3 Events and Server Requests
  -> M4 Extended Protocol Coverage
  -> M5 Contract Tests
  -> M6 Release Documentation
```

该顺序保证协议事实先于 runtime，runtime 先于 facade，outbound API 先于 inbound stream，基础能力先于扩展能力，单元验证先于真实 app-server 契约验证，最后再冻结 public API 和发布文档。
