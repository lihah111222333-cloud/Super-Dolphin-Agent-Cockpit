# M0 协议基线阶段总目标

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | M0 |
| 阶段名称 | 协议基线 |
| 所属迭代 | `20-delivery/iterations/01-codexapp-go-m0-m6` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | 固定 Codex app-server JSON-RPC 协议事实，作为后续所有阶段的唯一协议依据。 |

## 1. 计划目标

建立 `codexapp-go` 的协议事实基线，使后续 runtime、typed facade、事件流、server request 和契约测试都基于同一份 schema、method 清单和差异记录推进。

M0 完成后，项目必须能够明确回答：

- 当前 SDK 面向哪个目标 `codex` / app-server 版本。
- app-server 暴露了哪些 client request、client notification、server notification、server request。
- generated protocol 包覆盖了哪些类型、method 常量和 decode 能力。
- schema 与人工接口文档之间是否存在差异，以及这些差异是否阻断后续阶段。

## 2. 阶段内容

- 确认目标 `codex` 二进制版本。
- 生成 app-server TypeScript schema。
- 生成 app-server JSON Schema。
- 固化 schema snapshot。
- 固化 schema hash。
- 产出 method 覆盖清单。
- 记录文档存在但 schema 未暴露的 method。
- 记录 schema 暴露但人工文档未展开的 method。
- 明确 generated `protocol` 包的初始布局。

## 3. 范围边界

M0 只处理协议事实和 generated protocol。

M0 不包含：

- Client runtime。
- stdio transport。
- WebSocket transport。
- Unix socket WebSocket transport。
- typed facade。
- event stream。
- delta stream。
- server request reply。
- contract test harness。
- app-server 进程管理。
- AgentHost 业务编排。

## 4. 责任归属

| 责任方 | 责任 |
| --- | --- |
| codexapp-go | 生成并提交 schema snapshot、schema hash、method 常量、基础 generated 类型和 decode registry。 |
| CodexRuntime Adapter | 不参与 M0 实现，只作为未来调用方校验 method 覆盖是否满足后续阶段。 |
| Codex app-server | 提供 schema 生成命令和真实协议事实。 |
| AgentHost | 不直接参与 M0；不得要求 M0 提前提供 runtime 或业务封装。 |

## 5. 前置依赖

- `codexapp-go` 产品说明书已确认。
- `codexapp-go` 技术架构说明书已确认。
- `codexapp-go` 开发执行规格已确认。
- 本机可执行 `codex --version`。
- 可执行 app-server schema 生成命令。

## 6. 交付物

- `protocol/schema/ts/`
- `protocol/schema/json/`
- `protocol/schema/schema.hash`
- `protocol/methods_gen.go`
- `protocol/types_gen.go`
- `protocol/decode_gen.go`
- method 覆盖清单。
- schema/manual 差异清单。

## 7. 验收方式

- `go generate ./protocol` 可重复运行。
- generated 代码可编译。
- schema hash 可复算。
- method 覆盖清单能解释所有 client request、client notification、server notification、server request。
- schema/manual 差异清单能说明文档与 schema 不一致项。
- M0 不暴露 runtime、facade、event 或 server request public API。

## 8. 进入 M1 门禁

只有在 M0 协议事实、schema hash、method 覆盖和差异清单完成后，才能进入 M1。

M1 只能依赖 M0 已交付的 generated protocol 和 method 事实，不得反向要求 M0 实现 transport 或 runtime。
