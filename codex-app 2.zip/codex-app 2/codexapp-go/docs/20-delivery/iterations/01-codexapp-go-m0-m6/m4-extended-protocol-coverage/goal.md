# M4 扩展协议覆盖阶段总目标

| 项目 | 内容 |
| --- | --- |
| 阶段序号 | M4 |
| 阶段名称 | 扩展协议覆盖 |
| 所属迭代 | `20-delivery/iterations/01-codexapp-go-m0-m6` |
| 上游总规划 | `../master-plan.md` |
| 阶段定位 | 补齐高频扩展 facade 和额外 transport，但不追求所有 method 手写封装。 |

## 1. 计划目标

在 M3 inbound 能力稳定后，补齐 CodexRuntime Adapter 高频使用的扩展能力 facade 和额外 transport，使 SDK 覆盖更完整的本地 runtime 操作面。

M4 的重点是补齐基础扩展面，不是把所有 app-server method 都做成手写 facade。

## 2. 阶段内容

- `MCP()` 基础 facade。
- `Config()` 基础 facade。
- `Commands()` 基础 facade。
- `Filesystem()` 基础 facade。
- WebSocket transport。
- Unix socket WebSocket transport。
- 保证 Skills/Apps/Plugins/WindowsSandbox/Feedback generated low-level 可用。

## 3. 范围边界

M4 不追求所有 method 手写 facade。

M4 不包含：

- Skills facade。
- Apps facade。
- Plugins facade。
- WindowsSandbox facade。
- Feedback facade。
- 自动重连。
- app-server 进程管理。
- record/replay 工具。
- AgentHost 权限策略。
- Electron API。

## 4. 责任归属

| 责任方 | 责任 |
| --- | --- |
| codexapp-go | 提供 M4 基础 facade 和额外 transport。 |
| CodexRuntime Adapter | 使用 M4 facade 验证 MCP/config/command/filesystem 运行映射。 |
| AgentHost | 决定哪些扩展能力暴露给产品功能。 |
| Codex app-server | 保持对应 method 的真实语义和 sandbox/approval 行为。 |

## 5. 前置依赖

- M3 已完成。
- event/delta/server request 流不阻塞关键请求。
- low-level coverage 能覆盖所有 schema method。
- M2 facade 已证明 thin wrapper 模式可用。

## 6. 交付物

- `MCP()` facade。
- `Config()` facade。
- `Commands()` facade。
- `Filesystem()` facade。
- WebSocket transport。
- Unix socket WebSocket transport。
- M4 facade 单元测试。
- low-level coverage 检查。

## 7. 验收方式

- M4 facade 使用 generated params/result。
- M4 facade 不改变 app-server 语义。
- command/filesystem 高风险能力不绕过 app-server sandbox/approval。
- WebSocket transport 能关闭并唤醒阻塞读写。
- Unix socket WebSocket transport 不删除 socket 文件。
- Skills/Apps/Plugins/WindowsSandbox/Feedback 可通过 low-level 调用。
- M4 不新增稳定 API 之外的 speculative facade。

## 8. 进入 M5 门禁

只有在 M4 扩展 facade、额外 transport 和 low-level coverage 均可验证后，才能进入 M5。

M5 只验证 M1-M4 已完成行为，不得把未完成的 M4 facade 或 transport 当作契约测试阶段的开发内容。
