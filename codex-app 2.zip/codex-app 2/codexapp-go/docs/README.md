# codexapp-go docs 入口

本目录按“入口 -> 基础事实 -> 交付推进 -> 发布材料 -> 归档”的生命周期组织。开发人员先读 `00-start/`，再按自己的任务进入对应目录。

## 先看这里

| 问题 | 文档 |
| --- | --- |
| AI 从 0 进入项目先读什么？ | `00-start/ai-project-context.md` |
| 当前项目做到哪一步？ | `00-start/current-status.md` |
| 新开发者应该按什么顺序读？ | `00-start/reading-guide.md` |
| 文档应该放在哪里？ | `00-start/doc-governance.md` |
| 本地和飞书云盘如何对应？ | `00-start/feishu-drive-mapping.md` |

## 推荐阅读顺序

```text
1. 00-start/ai-project-context.md
2. 00-start/current-status.md
3. 00-start/reading-guide.md
4. 10-foundation/product/codexapp-product-spec.md
5. 10-foundation/product/codexapp-go-product-spec.md
6. 10-foundation/architecture/technical-architecture.md
7. 20-delivery/execution/execution-spec.md
8. 20-delivery/iterations/01-codexapp-go-m0-m6/master-plan.md
9. 10-foundation/protocol/app-server/json-rpc-manual.md
```

## 按诉求定位

| 我要做什么 | 看哪里 |
| --- | --- |
| AI 从 0 加载项目上下文 | `00-start/ai-project-context.md` |
| 判断当前阶段和下一步门禁 | `00-start/current-status.md` |
| 快速接手项目 | `00-start/reading-guide.md` |
| 确认桌面应用整体边界 | `10-foundation/product/codexapp-product-spec.md` |
| 确认 SDK 产品范围和非目标 | `10-foundation/product/codexapp-go-product-spec.md` |
| 理解 SDK 架构和包边界 | `10-foundation/architecture/technical-architecture.md` |
| 查 Codex app-server JSON-RPC | `10-foundation/protocol/app-server/json-rpc-manual.md` |
| 开始 M0-M6 阶段开发 | `20-delivery/iterations/01-codexapp-go-m0-m6/master-plan.md` |
| 查某个阶段的目标和验收 | `20-delivery/iterations/01-codexapp-go-m0-m6/<阶段>/goal.md` |
| 查开发执行和测试约束 | `20-delivery/execution/execution-spec.md` |
| 查团队开发规范 | `20-delivery/execution/team-development-standards.md` |
| 查发布 API、兼容和变更 | `30-release/` |
| 查历史材料 | `99-archive/` |

## 一级目录

| 目录 | 放置内容 |
| --- | --- |
| `00-start/` | 当前状态、阅读路径、文档治理、飞书映射。 |
| `10-foundation/` | 长期有效的产品、架构、协议事实。 |
| `20-delivery/` | 开发执行规格、迭代计划、阶段目标、验收材料。 |
| `30-release/` | API reference、compatibility、changelog、release note。 |
| `99-archive/` | 已过期但需要追溯的历史文档。 |

## 责任边界速记

| 层级 | 责任 |
| --- | --- |
| Electron | 桌面 UI 和用户交互，只调用 AgentHost。 |
| AgentHost | 本地宿主层，对上提供 HTTP REST/SSE，内部通过 AgentRuntime 控制 runtime。 |
| AgentRuntime | AgentHost 内部 runtime 抽象，定义 thread、turn、事件和 pending request 的统一模型。 |
| CodexRuntime Adapter | AgentRuntime 的 Codex 实现，对下引用 `codexapp-go`。 |
| codexapp-go | 纯 Go SDK，只封装 Codex app-server JSON-RPC。 |
| Codex app-server | Agent runtime，负责 thread、turn、事件流、工具调用和审批等能力。 |
