# AgentHost 阶段计划

## 1. 推进原则

- 严格按 P0 -> P1 -> P2 -> P3 -> P4 顺序推进。
- Host API 只能通过 AgentRuntime 触达 runtime。
- AgentRuntime 不依赖 `codexapp-go` 或 Codex protocol 类型。
- CodexRuntimeAdapter 是首版唯一 Adapter，可以依赖 `codexapp-go`。
- 本地服务保持 Go 单体 + SQLite。

## 2. 阶段计划

| 阶段 | 目标 | 最小交付物 | 验收 |
| --- | --- | --- | --- |
| P0 | 建立本地服务、安全和远程代理基础。 | Gin、config、slog、SQLite、session、remote client、cache。 | 鉴权、token refresh、cache hit/stale/miss 可测。 |
| P1 | 建立 runtime 最小闭环。 | AgentRuntime、CodexRuntimeAdapter、runtime endpoint、SSE、pending request。 | Host API 通过 Runtime 启动 Codex turn，SSE 收到事件。 |
| P2 | 完成动态数据代理和任务体验投影。 | 模型、技能、连接器、资料库、自动化模板、灵感代理，任务事件和产物投影。 | Electron 不持远程 token，可读取动态数据和恢复任务事件。 |
| P3 | 完成同步队列和复杂远程代理。 | 同步队列、worker、反馈、日志、分享、项目、助理、计费代理。 | 远程离线可保留任务，网络恢复可重试成功。 |
| P4 | 发布前稳定化。 | API 文档、错误码、兼容说明、回归测试。 | 文档与实现一致，关键链路回归通过。 |

## 3. 关键依赖

| AgentHost 阶段 | 外部依赖 |
| --- | --- |
| P0 | AgentCloud P0 API 用于远程登录、设备、模型、套餐联调。 |
| P1 | `codexapp-go` 至少具备 M1 runtime；完整事件和 pending request 闭环依赖 M3。 |
| P2 | AgentCloud P1/P2 部分动态目录和资料库能力。 |
| P3 | AgentCloud P2/P3 协作、分享、助理、计费、反馈能力。 |

## 4. 事实源

- `agent-host/docs/20-delivery/iterations/01-agent-host-core/master-plan.md`
- `agent-host/docs/20-delivery/iterations/01-agent-host-core/feature-plan.md`
- `agent-host/docs/10-foundation/architecture/agent-host-technical-architecture.md`
