# AgentCloud P0-P3 实施计划

## 1. 推进原则

- 严格按 P0 -> P1 -> P2 -> P3 顺序推进。
- 当前阶段只能依赖已完成阶段的 API、表结构、配置和测试能力。
- 未进入当前阶段的接口不得用假实现占位。
- 数据库按阶段执行 goose migration。

## 2. 阶段计划

| 阶段 | 目标 | 最小交付物 | 验收 |
| --- | --- | --- | --- |
| P0 | 基础身份、设备、模型、套餐能力可用。 | Go HTTP 服务、P0 migration、登录/刷新/设备/模型/套餐 API。 | 设备端可登录、刷新、注册设备、心跳、拉取账号/模型/套餐。 |
| P1 | 运营配置、市场目录、连接器和 Webhook 基础设施可用。 | 专家、技能、灵感、连接器目录，Webhook 验签去重。 | 目录分页、版本缓存、授权状态、重复事件不重复处理。 |
| P2 | 项目协作、资料库、资产、分享和审计闭环。 | 项目成员、任务摘要、资产、分享、云资料库、审计 API。 | 权限隔离、资产分享、provider 错误映射、审计可查。 |
| P3 | 助理网关、自动化、计费、反馈和云记忆完善。 | 助理回调、自动化、支付记账、反馈附件、云记忆 API。 | 支付幂等、助理消息去重、自动化不重复触发、记忆权限隔离。 |

## 3. 阶段门禁

| 阶段 | 进入条件 | 退出条件 |
| --- | --- | --- |
| P0 | 技术栈、数据库设计、执行规格确认。 | P0 API、migration、seed、测试和验收清单通过。 |
| P1 | P0 通过。 | P1 目录、连接器、Webhook 测试通过。 |
| P2 | P1 通过。 | P2 权限、资产、分享、审计测试通过。 |
| P3 | P2 通过。 | P3 助理、计费、自动化、反馈、云记忆验收通过。 |

## 4. 事实源

- `agent-cloud/docs/20-delivery/iterations/01-agent-cloud-api-service/master-plan.md`
- `agent-cloud/docs/20-delivery/iterations/01-agent-cloud-api-service/feature-plan.md`
- `agent-cloud/docs/10-foundation/architecture/database-design.md`
