# codexapp-go M0-M6 实施计划

## 1. 推进原则

- 严格按 M0 -> M1 -> M2 -> M3 -> M4 -> M5 -> M6 顺序推进。
- 前置阶段不得提前暴露后续 public API。
- 不写空实现、假实现或 `ErrNotImplemented` public API。
- generated protocol 覆盖可以先完整，public facade 按阶段开放。

## 2. 阶段计划

| 阶段 | 目标 | 最小交付物 | 验收 |
| --- | --- | --- | --- |
| M0 | 固定目标 app-server 协议事实。 | schema、hash、method 清单、generated protocol。 | schema hash 可复算，method 覆盖清单可解释。 |
| M1 | 最小 JSON-RPC runtime。 | stdio transport、request/notify、initialize、close、pending map。 | 并发响应匹配、error、timeout、close 可测。 |
| M2 | 核心 typed API。 | Threads、Turns、Review、Models、Account facade。 | facade 只薄封装 method，不新增业务状态。 |
| M3 | 事件与 server request。 | Events、Deltas、ServerRequests、Respond、PendingRequest。 | notification、delta、server request 分类和一次性回复可测。 |
| M4 | 扩展协议和 transport。 | MCP、Config、Commands、Filesystem facade，WebSocket、Unix socket WebSocket。 | 扩展 facade 使用 generated 类型，transport 可关闭。 |
| M5 | 真实 app-server 契约测试。 | contract test harness、显式开关、结果记录。 | contract 测试区分 SDK bug、app-server 变化、环境缺失。 |
| M6 | 发布文档和 API freeze。 | README、API reference、Testing、Compatibility、Changelog。 | 声明 SDK version、target app-server version、schema hash 和 contract 结果。 |

## 3. 与 AgentHost 的关系

| SDK 阶段 | 对 AgentHost 的意义 |
| --- | --- |
| M1 | Adapter 可做最小连接和 request 验证。 |
| M2 | Adapter 可调用 thread/turn/model/account 核心能力。 |
| M3 | AgentHost 可获得事件、delta 和 pending request 控制点。 |
| M4 | Adapter 可覆盖 MCP、config、command、filesystem 等扩展能力。 |
| M5-M6 | 发布前验证和 API 稳定性保障。 |

## 4. 事实源

- `codexapp-go/docs/20-delivery/iterations/01-codexapp-go-m0-m6/master-plan.md`
- `codexapp-go/docs/20-delivery/execution/execution-spec.md`
- `codexapp-go/docs/10-foundation/protocol/app-server/json-rpc-manual.md`
