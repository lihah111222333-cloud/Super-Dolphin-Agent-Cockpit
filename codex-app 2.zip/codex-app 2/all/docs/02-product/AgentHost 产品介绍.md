# AgentHost 产品介绍

## 1. 产品定位

AgentHost 是桌面 Agent 应用唯一的本地宿主服务。它对 Electron 提供本地 HTTP REST/SSE，内部承载 Host API、AgentRuntime 和 AgentRuntimeAdapter 三个需求域。

统一依赖方向：

| 顺序 | 层级 |
| --- | --- |
| 1 | Electron |
| 2 | AgentHost Host API |
| 3 | AgentRuntime |
| 4 | CodexRuntimeAdapter |
| 5 | `codexapp-go` |
| 6 | Codex app-server |

## 2. 核心价值

| 价值 | 说明 |
| --- | --- |
| Electron 唯一本地后端 | 前端只调用本地 API，不直连云端和 SDK。 |
| 本地执行安全边界 | 控制文件、shell、权限确认、产物和预览。 |
| Runtime 抽象 | 用 AgentRuntime 屏蔽具体 agent 后端协议。 |
| 远程代理与缓存 | 代理 AgentCloud API，保存 token，提供本地缓存和降级。 |
| 事件投影 | 将 runtime 事件转换为 Electron 可消费的 SSE 和状态。 |

## 3. 内部需求域

| 需求域 | 责任 | 不做 |
| --- | --- | --- |
| Host API | REST/SSE、鉴权、状态投影、远程代理、本地存储。 | 不直接调 `codexapp-go`。 |
| AgentRuntime | thread、turn、event、pending request、capability、error 抽象。 | 不依赖 Codex protocol 类型。 |
| AgentRuntimeAdapter | 将具体后端映射到 AgentRuntime。首版为 CodexRuntimeAdapter。 | 不定义产品 API，不做动态插件系统。 |

## 4. 能力范围

| 阶段 | 能力 |
| --- | --- |
| P0 | Host API 基础、Gin、config、slog、SQLite、session、remote client、cache。 |
| P1 | AgentRuntime 最小接口、CodexRuntimeAdapter、thread/turn、事件订阅、pending request、SSE bridge。 |
| P2 | 动态数据代理、任务事件投影、产物投影、本地对象管理。 |
| P3 | 同步队列、反馈、日志、分享、项目协作、助理网关、账号计费代理。 |
| P4 | API 文档、错误码、兼容性、回归测试、发布稳定化。 |

## 5. 明确非目标

- 不做云端多租户控制面。
- 不直接暴露远程 refresh token 给 Electron。
- 不让 Electron 直接访问本地文件和 shell。
- 不引入 Redis、Kafka、PostgreSQL 或微服务拆分。
- 不把 Codex app-server 协议类型暴露到 AgentRuntime。

## 6. 产品评审关注点

- Electron 是否始终只调用 AgentHost。
- Host API 是否只通过 AgentRuntime 触达 runtime。
- AgentHost P1 是否依赖 `codexapp-go` 的真实协议能力，而不是假实现。
- P0-P4 是否有清晰可验证产物。
