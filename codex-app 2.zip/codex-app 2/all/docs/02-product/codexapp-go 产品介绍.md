# codexapp-go 产品介绍

## 1. 产品定位

`codexapp-go` 是 Codex app-server JSON-RPC 协议的纯 Go client SDK。它只服务 AgentHost 内的 CodexRuntimeAdapter，不直接面向 Electron，也不提供 REST/SSE。

## 2. 核心价值

| 价值 | 说明 |
| --- | --- |
| 类型安全 | 用 generated protocol 类型覆盖请求、响应、通知和 server request。 |
| 协议封装 | 管理 JSON-RPC request id、响应匹配、错误、通知分发。 |
| 事件订阅 | 向 Adapter 暴露 typed event、delta、server request。 |
| 契约测试 | 用真实 app-server 验证 SDK 与目标协议版本一致。 |
| 边界隔离 | 避免 AgentHost 散落手写 method 字符串和底层 JSON-RPC 细节。 |

## 3. 目标用户

| 用户 | 使用方式 |
| --- | --- |
| CodexRuntimeAdapter 开发者 | 调用 SDK facade 或 low-level request，将结果映射为 AgentRuntime。 |
| AgentHost 开发者 | 通过 AgentRuntime 间接消费 Codex 能力，不直接使用 SDK。 |
| SDK 维护者 | 跟随 Codex app-server schema 变化更新类型、method、契约测试。 |

## 4. 能力范围

| 阶段 | 能力 |
| --- | --- |
| M0 | 协议基线、schema、hash、method 清单、generated protocol。 |
| M1 | 最小 JSON-RPC runtime、stdio transport、initialize、request、notify、close。 |
| M2 | Threads、Turns、Review、Models、Account 核心 typed facade。 |
| M3 | Events、Deltas、ServerRequests、Respond、PendingRequest。 |
| M4 | MCP、Config、Commands、Filesystem 基础 facade，WebSocket 和 Unix socket transport。 |
| M5 | 真实 app-server contract test harness。 |
| M6 | README、API reference、Testing、Compatibility、Changelog、API freeze。 |

## 5. 明确非目标

- 不实现 Electron UI。
- 不提供 HTTP REST API 或 SSE。
- 不做 AgentHost 任务编排、状态投影或审批策略。
- 不启动、安装、升级或守护 Codex app-server。
- 不定义 AgentHost 产品模型。

## 6. 产品评审关注点

- M0 是否以真实 app-server schema 为准。
- M1-M4 是否按阶段逐步开放 public API。
- M3 server request 是否只提供机制，不替 AgentHost 做决策。
- M5 契约测试是否能区分 SDK bug、app-server 行为变化和环境缺失。
