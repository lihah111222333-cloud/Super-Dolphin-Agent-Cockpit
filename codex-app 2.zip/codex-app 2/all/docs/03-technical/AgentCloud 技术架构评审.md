# AgentCloud 技术架构评审

## 1. 架构定位

AgentCloud 是云端远程 API 服务，通过 HTTPS API、Webhook 和后台 Worker 支撑账号、设备、运营配置、协作、第三方授权、计费和同步类能力。

## 2. 固定技术栈

| 类别 | 选型 |
| --- | --- |
| 服务端 | Go + Gin |
| 数据库 | PostgreSQL + GORM + goose |
| 缓存 | Redis + go-redis |
| Token | JWT access token + opaque refresh token |
| 密码哈希 | bcrypt |
| 配置 | `config.yaml` + 环境变量覆盖 secret |
| 日志 | Go `slog` 结构化日志 |

## 3. 逻辑分层

| 层 | 职责 |
| --- | --- |
| API Edge | 路由、请求 ID、响应 envelope、错误映射、分页、限流。 |
| Auth Context | access token 校验、refresh token 轮换、用户/组织/角色上下文。 |
| Device Context | `X-Device-Id` 校验、设备注册、心跳、解绑、在线状态。 |
| Domain Services | 账号、模型、市场、连接器、项目、资产、计费、反馈等业务服务。 |
| Provider Gateway | OAuth、云资料库、支付、助理平台 provider 适配。 |
| Queue / Worker | Webhook 异步处理、回调重试、消息派发、计费记账。 |
| Storage | PostgreSQL、Redis、对象存储、审计日志、凭证引用。 |

## 4. 数据和迁移边界

| 项 | 约束 |
| --- | --- |
| schema 管理 | 正式 schema 只通过 goose migration。 |
| ORM | GORM model 必须与 migration 保持一致，schema 以 migration 为准。 |
| 阶段迁移 | P0 到 `1`，P1 到 `10`，P2 到 `20`，P3 到 `30`。 |
| 数据库事实源 | `agent-cloud/docs/10-foundation/architecture/database-design.md`。 |

## 5. 安全边界

- refresh token 哈希存储，可撤销、可轮换、可按设备失效。
- 第三方 token 不明文返回调用方。
- Webhook 必须验签、去重、快速返回。
- 写接口、支付、记账、资产上传等必须支持幂等。
- 日志不得记录密码、refresh token、JWT 原文或第三方 token 明文。

## 6. 技术评审问题

| 问题 | 判断标准 |
| --- | --- |
| P0 是否能独立落地？ | 登录、刷新、设备注册、心跳、账号/模型/套餐可测。 |
| P1 是否依赖 P2/P3？ | 不应依赖项目协作、支付、助理完整链路。 |
| Webhook 是否可重放安全？ | event id 去重、签名校验、幂等处理。 |
| 云端是否越界本地执行？ | 不保存完整执行轨迹、不读本机文件。 |
