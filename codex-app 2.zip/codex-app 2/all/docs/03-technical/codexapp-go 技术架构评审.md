# codexapp-go 技术架构评审

## 1. 架构定位

`codexapp-go` 位于 CodexRuntimeAdapter 和 Codex app-server 之间，只负责把 Codex app-server JSON-RPC 协议稳定地变成 Go 可调用能力。

## 2. 模块划分

| 模块 | 职责 |
| --- | --- |
| Client Core | 生命周期、initialize、request、notify、respond、close。 |
| Transport | stdio、WebSocket、Unix socket WebSocket 的消息读写。 |
| Dispatcher | 区分 response、notification、server request。 |
| Pending Registry | request id 到响应通道的匹配和清理。 |
| Event Bus | notification、delta、unknown event 分发。 |
| ServerRequest Bus | server request 暴露、一次性回复保护。 |
| Protocol | generated 类型、method 常量、decode registry、schema snapshot。 |
| Facades | Threads、Turns、Models、Account、MCP、Config 等薄封装。 |
| Error Model | JSON-RPC error、transport error、decode error、protocol mismatch。 |

## 3. 分阶段 API 开放

| 阶段 | Public API |
| --- | --- |
| M0 | `protocol` generated 类型、method 常量、decode registry。 |
| M1 | `NewClient`、`Initialize`、`Initialized`、`Request`、`Notify`、`Close`、stdio transport。 |
| M2 | `Threads()`、`Turns()`、`Review()`、`Models()`、`Account()`。 |
| M3 | `Events()`、`Deltas()`、`ServerRequests()`、`Respond()`、`PendingRequest`、`Event`、`Delta`。 |
| M4 | `MCP()`、`Config()`、`Commands()`、`Filesystem()`、WebSocket、Unix socket WebSocket。 |
| M5 | contract test harness，不新增稳定 runtime API。 |
| M6 | 首个稳定 public API freeze。 |

## 4. 技术边界

- generated 类型以目标 app-server schema 为准。
- facade 只做 method 分组，不引入业务模型。
- SDK 不决定审批、用户输入、token refresh 策略。
- SDK 不启动、安装、升级或守护 app-server。
- raw message 应保留，便于诊断协议差异。

## 5. 技术评审问题

| 问题 | 判断标准 |
| --- | --- |
| M0 是否真实可信？ | schema、hash、method 清单可复算、可审查。 |
| M1 是否足够小？ | 只做 JSON-RPC runtime，不提前暴露 M3/M4 API。 |
| M3 是否能承接暂停/审批？ | 能暴露 server request 和一次性回复机制，但不做业务决策。 |
| M5 是否可重复？ | contract test 显式开启，记录 app-server version、schema hash、transport。 |
