# AgentHost 技术架构评审

## 1. 架构定位

AgentHost 是本地 Go 单体服务。Host API、AgentRuntime、AgentRuntimeAdapter 是同一项目内的需求域，不是三个独立项目。

## 2. 固定技术栈

| 类别 | 选型 |
| --- | --- |
| HTTP API | Gin |
| 事件流 | SSE |
| 本地存储 | SQLite |
| ORM | GORM |
| SQLite driver | `github.com/glebarez/sqlite` |
| 日志 | 标准库 `log/slog` |
| 配置 | `config.yaml` |
| 后台任务 | 进程内 goroutine + `context.Context` + SQLite 状态表 |

不引入 Redis、Kafka、PostgreSQL、独立队列系统或微服务拆分。

## 3. 内部域边界

| 域 | 技术职责 | 依赖约束 |
| --- | --- | --- |
| Host API | REST/SSE、鉴权、投影、远程代理、SQLite 状态。 | 只能通过 AgentRuntime 触达 runtime。 |
| AgentRuntime | thread、turn、event、pending request、capability、error 统一模型。 | 不依赖具体后端 SDK。 |
| CodexRuntimeAdapter | Codex app-server 适配。 | 可以依赖 `codexapp-go`。 |

## 4. 本地安全边界

- Electron 只调用 AgentHost 本地 API。
- 远程 token 只由 AgentHost 保存和使用。
- Electron 不直接读写任意本地文件。
- 高风险文件、shell、工具调用必须进入权限确认链路。
- 本地 API 即使只操作本地资源，也要校验本地 session。

## 5. 数据边界

| 数据 | 归属 |
| --- | --- |
| 本地 session、远程 token 引用、缓存 | SQLite |
| 任务、run、event、pending、产物投影 | SQLite |
| 同步队列 | SQLite 状态表 + 进程内 worker |
| 云端账号、组织、项目、计费事实 | AgentCloud |
| Codex 原始协议事件 | `codexapp-go` 解码，AgentRuntime 映射后再投影 |

## 6. 技术评审问题

| 问题 | 判断标准 |
| --- | --- |
| Host API 是否直连 SDK？ | 不允许，必须通过 AgentRuntime。 |
| AgentRuntime 是否引用 Codex 类型？ | 不允许，只暴露统一 runtime 模型。 |
| 本地队列是否过度设计？ | P3 只用 SQLite + 进程内 worker。 |
| SSE 是否有恢复策略？ | 事件应可从本地状态恢复查看。 |
